/***
*crtdefs.h - definitions/declarations common to all CRT
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       This file has mostly defines used by the entire CRT.
*
*       [Public]
*
****/

/* Define _CRTIMP */

#ifndef _CRTIMP
#ifdef  _DLL
#define _CRTIMP __declspec(dllimport)
#else   /* ndef _DLL */
#define _CRTIMP
#endif  /* _DLL */
#endif  /* _CRTIMP */

#ifndef _INC_CRTDEFS
#define _INC_CRTDEFS


#if     !defined(_WIN32)
#error ERROR: Only Win32 target supported!
#endif

#ifdef _DLL

#ifndef _CRT_NOFORCE_MANIFEST

#if _MSC_FULL_VER >= 140040130
#ifdef _M_IX86

#ifdef _DEBUG
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.VC80.DebugCRT' version='8.00.0.0' processorArchitecture='x86' publicKeyToken='1fc8b3b9a1e18e3b'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.VC80.CRT' version='8.00.0.0' processorArchitecture='x86' publicKeyToken='1fc8b3b9a1e18e3b'\"")
#endif

#endif	/* _M_IX86 */

#ifdef _M_AMD64

#ifdef _DEBUG
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.VC80.DebugCRT' version='8.00.0.0' processorArchitecture='amd64' publicKeyToken='1fc8b3b9a1e18e3b'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.VC80.CRT' version='8.00.0.0' processorArchitecture='amd64' publicKeyToken='1fc8b3b9a1e18e3b'\"")
#endif

#endif	/* _M_AMD64 */

#ifdef _M_IA64

#ifdef _DEBUG
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.VC80.DebugCRT' version='8.00.0.0' processorArchitecture='ia64' publicKeyToken='1fc8b3b9a1e18e3b'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.VC80.CRT' version='8.00.0.0' processorArchitecture='ia64' publicKeyToken='1fc8b3b9a1e18e3b'\"")
#endif

#endif	/* _M_IA64 */

#endif	/* _MSC_FULL_VER */

#endif	/* _CRT_NOFORCE_MANIFEST */

#endif	/* _DLL */

#ifdef  __cplusplus
extern "C" {
#endif

#if !defined(_W64)
#if !defined(__midl) && (defined(_X86_) || defined(_M_IX86)) && _MSC_VER >= 1300
#define _W64 __w64
#else
#define _W64
#endif
#endif

/* TEMP: Because object sizes change with iterator debugging, 
 * we force all SCL code to be inline here
 */
#ifdef _HAS_ITERATOR_DEBUGGING
#if !(_HAS_ITERATOR_DEBUGGING) && !defined(_STATIC_CPPLIB) && defined(_DEBUG)
#define _STATIC_CPPLIB
#endif
#endif

/* TEMP (alecont): To solve the alignment problems when _SECURE_SCL is on and 
 * we link with the DLL, we are forcing _STATIC_CPPLIB when _SECURE_SCL is on
 */
#ifdef _SECURE_SCL
#if _SECURE_SCL && !defined(_STATIC_CPPLIB)
#define _STATIC_CPPLIB
#endif
#endif

/*
TEMP: Because the m<>n thunks don't currently correctly call copy constructors
we force all SCL code to be inline here
*/
#if defined(_M_CEE) && !defined(_STATIC_CPPLIB)
#define _STATIC_CPPLIB
#endif



/* Define _CRTIMP2 */

#ifndef _CRTIMP2
#if defined(_DLL) && !defined(_STATIC_CPPLIB)
#define _CRTIMP2 __declspec(dllimport)
#else   /* ndef _DLL && !STATIC_CPPLIB */
#define _CRTIMP2
#endif  /* _DLL && !STATIC_CPPLIB */
#endif  /* _CRTIMP2 */

/* Define _MRTIMP */

#ifndef _MRTIMP
#define _MRTIMP __declspec(dllimport)
#endif  /* _MRTIMP */

#ifndef _MCRTIMP
#ifdef  _DLL
#define _MCRTIMP __declspec(dllimport)
#else   /* ndef _DLL */
#define _MCRTIMP
#endif  /* _DLL */
#endif  /* _CRTIMP */

#ifndef __CLR_OR_THIS_CALL
#if defined(MRTDLL) || defined(_M_CEE_PURE)
#define __CLR_OR_THIS_CALL  __clrcall
#else
#define __CLR_OR_THIS_CALL
#endif
#endif

#ifndef __CLRCALL_OR_CDECL
#if defined(MRTDLL) || defined(_M_CEE_PURE)
#define __CLRCALL_OR_CDECL __clrcall
#else
#define __CLRCALL_OR_CDECL __cdecl
#endif
#endif

#ifndef _CRTIMP_PURE
 #if defined(_M_CEE_PURE) || defined(_STATIC_CPPLIB)
  #define _CRTIMP_PURE
 #else
  #define _CRTIMP_PURE _CRTIMP
 #endif
#endif

#ifndef _PGLOBAL
#ifdef _M_CEE
#define _PGLOBAL __declspec(process)
#else
#define _PGLOBAL
#endif
#endif

#ifndef _AGLOBAL
#ifdef _M_CEE
#define _AGLOBAL __declspec(appdomain)
#else
#define _AGLOBAL
#endif
#endif

/* define a specific constant for mixed mode */
#ifdef _M_CEE
#ifndef _M_CEE_PURE
#define _M_CEE_MIXED
#endif
#endif

/* Define __GOT_SECURE_LIB__ */
#define __GOT_SECURE_LIB__ 200402L

/* Define _CRT_INSECURE_DEPRECATE */
#ifndef _CRT_INSECURE_DEPRECATE
#ifdef _CRT_SECURE_NO_DEPRECATE
#define _CRT_INSECURE_DEPRECATE
#else
#define _CRT_INSECURE_DEPRECATE __declspec(deprecated)
#endif
#endif

/* Define _CRT_INSECURE_DEPRECATE_MEMORY */
#ifndef _CRT_INSECURE_DEPRECATE_MEMORY
#if defined(_CRT_SECURE_NO_DEPRECATE) || !defined(_CRT_SECURE_DEPRECATE_MEMORY)
#define _CRT_INSECURE_DEPRECATE_MEMORY
#else
#define _CRT_INSECURE_DEPRECATE_MEMORY __declspec(deprecated)
#endif
#endif

#ifndef _SIZE_T_DEFINED
#ifdef  _WIN64
typedef unsigned __int64    size_t;
#else
typedef _W64 unsigned int   size_t;
#endif
#define _SIZE_T_DEFINED
#endif

#ifndef _INTPTR_T_DEFINED
#ifdef  _WIN64
typedef __int64             intptr_t;
#else
typedef _W64 int            intptr_t;
#endif
#define _INTPTR_T_DEFINED
#endif

#ifndef _UINTPTR_T_DEFINED
#ifdef  _WIN64
typedef unsigned __int64    uintptr_t;
#else
typedef _W64 unsigned int   uintptr_t;
#endif
#define _UINTPTR_T_DEFINED
#endif

#ifndef _PTRDIFF_T_DEFINED
#ifdef  _WIN64
typedef __int64             ptrdiff_t;
#else
typedef _W64 int            ptrdiff_t;
#endif
#define _PTRDIFF_T_DEFINED
#endif

#ifndef _WCHAR_T_DEFINED
typedef unsigned short wchar_t;
#define _WCHAR_T_DEFINED
#endif

#ifndef _WCTYPE_T_DEFINED
typedef unsigned short wint_t;
typedef unsigned short wctype_t;
#define _WCTYPE_T_DEFINED
#endif

#ifndef _VA_LIST_DEFINED
#ifdef _M_CEE_PURE
typedef System::ArgIterator va_list;
#else
typedef char *  va_list;
#endif
#define _VA_LIST_DEFINED
#endif

#ifdef  _USE_32BIT_TIME_T
#ifdef  _WIN64
#pragma message( "_USE_32BIT_TIME_T ignored. You cannot use 32-bit time_t with _WIN64" )
#undef  _USE_32BIT_TIME_T
#endif
#else
#if     _INTEGRAL_MAX_BITS < 64
#define _USE_32BIT_TIME_T
#endif
#endif

#ifndef _ERRCODE_DEFINED
#define _ERRCODE_DEFINED
typedef int errcode; /* transitional */
typedef int errno_t; /* standard */
#endif

#ifndef _TIME32_T_DEFINED
typedef _W64 long __time32_t;   /* 32-bit time value */
#define _TIME32_T_DEFINED
#endif

#ifndef _TIME64_T_DEFINED
#if     _INTEGRAL_MAX_BITS >= 64
typedef __int64 __time64_t;     /* 64-bit time value */
#endif
#define _TIME64_T_DEFINED
#endif

#ifndef _TIME_T_DEFINED
#ifdef _USE_32BIT_TIME_T
typedef __time32_t time_t;      /* time value */
#else
typedef __time64_t time_t;      /* time value */
#endif
#define _TIME_T_DEFINED         /* avoid multiple def's of time_t */
#endif

#ifndef _CONST_RETURN
#ifdef  __cplusplus
#define _CONST_RETURN  const
#define _CRT_CONST_CORRECT_OVERLOADS
#else
#define _CONST_RETURN
#endif
#endif

/* Define _CRTNOALIAS, _CRTRESTRICT */

#if     _MSC_FULL_VER >= 13102050
#if !defined(_MSC_VER_GREATER_THEN_13102050)
#define _MSC_VER_GREATER_THEN_13102050 
#endif
#endif

#if     ( defined(_M_IA64) && defined(_MSC_VER_GREATER_THEN_13102050) ) || _MSC_VER >= 1400
#ifndef _CRTNOALIAS
#define _CRTNOALIAS __declspec(noalias)
#endif  /* _CRTNOALIAS */

#ifndef _CRTRESTRICT
#define _CRTRESTRICT __declspec(restrict)
#endif  /* _CRTRESTRICT */

#else

#ifndef _CRTNOALIAS
#define _CRTNOALIAS
#endif  /* _CRTNOALIAS */

#ifndef _CRTRESTRICT
#define _CRTRESTRICT
#endif  /* _CRTRESTRICT */

#endif

/* Define __cdecl for non-Microsoft compilers */

#if     ( !defined(_MSC_VER) && !defined(__cdecl) )
#define __cdecl
#endif

#if !defined(__CRTDECL)
#if defined(_M_CEE_PURE)
#define __CRTDECL
#else
#define __CRTDECL   __cdecl
#endif
#endif


#define _ARGMAX 100

struct threadlocaleinfostruct;
struct threadmbcinfostruct;
typedef struct threadlocaleinfostruct * pthreadlocinfo;
typedef struct threadmbcinfostruct * pthreadmbcinfo;
struct __lc_time_data;

typedef struct localeinfo_struct
{
    pthreadlocinfo locinfo;
    pthreadmbcinfo mbcinfo;
} _locale_tstruct, *_locale_t;

#ifndef _TAGLC_ID_DEFINED
typedef struct tagLC_ID {
        unsigned short wLanguage;
        unsigned short wCountry;
        unsigned short wCodePage;
} LC_ID, *LPLC_ID;
#define _TAGLC_ID_DEFINED
#endif  /* _TAGLC_ID_DEFINED */

#ifndef _THREADLOCALEINFO
typedef struct threadlocaleinfostruct {
        int refcount;
        unsigned int lc_codepage;
        unsigned int lc_collate_cp;
        unsigned long lc_handle[6]; /* LCID */
        LC_ID lc_id[6];
        struct {
            char *locale;
            wchar_t *wlocale;
            int *refcount;
            int *wrefcount;
        } lc_category[6];
        int lc_clike;
        int mb_cur_max;
        int * lconv_intl_refcount;
        int * lconv_num_refcount;
        int * lconv_mon_refcount;
        struct lconv * lconv;
        int * ctype1_refcount;
        unsigned short * ctype1;
        const unsigned short * pctype;
        const unsigned char * pclmap;
        const unsigned char * pcumap;
        struct __lc_time_data * lc_time_curr;
} threadlocinfo;
#define _THREADLOCALEINFO
#endif

#ifdef  __cplusplus
}
#endif

#endif  /* _INC_CRTDEFS */
