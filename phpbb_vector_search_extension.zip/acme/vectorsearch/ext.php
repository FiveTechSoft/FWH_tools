<?php

namespace acme\vectorsearch;

/**
 * @ignore
 */
if (!defined('IN_PHPBB'))
{
    exit;
}

class ext extends \phpbb\extension\base
{
    /**
     * {@inheritdoc}
     */
    public function is_enableable()
    {
        // Add any checks here that would prevent the extension from being enabled
        // For example, PHP version, phpBB version, required PHP extensions, etc.
        // For now, we assume it's always enableable if dependencies are met via composer.
        return true;
    }

    // Optional: Implement enable_step, disable_step, purge_step methods
    // if you need to perform actions during these stages.
    // For example, adding/removing ACP modules, database schema changes (though migrations are preferred for schema).

    /* Example for adding an ACP module during enable_step
    public function enable_step($old_state)
    {
        if ($old_state === false) // First time enabling
        {
            $this->container->get('migrator')->add_module_acp('acme_vectorsearch_module', 'ACP_CAT_DOT_MODS', 'ACP_VECTORSEARCH_TITLE');
        }
        return parent::enable_step($old_state);
    }

    public function disable_step($old_state)
    {
        if ($old_state !== false) // Disabling
        {
            $this->container->get('migrator')->remove_module_acp('acme_vectorsearch_module');
        }
        return parent::disable_step($old_state);
    }

    public function purge_step($old_state)
    {
        // Remove any data, config settings, etc., created by the extension
        // This is called when the extension data is purged from the ACP
        // For example, remove config settings:
        // $this->config->delete_array(array('acme_vectorsearch_api_key', 'acme_vectorsearch_pinecone_index'));
        return parent::purge_step($old_state);
    }
    */
}

