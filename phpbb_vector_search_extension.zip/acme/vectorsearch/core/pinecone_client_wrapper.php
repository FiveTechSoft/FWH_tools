<?php

namespace acme\vectorsearch\core;

use Pinecone\Client as PineconeClient;
use Pinecone\Index;
use Pinecone\Exception\PineconeException;

/**
 * Wrapper for the Pinecone PHP client.
 */
class pinecone_client_wrapper
{
    /** @var PineconeClient|null */
    private $pinecone_client;

    /** @var Index|null */
    private $index;

    /** @var string */
    private $api_key;

    /** @var string */
    private $environment;

    /** @var string */
    private $index_name;

    /** @var \phpbb\config\config */
    protected $config;

    /** @var \phpbb\log\log_interface */
    protected $log;

    /**
     * Constructor.
     *
     * @param \phpbb\config\config $config phpBB config object.
     * @param \phpbb\log\log_interface $log phpBB log object.
     */
    public function __construct(\phpbb\config\config $config, \phpbb\log\log_interface $log)
    {
        $this->config = $config;
        $this->log = $log;
        // Defer initialization until API key and environment are confirmed to be set
    }

    /**
     * Initializes the Pinecone client and index.
     * This should be called after ensuring config values are set.
     *
     * @return bool True on success, false on failure.
     */
    private function init_client()
    {
        if ($this->index) {
            return true; // Already initialized
        }

        $this->api_key = $this->config['acme_vectorsearch_pinecone_api_key'];
        $this->environment = $this->config['acme_vectorsearch_pinecone_env'];
        $this->index_name = $this->config['acme_vectorsearch_pinecone_index_name'];

        if (empty($this->api_key) || empty($this->environment) || empty($this->index_name))
        {
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_CONFIG_MISSING', 'Pinecone API Key, Environment, or Index Name not configured.');
            return false;
        }

        try {
            $this->pinecone_client = new PineconeClient($this->api_key, $this->environment);
            // Check if index exists, if not, optionally create it or log an error
            // For now, we assume the index exists or will be created manually or by another process.
            $this->index = $this->pinecone_client->index($this->index_name);
            // You might want to add a check here to see if the index actually exists
            // $this->index->describeIndexStats(); // This would throw an exception if index doesn't exist
        } catch (PineconeException $e) {
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_PINECCONE_ERROR', 'Pinecone client initialization failed: ' . $e->getMessage());
            $this->pinecone_client = null;
            $this->index = null;
            return false;
        }
        return true;
    }

    /**
     * Upserts (inserts or updates) vectors into the Pinecone index.
     *
     * @param array $vectors Array of vectors to upsert. Each vector should be an array with 'id' and 'values'. Optionally 'metadata'.
     * @param string $namespace Optional namespace.
     * @return array|null Response from Pinecone or null on error.
     */
    public function upsert_vectors(array $vectors, string $namespace = '')
    {
        if (!$this->init_client() || !$this->index) {
            return null;
        }
        try {
            if ($namespace) {
                return $this->index->vectors($namespace)->upsert($vectors);
            }
            return $this->index->vectors()->upsert($vectors);
        } catch (PineconeException $e) {
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_PINECCONE_UPSERT_ERROR', 'Pinecone upsert failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Queries the Pinecone index for similar vectors.
     *
     * @param array $vector The query vector.
     * @param int $top_k Number of results to return.
     * @param string $namespace Optional namespace.
     * @param array $filter Optional metadata filter.
     * @param bool $include_values Whether to include the vector values in the results.
     * @param bool $include_metadata Whether to include the metadata in the results.
     * @return array|null Query results or null on error.
     */
    public function query_vectors(array $vector, int $top_k, string $namespace = '', array $filter = [], bool $include_values = false, bool $include_metadata = true)
    {
        if (!$this->init_client() || !$this->index) {
            return null;
        }
        try {
            $query_params = [
                'vector' => $vector,
                'topK' => $top_k,
                'includeValues' => $include_values,
                'includeMetadata' => $include_metadata,
            ];
            if (!empty($filter)) {
                $query_params['filter'] = $filter;
            }

            if ($namespace) {
                return $this->index->vectors($namespace)->query($query_params);
            }
            return $this->index->vectors()->query($query_params);
        } catch (PineconeException $e) {
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_PINECCONE_QUERY_ERROR', 'Pinecone query failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Deletes vectors from the Pinecone index by ID.
     *
     * @param array $ids Array of vector IDs to delete.
     * @param string $namespace Optional namespace.
     * @return array|null Response from Pinecone or null on error.
     */
    public function delete_vectors(array $ids, string $namespace = '')
    {
        if (!$this->init_client() || !$this->index) {
            return null;
        }
        try {
            $delete_params = ['ids' => $ids];
            if ($namespace) {
                return $this->index->vectors($namespace)->delete($delete_params);
            }
            return $this->index->vectors()->delete($delete_params);
        } catch (PineconeException $e) {
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_PINECCONE_DELETE_ERROR', 'Pinecone delete failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Gets statistics about the index.
     *
     * @return array|null Index statistics or null on error.
     */
    public function get_index_stats()
    {
        if (!$this->init_client() || !$this->index) {
            return null;
        }
        try {
            return $this->index->describeIndexStats();
        } catch (PineconeException $e) {
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_PINECCONE_STATS_ERROR', 'Pinecone get_index_stats failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Creates the index if it does not exist.
     * Note: This might require specific permissions and configuration.
     * The probots-io/pinecone-php client as of v0.1.0 might not directly support index creation easily,
     * it focuses on operations on existing indexes. This method is a placeholder for potential future enhancement
     * or if using a different client/direct API calls.
     *
     * @param string $index_name_to_create The name of the index to create.
     * @param int $dimension Dimension of the vectors.
     * @param string $metric Metric type (e.g., 'cosine', 'euclidean', 'dotproduct').
     * @param array $options Additional options for index creation (e.g., pods, replicas, metadata_config).
     * @return bool True if index exists or was created, false otherwise.
     */
    public function create_index_if_not_exists(string $index_name_to_create, int $dimension, string $metric = 'cosine', array $options = [])
    {
        if (!$this->init_client()) { // init_client initializes $this->pinecone_client
             return false;
        }
        try {
            $indexes = $this->pinecone_client->listIndexes()->getIndexes();
            foreach ($indexes as $index_info) {
                if ($index_info['name'] === $index_name_to_create) {
                    // Index already exists, ensure our current index object points to it
                    if ($this->index_name !== $index_name_to_create) {
                        $this->index_name = $index_name_to_create;
                        $this->index = $this->pinecone_client->index($this->index_name);
                    }
                    return true;
                }
            }

            // Index does not exist, attempt to create it
            // The specific method for index creation depends on the client library's capabilities.
            // As of probots-io/pinecone-php v0.1.0, direct index creation is not straightforward.
            // This part would need to be implemented using direct API calls or an updated client.
            // For now, we'll log that it needs manual creation or a more capable client.
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_PINECCONE_INDEX_CREATE_INFO', 'Index "' . $index_name_to_create . '" does not exist. Automatic creation is not fully supported by this client version. Please create it manually or use an updated client/direct API calls.');
            // Example (conceptual) of how it might look with a more complete client:
            // $this->pinecone_client->createIndex($index_name_to_create, $dimension, $metric, $options);
            // $this->index_name = $index_name_to_create;
            // $this->index = $this->pinecone_client->index($this->index_name);
            return false; // Return false as automatic creation is not implemented here

        } catch (PineconeException $e) {
            $this->log->add('admin', 0, 0, 'LOG_VECTORSEARCH_PINECCONE_INDEX_MGMT_ERROR', 'Pinecone index management failed: ' . $e->getMessage());
            return false;
        }
    }
}

