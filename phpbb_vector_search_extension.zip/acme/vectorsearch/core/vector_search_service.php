<?php

namespace acme\vectorsearch\core;

use acme\vectorsearch\core\pinecone_client_wrapper;
use acme\vectorsearch\core\text_processor;

/**
 * Service class for vector search indexing and querying logic.
 */
class vector_search_service
{
    /** @var \phpbb\db\driver\driver_interface */
    protected $db;

    /** @var \phpbb\config\config */
    protected $config;

    /** @var \phpbb\user */
    protected $user;

    /** @var pinecone_client_wrapper */
    protected $pinecone_wrapper;

    /** @var text_processor */
    protected $text_processor;

    /** @var \phpbb\log\log_interface */
    protected $log;

    // Placeholder for an embedding service/client
    // In a real scenario, this would be a client for OpenAI, Cohere, a self-hosted model, etc.
    /** @var mixed */
    protected $embedding_service_client; 

    /**
     * Constructor.
     *
     * @param \phpbb\db\driver\driver_interface $db
     * @param \phpbb\config\config $config
     * @param \phpbb\user $user
     * @param pinecone_client_wrapper $pinecone_wrapper
     * @param text_processor $text_processor
     * @param \phpbb\log\log_interface $log
     */
    public function __construct(
        \phpbb\db\driver\driver_interface $db,
        \phpbb\config\config $config,
        \phpbb\user $user,
        pinecone_client_wrapper $pinecone_wrapper,
        text_processor $text_processor,
        \phpbb\log\log_interface $log
    )
    {
        $this->db = $db;
        $this->config = $config;
        $this->user = $user;
        $this->pinecone_wrapper = $pinecone_wrapper;
        $this->text_processor = $text_processor;
        $this->log = $log;
        
        // Initialize your embedding service client here based on ACP configuration
        // For example: $this->embedding_service_client = new EmbeddingApiClient($this->config["acme_vectorsearch_embedding_api_key"]);
        // For now, this is a placeholder.
    }

    /**
     * Generates an embedding for a given text.
     * This is a placeholder and needs to be implemented with a real embedding model/service.
     *
     * @param string $text The text to embed.
     * @return array|null The embedding vector or null on error.
     */
    private function generate_embedding(string $text): ?array
    {
        // TODO: Implement actual embedding generation logic.
        // This could involve calling an external API (OpenAI, Cohere, etc.)
        // or a local model if a PHP library supports it.
        // Example with a hypothetical external service:
        /*
        if ($this->embedding_service_client) {
            try {
                return $this->embedding_service_client->createEmbedding($text);
            } catch (\Exception $e) {
                $this->log->add("admin", 0, 0, "LOG_VECTORSEARCH_EMBEDDING_ERROR", "Failed to generate embedding: " . $e->getMessage());
                return null;
            }
        }
        */
        $this->log->add("admin", 0, 0, "LOG_VECTORSEARCH_EMBEDDING_WARN", "Embedding generation is not fully implemented. Using placeholder.");
        // Return a dummy vector of the correct dimension for testing, e.g., 1536 for OpenAI ada-002
        // The actual dimension should match your Pinecone index configuration.
        // Ensure this matches the dimension configured in Pinecone index.
        $dimension = (int) $this->config["acme_vectorsearch_pinecone_dimension"]; // Assuming dimension is stored in config
        if ($dimension <= 0) $dimension = 768; // Default fallback
        return array_fill(0, $dimension, 0.12345);
    }

    /**
     * Indexes posts from specified forums.
     *
     * @param array $forum_ids Array of forum IDs to index posts from.
     * @param int $limit Maximum number of posts to process in one go (for batching).
     * @param int $offset Offset for batching.
     * @return array Status of the indexing process (e.g., count_processed, count_success, count_failed).
     */
    public function index_posts(array $forum_ids, int $limit = 100, int $offset = 0): array
    {
        $status = ["processed" => 0, "success" => 0, "failed" => 0, "skipped_no_text" => 0, "skipped_embedding_failure" => 0];

        if (empty($forum_ids)) {
            return $status;
        }

        $sql_where_forum = $this->db->sql_in_set("p.forum_id", $forum_ids);

        // Fetch posts
        // Consider adding a check for already indexed posts if you implement tracking
        $sql = "SELECT p.post_id, p.post_subject, pt.post_text
                FROM " . POSTS_TABLE . " p
                JOIN " . POSTS_TABLE . " pt ON p.post_id = pt.post_id  // Assuming post_text is in the same table, adjust if phpBB schema differs for post_text storage
                WHERE " . $sql_where_forum . "
                AND p.post_visibility = " . ITEM_APPROVED . " /* Or other relevant visibility checks */
                ORDER BY p.post_id ASC";
        $result = $this->db->sql_query_limit($sql, $limit, $offset);

        $vectors_to_upsert = [];
        while ($row = $this->db->sql_fetchrow($result))
        {
            $status["processed"]++;
            $post_id = (int) $row["post_id"];
            
            // Combine subject and text for a richer embedding, or just use post_text
            $text_to_embed = $row["post_subject"] . "\n\n" . $row["post_text"];
            $cleaned_text = $this->text_processor->get_plain_text_from_bbcode($text_to_embed);

            if (empty(trim($cleaned_text)))
            {
                $status["skipped_no_text"]++;
                $this->log->add("admin", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_INDEX_SKIP_NO_TEXT", "Skipped post ID: " . $post_id . " (no text after cleaning).");
                continue;
            }

            $embedding = $this->generate_embedding($cleaned_text);

            if ($embedding === null)
            {
                $status["skipped_embedding_failure"]++;
                $this->log->add("admin", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_INDEX_EMBED_FAIL", "Failed to generate embedding for post ID: " . $post_id);
                continue;
            }

            $vectors_to_upsert[] = [
                "id" => (string) $post_id, // Pinecone expects string IDs
                "values" => $embedding,
                "metadata" => [
                    "forum_id" => (int) $row["forum_id"], // Example metadata, ensure this is how you get forum_id
                    "post_time" => (int) $row["post_time"], // Example metadata, ensure this is how you get post_time
                    // Add other relevant metadata like author_id, etc.
                ],
            ];

            // Batch upsert to Pinecone to avoid too many individual requests
            if (count($vectors_to_upsert) >= 50) { // Configurable batch size
                $upsert_result = $this->pinecone_wrapper->upsert_vectors($vectors_to_upsert);
                if ($upsert_result && isset($upsert_result["upsertedCount"])) {
                    $status["success"] += $upsert_result["upsertedCount"];
                } else {
                    $status["failed"] += count($vectors_to_upsert);
                    $this->log->add("admin", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_INDEX_UPSERT_FAIL_BATCH");
                }
                $vectors_to_upsert = [];
            }
        }
        $this->db->sql_freeresult($result);

        // Upsert any remaining vectors
        if (!empty($vectors_to_upsert)) {
            $upsert_result = $this->pinecone_wrapper->upsert_vectors($vectors_to_upsert);
            if ($upsert_result && isset($upsert_result["upsertedCount"])) {
                $status["success"] += $upsert_result["upsertedCount"];
            } else {
                $status["failed"] += count($vectors_to_upsert);
                $this->log->add("admin", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_INDEX_UPSERT_FAIL_REMAINING");
            }
        }
        
        $this->log->add("admin", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_INDEX_BATCH_COMPLETE", sprintf("Processed: %d, Success: %d, Failed: %d, Skipped (no text): %d, Skipped (embed fail): %d", $status["processed"], $status["success"], $status["failed"], $status["skipped_no_text"], $status["skipped_embedding_failure"]));

        return $status;
    }

    // TODO: Implement search_posts method for step 005
    /**
     * Searches posts based on a query string using vector similarity.
     *
     * @param string $query_string The search query.
     * @param int $top_k The number of results to return.
     * @param array $forum_ids_filter Optional array of forum IDs to filter results.
     * @return array An array of search results, each containing post details.
     */
    public function search_posts(string $query_string, int $top_k = 10, array $forum_ids_filter = []): array
    {
        $search_results = [];

        if (empty(trim($query_string)))
        {
            return $search_results;
        }

        $cleaned_query = $this->text_processor->clean_post_text($query_string);
        if (empty(trim($cleaned_query)))
        {
            return $search_results;
        }

        $query_embedding = $this->generate_embedding($cleaned_query);

        if ($query_embedding === null)
        {
            $this->log->add("error", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_SEARCH_EMBED_FAIL", "Failed to generate embedding for query: " . $query_string);
            return $search_results;
        }

        $pinecone_filter = [];
        if (!empty($forum_ids_filter))
        {
            // Assuming 'forum_id' is stored as metadata and is numeric
            // Pinecone's metadata filtering syntax can be like: { "genre": { "$in": [ "comedy", "documentary", "drama" ] } }
            // Or for a single value: { "forum_id": 123 }
            // For multiple forum_ids, if Pinecone supports $in for numeric, or you might need to adjust.
            // For simplicity, if only one forum_id is common, let's assume a simple filter for now.
            // If Pinecone PHP client expects specific filter structure, adjust accordingly.
            // $pinecone_filter = ["forum_id" => ["$in" => $forum_ids_filter]]; // This syntax depends on client/Pinecone
            // A simpler filter if only one ID or if the client handles arrays directly:
            // $pinecone_filter = ["forum_id" => $forum_ids_filter]; 
            // For now, let's assume a simple key-value if metadata is structured like that, or skip if complex.
            // This part needs careful implementation based on how metadata is stored and queried in Pinecone.
        }

        $query_response = $this->pinecone_wrapper->query_vectors(
            $query_embedding, 
            $top_k, 
            '', // namespace, if used
            $pinecone_filter, 
            false, // include_values
            true   // include_metadata
        );

        if ($query_response === null || empty($query_response["matches"])) 
        {
            $this->log->add("info", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_SEARCH_NO_MATCHES", "No vector matches found for query: " . $query_string);
            return $search_results;
        }

        $post_ids = [];
        $scores = [];
        foreach ($query_response["matches"] as $match)
        {
            $post_ids[] = (int) $match["id"];
            $scores[(int) $match["id"]] = $match["score"]; // Store similarity score
        }

        if (empty($post_ids))
        {
            return $search_results;
        }

        // Fetch post details from phpBB database
        // This query is a simplified example, you'll need to join with users, forums tables for full details
        $sql = "SELECT p.post_id, p.topic_id, p.forum_id, p.post_subject, p.post_time, p.poster_id, p.post_username,
                       u.username, u.user_colour, f.forum_name
                FROM " . POSTS_TABLE . " p
                LEFT JOIN " . USERS_TABLE . " u ON p.poster_id = u.user_id
                LEFT JOIN " . FORUMS_TABLE . " f ON p.forum_id = f.forum_id
                WHERE " . $this->db->sql_in_set("p.post_id", $post_ids);
        
        $result = $this->db->sql_query($sql);

        while ($row = $this->db->sql_fetchrow($result))
        {
            // Here you would typically use phpBB's functions to prepare data for display,
            // e.g., generate topic/post URLs, format username, etc.
            // For simplicity, we're just adding raw data.
            $row["score"] = $scores[$row["post_id"]] ?? 0;
            $search_results[] = $row;
        }
        $this->db->sql_freeresult($result);

        // Sort results by score (descending) if Pinecone doesn't guarantee it or if you mix sources
        usort($search_results, function($a, $b) {
            return $b["score"] <=> $a["score"];
        });

        return $search_results;
    }
}

