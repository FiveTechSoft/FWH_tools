# Extensión de Búsqueda Vectorial para phpBB (Integración con Pinecone)

## 1. Introducción

Esta extensión integra capacidades de búsqueda vectorial semántica en foros phpBB utilizando [Pinecone](https://www.pinecone.io/) como base de datos vectorial. Permite a los usuarios encontrar contenido relevante basado en el significado de su consulta, en lugar de solo coincidencias de palabras clave.

La extensión está diseñada para ser configurable a través del Panel de Control de Administración (ACP) de phpBB, permitiendo a los administradores gestionar la conexión a Pinecone, seleccionar el contenido a indexar e iniciar el proceso de indexación.

**Versión Actual:** 1.0.0

## 2. Características Principales

-   Integración con la base de datos vectorial Pinecone.
-   Indexación del contenido de los posts de foros seleccionados.
-   Configuración de la conexión a Pinecone y parámetros de indexación a través del ACP.
-   Panel en el ACP para iniciar la indexación manual por lotes.
-   Visualización de estadísticas básicas del índice de Pinecone en el ACP.
-   Capacidad de búsqueda vectorial (la integración con la interfaz de búsqueda de phpBB se realiza a través de eventos).
-   Procesamiento de texto para limpiar el contenido antes de la vectorización.
-   Diseño modular para facilitar el mantenimiento y futuras mejoras.

## 3. Requisitos

-   **phpBB:** Versión 3.3.0 o superior.
-   **PHP:** Versión 7.1 o superior (se recomienda 7.4+).
-   **Composer:** Necesario para instalar dependencias PHP.
-   **Cuenta de Pinecone:**
    -   Una cuenta activa en [Pinecone](https://www.pinecone.io/).
    -   Una **API Key** de Pinecone.
    -   El **Entorno (Environment)** de tu proyecto Pinecone (ej. `us-west1-gcp`).
    -   Un **Índice de Pinecone preexistente**. La extensión actualmente no crea el índice automáticamente. Debes crearlo manualmente en tu consola de Pinecone con la dimensión correcta que coincida con el modelo de embeddings que utilizarás.
-   **Servicio de Embeddings (Generación de Vectores):**
    -   La extensión requiere un mecanismo para convertir texto en vectores (embeddings). Actualmente, la lógica de `generate_embedding` en `core/vector_search_service.php` es un marcador de posición (`placeholder`) que devuelve vectores ficticios.
    -   **Deberás implementar la generación real de embeddings.** Opciones comunes:
        1.  **API Externa:** Utilizar servicios como OpenAI (ej. `text-embedding-ada-002`), Cohere, etc. Esto requerirá una clave API adicional para dicho servicio y puede incurrir en costes.
        2.  **Microservicio Propio:** Desplegar un pequeño servicio (ej. en Python usando Flask/FastAPI con bibliotecas como `sentence-transformers`) que la extensión PHP pueda llamar.
        3.  **Bibliotecas PHP (Limitado):** Investigar si existen bibliotecas PHP capaces de ejecutar modelos de embeddings localmente (ej. a través de ONNX Runtime, si hay soporte PHP adecuado para los modelos deseados). Esta opción suele ser más compleja y limitada.
    -   La dimensión del índice de Pinecone debe coincidir con la dimensión de los vectores generados por el modelo de embeddings elegido (ej. 1536 para `text-embedding-ada-002`).
-   **Extensiones PHP:**
    -   `curl` (generalmente habilitada por defecto, para comunicación con APIs).
    -   `json` (generalmente habilitada por defecto).

## 4. Instalación

1.  **Descargar/Clonar la Extensión:**
    -   Obtén los archivos de la extensión. Si es un repositorio Git, clónalo.

2.  **Subir Archivos al Servidor:**
    -   Crea la siguiente estructura de directorios en tu instalación de phpBB si no existe: `ext/acme/vectorsearch/`.
    -   Copia todos los archivos de la extensión dentro del directorio `ext/acme/vectorsearch/`.

3.  **Instalar Dependencias con Composer:**
    -   Navega a la raíz de tu instalación de phpBB en la línea de comandos.
    -   Ejecuta el siguiente comando para que Composer encuentre la extensión y sus dependencias (si el `composer.json` de la extensión está correctamente configurado y tu phpBB está preparado para gestionar dependencias de extensiones de esta manera):
        ```bash
        composer require probots-io/pinecone-php:"^0.1.0"
        ```
    -   Alternativamente, si la extensión ya incluye un `vendor` directorio con las dependencias, este paso podría no ser necesario, pero es la práctica recomendada gestionar dependencias a través del Composer raíz de phpBB o instalándolas específicamente para la extensión si se empaqueta de esa forma.
    -   **Nota Importante:** La forma más robusta es que el `composer.json` de la extensión declare sus dependencias y que el administrador ejecute `composer install` dentro del directorio de la extensión, o que el `composer.json` raíz de phpBB las maneje. Para este ejemplo, asumimos que `probots-io/pinecone-php` debe estar disponible. Si tu phpBB no está configurado para manejar dependencias de extensiones de forma centralizada, puede que necesites ejecutar `composer install --no-dev` dentro del directorio `ext/acme/vectorsearch/` (si la extensión está empaquetada con su propio `composer.json` para ser autocontenida en cuanto a dependencias).

4.  **Habilitar la Extensión en el ACP:**
    -   Ve al `Panel de Control de Administración (ACP)` de tu foro phpBB.
    -   Navega a la pestaña `Personalizar`.
    -   En la sección `Gestionar Extensiones`, busca "Vector Search Extension" en la lista de extensiones deshabilitadas.
    -   Haz clic en el enlace `Habilitar`.

## 5. Configuración

Una vez habilitada la extensión, deberás configurarla:

1.  **Acceder a la Configuración de la Extensión:**
    -   En el ACP, busca una nueva pestaña o sección relacionada con las extensiones o modificaciones. Debería aparecer un enlace para "Vector Search Configuration" (o el título que se haya definido en `acme_vectorsearch_info.php`).
    -   Alternativamente, puede estar bajo `ACP_CAT_DOT_MODS` o una categoría similar.

2.  **Modo "Settings":**
    -   **Pinecone API Key:** Ingresa tu clave API de Pinecone.
    -   **Pinecone Environment:** Ingresa el entorno de tu proyecto Pinecone (ej. `us-east-1-aws`, `europe-west4-gcp`).
    -   **Pinecone Index Name:** Ingresa el nombre exacto del índice que has creado previamente en tu consola de Pinecone.
    -   **Pinecone Index Dimension:** Ingresa la dimensión numérica de los vectores que tu modelo de embeddings genera (ej., 1536 para `text-embedding-ada-002` de OpenAI). **Esto debe coincidir exactamente con la configuración de tu índice en Pinecone.**
    -   **Embedding Service API Key (Opcional):** Si utilizas un servicio externo para generar embeddings (ej. OpenAI), ingresa su clave API aquí.
    -   **Embedding Model Name (Opcional):** Especifica el nombre del modelo si utilizas un servicio externo (ej. `text-embedding-ada-002`).
    -   **Forums to Index:** Selecciona los foros de los cuales deseas indexar los posts. Puedes seleccionar múltiples foros.
    -   Guarda la configuración.

3.  **Creación del Índice en Pinecone (Manual):**
    -   **Importante:** Como se mencionó, esta extensión **no crea automáticamente el índice en Pinecone**. Debes hacerlo manualmente desde tu dashboard de Pinecone antes de intentar indexar contenido.
    -   Asegúrate de que la `dimensión` del índice en Pinecone coincida con el valor que configuras en el ACP y con la salida de tu modelo de embeddings.
    -   Elige la `métrica` adecuada (ej. `cosine` es común para embeddings de texto).

## 6. Uso

### 6.1. Indexación de Contenido

1.  **Acceder a la Gestión de Indexación:**
    -   En el ACP, dentro de la configuración de la extensión "Vector Search", ve a la sección o modo "Indexing Management".
2.  **Iniciar Indexación:**
    -   Verás el estado actual de tu índice en Pinecone (si la conexión es exitosa) y un botón para "Start Full Re-index".
    -   Haz clic en este botón para comenzar el proceso de indexación. La extensión recorrerá los posts de los foros seleccionados, generará embeddings (usando tu implementación) y los enviará a Pinecone.
    -   Este proceso puede tardar dependiendo de la cantidad de contenido y la velocidad de generación de embeddings y la API de Pinecone.
    -   La indexación se realiza por lotes. El ACP mostrará un estado al finalizar.
3.  **Monitorización y Logs:**
    -   Revisa los logs de administración de phpBB para ver mensajes detallados sobre el proceso de indexación, incluyendo errores o posts omitidos.

### 6.2. Búsqueda Vectorial (Usuario Final)

-   La integración de la búsqueda vectorial en la interfaz de usuario de phpBB dependerá de cómo se haya implementado el `main_listener.php` para escuchar los eventos de búsqueda de phpBB (ej. `core.search_register_search_types` y el evento que maneja la ejecución de la búsqueda).
-   Idealmente, aparecerá un nuevo tipo de búsqueda "Vectorial" o "Semántica" en las opciones de búsqueda de phpBB.
-   Cuando un usuario realice una búsqueda utilizando este tipo, la extensión procesará la consulta, generará un embedding para ella y consultará a Pinecone para encontrar los posts más similares.

## 7. Troubleshooting

-   **Error de Configuración Faltante:** Si ves errores en los logs de phpBB sobre "Pinecone configuration missing", asegúrate de que todos los campos (API Key, Environment, Index Name, Dimension) estén correctamente guardados en el ACP.
-   **Errores de Pinecone:** Si hay errores de conexión, upsert o query con Pinecone, verifica:
    -   Tu clave API y entorno de Pinecone.
    -   Que el nombre del índice sea correcto y el índice exista en Pinecone.
    -   Que la dimensión del índice en Pinecone coincida con la dimensión de los embeddings generados.
    -   El estado del servicio de Pinecone.
-   **Fallos en la Generación de Embeddings:**
    -   Asegúrate de que tu implementación de `generate_embedding()` en `core/vector_search_service.php` funcione correctamente y pueda acceder al servicio de embeddings (si es externo) o al modelo local.
    -   Verifica las claves API del servicio de embeddings si aplica.
-   **No se Indexan Posts o No Hay Resultados de Búsqueda:**
    -   Confirma que has seleccionado foros para indexar en el ACP.
    -   Verifica que los posts en esos foros tengan contenido textual después de la limpieza.
    -   Asegúrate de que el proceso de indexación se haya completado sin demasiados errores (revisa los logs).
    -   Comprueba que la implementación de la búsqueda en `main_listener.php` y `vector_search_service.php` esté correcta.

## 8. Desinstalación

1.  **Deshabilitar la Extensión:**
    -   En el ACP, ve a `Personalizar` -> `Gestionar Extensiones`.
    -   Busca "Vector Search Extension" y haz clic en `Deshabilitar`.
2.  **Borrar Datos de la Extensión (Purge):**
    -   Después de deshabilitar, tendrás la opción de `Borrar datos`.
    -   Esto ejecutará el método `purge_step` de la extensión (si está implementado), que debería eliminar configuraciones y otros datos almacenados por la extensión en la base de datos de phpBB.
    -   **Nota:** Esto no elimina tu índice ni los datos en Pinecone. Deberás gestionarlos directamente desde tu cuenta de Pinecone si deseas eliminarlos.
3.  **Eliminar Archivos:**
    -   Una vez borrados los datos, puedes eliminar el directorio `ext/acme/vectorsearch/` de tu servidor.

## 9. Notas de Desarrollo (Implementación Actual)

-   **Generación de Embeddings:** La función `generate_embedding()` en `core/vector_search_service.php` es un **marcador de posición crítico**. Debes reemplazarla con una implementación real que genere vectores utilizando un modelo de embeddings. Actualmente, devuelve vectores ficticios, lo que significa que la búsqueda semántica no funcionará correctamente hasta que esto se implemente.
-   **Cliente Pinecone:** Se utiliza `probots-io/pinecone-php`. La creación de índices no está directamente soportada de forma sencilla por esta versión del cliente; los índices deben ser precreados en Pinecone.
-   **Procesamiento de Texto:** La clase `text_processor.php` implementa una limpieza básica de BBCode y HTML. Puede requerir mejoras para un manejo más robusto y preciso del contenido de los posts.
-   **Integración con la Búsqueda de phpBB:** La integración real con la interfaz de búsqueda de phpBB (mostrando la opción de búsqueda vectorial, mostrando resultados) se basa en la correcta implementación de los event listeners de phpBB. El archivo `event/main_listener.php` necesitará ser creado e implementado para esto.
-   **Manejo de Errores y Logs:** Se han añadido logs básicos. Un manejo de errores más granular y mensajes más informativos para el usuario/admin pueden ser necesarios.
-   **Escalabilidad de Indexación:** La indexación desde el ACP es síncrona y por lotes. Para foros muy grandes, un sistema de colas o trabajos en segundo plano sería más apropiado para evitar timeouts en el ACP.

## 10. Licencia

Esta extensión se distribuye bajo la licencia **GPL-2.0-only**, de acuerdo con el `composer.json`.

