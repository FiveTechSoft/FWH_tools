<?php

namespace acme\vectorsearch\acp;

class acme_vectorsearch_info
{
    public function module()
    {
        return [
            'filename'  => '\acme\vectorsearch\acp\acme_vectorsearch_module',
            'title'     => 'ACP_VECTORSEARCH_TITLE',
            'modes'     => [
                'settings'  => ['title' => 'ACP_VECTORSEARCH_SETTINGS', 'auth' => 'acl_a_board', 'cat' => ['ACP_CAT_DOT_MODS']],
                'index'     => ['title' => 'ACP_VECTORSEARCH_INDEXING', 'auth' => 'acl_a_board', 'cat' => ['ACP_CAT_DOT_MODS']],
            ],
        ];
    }
}

