<?php

namespace acme\vectorsearch\acp;

use Symfony\Component\HttpFoundation\Request;

class acme_vectorsearch_module
{
    public $u_action;
    private $request;
    private $config;
    private $template;
    private $user;
    private $log;
    private $db;
    private $vector_search_service; // Will be injected via services.yml

    public function __construct(
        Request $request,
        \phpbb\config\config $config,
        \phpbb\template\template $template,
        \phpbb\user $user,
        \phpbb\log\log_interface $log,
        \phpbb\db\driver\driver_interface $db
        // The vector_search_service will be injected if defined in services.yml
    )
    {
        $this->request = $request;
        $this->config = $config;
        $this->template = $template;
        $this->user = $user;
        $this->log = $log;
        $this->db = $db;
    }

    // This method is necessary to allow phpBB to inject the service.
    // The name of the method should be set<ServiceName> where ServiceName is the camelCased version of the service ID in services.yml.
    public function setAcmeVectorsearchCoreVectorSearchService(\acme\vectorsearch\core\vector_search_service $service)
    {
        $this->vector_search_service = $service;
    }

    public function main($id, $mode)
    {
        $this->user->add_lang_ext("acme/vectorsearch", "acp_vectorsearch");
        $this->tpl_name = "acp_acme_vectorsearch_body";
        $form_key = "acme_vectorsearch_acp";
        add_form_key($form_key);

        $submit = $this->request->is_set_post("submit");

        switch ($mode)
        {
            case "settings":
                $this->page_title = $this->user->lang["ACP_VECTORSEARCH_SETTINGS"];

                $current_config = [
                    "pinecone_api_key"         => $this->config["acme_vectorsearch_pinecone_api_key"],
                    "pinecone_env"             => $this->config["acme_vectorsearch_pinecone_env"],
                    "pinecone_index_name"    => $this->config["acme_vectorsearch_pinecone_index_name"],
                    "pinecone_dimension"       => $this->config["acme_vectorsearch_pinecone_dimension"],
                    "embedding_api_key"      => $this->config["acme_vectorsearch_embedding_api_key"], // Example for a generic embedding API
                    "embedding_model"        => $this->config["acme_vectorsearch_embedding_model"],   // Example
                    "forums_to_index"        => isset($this->config["acme_vectorsearch_forums_to_index"]) ? json_decode($this->config["acme_vectorsearch_forums_to_index"], true) : [],
                ];

                if ($submit)
                {
                    if (!check_form_key($form_key))
                    {
                        trigger_error($this->user->lang["FORM_INVALID"] . adm_back_link($this->u_action), E_USER_WARNING);
                    }

                    $new_config = [
                        "acme_vectorsearch_pinecone_api_key"         => $this->request->variable("pinecone_api_key", ""),
                        "acme_vectorsearch_pinecone_env"             => $this->request->variable("pinecone_env", ""),
                        "acme_vectorsearch_pinecone_index_name"    => $this->request->variable("pinecone_index_name", ""),
                        "acme_vectorsearch_pinecone_dimension"       => $this->request->variable("pinecone_dimension", 0),
                        "acme_vectorsearch_embedding_api_key"      => $this->request->variable("embedding_api_key", ""),
                        "acme_vectorsearch_embedding_model"        => $this->request->variable("embedding_model", ""),
                        "acme_vectorsearch_forums_to_index"        => json_encode($this->request->variable("forums_to_index", [0 => ""]) ),
                    ];
                    
                    foreach ($new_config as $key => $value)
                    {
                        $this->config->set($key, $value);
                    }
                    $this->log->add("admin", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_SETTINGS_UPDATED");
                    trigger_error($this->user->lang["ACP_VECTORSEARCH_SETTINGS_SAVED"] . adm_back_link($this->u_action));
                }

                // Get forums for multi-select
                $sql = "SELECT forum_id, forum_name FROM " . FORUMS_TABLE . " ORDER BY left_id ASC";
                $result = $this->db->sql_query($sql);
                $forums_options = [];
                while ($row = $this->db->sql_fetchrow($result))
                {
                    $forums_options[$row["forum_id"]] = $row["forum_name"];
                }
                $this->db->sql_freeresult($result);

                $this->template->assign_vars([
                    "U_ACTION"                  => $this->u_action,
                    "PINECONE_API_KEY"          => $current_config["pinecone_api_key"],
                    "PINECONE_ENV"              => $current_config["pinecone_env"],
                    "PINECONE_INDEX_NAME"     => $current_config["pinecone_index_name"],
                    "PINECONE_DIMENSION"        => $current_config["pinecone_dimension"],
                    "EMBEDDING_API_KEY"       => $current_config["embedding_api_key"],
                    "EMBEDDING_MODEL"         => $current_config["embedding_model"],
                    "S_FORUMS_OPTIONS"          => $forums_options,
                    "SELECTED_FORUMS"           => $current_config["forums_to_index"],
                    "L_SETTINGS_EXPLAIN"        => $this->user->lang["ACP_VECTORSEARCH_SETTINGS_EXPLAIN"],
                ]);
                break;

            case "index":
                $this->page_title = $this->user->lang["ACP_VECTORSEARCH_INDEXING"];
                $start_indexing = $this->request->variable("start_indexing", 0);
                $index_status = "";

                if ($start_indexing && $this->vector_search_service)
                {
                    if (!check_form_key($form_key))
                    {
                        trigger_error($this->user->lang["FORM_INVALID"] . adm_back_link($this->u_action), E_USER_WARNING);
                    }
                    $forum_ids_to_index = isset($this->config["acme_vectorsearch_forums_to_index"]) ? json_decode($this->config["acme_vectorsearch_forums_to_index"], true) : [];
                    if (empty($forum_ids_to_index) || (count($forum_ids_to_index) == 1 && empty($forum_ids_to_index[0])) ) {
                         trigger_error($this->user->lang["ACP_VECTORSEARCH_INDEXING_NO_FORUMS"] . adm_back_link($this->u_action), E_USER_WARNING);
                    }
                    
                    // Basic batching, for a real scenario, you might need a more robust queue or background job system
                    $limit = 100; // Posts per batch
                    $offset = 0;
                    $total_indexed_successfully = 0;
                    $total_processed = 0;
                    $total_failed = 0;

                    // Loop for batching - this is a simplified synchronous loop for ACP.
                    // For large forums, this should be an asynchronous process.
                    do {
                        $result_batch = $this->vector_search_service->index_posts($forum_ids_to_index, $limit, $offset);
                        $total_processed += $result_batch["processed"];
                        $total_indexed_successfully += $result_batch["success"];
                        $total_failed += $result_batch["failed"];
                        $offset += $limit;
                        if ($result_batch["processed"] < $limit) {
                            break; // No more posts or last batch
                        }
                        // Optional: Add a small delay or check execution time to prevent timeouts in ACP
                    } while ($result_batch["processed"] > 0);

                    $index_status = sprintf($this->user->lang["ACP_VECTORSEARCH_INDEXING_STATUS"], $total_indexed_successfully, $total_processed, $total_failed);
                    $this->log->add("admin", $this->user->data["user_id"], $this->user->ip, "LOG_VECTORSEARCH_INDEXING_MANUAL_RUN", $index_status);
                    trigger_error($index_status . adm_back_link($this->u_action));
                }
                
                // Get Pinecone index stats if service is available
                $pinecone_stats_str = $this->user->lang["ACP_VECTORSEARCH_STATS_UNAVAILABLE"];
                if ($this->vector_search_service && $this->vector_search_service->pinecone_wrapper) {
                    $stats = $this->vector_search_service->pinecone_wrapper->get_index_stats();
                    if ($stats && isset($stats["totalVectorCount"])) {
                        $pinecone_stats_str = sprintf($this->user->lang["ACP_VECTORSEARCH_STATS_AVAILABLE"], 
                            $stats["totalVectorCount"],
                            $stats["dimension"],
                            // Add more stats as available and needed
                            implode(", ", array_keys($stats["namespaces"] ?? []))
                        );
                    } else if ($stats === null && !empty($this->config["acme_vectorsearch_pinecone_api_key"])) {
                         $pinecone_stats_str = $this->user->lang["ACP_VECTORSEARCH_STATS_ERROR_CHECK_LOGS"];
                    }
                }

                $this->template->assign_vars([
                    "U_ACTION"                  => $this->u_action,
                    "L_INDEXING_EXPLAIN"        => $this->user->lang["ACP_VECTORSEARCH_INDEXING_EXPLAIN"],
                    "INDEX_STATUS"              => $index_status,
                    "PINECONE_STATS"            => $pinecone_stats_str,
                ]);
                break;

            default:
                trigger_error("NO_MODE", E_USER_ERROR);
                break;
        }
    }
}

