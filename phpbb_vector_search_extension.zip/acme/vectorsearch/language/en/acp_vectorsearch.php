<?php

if (empty($lang) || !is_array($lang))
{
    $lang = [];
}

$lang = array_merge($lang, [
    "ACP_VECTORSEARCH_TITLE"                => "Vector Search Configuration",
    "ACP_VECTORSEARCH_SETTINGS"             => "Settings",
    "ACP_VECTORSEARCH_SETTINGS_EXPLAIN"     => "Configure the connection to your Pinecone vector database and other related settings.",
    "ACP_VECTORSEARCH_INDEXING"             => "Indexing Management",
    "ACP_VECTORSEARCH_INDEXING_EXPLAIN"     => "Manage the indexing process for your forum content. Ensure your Pinecone index is created with the correct dimension before starting.",
    "ACP_VECTORSEARCH_SETTINGS_SAVED"       => "Vector search settings saved successfully.",
    "LOG_VECTORSEARCH_SETTINGS_UPDATED"   => "<strong>Vector search settings updated.</strong>",
    "LOG_VECTORSEARCH_CONFIG_MISSING"     => "<strong>Vector Search Error:</strong> Pinecone configuration (API Key, Environment, or Index Name) is missing.",
    "LOG_VECTORSEARCH_PINECCONE_ERROR"    => "<strong>Vector Search Pinecone Error:</strong> %s",
    "LOG_VECTORSEARCH_PINECCONE_UPSERT_ERROR" => "<strong>Vector Search Pinecone Error:</strong> Upsert failed. %s",
    "LOG_VECTORSEARCH_PINECCONE_QUERY_ERROR"  => "<strong>Vector Search Pinecone Error:</strong> Query failed. %s",
    "LOG_VECTORSEARCH_PINECCONE_DELETE_ERROR" => "<strong>Vector Search Pinecone Error:</strong> Delete failed. %s",
    "LOG_VECTORSEARCH_PINECCONE_STATS_ERROR"  => "<strong>Vector Search Pinecone Error:</strong> Failed to get index stats. %s",
    "LOG_VECTORSEARCH_PINECCONE_INDEX_CREATE_INFO" => "<strong>Vector Search Pinecone Info:</strong> %s",
    "LOG_VECTORSEARCH_PINECCONE_INDEX_MGMT_ERROR" => "<strong>Vector Search Pinecone Error:</strong> Index management failed. %s",
    "LOG_VECTORSEARCH_EMBEDDING_WARN"       => "<strong>Vector Search Embedding Warning:</strong> %s",
    "LOG_VECTORSEARCH_EMBEDDING_ERROR"      => "<strong>Vector Search Embedding Error:</strong> %s",
    "LOG_VECTORSEARCH_INDEX_SKIP_NO_TEXT"   => "<strong>Vector Search Indexing:</strong> Skipped post ID %s (no text after cleaning).",
    "LOG_VECTORSEARCH_INDEX_EMBED_FAIL"     => "<strong>Vector Search Indexing:</strong> Failed to generate embedding for post ID %s.",
    "LOG_VECTORSEARCH_INDEX_UPSERT_FAIL_BATCH" => "<strong>Vector Search Indexing:</strong> Failed to upsert a batch of vectors to Pinecone.",
    "LOG_VECTORSEARCH_INDEX_UPSERT_FAIL_REMAINING" => "<strong>Vector Search Indexing:</strong> Failed to upsert remaining vectors to Pinecone.",
    "LOG_VECTORSEARCH_INDEX_BATCH_COMPLETE" => "<strong>Vector Search Indexing Batch Complete:</strong> %s",
    "LOG_VECTORSEARCH_INDEXING_MANUAL_RUN"  => "<strong>Vector Search Indexing:</strong> Manual run completed. %s",
    "ACP_VECTORSEARCH_INDEXING_STATUS"      => "Indexing Status: Successfully indexed %d posts out of %d processed. Failed: %d.",
    "ACP_VECTORSEARCH_INDEXING_NO_FORUMS"   => "Cannot start indexing. No forums selected for indexing in settings.",
    "ACP_VECTORSEARCH_STATS_UNAVAILABLE"    => "Pinecone index statistics are currently unavailable. Ensure settings are correct and the service is reachable.",
    "ACP_VECTORSEARCH_STATS_AVAILABLE"      => "Pinecone Index Stats: Total Vectors: %s, Dimension: %s, Namespaces: %s.",
    "ACP_VECTORSEARCH_STATS_ERROR_CHECK_LOGS" => "Could not retrieve Pinecone index statistics. Please check your API key, environment, index name, and ensure the index exists. Consult the admin log for more details.",

    // Form fields
    "ACP_VECTORSEARCH_PINECONE_API_KEY"         => "Pinecone API Key",
    "ACP_VECTORSEARCH_PINECONE_API_KEY_EXPLAIN" => "Enter your Pinecone API key.",
    "ACP_VECTORSEARCH_PINECONE_ENV"             => "Pinecone Environment",
    "ACP_VECTORSEARCH_PINECONE_ENV_EXPLAIN"     => "Enter your Pinecone environment (e.g., us-west1-gcp).",
    "ACP_VECTORSEARCH_PINECONE_INDEX_NAME"    => "Pinecone Index Name",
    "ACP_VECTORSEARCH_PINECONE_INDEX_NAME_EXPLAIN" => "Enter the name of your Pinecone index.",
    "ACP_VECTORSEARCH_PINECONE_DIMENSION"       => "Pinecone Index Dimension",
    "ACP_VECTORSEARCH_PINECONE_DIMENSION_EXPLAIN" => "Enter the dimension of the vectors in your Pinecone index (e.g., 768, 1536). This must match your embedding model.",
    "ACP_VECTORSEARCH_EMBEDDING_API_KEY"        => "Embedding Service API Key (Optional)",
    "ACP_VECTORSEARCH_EMBEDDING_API_KEY_EXPLAIN" => "If using an external service for embeddings (e.g., OpenAI), enter its API key here.",
    "ACP_VECTORSEARCH_EMBEDDING_MODEL"          => "Embedding Model Name (Optional)",
    "ACP_VECTORSEARCH_EMBEDDING_MODEL_EXPLAIN"  => "Specify the model name if using an external embedding service (e.g., text-embedding-ada-002).",
    "ACP_VECTORSEARCH_FORUMS_TO_INDEX"          => "Forums to Index",
    "ACP_VECTORSEARCH_FORUMS_TO_INDEX_EXPLAIN"  => "Select the forums whose posts you want to index for vector search.",
    "ACP_VECTORSEARCH_START_INDEXING_BUTTON"    => "Start Full Re-index",
]);

