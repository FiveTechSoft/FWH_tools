#------------------------------------------------------------------------------
# Proyecto: Control debug
# Fichero: ejforall.ch
# Descripción: Include para todos los ejemplos
# Autor: Manu Exposito 2014-21
# Fecha: 11/11/2020
#------------------------------------------------------------------------------
#!/bin/bash

cd $HOME/desarrollo/proyectos/thbrdd/test
if [ -f hb_out.log ]
then
    rm hb_out.log
fi
hbmk2 -comp=clang -b -l-hbvm -lhbvm_dbg $1 genexe.hbp
if [ $? -eq 0 ]
then
    ./demo
    if [ -f hb_out.log ]
    then
        echo --------------------------------------------------------------------
        echo -                             ATENCION                             -
        echo --------------------------------------------------------------------
        echo -                     Hay perdidas de memoria...                   -
        echo -                 Para verlo mira el fichero hb_out.log            -
        echo --------------------------------------------------------------------
    else
        echo --------------------------------------------------------------------
        echo -                 No hay perdidas de memoria...                    -
        echo --------------------------------------------------------------------
    fi
else
    echo -------------------------------------------------------------------------
    echo Se ha producido un error...
    echo -------------------------------------------------------------------------
fi
