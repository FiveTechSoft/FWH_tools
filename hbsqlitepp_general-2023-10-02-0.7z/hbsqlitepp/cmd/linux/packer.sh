ficname=$(date +"$1_general-%Y-%m-%d-1")
cd ..
7z a -s -x*\.hbmk -x*/lib -x*.log -x*demo -x*.dbf -x*.db $HOME/Descargas/$ficname $1