//-----------------------------------------------------------------------------
// Archivo: hbsqlitepp.h
// Autor: Manu Exposito
//-----------------------------------------------------------------------------

#pragma once
#ifndef HBSQLITEPP_H
#define HBSQLITEPP_H

//-----------------------------------------------------------------------------
// includes:

#include <hbobject.h> // de HbObejct
#include "sqlite3.h" // de sqlite

//-----------------------------------------------------------------------------
// Para facilitar la obtencion del objeto C

#define _GETOBJC0() static_cast<THbSQLitepp *>( THbObject::getObjC() )
#define _GETOBJC1( pSelf ) static_cast<THbSQLitepp *>( THbObject::getObjC( pSelf ) )

//-----------------------------------------------------------------------------
// Constantes:

const HB_SIZE _OBJC_POS = 1;
const HB_UINT _NUN_VARS = 1;

//-----------------------------------------------------------------------------
// Clase C++

class THbSQLitepp : public THbObject 
{
	private:
		//---------------------------------------------------------------------
		// Propiedades privadas del objeto C++:
		sqlite3 *db;
		char *szDbName;
	public:
		// Constructor y destructor desde C++:
		THbSQLitepp( void );
		~THbSQLitepp( void );		
		//---------------------------------------------------------------------
		// Metodos override:
		void init( void ) override;
		void init( PHB_ITEM ) override;
		void addMethods( HB_USHORT ) const override;
		//---------------------------------------------------------------------
		// Gestion real del objeto:
		bool open( void );
		void close( void ) const;
		bool exec( const char *szStmt );
		PHB_ITEM query( const char *szQuery, PHB_ITEM aColName );
		const char *getLastError( void );
		int getErrCode( void );
};

//-----------------------------------------------------------------------------
// Declaración de funciones públicas. (Si hay, poner aquí)
	
//-----------------------------------------------------------------------------

#endif      // Fin de HBSQLITEPP_H

//-----------------------------------------------------------------------------
