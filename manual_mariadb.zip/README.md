# Manual de MariaDB para FiveWin / Harbour

*Guía Práctica de Conexión, Consultas y Manejo de Datos*

Basado en los ejemplos oficiales de FiveWin y el código fuente de `fwmaria.prg` y `mariarec.prg`

**Versión 2025**

---

## Índice

| Cap. | Título | Fichero |
|------|--------|---------|
| 1 | [Introducción](01_introduccion.md) | `01_introduccion.md` |
| 2 | [Conexión a MariaDB](02_conexion.md) | `02_conexion.md` |
| 3 | [Comandos y Funciones Principales](03_comandos_funciones.md) | `03_comandos_funciones.md` |
| 4 | [RowSet: Consultas y Edición de Datos](04_rowset.md) | `04_rowset.md` |
| 5 | [Operaciones CRUD](05_crud.md) | `05_crud.md` |
| 6 | [Manejo de Tablas](06_manejo_tablas.md) | `06_manejo_tablas.md` |
| 7 | [Relaciones Padre-Hijo](07_relaciones_padre_hijo.md) | `07_relaciones_padre_hijo.md` |
| 8 | [Funciones Avanzadas](08_funciones_avanzadas.md) | `08_funciones_avanzadas.md` |
| 9 | [Encriptación AES](09_encriptacion_aes.md) | `09_encriptacion_aes.md` |
| 10 | [Datos Espaciales (GEO)](10_datos_espaciales.md) | `10_datos_espaciales.md` |
| 11 | [Unicode y Codificaciones](11_unicode.md) | `11_unicode.md` |
| 12 | [Importar DBF a MariaDB](12_importar_dbf.md) | `12_importar_dbf.md` |
| 13 | [FWMariaRecord: Edición de Registros](13_fwmariarecord.md) | `13_fwmariarecord.md` |
| 14 | [Comparación FWH vs ADO vs Dolphin](14_comparacion.md) | `14_comparacion.md` |
| 15 | [RecSet: Tablas Grandes y Rendimiento](15_recset_rendimiento.md) | `15_recset_rendimiento.md` |
| 16 | [Bloqueo de Registros (Locking)](16_bloqueo_registros.md) | `16_bloqueo_registros.md` |
| 17 | [Replicación entre Servidores](17_replicacion.md) | `17_replicacion.md` |
| 18 | [Sincronización DBF ↔ MariaDB](18_sincronizacion_dbf.md) | `18_sincronizacion_dbf.md` |
| 19 | [Totales Acumulados (Running Totals)](19_totales_acumulados.md) | `19_totales_acumulados.md` |
| 20 | [Query Browser Interactivo](20_query_browser.md) | `20_query_browser.md` |
| 21 | [Portar una App de DBF a MariaDB](21_portar_dbf_a_mariadb.md) | `21_portar_dbf_a_mariadb.md` |
| 22 | [Referencia Rápida y Constantes](22_referencia_rapida.md) | `22_referencia_rapida.md` |
| 23 | [Clase TField: Metadatos de Campos](23_clase_tfield.md) | `23_clase_tfield.md` |

---

## Programas de Ejemplo Incluidos

| Ejemplo | Descripción |
|---------|-------------|
| `maria01.prg` | Listar tablas y ver contenido con doble-click |
| `maria02.prg` | JOIN izquierdo con edición en XBrowse |
| `maria03.prg` | Tablas Pivot con inversión de filas/columnas |
| `maria04.prg` | Relaciones padre-hijo (2 métodos) |
| `maria05.prg` | Comparación FWH vs Dolphin vs ADO |
| `maria06.prg` | Importar DBF con collation español |
| `maria07.prg` | Cargar información de zonas horarias |
| `maria08.prg` | Actualizar resúmenes master-detail |
| `maria09.prg` | Auto-append con valores por defecto y columnas computadas |
| `maria10.prg` | RecSet para tabla con millones de registros |
| `maria11.prg` | Unicode con triggers automáticos |
| `maria12.prg` | Running totals (saldos acumulados) |
| `maria14.prg` | Benchmark de rendimiento ADO vs FWH vs Dolphin |
| `maria15.prg` | EditBaseRecord con formulario personalizado |
| `maria16.prg` | Padre con 2 hijos usando SetFilter/ReFilter |
| `mariaaes.prg` | Cifrado AES de campos sensibles |
| `mariabig.prg` | RecSet paginado para tabla con millones de registros |
| `mariageo.prg` | Tipo POINT y cálculo de distancias geográficas |
| `mariainv.prg` | Sistema de facturación completo |
| `marialok.prg` | Bloqueo pesimista con FOR UPDATE |
| `mariaqry.prg` | Query Browser interactivo con re-query dinámico |
| `mariarpl.prg` | Replicación de cambios entre dos servidores |
| `mariasyn.prg` | Sincronización DBF → MariaDB en tiempo real |

---

*Documentación adicional y foro de soporte: https://forums.fivetechsupport.com*
