# 11. Unicode y Codificaciones

[← GEO](10_datos_espaciales.md) | [Índice](README.md) | [Siguiente: Importar DBF →](12_importar_dbf.md)

---

## 11.1 Activar Unicode

```clipper
FW_SetUnicode( .t. )   // activar ANTES de conectar
oCn := maria_Connect( "localhost", "mibd", "user", "pass" )
```

## 11.2 Charset por tabla y por campo — `maria11.prg`

```clipper
// Tabla con charset utf8 y campos con charset individual
oCn:CreateTable( "testunicode", { ;
   { "language",     'C', 15, 0, "latin1 comment 'case:upper'" }, ;
   { "unicodetext",  'C', 40, 0, "utf8" }, ;
   { "entrymode",    'C', 20, 0, "latin1 comment 'case:proper'" }, ;
   { "username",     'C', 30, 0, "utf8" }, ;
   { "writedt",      '=',  8, 0 } }, nil, "utf8" )
```

## 11.3 Charset en ImportFromDbf

```clipper
oCn:ImportFromDbf( "clientes.dbf",,,,,,  "utf8_spanish2_ci" )
```

## 11.4 Triggers para registrar usuario automáticamente

```clipper
TEXT INTO cSql
CREATE TRIGGER testunicode_bi BEFORE INSERT ON testunicode
FOR EACH ROW
BEGIN
   SET NEW.username = SUBSTRING( CONCAT_WS( ', ', @os_user, @pc_name ), 1, 30 );
END
ENDTEXT

oCn:Execute( "DROP TRIGGER IF EXISTS testunicode_bi" )
oCn:Execute( cSql )

// También para UPDATE
TEXT INTO cSql
CREATE TRIGGER testunicode_bu BEFORE UPDATE ON testunicode
FOR EACH ROW
BEGIN
   SET NEW.username = SUBSTRING( CONCAT_WS( ', ', @os_user, @pc_name ), 1, 30 );
END
ENDTEXT

oCn:Execute( "DROP TRIGGER IF EXISTS testunicode_bu" )
oCn:Execute( cSql )
```

## 11.5 Ejemplo con browse Unicode

```clipper
FW_SetUnicode( .T. )
oCn := FW_DemoDB( 1 )

oRs := oCn:testunicode
oRs:Fields( "username" ):lReadOnly := .t.  // campo auto-rellenado por trigger
oRs:lAutoAppend := .t.

XBROWSER oRs FASTEDIT TITLE "Unicode Text" SETUP ( ;
   oBrw:lCanPaste := .t., ;
   oBrw:bChange   := { || oRs:ReSync(), oBrw:RefreshCurrent() }, ;
   oBrw:bGotFocus := { || If( oRs:Refresh() > 0, oBrw:Refresh(), nil ) } )
```

## 11.6 Notas internas sobre Unicode

En `fwmaria.prg`, el manejo de Unicode incluye:
- Ajuste automático de longitudes de campo para UTF-8 (dividiendo entre 3 si el charset es 33/utf8)
- Función `FWMARIA_LCMESSAGES()` para activar/desactivar mensajes localizados del servidor
- Función `FWMARIA_SET_PAD_CHAR_TO_FULL_LENGTH()` para padding de campos CHAR
- La variable estática `lSetLanguage` controla si se envía `SET lc_messages` al conectar

---

# 12. Importar DBF a MariaDB

[← Unicode](11_unicode.md) | [Índice](README.md) | [Siguiente: FWMariaRecord →](13_fwmariarecord.md)

---

FiveWin permite importar directamente tablas DBF a MariaDB con un solo método, preservando la estructura y los datos.

## 12.1 Importación básica — `maria06.prg`

```clipper
RDDSETDEFAULT( "DBFCDX" )
SET DELETED ON
SET DATE ITALIAN
SET CENTURY ON
HB_CDPSELECT( "ESWIN" )
HB_LangSelect( "ES" )
FW_SetUnicode( .f. )

oCn := FW_DemoDB()
oCn:lLogErr := .t.               // registrar errores en archivo .log

oCn:ImportFromDbf( "nombres.dbf",,,,,,  "utf8_spanish2_ci" )

// Verificar resultado
oRs := oCn:RowSet( "nombres" )
XBROWSER oRs FASTEDIT AUTOSORT

oCn:Close()

// Revisar log de errores si existe
if File( cFileSetExt( ExeName(), "log" ) )
   WinExec( "notepad.exe " + cFileSetExt( ExeName(), "log" ) )
endif
```

## 12.2 Proceso recomendado de migración

1. Conectar a MariaDB con `oCn`
2. Activar log: `oCn:lLogErr := .t.`
3. Llamar a `oCn:ImportFromDbf()` para cada tabla DBF
4. Revisar el archivo `.log` por si hubiera errores de conversión
5. Verificar los datos importados con `XBROWSER oCn:RowSet( cTabla )`
6. Ajustar charsets si hay problemas con caracteres especiales

## 12.3 Copiar tabla entre servidores

```clipper
oMain := FW_DemoDB()
oRepl := FW_DemoDB( 6 )

// Copiar tabla completa de un servidor a otro
oMain:CopyTableToServer( "states", oRepl )
```
