# 10. Datos Espaciales (GEO)

[← AES](09_encriptacion_aes.md) | [Índice](README.md) | [Siguiente: Unicode →](11_unicode.md)

---

Requiere MariaDB/MySQL 5.7.1+. Soporta tipo `POINT` y funciones geométricas.

Ver sección completa en [Capítulo 9](09_encriptacion_aes.md#10-datos-espaciales-geo) (incluido junto con AES).
