# 8. Funciones Avanzadas

[← Padre-Hijo](07_relaciones_padre_hijo.md) | [Índice](README.md) | [Siguiente: AES →](09_encriptacion_aes.md)

---

## 8.1 AutoAppend: agregar registros desde el browse — `maria09.prg`

```clipper
oRs := oCn:RowSet( "SELECT * FROM detalle WHERE docid = ?", { nDocId } )
oRs:lAutoAppend := .t.              // habilita agregar con flecha abajo
oRs:SetDefault( "docid", nDocId )   // valor fijo para campo clave

// Para cambiar de documento más tarde:
// oRs:ReQuery( { nOtherDocId } )
// oRs:SetDefault( "docid", nOtherDocId )

XBROWSER oRs FASTEDIT TITLE "Detalle del documento" ;
   SETUP SetUpBrowse( oBrw )

static function SetUpBrowse( oBrw )
   WITH OBJECT oBrw
      // Color diferente para fila en proceso de agregar
      :bClrRowFocus := { || If( oBrw:oDbf:ID == 0, ;
         { CLR_BLACK, 0xAEEDFF }, { CLR_BLACK, RGB(185,220,255) } ) }
      // Totales en footers
      :lFooter := .t.
      :qty:nFooterType    := AGGR_SUM
      :Amount:nFooterType := AGGR_SUM
      :MakeTotals()
      // Mensaje cuando no hay datos
      :bPainted := { |dc,ps,brw| If( brw:nLen == 0, ;
         brw:SayText( "Press Down Arrow to Start" ), nil ) }
   END
return nil
```

## 8.2 EditBaseRecord: editar registro completo — `maria15.prg`

Cuando el RowSet contiene solo algunas columnas, `EditBaseRecord()` permite editar el registro completo de la tabla base con un formulario personalizado.

```clipper
oRs := oCn:RowSet( "SELECT ID,FIRST,CITY,SALARY FROM customer" )

// Botones para agregar y editar
@ 20, 20 BTNBMP PROMPT "ADD"  SIZE 100,30 PIXEL FLAT OF oDlg ;
   ACTION oRs:EditBaseRecord( nil, .t., { |oRec| MyEditDlg( oRec ) }, oBrw )

@ 20,130 BTNBMP PROMPT "EDIT" SIZE 100,30 PIXEL FLAT OF oDlg ;
   ACTION oRs:EditBaseRecord( nil, .f., { |oRec| MyEditDlg( oRec ) }, oBrw, .t. )
// Parámetros: cFieldList, lAppend, bEditDlg, oBrw [, lLock]

static function MyEditDlg( oRec )
   local lNew := ( oRec:RecNo == 0 )

   DEFINE DIALOG oDlg SIZE 400,470 PIXEL TRUEPIXEL FONT oFont ;
      TITLE If( lNew, "ADD NEW", "EDIT" ) + " RECORD"

   @ 060,120 GET oRec:First   SIZE 240,22 PIXEL OF oDlg VALID !Empty(oRec:First)
   @ 090,120 GET oRec:Last    SIZE 240,22 PIXEL OF oDlg VALID !Empty(oRec:Last)
   @ 120,120 GET oRec:Street  SIZE 240,22 PIXEL OF oDlg
   @ 150,120 GET oRec:City    SIZE 240,22 PIXEL OF oDlg
   @ 240,120 GET oRec:HireDate SIZE 240,22 PIXEL OF oDlg
   @ 270,120 CHECKBOX oRec:Married PROMPT "" SIZE 22,22 PIXEL OF oDlg
   @ 300,120 GET oRec:Age     SIZE 240,22 PIXEL OF oDlg PICTURE "99" RIGHT
   @ 330,120 GET oRec:Salary  SIZE 240,22 PIXEL OF oDlg PICTURE "999,999.99" RIGHT

   // DBCOMBO para seleccionar estado de una lista
   @ 180,120 DBCOMBO oRec:State SIZE 240,300 PIXEL OF oDlg ;
      ALIAS aStates ITEMFIELD "1" LISTFIELD "2"

   @ 420,020 BTNBMP PROMPT "Save" SIZE 150,30 PIXEL FLAT OF oDlg ;
      ACTION ( If( oRec:Modified(), oRec:Save(), nil ), oDlg:End() ) ;
      WHEN oRec:Modified()

   @ 420,240 BTNBMP PROMPT "Cancel" SIZE 150,30 PIXEL FLAT OF oDlg ;
      ACTION oDlg:End()

   ACTIVATE DIALOG oDlg CENTERED
return nil
```

## 8.3 Tabla Pivot — `maria03.prg`

```clipper
// Generar tabla pivot
// Parámetros: tabla, campo_fila, campo_columna, campo_valor, función_agregación
aPivot := oCn:PivotArray( "ventas", "region", "producto", "importe", "SUM" )
// La función de agregación puede ser: "SUM", "COUNT", "AVG"

// Mostrar e invertir ejes
@ 30,10 XBROWSE oBrw SIZE -10,-10 PIXEL OF oDlg ;
   DATASOURCE aPivot AUTOCOLS CELL LINES FOOTERS NOBORDER

WITH OBJECT oBrw
   :bRClicked := { || oBrw:InvertPivot() }   // click derecho invierte
   :CreateFromCode()
END

// Botón para invertir
@ 08,10 BTNBMP PROMPT "Change View" PIXEL OF oDlg FLAT ;
   ACTION ( oBrw:InvertPivot(), oBrw:SetFocus() )
```

## 8.4 Batch Mode — ediciones masivas

```clipper
oRs:SetBatchMode( .t. )     // activar modo batch
// ... múltiples ediciones ...
oRs:SaveBatch()              // guardar todo de una vez
// o
oRs:CancelBatch()            // cancelar todas las ediciones
? oRs:IsBatchEdited()        // .t. si hay cambios pendientes
```

## 8.5 Carga de zonas horarias — `maria07.prg`

```clipper
FWCONNECT oCn HOST cHost USER cUser PASSWORD cPassword DATABASE "mysql"
oCn:lLogErr := .t.

// Cargar archivo timezone_posix.sql (descargable de dev.mysql.com)
hFile := FOpen( "timezone_posix.sql", 0 )
cText := FReadStr( hFile, FileSize( "timezone_posix.sql" ) + 10000 )

// Ejecutar cada sentencia del archivo
do while ( nUpto := HB_At( ";" + CHR(10), cText, nFrom ) ) > 0
   cSql  := SubStr( cText, nFrom, nUpto - nFrom )
   oCn:Execute( cSql )
   if oCn:nError != 0
      oCn:ShowError()
      exit
   endif
   nFrom := nUpto + 2
enddo
```
