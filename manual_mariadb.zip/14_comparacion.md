# 14. Comparación FWH vs ADO vs Dolphin

[← FWMariaRecord](13_fwmariarecord.md) | [Índice](README.md) | [Siguiente: RecSet →](15_recset_rendimiento.md)

---

Ver contenido completo en [Capítulo 13](13_fwmariarecord.md#14-comparación-fwh-vs-ado-vs-dolphin) (incluido junto con FWMariaRecord).
