# 3. Comandos y Funciones Principales

[← Conexión](02_conexion.md) | [Índice](README.md) | [Siguiente: RowSet →](04_rowset.md)

---

## 3.1 Resumen de métodos del objeto de conexión

| Método | Descripción |
|--------|-------------|
| `oCn:RowSet( cSQL [, aParams] )` | Ejecuta consulta y devuelve un RowSet editable |
| `oCn:RecSet( cTabla, nRecs )` | Lee n registros con paginación (tablas grandes) |
| `oCn:Query( cSQL )` | Ejecuta consulta (compatible TDolphin) |
| `oCn:Execute( cSQL )` | Ejecuta sentencia SQL sin resultado (INSERT, UPDATE, DELETE, CREATE...) |
| `oCn:QueryResult( cSQL )` | Devuelve el valor de la primera celda del resultado |
| `oCn:ListTables()` | Devuelve array con nombres de tablas de la BD |
| `oCn:TableExists( cTabla )` | Devuelve `.t.` si la tabla existe |
| `oCn:TableStructure( cTabla )` | Devuelve estructura de la tabla |
| `oCn:CreateTable( cTabla, aEstructura [, lPK] [, cCharset] )` | Crea una tabla nueva |
| `oCn:DropTable( cTabla )` | Elimina una tabla |
| `oCn:Insert( cTabla, cCampos, aData )` | Inserta uno o múltiples registros |
| `oCn:Upsert( cTabla, nil, aVals )` | INSERT ... ON DUPLICATE KEY UPDATE |
| `oCn:UpdateSummary( ... )` | Actualiza totales de tabla maestra desde detalle |
| `oCn:ImportFromDbf( cArchivo [,...] )` | Importa un archivo DBF a MariaDB |
| `oCn:CopyTableToServer( cTabla, oOtroCn )` | Copia tabla a otro servidor |
| `oCn:PivotArray( cTabla, cFila, cCol, cVal, cAggr )` | Genera tabla pivot |
| `oCn:BeginTransaction()` | Inicia transacción |
| `oCn:CommitTransaction()` | Confirma transacción |
| `oCn:RollBack()` | Revierte transacción |
| `oCn:SetAutoCommit( lVal )` | Activa/desactiva auto commit |
| `oCn:Close()` / `oCn:End()` | Cierra la conexión |
| `oCn:ShowError()` | Muestra el último error |
| `oCn:FieldsAndValsToSQL( aCols [, nil, lWhere] )` | Genera pares campo=valor para SQL |
| `oCn:ValToSql( uVal )` | Convierte valor Harbour a literal SQL |
| `oCn:ApplyParams( cSql, aParams )` | Sustituye `?` por valores en SQL |
| `oCn:ReadNextResults()` | Lee resultados adicionales (multi-statement) |

## 3.2 Funciones públicas

| Función | Descripción |
|---------|-------------|
| `maria_Connect( ... )` | Conectar al servidor |
| `maria_ConnectError()` | Obtener error de la última conexión `{ nErr, cErr }` |
| `maria_Embedded( cDataFolder, cDB, cLangFolder )` | Conexión embebida (32 bits) |
| `mysql_RowSet( oCn, cSql )` | Crear RowSet (wrapper) |
| `fwmarialib_Version()` | Versión de la librería |
| `FW_SetUnicode( lSet )` | Activar/desactivar Unicode |
| `FWMARIA_LCMESSAGES( lSet )` | Activar/desactivar mensajes localizados |
| `FWMARIA_SET_PAD_CHAR_TO_FULL_LENGTH( lSet )` | Padding de campos CHAR |
| `FW_DemoDB( [nType] )` | Conectar al servidor de demostración |
| `MYSQL_TinyIntAsLogical( [lSet] )` | Tratar TINYINT como lógico |
| `MYSQL_MaxPadLimit( [nLimit] )` | Establecer límite de padding |

## 3.3 Configuración inicial recomendada

```clipper
#include "fivewin.ch"

function Main()
   local oCn

   SET DATE ITALIAN        // formato dd/mm/yyyy
   SET CENTURY ON
   FW_SetUnicode( .t. )    // habilitar Unicode
   FWNumFormat( "A", .t. ) // formato numérico con separadores

   oCn := maria_Connect( "localhost", "mibd", "usuario", "clave" )
   if oCn == nil
      MsgStop( "Error de conexión" )
      return nil
   endif

   oCn:lShowErrors := .t.

   // ... código de la aplicación ...

   oCn:Close()
return nil
```

## 3.4 Transacciones

```clipper
// Método 1: Desactivar auto-commit
oCn:SetAutoCommit( .f. )
// ... múltiples operaciones INSERT/UPDATE ...
oCn:SetAutoCommit( .t. )    // commit implícito

// Método 2: Transacciones explícitas
oCn:BeginTransaction()
oCn:Execute( "UPDATE cuentas SET saldo = saldo - 1000 WHERE id = 1" )
oCn:Execute( "UPDATE cuentas SET saldo = saldo + 1000 WHERE id = 2" )
if oCn:nError == 0
   oCn:CommitTransaction()
else
   oCn:RollBack()
endif
```

## 3.5 Llamar funciones del servidor

Las funciones creadas en el servidor pueden invocarse directamente como métodos del objeto de conexión:

```clipper
// Si existe la función 'distance_between' en el servidor:
? oCn:distance_between( "Madrid", "Paris" )
```
