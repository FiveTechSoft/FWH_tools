# 18. Sincronización DBF ↔ MariaDB

[← Replicación](17_replicacion.md) | [Índice](README.md) | [Siguiente: Running Totals →](19_totales_acumulados.md)

---

## 18.1 Replicación en tiempo real de DBF a MariaDB — `mariasyn.prg`

```clipper
function Main()
   local oCn, oDbf, oRs

   oCn := FW_DemoDB()

   MsgRun( "Setting up tables", "PLEASE WAIT", <||
      // Crear DBF con campo ID auto-incremento
      CreateDBF()

      // Importar el DBF a MariaDB
      oCn:DropTable( "statex" )
      oCn:ImportFromDBF( "statex.dbf" )

      // Abrir DBF y activar replicación
      oDbf := TDatabase():Open( nil, "statex", "DBFCDX", .t. )
      oDbf:SetReplicationServer( oCn )   // ← CLAVE

      // RowSet para ver réplica en tiempo real
      oRs := oCn:RowSet( "SELECT * FROM statex" )
      return nil
   > )

   // Mostrar ambos lado a lado
   DEFINE DIALOG oDlg SIZE 800,550 PIXEL TRUEPIXEL FONT oFont ;
      TITLE "DBF CHANGES Replication to MYSQL/MARIADB SERVER"

   @ 20,20 SAY "DBFCDX" SIZE 150,24 PIXEL OF oDlg
   @ 50,20 XBROWSE oBrw1 SIZE 350,-100 PIXEL OF oDlg ;
      DATASOURCE oDbf AUTOCOLS CELL LINES NOBORDER

   WITH OBJECT oBrw1
      :nEditTypes := EDIT_GET
      :bOnChanges := { || oSay:Refresh(), oRs:ReQuery(), ;
                          oBrw2:BookMark := oBrw1:BookMark, ;
                          oBrw2:Refresh() }
      :CreateFromCode()
   END

   @ 20,400 SAY "MARIADB" SIZE 150,24 PIXEL OF oDlg
   @ 50,400 XBROWSE oBrw2 SIZE 350,-100 PIXEL OF oDlg ;
      DATASOURCE oRs AUTOCOLS CELL LINES NOBORDER

   // Mostrar última SQL ejecutada
   @ 460,20 SAY "LAST SQL EXECUTED BY MARIADB SERVER"
   @ 490,20 SAY oSay PROMPT oCn:cLastSQL SIZE 760,50 PIXEL OF oDlg ;
      COLOR CLR_BLACK, CLR_YELLOW UPDATE

   ACTIVATE DIALOG oDlg CENTERED
return nil
```

Cada modificación en el DBF genera automáticamente el SQL correspondiente (INSERT/UPDATE/DELETE) y lo ejecuta en MariaDB. El SQL generado se puede ver en `oCn:cLastSQL`.

---

# 19. Totales Acumulados (Running Totals)

[← Sincronización](18_sincronizacion_dbf.md) | [Índice](README.md) | [Siguiente: Query Browser →](20_query_browser.md)

---

## 19.1 Saldos acumulados con variables SQL — `maria12.prg`

```clipper
TEXT INTO cSql
   SELECT id, ncli, fecha, descripcion, numero, tipo, importe,
   ( @bal := IF( tipo = '1', @bal + importe, @bal - importe ) ) AS nsaldo
   FROM ctacte,
   ( SELECT @bal := 0 ) AS t
   WHERE ncli = ?
   ORDER BY fecha
ENDTEXT

oRs := oCn:RowSet( cSql, { 101 } )   // parámetro: nCliente
oRs:GoBottom()

@ 50,20 XBROWSE oBrw SIZE -20,-20 PIXEL OF oDlg ;
   DATASOURCE oRs ;
   COLUMNS "id", "Fecha", "Descripcion", "Numero", ;
      "If( tipo == '1', importe, 0 )", ;
      "If( tipo == '1', 0, importe )", ;
      "nsaldo" ;
   HEADERS "DocID", nil, nil, nil, "DEBE", "PAGO", "SALDO" ;
   PICTURES "999", nil, nil, nil, ;
      "@EZ 999,999,999.99", "@EZ 999,999,999.99", "@EZ 999,999,999.99" ;
   CELL LINES NOBORDER FOOTERS FASTEDIT

WITH OBJECT oBrw
   // Columna DEBE editable con validación y recálculo
   :Debe:nFooterType := AGGR_SUM
   :Debe:bOnPostEdit := { |o,x,n| If( o == VK_ESCAPE .or. x < 0, nil, ;
      ( oRs:tipo := '1', oRs:importe := x ) ) }
   :Debe:bOnChange   := { || oRs:Requery(), oBrw:Refresh() }

   // Columna PAGO editable
   :Pago:nFooterType := AGGR_SUM
   :Pago:bOnPostEdit := { |o,x,n| If( o == VK_ESCAPE .or. x < 0, nil, ;
      ( oRs:tipo := '0', oRs:importe := x ) ) }
   :Pago:bOnChange   := { || oRs:Requery(), oBrw:Refresh() }

   // Footer de SALDO = DEBE - PAGO
   :Saldo:bFooter := { || oBrw:Debe:nTotal - oBrw:Pago:nTotal }

   :MakeTotals()
   :CreateFromCode()
END

// Botón eliminar con recálculo
@ 20,20 BTNBMP PROMPT "Delete" SIZE 60,20 PIXEL FLAT OF oDlg ;
   ACTION ( oRs:Delete(), oRs:ReQuery(), oBrw:MakeTotals(), ;
            oBrw:Refresh(), oBrw:SetFocus() )
```

El patrón `@bal := IF(...)` calcula el saldo acumulado directamente en el servidor.

---

# 20. Query Browser Interactivo

[← Running Totals](19_totales_acumulados.md) | [Índice](README.md) | [Siguiente: Portar DBF →](21_portar_dbf_a_mariadb.md)

---

## 20.1 Browser SQL dinámico — `mariaqry.prg`

```clipper
function Main()
   local oCn, oRs, cSql

   FW_SetUnicode( .t. )
   oCn := FW_DemoDB()

   cSql := "SELECT Now()"
   oRs  := oCn:RowSet( cSql )

   DEFINE DIALOG oDlg SIZE 900,700 PIXEL TRUEPIXEL FONT oFont ;
      TITLE FWVERSION + " : MySQL QUERY BROWSER"

   // Área de edición SQL
   @ 20,20 GET oGet VAR cSql MEMO SIZE 840,150 PIXEL OF oDlg UPDATE FONT oFixed

   // Al validar el GET, re-ejecutar el SQL
   oGet:bValid := <|o|
      if Upper( cSql ) == Upper( oRs:Source )
         return .t.
      endif
      CursorWait()
      if oRs:Requery( cSql )
         oRs:SetXbrColumns( oBrw )
         oBrw:nEditTypes := EDIT_GET
         oBrw:GoTop()
         oBrw:Refresh()
         return .t.
      endif
      MsgAlert( "Invalid SQL" )
      return .f.
   >

   // Browse con resultados
   @ 190,20 XBROWSE oBrw SIZE -20,-20 PIXEL OF oDlg ;
      DATASOURCE oRs AUTOCOLS CELL LINES NOBORDER FOOTERS FASTEDIT

   WITH OBJECT oBrw
      :bRecSelHeader := { || "RecNo" }
      :bRecSelData   := { |o| o:BookMark }
      :bRecSelFooter := { || oBrw:nLen }
      :nRecSelWidth  := "99999"
      :CreateFromCode()
   END

   ACTIVATE DIALOG oDlg CENTERED ON INIT oGet:SetFocus()
return nil
```

Permite escribir cualquier SQL en el GET superior y ver los resultados inmediatamente en el XBrowse inferior. Usa `oRs:Requery( cSql )` para cambiar dinámicamente la consulta, y `oRs:SetXbrColumns( oBrw )` para adaptar las columnas del browse al nuevo resultado.
