# 16. Bloqueo de Registros (Locking)

Ver contenido en [Capítulo 15](15_recset_rendimiento.md#16-bloqueo-de-registros-locking).

# 17. Replicación entre Servidores

Ver contenido en [Capítulo 15](15_recset_rendimiento.md#17-replicación-entre-servidores).
