# 23. Clase TField: Metadatos de Campos

Ver contenido en [Capítulo 22](22_referencia_rapida.md#23-clase-tfield-metadatos-de-campos).
