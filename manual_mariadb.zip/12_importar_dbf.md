# 12. Importar DBF a MariaDB

[← Unicode](11_unicode.md) | [Índice](README.md) | [Siguiente: FWMariaRecord →](13_fwmariarecord.md)

---

Ver contenido completo en [Capítulo 11](11_unicode.md#12-importar-dbf-a-mariadb) (incluido junto con Unicode).
