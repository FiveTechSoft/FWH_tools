# 7. Relaciones Padre-Hijo

[← Tablas](06_manejo_tablas.md) | [Índice](README.md) | [Siguiente: Avanzadas →](08_funciones_avanzadas.md)

---

## 7.1 Un padre con un hijo — `maria04.prg`

### Método 1: AddChild con SQL

```clipper
oStates := oCn:RowSet( "states" )
oStates:AddChild( "SELECT * FROM customer WHERE state = states.code" )

// Sincronizar al cambiar de registro padre
oBrwParent:bChange := { || oStates:SyncChild(), ;
                           oBrwChild:GoTop(), oBrwChild:Refresh() }
```

### Método 2: AddChild con RowSet existente

```clipper
oStates := oCn:RowSet( "states" )
oCust   := oCn:RowSet( "customer" )
oStates:AddChild( oCust, "state = states.code" )
```

### Ejemplo completo

```clipper
oStates := oCn:RowSet( "states" )
oStates:AddChild( "SELECT * FROM customer WHERE state = states.code" )

DEFINE DIALOG oDlg SIZE 900,600 PIXEL TRUEPIXEL FONT oFont ;
   TITLE "FWH MYSQL PARENT CHILD ROWSET"

@ 20,20 XBROWSE oBrwParent SIZE 250,-20 PIXEL OF oDlg ;
   DATASOURCE oStates COLUMNS "Code", "Name" CELL LINES NOBORDER

WITH OBJECT oBrwParent
   :nStretchCol := 2
   :bChange := { || oStates:SyncChild(), ;
                    oBrwChild:GoTop(), oBrwChild:Refresh() }
   :CreateFromCode()
END

@ 20,270 XBROWSE oBrwChild SIZE -20,-20 PIXEL OF oDlg ;
   DATASOURCE oStates:oChild ;
   COLUMNS "First", "City", "State", "Salary" CELL LINES NOBORDER

WITH OBJECT oBrwChild
   :CreateFromCode()
END

ACTIVATE DIALOG oDlg CENTERED
```

## 7.2 Un padre con dos hijos (SetFilter) — `maria16.prg`

```clipper
oRsState := oCn:RowSet( "SELECT * FROM states ORDER BY name" )
oRsCity  := oCn:RowSet( "SELECT id, state, city FROM customer ORDER BY state, city" )
oRsCust  := oCn:RowSet( "SELECT id, state, CONCAT_WS(', ', first, last) AS Name " + ;
            "FROM customer ORDER BY state, Name" )

// Filtros parametrizados vinculados al padre
oRsCity:SetFilter( "STATE = ?", { oRsState:code } )
oRsCust:SetFilter( "STATE = ?", { oRsState:code } )

// Al cambiar en el padre, re-filtrar ambos hijos
oBrwState:bChange := <||
   oRsCity:ReFilter( { oRsState:code } )
   oRsCust:ReFilter( { oRsState:code } )
   oBrwCity:Refresh()
   oBrwCust:Refresh()
   return nil
>

// Cada browse hijo tiene su cabecera
oBrwState:SetGroupHeader( "PARENT", 1, 2 )
oBrwCity:SetGroupHeader( "CHILD-1", 1, 2 )
oBrwCust:SetGroupHeader( "CHILD-2", 1, 2 )
```

## 7.3 También usando OrdSetRelation

```clipper
// Sintaxis alternativa (equivalente a AddChild)
oStates:OrdSetRelation( oChildRs, "state = ?", { oStates:code } )
```
