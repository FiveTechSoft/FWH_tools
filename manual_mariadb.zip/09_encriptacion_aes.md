# 9. Encriptación AES

[← Avanzadas](08_funciones_avanzadas.md) | [Índice](README.md) | [Siguiente: GEO →](10_datos_espaciales.md)

---

MariaDB incluye funciones nativas `AES_ENCRYPT()` y `AES_DECRYPT()` que permiten almacenar datos sensibles como contraseñas y credenciales de forma segura.

## 9.1 Crear tabla con campos encriptados — `mariaaes.prg`

```clipper
TEXT INTO cSql
CREATE TABLE `test_aes_encrypt` (
   `id`    int(11) NOT NULL AUTO_INCREMENT,
   `name`  varchar(20) DEFAULT NULL,
   `login` tinyblob,
   `pass`  varbinary(255),
   PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=latin1
ENDTEXT
oCn:Execute( cSql )
```

> **Nota:** Los campos encriptados deben ser de tipo `TINYBLOB`, `BLOB` o `VARBINARY`, ya que `AES_ENCRYPT()` produce datos binarios.

## 9.2 Insertar datos encriptados

```clipper
cSql := "INSERT INTO test_aes_encrypt ( name, login, pass ) VALUES ( " + ;
        "'andrew', AES_ENCRYPT( 'Andrew', 'myencryptkey' ), " + ;
        "AES_ENCRYPT( 'Pass123', 'myencryptkey' ) )"
oCn:Execute( cSql )

// Actualizar un campo encriptado
cSql := "UPDATE test_aes_encrypt SET pass = " + ;
        "AES_ENCRYPT( 'NewPass@456', 'myencryptkey' ) WHERE id = 1"
oCn:Execute( cSql )
```

## 9.3 Consultar con desencriptación

```clipper
cSql := "SELECT id, name, " + ;
        "AES_DECRYPT( login, 'myencryptkey' ) AS login, " + ;
        "AES_DECRYPT( pass, 'myencryptkey' ) AS pass " + ;
        "FROM test_aes_encrypt"
oRs := oCn:RowSet( cSql )
XBROWSER oRs
oRs:Close()
oCn:Close()
```

> **Seguridad:** La clave de encriptación nunca se almacena en la base de datos. Guárdala de forma segura en tu aplicación o en un archivo de configuración externo.

---

# 10. Datos Espaciales (GEO)

[← AES](09_encriptacion_aes.md) | [Índice](README.md) | [Siguiente: Unicode →](11_unicode.md)

---

MariaDB 5.7.1+ soporta el tipo de dato `POINT` y funciones geométricas para calcular distancias entre coordenadas geográficas.

## 10.1 Crear tabla y insertar coordenadas — `mariageo.prg`

```clipper
oCn:Execute( "CREATE TABLE citylatlong (" + ;
   "id INT AUTO_INCREMENT PRIMARY KEY, " + ;
   "city VARCHAR(20), pt POINT )" )

TEXT INTO cSql
INSERT INTO citylatlong (city, pt) VALUES
   ( "Hyd",    POINT( 78.4867, 17.3850 ) ),
   ( "Mumbai", POINT( 72.8777, 19.0760 ) ),
   ( "Delhi",  POINT( 77.1025, 20.7041 ) ),
   ( "London", POINT(  0.1278, 51.5074 ) ),
   ( "Paris",  POINT(  2.3522, 48.8566 ) ),
   ( "Madrid", POINT(  3.7038, 40.4168 ) )
ENDTEXT
oCn:Execute( cSql )
```

## 10.2 Crear función de distancia en el servidor

```clipper
oCn:Execute( "DROP FUNCTION IF EXISTS distance_between" )

TEXT INTO cSql
CREATE FUNCTION distance_between( city1 VARCHAR(20), city2 VARCHAR(20) )
RETURNS DOUBLE
BEGIN
   DECLARE p1 POINT;
   DECLARE p2 POINT;
   SELECT pt INTO p1 FROM citylatlong WHERE city = city1;
   SELECT pt INTO p2 FROM citylatlong WHERE city = city2;
   RETURN ST_Distance_Sphere( p1, p2 );
END;
ENDTEXT
oCn:Execute( cSql )
```

## 10.3 Usar desde FiveWin

```clipper
// Consultar coordenadas
oRs := oCn:RowSet( "SELECT id, city, X(pt) AS Longitude, " + ;
       "Y(pt) AS Lattitude FROM citylatlong" )
XBROWSER oRs

// Llamar función de distancia (resultado en metros)
? oCn:distance_between( "London", "Paris" )
? oCn:distance_between( "Madrid", "Paris" )
```
