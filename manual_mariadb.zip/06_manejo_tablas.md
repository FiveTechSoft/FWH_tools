# 6. Manejo de Tablas

[← CRUD](05_crud.md) | [Índice](README.md) | [Siguiente: Padre-Hijo →](07_relaciones_padre_hijo.md)

---

## 6.1 Crear tabla

```clipper
// Estructura: { nombre, tipo, longitud, decimales [, opciones] }
oCn:CreateTable( "clientes", { ;
   { "nombre",   'C', 30, 0 }, ;
   { "ciudad",   'C', 20, 0 }, ;
   { "salario",  'N', 10, 2, "DEFAULT 0" }, ;
   { "activo",   'L',  1, 0 }, ;
   { "fecha",    'D',  8, 0 }, ;
   { "notas",    'M',  0, 0 } } )
```

### Tipos de datos soportados

| Tipo FWH | Tipo MariaDB | Descripción |
|----------|-------------|-------------|
| `C` | VARCHAR | Carácter / texto corto |
| `N` | DECIMAL | Numérico |
| `D` | DATE | Fecha |
| `L` | TINYINT(1) | Lógico (booleano) |
| `M` | TEXT / BLOB | Memo / texto largo |
| `+` | INT AUTO_INCREMENT | Entero autoincrementable (clave primaria) |
| `=` | TIMESTAMP | Fecha/hora automática (se actualiza al modificar) |
| `@` | DATETIME | Fecha y hora |
| `^` | BLOB | Datos binarios |

## 6.2 Opciones especiales en columnas

```clipper
// Auto-increment (clave primaria automática — se añade siempre como campo "id")
{ "id", "+", 4, 0 }

// Timestamp automático (se actualiza al insertar/modificar)
{ "modificado", "=", 8, 0 }

// Comentarios para comportamiento especial
{ "codigo",  'C', 10, 0, "comment 'case:upper'" }   // fuerza mayúsculas
{ "nombre",  'C', 30, 0, "comment 'case:proper'" }   // primera letra mayúscula

// Con valor por defecto
{ "cantidad", 'N', 6, 3, "DEFAULT 1" }
{ "rate",     'N', 5, 2, "DEFAULT 10" }

// Columna computada (virtual)
{ "amount=qty*rate", 'N', 12, 2 }    // amount se calcula automáticamente

// Con charset específico por campo
{ "texto_utf8",  'C', 40, 0, "utf8" }
{ "texto_latin", 'C', 40, 0, "latin1" }
{ "idioma",      'C', 15, 0, "latin1 comment 'case:upper'" }

// Clave foránea (referencia a otra tabla)
{ "pid", "REFERENCES tabla_padre( id )" }
```

### Ejemplo avanzado — `maria09.prg`

```clipper
oCn:CreateTable( "factura_det", { ;
   { "docid",  'N',  4, 0 }, ;
   { "code",   'C',  2, 0, "comment 'case:upper'"  }, ;
   { "name",   'C', 20, 0, "comment 'case:proper'" }, ;
   { "qty",    'N',  6, 3, "DEFAULT 1" }, ;
   { "rate",   'N',  5, 2, "DEFAULT 10" }, ;
   { "amount=qty*rate", 'N', 12, 2 } }, ;
   .t., "latin1" )   // .t. = con PK auto_increment, charset latin1
```

## 6.3 Verificar, listar y eliminar tablas

```clipper
// Verificar si existe
if oCn:TableExists( "clientes" )
   ? "La tabla existe"
endif

// Eliminar tabla
oCn:DropTable( "clientes" )

// Patrón seguro: verificar antes de crear
if .not. oCn:TableExists( "productos" )
   oCn:CreateTable( "productos", aCols )
endif

// Listar todas las tablas
aTables := oCn:ListTables()
XBROWSER aTables TITLE "Tablas disponibles"

// Obtener estructura
aStruct := oCn:TableStructure( "clientes" )
```

## 6.4 Crear tabla con SQL directo

Para tablas complejas se puede usar SQL directo:

```clipper
TEXT INTO cSql
CREATE TABLE test_aes_encrypt (
   `id`    int(11) NOT NULL AUTO_INCREMENT,
   `name`  varchar(20) DEFAULT NULL,
   `login` tinyblob,
   `pass`  varbinary(255),
   PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=latin1
ENDTEXT

oCn:Execute( cSql )
```

## 6.5 Crear triggers

```clipper
TEXT INTO cSql
CREATE TRIGGER mitabla_bi BEFORE INSERT ON mitabla
FOR EACH ROW
BEGIN
   SET NEW.username = SUBSTRING(CONCAT_WS(', ', @os_user, @pc_name), 1, 30);
END
ENDTEXT

oCn:Execute( "DROP TRIGGER IF EXISTS mitabla_bi" )
oCn:Execute( cSql )
```
