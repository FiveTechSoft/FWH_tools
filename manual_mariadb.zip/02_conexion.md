# 2. Conexión a MariaDB

[← Introducción](01_introduccion.md) | [Índice](README.md) | [Siguiente: Comandos →](03_comandos_funciones.md)

---

## 2.1 Función `maria_Connect()`

La función principal para establecer la conexión es `maria_Connect()`. Devuelve un objeto de conexión o `NIL` si falla.

### Sintaxis

```clipper
oCn := maria_Connect( cConexion, lMostrarError )
oCn := maria_Connect( cHost, cDatabase, cUser, cPassword [, nPort] )
oCn := maria_Connect( { cHost, cDB, cUser, cPassword } )
```

### Parámetros — Forma con cadena de conexión

| Parámetro | Tipo | Descripción |
|-----------|------|-------------|
| `cConexion` | C | Cadena con formato: `host:puerto,base,usuario,password` |
| `lMostrarError` | L | `.t.` muestra mensaje si falla la conexión |

### Parámetros — Forma extendida

| Parámetro | Tipo | Descripción |
|-----------|------|-------------|
| `cHost` | C | Nombre o IP del servidor. Puede incluir `:puerto` (ej: `localhost:3306`) |
| `cDatabase` | C | Nombre de la base de datos |
| `cUser` | C | Usuario de MariaDB |
| `cPassword` | C | Contraseña |
| `nPort` | N | Puerto (opcional, default 3306) |
| `nFlags` | N | Flags de conexión (opcional) |
| `cCharSet` | C | Juego de caracteres (opcional) |
| `cMsgLang` | C | Idioma de mensajes (opcional) |
| `cLocale` | C | Locale (opcional) |

### Ejemplos de conexión

```clipper
// Forma 1: cadena compacta
oCn := maria_Connect( "208.91.198.197:3306,fwhdemo,usuario,password", .t. )

// Forma 2: parámetros separados (local)
oCn := maria_Connect( "localhost", "fwh", "usuario", "1234" )

// Forma 3: via comando FWCONNECT
FWCONNECT oCn HOST cHost USER cUser PASSWORD cPassword DATABASE cDB

// Forma 4: array de parámetros
oCn := maria_Connect( { "localhost", "mibase", "root", "clave" } )

// Forma 5: función de demo incluida en FiveWin
oCn := FW_DemoDB()          // conecta al servidor de demo de FiveWin
oCn := FW_DemoDB( 1 )       // servidor de demo alternativo
oCn := FW_DemoDB( "ADO" )   // conexión via ADO
oCn := FW_DemoDB( "DLP" )   // conexión via TDolphin

// Forma 6: desde objeto ADO o Dolphin existente
oCn := maria_Connect( oAdoConnection )    // desde ADODB.Connection
oCn := maria_Connect( oDolphinServer )    // desde TDolphinSrv
```

> **Nota:** Internamente, `maria_Connect()` analiza los parámetros y acepta múltiples combinaciones: cadena CSV, array, parámetros individuales, e incluso objetos ADO o Dolphin existentes (ver función `ParseConObject` en `fwmaria.prg`).

### Verificar conexión y cerrar

```clipper
if ( oCn := maria_Connect( "host,db,user,pwd", .t. ) ) == nil
   MsgStop( "No se pudo conectar al servidor" )
   return nil
endif

// ... operaciones con la base de datos ...

oCn:Close()   // o oCn:End()
```

### Obtener error de conexión

```clipper
aErr := maria_ConnectError()  // devuelve { nErrorCode, cErrorMsg }
```

## 2.2 Conexión embebida (solo 32 bits)

```clipper
oCn := maria_Embedded( cDataFolder, cDB, cLangFolder )
```

Permite usar MariaDB sin servidor externo. Solo disponible en 32 bits.

## 2.3 Propiedades del objeto de conexión

| Propiedad | Tipo | Descripción |
|-----------|------|-------------|
| `oCn:lOpen` | L | `.t.` si la conexión está activa |
| `oCn:cDB` | C | Nombre de la base de datos actual |
| `oCn:lLogErr` | L | Activa el registro de errores en archivo `.log` |
| `oCn:lShowErrors` | L | Muestra errores en pantalla automáticamente |
| `oCn:nError` | N | Código del último error (0 = sin error) |
| `oCn:LockTimeOut` | N | Tiempo de espera para bloqueos (segundos) |
| `oCn:lUnicode` | L | Modo Unicode activo |
| `oCn:cLastSQL` | C | Última sentencia SQL ejecutada |
| `oCn:pMySql` | P | Puntero interno a la conexión MySQL |

```clipper
oCn:lLogErr      := .t.   // activa log de errores
oCn:lShowErrors  := .t.   // muestra errores en pantalla
```

## 2.4 Ejemplo completo — `maria01.prg`

```clipper
#include "fivewin.ch"

REQUEST DBFCDX

static oCn

function Main()
   local aTables

   SET DATE ITALIAN
   SET CENTURY ON
   FW_SetUnicode( .t. )

   CursorWait()
   oCn := maria_Connect( "208.91.198.197:3306,fwhdemo,gnraofwh,Bharat@1950", .t. )

   XBROWSER oCn:ListTables() ;
      TITLE "Dbl-Click to View Table" ;
      SHOW RECID ;
      SETUP ( ;
      oBrw:aCols[ 1 ]:bLDClickData := { |r,c,f,o| ShowTable( o:Value ) } )

   oCn:Close()
return nil

function ShowTable( cTable )
   local oRs
   if cTable == "custbig"
      MsgRun( "Reading " + cTable, "Please wait", ;
         { || oRs := oCn:RecSet( cTable, -100 ) } )
   else
      MsgRun( "Reading " + cTable, "Please wait", ;
         { || oRs := oCn:RowSet( cTable ) } )
   endif
   XBROWSER oRs TITLE cTable FASTEDIT NOMODAL SHOW RECID
return nil
```

Este ejemplo conecta al servidor demo, lista todas las tablas y permite explorar cada una con doble-click.
