# 1. Introducción

[← Índice](README.md) | [Siguiente: Conexión →](02_conexion.md)

---

FiveWin for Harbour (FWH) incluye soporte nativo para **MariaDB/MySQL** a través de la función `maria_Connect()` y un conjunto de clases que permiten trabajar con bases de datos relacionales de forma sencilla, sin necesidad de drivers ODBC ni componentes externos.

Este manual cubre el uso práctico de MariaDB en FiveWin, basado en los ejemplos oficiales incluidos en la distribución (`maria01.prg` a `maria16.prg` y otros) y el análisis del código fuente (`fwmaria.prg`, `mariarec.prg`).

## Características principales

- **Conexión directa** al servidor MariaDB/MySQL vía protocolo nativo TCP/IP
- **RowSets editables** con soporte completo CRUD (Create, Read, Update, Delete)
- **RecSets paginados** para tablas con millones de registros
- **Integración total con XBrowse** para visualización y edición interactiva
- **Soporte Unicode** (UTF-8) nativo
- **Tablas Pivot**, relaciones padre-hijo, replicación, cifrado AES, datos geoespaciales
- **Importación/Exportación** desde/hacia ficheros DBF
- **Compatibilidad** con Harbour y xHarbour, 32 y 64 bits

## Requisitos

- FiveWin for Harbour 25.x o superior
- Servidor MariaDB 10.x / MySQL 5.7+ accesible en red o local
- Incluir `fivewin.ch` en el programa
- Habilitar Unicode: `FW_SetUnicode( .t. )` si se usan caracteres especiales

## Arquitectura de la conexión

La conexión nativa de FiveWin a MariaDB se realiza directamente sin ODBC, lo que ofrece mayor velocidad y simplicidad. El objeto de conexión (`oCn`) es el punto central desde el que se realizan todas las operaciones.

```
┌─────────────────────────┐
│   Aplicación FWH        │
│   (Harbour / xHarbour)  │
├─────────────────────────┤
│   fwmaria.prg           │  ← Clases: FWMariaRowSet, FRecSet, TField
│   mariarec.prg          │  ← Clase: FWMariaRecord (TDataRow)
├─────────────────────────┤
│   libmariadb.dll        │  ← DLL nativa MariaDB (32/64 bits)
├─────────────────────────┤
│   Servidor MariaDB      │
│   o MySQL               │
└─────────────────────────┘
```

## Ficheros necesarios

| Fichero | Descripción |
|---------|-------------|
| `libmariadb.dll` | DLL cliente MariaDB (32 bits) |
| `libmariadb64.dll` | DLL cliente MariaDB (64 bits) |
| `libmariadb.lib` / `libmariadb32.lib` | Librería de enlace (32 bits) |
| `libmariadb64.lib` / `libmariadb64.a` | Librería de enlace (64 bits) |
| `fwmaria.prg` | Código fuente de las clases principales |
| `mariarec.prg` | Código fuente de la clase FWMariaRecord |

La DLL `libmariadb.dll` debe estar en la misma carpeta que el `.exe` o en una carpeta del `PATH` del sistema.
