# 15. RecSet: Tablas Grandes y Rendimiento

[← Comparación](14_comparacion.md) | [Índice](README.md) | [Siguiente: Locking →](16_bloqueo_registros.md)

---

El **RecSet** (clase `FRecSet`) está diseñado para tablas muy grandes (millones de registros). A diferencia del RowSet que carga todo en memoria, el RecSet usa **paginación** para cargar solo una porción a la vez, cargando más datos bajo demanda cuando el usuario navega.

## 15.1 Creación — `maria10.prg`, `mariabig.prg`

```clipper
// RecSet con página de 1000 registros
oRs := oCn:RecSet( "custbig", 1000 )

// RecSet con lectura de los últimos N registros
oRs := oCn:RecSet( "custbig", -100 )

// Establecer el total de registros (para barra de scroll correcta)
oRs:nLastRec := oCn:QueryResult( "SELECT COUNT(*) FROM custbig" )
```

## 15.2 Ejemplo con tabla de millón de registros

```clipper
function Main()
   local oCn, oRs, nRecs, nSecs, nSum

   FWNumFormat( "A", .t. )
   FW_SetUnicode( .t. )

   oCn := maria_Connect( "servidor:3306,base,user,pwd", .t. )
   oCn:lShowErrors := .t.

   nSecs := SECONDS()
   MsgRun( "Reading custbig", "Please wait", { || ;
      oRs  := oCn:RecSet( "custbig", -100 ), ;
      nSum := oCn:QueryResult( "SELECT SUM(SALARY) FROM custbig" ) } )
   nSecs := SECONDS() - nSecs

   XBROWSER oRs TITLE "CUSTBIG (" + cValToChar( nSecs ) + " seconds)" ;
      FASTEDIT SHOW RECID ;
      SETUP ( ;
      oBrw:id:cEditPicture := "99,999,999", ;
      oBrw:nFreeze := 1, ;
      oBrw:Salary:nFooterType := AGGR_SUM, ;
      oBrw:Salary:nTotal := nSum, ;
      oBrw:aSumCols := { oBrw:oCol( "SALARY" ) } )

   oCn:Close()
return nil
```

## 15.3 Navegación del RecSet

El RecSet implementa la misma interfaz de navegación que el RowSet: `GoTop()`, `GoBottom()`, `Skip()`, `GoTo()`, `Bof()`, `Eof()`, `RecNo()`, `BookMark`, etc.

Internamente, cuando el usuario navega fuera de la página actual, el RecSet:
1. Calcula el nuevo offset necesario
2. Ejecuta una nueva consulta SQL con `LIMIT nPageSize OFFSET nFrom`
3. Lee los nuevos datos en `::aData`
4. Ajusta `::nOffset` y `::nAt`

## 15.4 Propiedades del RecSet

| Propiedad | Tipo | Descripción |
|-----------|------|-------------|
| `nPageSize` | N | Tamaño de página (por defecto 1000) |
| `nLastRec` | N | Último registro total |
| `nAt` | N | Posición actual dentro de la página |
| `nOffset` | N | Offset de la página actual |
| `nReadSecs` | N | Tiempo de lectura |
| `aStruct` | A | Estructura de campos |
| `aData` | A | Datos de la página actual |

---

# 16. Bloqueo de Registros (Locking)

[← RecSet](15_recset_rendimiento.md) | [Índice](README.md) | [Siguiente: Replicación →](17_replicacion.md)

---

## 16.1 Bloqueo pesimista con FOR UPDATE — `marialok.prg`

```clipper
static function LockedEdit( oBrw )
   local oRsMain, oRsEdit, oRec, nWait, oCn

   oRsMain  := oBrw:oDbf
   oCn      := oRsMain:oCn

   // Guardar timeout actual y poner uno corto
   nWait := oCn:QueryResult( ;
      "SHOW SESSION VARIABLES LIKE 'innodb_lock_wait_timeout'" )[ 2 ]
   oCn:Execute( "SET SESSION innodb_lock_wait_timeout = 1" )

   // Iniciar transacción y bloquear el registro
   oCn:BeginTransaction()
   MsgRun( "Reading Record", "WAIT", { || ;
      oRsEdit := oCn:RowSet( ;
         "SELECT * FROM customer WHERE ID = ? FOR UPDATE", ;
         { oRsMain:ID } ) } )

   if oCn:nError == 0
      // Registro bloqueado OK — editar
      oCn:Execute( "SET SESSION innodb_lock_wait_timeout = " + ;
                   cValToChar( nWait ) )
      oRec := TDataRow():New( oRsEdit )
      oRec:Edit()
      oCn:CommitTransaction()
      oRsMain:ReSync()
      oBrw:RefreshCurrent()
   else
      // No se pudo bloquear — otro usuario lo tiene
      oCn:RollBack()
      oCn:Execute( "SET SESSION innodb_lock_wait_timeout = " + ;
                   cValToChar( nWait ) )
      ? "Registro bloqueado por otro usuario"
   endif

   oBrw:SetFocus()
return nil
```

El patrón es:
1. Establecer `innodb_lock_wait_timeout` a 1 segundo
2. `BeginTransaction()`
3. `SELECT ... FOR UPDATE` → bloquea la fila
4. Si OK: editar, `CommitTransaction()`
5. Si error: `RollBack()`, informar al usuario
6. Restaurar timeout original

---

# 17. Replicación entre Servidores

[← Locking](16_bloqueo_registros.md) | [Índice](README.md) | [Siguiente: Sincronización →](18_sincronizacion_dbf.md)

---

## 17.1 Replicación automática de cambios — `mariarpl.prg`

```clipper
oMain := FW_DemoDB()         // servidor principal
oRepl := FW_DemoDB( 6 )     // servidor de réplica

// Primera vez: copiar tabla
// oMain:CopyTableToServer( "states", oRepl )

oRsMain := oMain:RowSet( "states" )
oRsMain:oReplServer := oRepl   // ¡ACTIVAR REPLICACIÓN!

oRsRepl := oRepl:RowSet( "states" )

// Configurar browses
oBrwMain:nEditTypes    := EDIT_GET
oBrwMain:bOnChanges    := { || oRsRepl:ReSync(), oBrwRepl:RefreshCurrent() }
oBrwMain:lColChangeNotify := .t.
oBrwMain:bChange       := { || BrwSync( oBrwMain, oBrwRepl ) }
oBrwMain:bOnRefresh    := { || oRsRepl:ReQuery(), BrwSync( oBrwMain, oBrwRepl ) }
```

Con `oRsMain:oReplServer := oRepl`, cada INSERT, UPDATE o DELETE ejecutado en el RowSet principal se replica automáticamente al servidor de réplica.
