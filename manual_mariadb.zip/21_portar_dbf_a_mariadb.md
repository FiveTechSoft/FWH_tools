# 21. Portar una Aplicación de DBF a MariaDB

[← Query Browser](20_query_browser.md) | [Índice](README.md) | [Siguiente: Referencia →](22_referencia_rapida.md)

---

Migrar una aplicación FWH basada en DBFs a MariaDB es un proceso gradual que puede hacerse tabla por tabla. Las principales ventajas son: acceso multiusuario concurrente sin corrupción, rendimiento superior con grandes volúmenes, SQL para consultas complejas, seguridad con usuarios/permisos, integridad referencial y acceso remoto vía TCP/IP.

## 21.1 Tabla de Equivalencias DBF → MariaDB

| Operación DBF | Equivalente MariaDB/FWH |
|---------------|-------------------------|
| `USE "clientes"` | `oRs := oCn:RowSet("clientes")` |
| `APPEND BLANK` | `oRs:AppendBlank()` |
| `DELETE` | `oRs:Delete()` |
| `REPLACE field WITH val` | `oRs:field := val; oRs:Save()` |
| `GO TOP` | `oRs:GoTop()` |
| `GO BOTTOM` | `oRs:GoBottom()` |
| `SKIP n` | `oRs:Skip(n)` |
| `GO nRec` | `oRs:GoTo(nRec)` |
| `RECNO()` | `oRs:RecNo()` |
| `RECCOUNT()` / `LASTREC()` | `oRs:KeyCount()` / `oRs:LastRec()` |
| `BOF()` | `oRs:Bof()` |
| `EOF()` | `oRs:Eof()` |
| `FIELD->name` | `oRs:name` |
| `FieldGet(n)` | `oRs:FieldGet(n)` |
| `FieldPut(n,v)` | `oRs:FieldPut(n,v)` |
| `FCOUNT()` | `oRs:FCount()` |
| `SET INDEX TO / INDEX ON` | `oRs:SetOrder("campo")` |
| `SEEK val` | `oRs:Seek(val)` |
| `SET FILTER TO expr` | `oRs:SetFilter("campo = ?", {val})` |
| `LOCATE FOR cond` | `oRs:Locate({|| oRs:campo == val})` |
| `SET RELATION TO` | `oRs:AddChild(...)` |
| `DBSTRUCT()` | `oRs:aStructure` |
| `TDatabase()` | `FWMariaRecord()` + `oCn:RowSet()` |
| `CLOSE DATA` | `oRs:Close(); oCn:Close()` |
| `PACK` / `ZAP` | `oRs:Zap()` / `oRs:Truncate` |

## 21.2 Paso 1: Importar los DBFs al Servidor

```clipper
function MigrarDBFs()
   local oCn

   oCn := maria_Connect( "miservidor,mibase,root,clave" )
   oCn:lLogErr := .t.

   for each cTabla in { "clientes", "facturas", "productos", "estados" }
      if File( cTabla + ".dbf" )
         MsgRun( "Importando " + cTabla, "Por favor espere...", ;
            { || oCn:ImportFromDbf( cTabla + ".dbf" ) } )
      endif
   next

   // Revisar log
   if File( cFileSetExt( ExeName(), "log" ) )
      WinExec( "notepad.exe " + cFileSetExt( ExeName(), "log" ) )
   endif

   oCn:Close()
return nil
```

## 21.3 Paso 2: Adaptar la Conexión

**Antes (DBF):**
```clipper
function Main()
   RDDSETDEFAULT( "DBFCDX" )
   SET DELETED ON
   SET DATE ITALIAN
   SET CENTURY ON
   USE CLIENTES NEW
   USE PRODUCTOS NEW
   // ...
```

**Después (MariaDB):**
```clipper
function Main()
   local oCn

   SET DATE ITALIAN
   SET CENTURY ON
   FW_SetUnicode( .t. )

   oCn := maria_Connect( "servidor,mibase,usuario,clave" )
   if oCn == nil
      MsgStop( "Error de conexión" )
      return nil
   endif
   oCn:lShowErrors := .t.

   oRsClientes  := oCn:RowSet( "clientes" )
   oRsProductos := oCn:RowSet( "productos" )
   // ...
```

## 21.4 Paso 3: Adaptar los Browses

**Antes (DBF):**
```clipper
USE CLIENTES NEW
INDEX ON FIRST TAG FIRST

@ 20,20 XBROWSE oBrw SIZE -20,-20 PIXEL OF oDlg ;
   DATASOURCE "CLIENTES" ;
   COLUMNS "FIRST", "LAST", "CITY", "SALARY" ;
   CELL LINES NOBORDER
```

**Después (MariaDB):**
```clipper
oRs := oCn:RowSet( "SELECT FIRST, LAST, CITY, SALARY FROM clientes ORDER BY FIRST" )

@ 20,20 XBROWSE oBrw SIZE -20,-20 PIXEL OF oDlg ;
   DATASOURCE oRs ;
   AUTOCOLS ;
   CELL LINES NOBORDER FASTEDIT AUTOSORT
```

> **Nota:** `AUTOSORT` habilita ordenación por click en cabecera. `FASTEDIT` habilita edición directa en celda. No se necesitan índices — la ordenación se hace en memoria.

## 21.5 Paso 4: Adaptar la Edición

**Antes (DBF):**
```clipper
USE CLIENTES NEW
APPEND BLANK
REPLACE FIRST WITH "Juan", LAST WITH "López", SALARY WITH 35000
```

**Después (MariaDB) — 3 opciones:**
```clipper
// Opción 1: Vía RowSet (más parecido al estilo xBase)
oRs:AppendBlank()
oRs:First  := "Juan"
oRs:Last   := "López"
oRs:Salary := 35000
oRs:Save()

// Opción 2: Vía Insert directo (más eficiente para inserciones masivas)
oCn:Insert( "clientes", "first,last,salary", { "Juan", "López", 35000 } )

// Opción 3: Vía FWMariaRecord (ideal para formularios)
oRec := FWMariaRecord():New( oCn, "clientes" )
oRec:Blank()
oRec:First  := "Juan"
oRec:Last   := "López"
oRec:Salary := 35000
oRec:Save()
```

## 21.6 Paso 5: Adaptar Búsquedas y Filtros

**Antes (DBF):**
```clipper
SET ORDER TO TAG CITY
SEEK "Madrid"
SET FILTER TO salary > 30000
```

**Después (MariaDB) — 2 enfoques:**
```clipper
// Enfoque A: SQL directo (más eficiente, datos se filtran en el servidor)
oRs := oCn:RowSet( "SELECT * FROM clientes WHERE city = ? AND salary > ?", ;
                   { "Madrid", 30000 } )

// Enfoque B: Filtros locales (sobre datos ya leídos)
oRs := oCn:RowSet( "clientes" )
oRs:SetOrder( "CITY" )
oRs:Seek( "Madrid" )
oRs:SetFilter( "SALARY > ?", { 30000 } )
```

## 21.7 Paso 6: Relaciones entre Tablas

**Antes (DBF):**
```clipper
USE ESTADOS NEW
USE CLIENTES NEW
INDEX ON STATE TAG STATE
SET RELATION TO CODE INTO CLIENTES
```

**Después (MariaDB) — 2 opciones:**
```clipper
// Opción 1: JOIN en SQL (una sola consulta — MÁS EFICIENTE)
oRs := oCn:RowSet( "SELECT C.*, S.NAME AS StateName " + ;
                   "FROM clientes C " + ;
                   "LEFT JOIN estados S ON C.STATE = S.CODE" )

// Opción 2: Parent-Child (estilo xBase)
oEstados  := oCn:RowSet( "estados" )
oClientes := oCn:RowSet( "clientes" )
oEstados:AddChild( oClientes, "state = estados.code" )
// Sincronizar: oEstados:SyncChild()
```

## 21.8 Paso 7: Migración Gradual con Replicación

Si necesitas mantener el DBF funcionando durante la transición, usa la replicación automática:

```clipper
// El DBF sigue siendo la fuente principal
oDbf := TDatabase():Open( nil, "clientes", "DBFCDX", .t. )

// Cada cambio en el DBF se replica al servidor MariaDB
oDbf:SetReplicationServer( oCn )

// En el futuro, cuando estés listo, cambia al RowSet directamente:
// oRs := oCn:RowSet( "clientes" )
```

Ver ejemplo completo en `mariasyn.prg`.

## 21.9 Ejemplo: Formulario de Edición Completo

**Antes (DBF con TDatabase):**
```clipper
oDbf := TDatabase():Open( nil, "clientes", "DBFCDX" )
// ... gets y dialog ...
oDbf:Save()
oDbf:Close()
```

**Después (con FWMariaRecord):**
```clipper
oRec := FWMariaRecord():New( oCn, "clientes", "id = " + cValToChar(nId) )

DEFINE DIALOG oDlg SIZE 400,300 PIXEL TRUEPIXEL FONT oFont
@ 30,120 GET oRec:First   SIZE 240,22 PIXEL OF oDlg
@ 60,120 GET oRec:Last    SIZE 240,22 PIXEL OF oDlg
@ 90,120 GET oRec:City    SIZE 240,22 PIXEL OF oDlg
@ 120,120 GET oRec:Salary SIZE 240,22 PIXEL OF oDlg PICTURE "999,999.99"

@ 200,20 BTNBMP PROMPT "Guardar" SIZE 150,30 PIXEL FLAT OF oDlg ;
   ACTION ( If( oRec:Modified(), oRec:Save(), nil ), oDlg:End() ) ;
   WHEN oRec:Modified()

ACTIVATE DIALOG oDlg CENTERED
```

**Con EditBaseRecord (desde un browse parcial):**
```clipper
oRs := oCn:RowSet( "SELECT ID, FIRST, CITY, SALARY FROM clientes" )

// Editar registro con TODOS los campos de la tabla
oRs:EditBaseRecord( nil, .f., { |oRec| MyEditDlg( oRec ) }, oBrw, .t. )
```

## 21.10 Errores Comunes al Migrar

| Error | Causa | Solución |
|-------|-------|----------|
| Caracteres extraños | Charset incorrecto | `FW_SetUnicode(.t.)` antes de conectar |
| Datos truncados | Campo muy corto en MariaDB | Verificar longitudes al crear tabla |
| No se puede editar | Tabla sin clave primaria | FWH añade `id AUTO_INCREMENT` automáticamente con `CreateTable` |
| Lentitud al abrir | Tabla muy grande | Usar `RecSet` con paginación o limitar con `WHERE` |
| Registro bloqueado | Otro usuario editando | Implementar locking con `FOR UPDATE` y timeout |
| Campo no encontrado | Nombre con alias diferente | Usar `AS` en el SQL para mantener nombres conocidos |
| Error en Save() | nError != 0 | Activar `oCn:lShowErrors := .t.` para ver detalles |
| DBF con DELETED | Registros marcados | En MariaDB se borran de verdad con `DELETE`; no hay `SET DELETED` |
