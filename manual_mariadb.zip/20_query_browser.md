# 20. Query Browser Interactivo

Ver contenido en [Capítulo 18](18_sincronizacion_dbf.md#20-query-browser-interactivo).
