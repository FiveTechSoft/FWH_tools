# 13. FWMariaRecord: Edición de Registros Individuales

[← Importar](12_importar_dbf.md) | [Índice](README.md) | [Siguiente: Comparación →](14_comparacion.md)

---

La clase `FWMariaRecord` (definida en `mariarec.prg`) hereda de `TDataRow` y permite leer, editar y guardar un registro individual de MariaDB. Es ideal para formularios de alta/edición.

## 13.1 Crear y usar un FWMariaRecord

```clipper
// Leer un registro existente
oRec := FWMariaRecord():New( oCn, "clientes", "id = " + cValToChar( nId ) )

// Registro en blanco (para alta)
oRec := FWMariaRecord():New( oCn, "clientes" )
oRec:Blank()

// Leer otro registro
oRec:Read( "id = 10" )
```

## 13.2 Acceder y modificar campos

```clipper
? oRec:nombre                    // leer campo
oRec:nombre := "Juan García"    // modificar campo
oRec:salario := 3500
```

## 13.3 Guardar cambios

```clipper
if oRec:Modified()
   if oRec:Save()
      ? "Guardado correctamente"
   else
      ? "Error al guardar"
   endif
endif
```

El método `Save()` usa internamente `oCn:Upsert()`: si el registro es nuevo (RecNo == 0) hace INSERT, si existe hace UPDATE. Después de guardar, recarga el registro del servidor para obtener valores actualizados (auto-increment, timestamps, etc.).

## 13.4 Propiedades y métodos principales

| Propiedad / Método | Descripción |
|---------------------|-------------|
| `oRec:lValidData` | `.t.` si el registro tiene datos válidos |
| `oRec:RecNo` | Número de registro (0 = nuevo) |
| `oRec:oCn` | Objeto de conexión |
| `oRec:cTable` | Nombre de la tabla |
| `oRec:cWhere` | Cláusula WHERE del registro |
| `oRec:aStruct` | Estructura de campos |
| `oRec:aPrimary` | Índices de campos de clave primaria |
| `oRec:nAutoIncFld` | Índice del campo auto-incremento |
| `oRec:New( oCn, cTabla, cWhere )` | Constructor |
| `oRec:Read( cWhere )` | Carga un registro según condición WHERE |
| `oRec:Blank()` | Carga un registro en blanco para inserción |
| `oRec:Load( [lBlank] )` | Recarga el registro del servidor |
| `oRec:Save()` | Guarda los cambios (INSERT o UPDATE) |
| `oRec:Modified()` | `.t.` si hubo cambios sin guardar (heredado de TDataRow) |
| `oRec:MakePrimaryWhere()` | Genera cláusula WHERE desde clave primaria |
| `oRec:campo` | Acceso directo a cada campo como propiedad |

## 13.5 Notas de implementación

- Al hacer `Save()`, si el campo auto-incremento tiene valor 0 (registro nuevo), se obtiene el ID generado con `oCn:Last_Insert_id`
- Después de `Save()`, se llama `MakePrimaryWhere()` para actualizar `cWhere` con los valores reales de la clave primaria
- Si hay error al guardar, se muestra con `oCn:ShowError()`
- Los campos tipo `C` se recortan con `Trim()` antes de guardar y se rellenan con `UPadR()` al leer (compatible con estilo xBase)

---

# 14. Comparación FWH vs ADO vs Dolphin

[← FWMariaRecord](13_fwmariarecord.md) | [Índice](README.md) | [Siguiente: RecSet →](15_recset_rendimiento.md)

---

FiveWin permite conectarse a MariaDB/MySQL usando tres bibliotecas diferentes. El ejemplo `maria14.prg` hace una comparación de rendimiento en tiempo real. El ejemplo `maria05.prg` permite elegir entre las tres opciones.

## 14.1 Tabla comparativa

| Aspecto | FWH Nativo | ADO | TDolphin |
|---------|-----------|-----|----------|
| Conexión | `maria_Connect()` | `FW_DemoDB("ADO")` | `FW_DemoDB("DLP")` |
| Query | `oCn:RowSet(cSql)` | `FW_OpenRecordSet(oCn,cSql)` | `oCn:Query(cSql)` |
| Cerrar RS | `oRs:Close()` | `oRs:Close()` | `oRs:End()` |
| Cerrar CN | `oCn:Close()` | `oCn:Close()` | `oCn:End()` |
| Driver extra | No (nativo) | Necesita ODBC | Necesita TDolphin |
| Velocidad lectura | Muy alta | Media | Alta |
| Tráfico de red | Mínimo | Alto | Medio |
| Edición | Completa + local | Vía servidor | Vía servidor |
| Recomendado | ✅ Primera opción | Solo si ya existe | Compatible |

## 14.2 Código de benchmark — `maria14.prg`

```clipper
cSql := "SELECT * FROM custbig WHERE id <= 51000"

// Leer con cada librería y medir tiempos
nSecs := SECONDS()
MsgRun( "Reading", "FWH", { || oRsFWH := oCn:RowSet( cSql ) } )
nFWHSecs := SECONDS() - nSecs

nSecs := SECONDS()
MsgRun( "Reading", "ADO", { || oRsADO := FW_OpenRecordSet( oAdo, cSql ) } )
nAdoSecs := SECONDS() - nSecs

nSecs := SECONDS()
MsgRun( "Reading", "DLP", { || oQry := oServer:Query( cSql ) } )
nDlpSecs := SECONDS() - nSecs
```

Se muestra cada browse con su tiempo de lectura, tiempo de ordenación, tiempo de guardado y tráfico de red generado.

> **Para nuevas aplicaciones** se recomienda siempre el conector nativo FWH (`maria_Connect`). Es el más rápido, no requiere drivers adicionales y tiene mejor integración con las clases de FiveWin.
