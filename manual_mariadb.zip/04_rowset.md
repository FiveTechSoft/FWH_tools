# 4. RowSet: Consultas y Edición de Datos

[← Comandos](03_comandos_funciones.md) | [Índice](README.md) | [Siguiente: CRUD →](05_crud.md)

---

El **RowSet** es el objeto central para trabajar con datos en FiveWin/MariaDB. Representa un conjunto de registros que puede mostrarse en un XBrowse y editarse directamente. Todos los datos se leen a memoria, permitiendo ordenación y filtrado local sin consultas adicionales al servidor.

## 4.1 Crear un RowSet

```clipper
// Tabla completa
oRs := oCn:RowSet( "clientes" )

// Acceso directo por nombre de tabla
oRs := oCn:clientes    // equivale a oCn:RowSet( "clientes" )

// Con SQL personalizado
oRs := oCn:RowSet( "SELECT * FROM clientes WHERE activo = 1" )

// SQL con parámetros (evita SQL injection)
oRs := oCn:RowSet( "SELECT * FROM clientes WHERE estado = ?", { cEstado } )

// JOIN entre tablas (ejemplo maria02.prg)
TEXT INTO cSql
   SELECT C.ID AS CustID, C.FIRST AS CustName, C.AGE AS AG,
          C.STATE AS ST, S.NAME AS StateName
   FROM customer C
   LEFT OUTER JOIN states S ON C.STATE = S.CODE
   ORDER BY CUSTID
ENDTEXT
oRs := oCn:RowSet( cSql )
```

## 4.2 Mostrar en XBrowse

```clipper
// Modo simple
XBROWSER oRs FASTEDIT TITLE "Clientes"

// Con opciones avanzadas
XBROWSER oRs FASTEDIT AUTOSORT AUTOFIT SHOW RECID ;
   TITLE "Clientes" ;
   SETUP ( oBrw:lFastEdit := .f., oBrw:aCols[ 4 ]:cEditPicture := "@!" )

// Control total programático
DEFINE DIALOG oDlg SIZE 800,600 PIXEL FONT oFont TITLE "Clientes"

@ 50,20 XBROWSE oBrw SIZE -20,-20 PIXEL OF oDlg ;
   DATASOURCE oRs ;
   COLUMNS "First", "City", "Salary" ;
   CELL LINES NOBORDER FOOTERS FASTEDIT

WITH OBJECT oBrw
   :nEditTypes := EDIT_GET
   :Salary:nFooterType := AGGR_SUM
   :MakeTotals()
   :CreateFromCode()
END

ACTIVATE DIALOG oDlg CENTERED
```

## 4.3 Navegación

| Método | Descripción |
|--------|-------------|
| `oRs:GoTop()` | Ir al primer registro |
| `oRs:GoBottom()` | Ir al último registro |
| `oRs:Skip( n )` | Saltar n registros |
| `oRs:GoTo( nRec )` | Ir al registro nRec |
| `oRs:Bof()` | `.t.` si está al inicio |
| `oRs:Eof()` | `.t.` si está al final |
| `oRs:RecNo()` | Número de registro actual (según ID del servidor) |
| `oRs:KeyNo()` | Posición actual en el conjunto de datos |
| `oRs:KeyCount()` | Total de registros |
| `oRs:LastRec()` | Último número de registro |
| `oRs:BookMark` | Leer/asignar marcador de posición |

## 4.4 Acceso a campos

```clipper
// Como propiedades (via error handler — la forma más cómoda)
? oRs:First       // lee el campo "First"
? oRs:Salary      // lee el campo "Salary"
oRs:First  := "Juan"        // escribe en el campo
oRs:Salary := 50000

// Por posición numérica
? oRs:FieldGet( 1 )
oRs:FieldPut( 2, "Nuevo valor" )

// Por nombre de campo
? oRs:FieldGet( "FIRST" )
oRs:FieldPut( "SALARY", 60000 )

// Información de campos
? oRs:FieldName( n )      // nombre del campo n
? oRs:FieldType( n )      // tipo ('C', 'N', 'D', 'L', 'T', 'M', '+', '=')
? oRs:FieldLen( n )       // longitud
? oRs:FieldDec( n )       // decimales
? oRs:FieldPos( "FIRST" ) // posición del campo por nombre
? oRs:FieldReadOnly( n )  // .t. si es solo lectura
? oRs:FCount()             // número total de campos
```

## 4.5 Objeto Fields

Cada campo del RowSet se accede como un objeto `TField` con metadatos completos:

```clipper
oField := oRs:Fields( "salary" )
? oField:Value              // valor actual
oField:Value := 60000       // asignar nuevo valor
oField:lReadOnly := .t.     // marcar como solo lectura
? oField:OriginalValue      // valor antes de editar
? oField:name, oField:type, oField:len, oField:dec
? oField:lPrimary           // .t. si es clave primaria
? oField:lAutoInc            // .t. si es auto-incremento
```

## 4.6 Ordenación

```clipper
oRs:SetOrder( "FIRST" )              // Ordenar por campo FIRST
oRs:SetOrder( "SALARY", , .t. )      // Ordenar descendente
oRs:OrdDescend( "CITY" )             // Cambiar orden
oRs:Sort := "FIRST"                  // Asignar orden vía propiedad
? oRs:Sort                           // Consultar orden actual
? oRs:lDescend                       // .t. si orden descendente
```

## 4.7 Filtros y búsqueda

```clipper
// Filtrar datos (se aplica localmente sobre los datos ya leídos)
oRs:SetFilter( "STATE = ?", { "CA" } )

// Re-filtrar con nuevos parámetros
oRs:ReFilter( { "NY" } )

// Búsqueda
oRs:Seek( "John" )                    // buscar exacto
oRs:Seek( "Jo", .t. )                 // búsqueda parcial (soft)
oRs:OrdWildSeek( "Jo*" )              // búsqueda con comodines
oRs:Locate( {|| oRs:Salary > 50000 } ) // buscar por condición
```

## 4.8 Guardado y edición

```clipper
oRs:First  := "Pedro"
oRs:Salary := 45000
oRs:Save()          // Genera UPDATE solo para columnas cambiadas

oRs:Cancel()        // Cancela cambios pendientes

// Agregar registros
oRs:Append( "first,last,salary", { "Ana", "López", 40000 } )
oRs:AppendBlank()   // Agrega registro en blanco

// Borrar registro actual
oRs:Delete()
```

## 4.9 Re-lectura de datos

```clipper
oRs:ReSync()                 // Re-leer registro actual del servidor
oRs:ReQuery()                // Re-leer todos los datos con mismo SQL
oRs:ReQuery( { "NY" } )     // Re-leer con nuevos parámetros
oRs:ReQuery( cNewSql )      // Re-leer con nuevo SQL
oRs:Refresh()                // Comprobar si hay cambios en el servidor
```

## 4.10 Propiedades importantes del RowSet

| Propiedad | Tipo | Descripción |
|-----------|------|-------------|
| `oRs:Source` | C | SQL fuente del RowSet |
| `oRs:cBaseTable` | C | Tabla base para operaciones CRUD |
| `oRs:cBaseDB` | C | Base de datos de la tabla base |
| `oRs:lReadOnly` | L | `.t.` si el RowSet es de solo lectura |
| `oRs:lAutoAppend` | L | Habilitar auto-agregar desde browse |
| `oRs:lAutoPage` | L | Paginación automática |
| `oRs:lBatchMode` | L | Modo batch para ediciones masivas |
| `oRs:lShowErrors` | L | Mostrar errores |
| `oRs:lMultiTables` | L | `.t.` si el SQL involucra varias tablas |
| `oRs:lLocked` | L | `.t.` si usa FOR UPDATE |
| `oRs:nReadSecs` | N | Segundos que tardó la lectura |
| `oRs:nFoundRows` | N | Registros encontrados (con SQL_CALC_FOUND_ROWS) |
| `oRs:aStruct` / `oRs:aStructure` | A | Estructura de campos |
| `oRs:aPrimary` | A | Columnas de clave primaria |
| `oRs:aBaseCols` | A | Columnas de la tabla base |
| `oRs:oChild` | O | RowSet hijo enlazado |
| `oRs:oReplServer` | O | Servidor de replicación |
| `oRs:nAutoIncCol` | N | Columna auto-incremento |
| `oRs:cLastSQL` | C | Última sentencia SQL ejecutada |
| `oRs:bDataRow` | B | Bloque para crear TDataRow |
| `oRs:bTrigger` | B | Bloque trigger antes de guardar |

## 4.11 Paginación

```clipper
// Navegación por páginas
oRs:GoToPage( nPage )
oRs:FirstPage()
oRs:PrevPage()
oRs:NextPage()
oRs:LastPage()
? oRs:nCurrentPage
? oRs:nMaxPages
```

## 4.12 Export

```clipper
oRs:ToExcel()            // Exportar a Excel
cJson := oRs:ToJson()    // Exportar a JSON
hHash := oRs:ToHash()    // Exportar a Hash
aRows := oRs:GetRows()   // Obtener como array
```
