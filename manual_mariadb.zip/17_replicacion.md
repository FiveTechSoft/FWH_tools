# 17. Replicación entre Servidores

Ver contenido en [Capítulo 15](15_recset_rendimiento.md#17-replicación-entre-servidores).
