# 5. Operaciones CRUD

[← RowSet](04_rowset.md) | [Índice](README.md) | [Siguiente: Manejo de Tablas →](06_manejo_tablas.md)

---

## 5.1 INSERT — Insertar registros

```clipper
// Un registro
oCn:Insert( "clientes", "nombre,ciudad,salario", ;
   { "Juan López", "Madrid", 3500 } )

// Múltiples registros de una vez (mucho más eficiente)
local aData := {}
for i := 1 to 1000
   AAdd( aData, { "Nombre" + Str(i), "Ciudad", HB_RandomInt(1000, 9999) } )
next

oCn:SetAutoCommit( .f. )     // inicio de transacción
oCn:Insert( "clientes", "nombre,ciudad,salario", aData )
oCn:SetAutoCommit( .t. )     // commit
```

### Upsert (INSERT o UPDATE)

```clipper
// Inserta si no existe, actualiza si ya existe (basado en clave primaria)
oCn:Upsert( "clientes", nil, aValues )
```

## 5.2 SELECT — Consultar datos

```clipper
// Valor único (escalar)
nTotal := oCn:QueryResult( "SELECT COUNT(*) FROM clientes" )
nSuma  := oCn:QueryResult( "SELECT SUM(salario) FROM clientes" )

// Resultado como array
aEstados := oCn:Execute( "SELECT CODE, NAME FROM states" )

// RowSet completo
oRs := oCn:RowSet( "SELECT * FROM clientes WHERE ciudad = ?", { cCiudad } )
```

## 5.3 UPDATE — Actualizar datos

```clipper
// Directo vía SQL
oCn:Execute( "UPDATE clientes SET salario = salario * 1.10 WHERE ciudad = 'Madrid'" )

// A través del RowSet
oRs := oCn:RowSet( "SELECT * FROM clientes WHERE id = ?", { nId } )
oRs:salario := 4000
oRs:Save()   // genera UPDATE solo para columnas cambiadas

// Actualizar campo específico
oRs:Update( { "salario" }, { 5000 } )

// Verificar error
if oCn:nError != 0
   oCn:ShowError()
endif
```

## 5.4 DELETE — Eliminar registros

```clipper
// Vía SQL
oCn:Execute( "DELETE FROM clientes WHERE id = " + cValToChar( nId ) )

// Vía RowSet
oRs:Delete()
oRs:ReQuery()    // recargar datos
```

### Eliminar desde XBrowse

```clipper
// Botón de eliminar en diálogo
@ 20,20 BTNBMP PROMPT "Delete" SIZE 60,20 PIXEL FLAT OF oDlg ;
   ACTION ( oRs:Delete(), oRs:ReQuery(), oBrw:MakeTotals(), ;
            oBrw:Refresh(), oBrw:SetFocus() )
```

## 5.5 Actualizar tabla maestra con totales del detalle

```clipper
// Actualiza campos de suma en tabla maestra a partir de tabla de detalle
// Parámetros: maestro, PK, campos_maestro, detalle, FK, campos_detalle
oCn:UpdateSummary( "facturas",  "id",  "total,cantidad", ;
                   "lineas",    "fid", "importe,qty" )

// Ver el SQL que se genera
? MYSQL_UpdateSummarySQL( "facturas", "id", "total,cantidad", ;
                          "lineas",   "fid", "importe,qty" )
```

*Útil para mantener totales en cabeceras de facturas/pedidos actualizados automáticamente desde las líneas de detalle.*

### Ejemplo completo — `maria08.prg`

```clipper
// Crear tabla maestra con totales
oCn:CreateTable( "test_mas", { ;
   { "quantity",  'N', 14, 0 }, ;
   { "value",     'N', 14, 0 } } )

oCn:Insert( "test_mas", "quantity,value", ;
   { { 10, 10 }, { 20, 20 }, { 30, 30 }, { 40, 40 }, { 50, 50 } } )

// Crear tabla detalle con clave foránea
oCn:CreateTable( "test_det", { ;
   { "pid", "REFERENCES test_mas( id )" }, ;
   { "qty",    'N', 10, 0 }, ;
   { "val",    'N', 10, 0 } } )

// Insertar transacciones y actualizar resúmenes
oCn:Insert( "test_det", "pid,qty,val", aDet )
oCn:UpdateSummary( "test_mas", "id", "quantity,value", ;
                   "test_det", "pid", "qty,val" )
```
