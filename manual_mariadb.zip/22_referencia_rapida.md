# 22. Referencia Rápida y Constantes

[← Portar DBF](21_portar_dbf_a_mariadb.md) | [Índice](README.md) | [Siguiente: TField →](23_clase_tfield.md)

---

## Conexión

| Comando | Descripción |
|---------|-------------|
| `maria_Connect(cStr, lErr)` | Conectar al servidor |
| `FWCONNECT oCn HOST ... USER ... PASSWORD ... DATABASE ...` | Conectar vía comando |
| `FW_DemoDB([tipo])` | Conectar al servidor de demo |
| `maria_ConnectError()` | `{ nErr, cErr }` del último intento |
| `oCn:Close()` / `oCn:End()` | Cerrar conexión |

## Consultas

| Comando | Descripción |
|---------|-------------|
| `oCn:RowSet(cSql [,aParams])` | Recordset editable en memoria |
| `oCn:RecSet(cTabla, nRecs)` | Recordset paginado (tablas grandes) |
| `oCn:QueryResult(cSql)` | Valor único (COUNT, SUM, etc.) |
| `oCn:Execute(cSql)` | Ejecutar SQL sin resultado |
| `oCn:ListTables()` | Array de tablas |

## Tablas

| Comando | Descripción |
|---------|-------------|
| `oCn:TableExists(cTabla)` | Verificar si existe |
| `oCn:CreateTable(cTabla, aStruct [,lPK] [,cCharset])` | Crear tabla |
| `oCn:DropTable(cTabla)` | Eliminar tabla |
| `oCn:Insert(cTabla, cCampos, aData)` | Insertar registros |
| `oCn:ImportFromDbf(cArchivo,...)` | Importar desde DBF |
| `oCn:TableStructure(cTabla)` | Estructura de la tabla |

## RowSet

| Método | Descripción |
|--------|-------------|
| `oRs:campo` | Leer/escribir campo directamente |
| `oRs:Fields('campo'):lReadOnly` | Poner campo de solo lectura |
| `oRs:lAutoAppend := .t.` | Habilitar inserción desde browse |
| `oRs:SetDefault('campo', val)` | Valor por defecto en nuevos registros |
| `oRs:SetFilter(cExpr, aParams)` | Filtrar registros |
| `oRs:ReFilter(aParams)` | Re-aplicar filtro con nuevos parámetros |
| `oRs:ReQuery([aParams])` | Recargar datos |
| `oRs:ReSync()` | Re-leer registro actual del servidor |
| `oRs:Delete()` | Eliminar registro actual |
| `oRs:EditBaseRecord(...)` | Editar registro completo con diálogo |
| `oRs:AddChild(cSQL)` | Agregar RowSet hijo |
| `oRs:SyncChild()` | Sincronizar hijo |
| `oRs:SetOrder('campo')` | Ordenar |
| `oRs:Seek(val)` | Buscar |
| `oRs:Save()` | Guardar cambios |
| `oRs:Cancel()` | Cancelar edición |
| `oRs:Close()` | Cerrar RowSet |

## Constantes — Flags de Campo

```clipper
#define NOT_NULL_FLAG       1
#define PRI_KEY_FLAG        2
#define UNIQUE_KEY_FLAG     4
#define MULTIPLE_KEY_FLAG   8
#define BLOB_FLAG          16
#define UNSIGNED_FLAG      32
#define ZEROFILL_FLAG      64
#define BINARY_FLAG       128
#define AUTO_INCREMENT_FLAG 512
#define NO_DEFAULT_VALUE_FLAG 4096
```

## Constantes — Tipos MySQL

```clipper
#define MYSQL_TYPE_DECIMAL       0
#define MYSQL_TYPE_TINY          1
#define MYSQL_TYPE_NEWDECIMAL  246
#define MYSQL_TYPE_ENUM        247
#define MYSQL_TYPE_SET         248
#define MYSQL_TYPE_TINY_BLOB   249
#define MYSQL_TYPE_MEDIUM_BLOB 250
#define MYSQL_TYPE_LONG_BLOB   251
#define MYSQL_TYPE_BLOB        252
```

## Constantes — Índices de Estructura

```clipper
#define STRUCT_FIELDNAME   1    // Nombre del campo
#define STRUCT_FIELDTYPE   2    // Tipo FWH (C, N, D, L, M, +, =, @)
#define STRUCT_FIELDLEN    3    // Longitud
#define STRUCT_FIELDDEC    4    // Decimales
#define STRUCT_MYSQLTYPE   5    // Tipo MySQL nativo
#define STRUCT_FLAGS       6    // Bit flags
#define STRUCT_ALIAS       7    // Alias
#define STRUCT_ORGNAME     8    // Nombre original
#define STRUCT_TABLE       9    // Tabla
#define STRUCT_DB         10    // Base de datos
#define STRUCT_CHARSETNR  11    // Número de charset
#define STRUCT_RO         12    // Solo lectura
```

---

# 23. Clase TField: Metadatos de Campos

[← Referencia](22_referencia_rapida.md) | [Índice](README.md)

---

Cada campo de un RowSet se representa como un objeto `TField` con metadatos completos del servidor.

## Propiedades

| Propiedad | Tipo | Descripción |
|-----------|------|-------------|
| `name` | C | Nombre del campo (alias en SQL) |
| `org_name` | C | Nombre original en la tabla |
| `type` | C | Tipo FWH: `C`, `N`, `D`, `L`, `T`, `M`, `+`, `=`, `@` |
| `cType` | C | Tipo normalizado para comparaciones |
| `len` | N | Longitud |
| `dec` | N | Decimales |
| `sqltype` | N | Tipo MySQL nativo |
| `flags` | N | Flags del campo (bit flags) |
| `table` | C | Alias de tabla en el SQL |
| `org_table` | C | Nombre real de tabla |
| `cDb` | C | Base de datos |
| `Collation` | C | Collation del campo |
| `lReadOnly` | L | Solo lectura |
| `lAutoInc` | L | Auto-incremento |
| `lPrimary` | L | Clave primaria |
| `lUnique` | L | Único |
| `lKey` | L | Parte de un índice |
| `lNoNull` | L | No permite NULL |
| `lBinary` | L | Campo binario |
| `Value` | * | Valor actual (lectura/escritura) |
| `OriginalValue` | * | Valor original sin modificar |
| `Default` | * | Valor por defecto |
| `list` | A | Lista de valores para ComboBox |
| `cCase` | C | Formato: 'upper', 'proper' |
| `Precision` | N | Precisión numérica |
| `NumericScale` | N | Escala numérica |
| `DefinedSize` | N | Tamaño definido |
| `ActualSize` | N | Tamaño actual del valor |
| `nChrGrp` | N | Grupo de charset (CHR_ANSI o CHR_WIDE) |

## Acceso

```clipper
oField := oRs:Fields( "salary" )     // por nombre
oField := oRs:Fields( 3 )            // por posición (vía aFields)

? oField:Value                        // valor actual
oField:Value := 50000                 // asignar
? oField:OriginalValue                // valor antes de editar
oField:lReadOnly := .t.               // marcar solo lectura
```

## Tipos de campo FWH → MySQL

| Tipo FWH | Significado | MySQL |
|----------|-------------|-------|
| `C` | Carácter | VARCHAR, CHAR |
| `N` | Numérico | INT, DECIMAL, FLOAT, DOUBLE |
| `D` | Fecha | DATE |
| `T` | Fecha+Hora | DATETIME |
| `L` | Lógico | TINYINT(1), BIT |
| `M` | Memo (texto largo) | TEXT |
| `m` | Memo (binario) | BLOB |
| `+` | Auto-incremento | INT AUTO_INCREMENT |
| `=` | Timestamp auto | TIMESTAMP |
| `@` | DateTime auto | DATETIME (con default) |

---

*Documentación adicional y foro de soporte: https://forums.fivetechsupport.com*
