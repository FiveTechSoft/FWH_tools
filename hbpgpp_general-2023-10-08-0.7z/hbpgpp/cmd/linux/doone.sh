#-------------------------------------------------------------------------------
#  AUTOR.....: Manuel Expósito Suárez   Soft4U 2002-2020
#  CLASE.....: Construccion de la libreria
#  FECHA MOD.: 20/02/2020
#  VERSION...: 1.00
#  PROPOSITO.: Script de construccion de las librerias para Linux
#  Notas.....: Cambiar la opcion -comp con gcc o clang
#-------------------------------------------------------------------------------

echo Construyendo todas las librerias de linux para el compilador $1

hbmk2 -comp=$1 ./hbp/buildall.hbp > ./cmd/linux/$1.log

echo ...............................................................................
