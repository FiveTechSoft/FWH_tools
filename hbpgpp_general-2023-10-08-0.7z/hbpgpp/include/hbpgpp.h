//-----------------------------------------------------------------------------
// Archivo: hbpgpp.h
// Autor: Manu Exposito 2023
//-----------------------------------------------------------------------------

#pragma once
#ifndef HBPGPP_H
#define HBPGPP_H

//-----------------------------------------------------------------------------
// includes:

#include <hbobject.h>
#include <libpq-fe.h> // de postgres

//-----------------------------------------------------------------------------
// Para facilitar la obtencion del objeto C

#define _GETOBJC0() static_cast<THbPgpp *>( THbObject::getObjC() )
#define _GETOBJC1( pSelf ) static_cast<THbPgpp *>( THbObject::getObjC( pSelf ) )

//-----------------------------------------------------------------------------
// Constantes:

const HB_SIZE _OBJC_POS = 1;
const HB_UINT _NUN_VARS = 1;

//-----------------------------------------------------------------------------
// Clase C++

class THbPgpp : public THbObject 
{
	private:
		//---------------------------------------------------------------------
		// Propiedades privadas del objeto C++
		PGconn *conn;
		char *szConnInfo;
	public:
		// Constructor y destructor desde C++:
		THbPgpp( void );
		~THbPgpp( void );
		//---------------------------------------------------------------------
		// Metodos override:
		void init( void ) override;
		void init( PHB_ITEM ) override;
		void addMethods( HB_USHORT ) const override;
		//---------------------------------------------------------------------
		// Gestion real del objeto:
		bool open( void );
		void close( void ) const;
		bool exec( const char *szStmt );
		PHB_ITEM query( const char *szQuery, PHB_ITEM aColName );
		const char *getLastError( void );
		int getErrCode( void );
		//---------------------------------------------------------------------
		// Otras metadatos:
		char *getDbName() 
		{
			return PQdb( conn );
		};
		char *getUser() 
		{
			return PQuser( conn );
		};
		char *getPassword() 
		{
			return PQpass( conn );
		};
		char *getHost() 
		{
			return PQhost( conn );
		};
		char *getPort() 
		{
			return PQport( conn );
		};
		char *getTty() 
		{
			return PQtty( conn );
		};
		char *getOptions() 
		{
			return PQoptions( conn );
		};
};

//-----------------------------------------------------------------------------
// Declaración de funciones públicas. (Si hay, poner aquí)

//-----------------------------------------------------------------------------

#endif      // Fin de HBPGPP_H

//-----------------------------------------------------------------------------
