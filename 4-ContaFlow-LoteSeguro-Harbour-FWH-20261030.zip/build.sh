#!/bin/bash
# Cross-build on Linux with Wine, llvm-mingw, licensed FWH libs and Harbour Windows libs.
# Set HB_ROOT, FWH_INCLUDE, FWH_LIB, WINE and CC_PREFIX before running.
# Example: ARCH=64 CC_PREFIX=x86_64-w64-mingw32 HB_ROOT=... FWH_INCLUDE=... FWH_LIB=... ./build.sh
set -euo pipefail
: "${ARCH:=64}" "${WINE:=wine}" "${CC_PREFIX:=x86_64-w64-mingw32}"
: "${HB_ROOT:?}" "${FWH_INCLUDE:?}" "${FWH_LIB:?}"
if [[ $ARCH == 64 ]]; then LIBSUB=mingw64; FLIBS='-l:libFiveHG64.a -l:libFiveHGC64.a'; else LIBSUB=mingw; FLIBS='-l:libFiveHG.a -l:libFiveHGC.a'; fi
mkdir -p "bin$ARCH" obj
"$CC_PREFIX-clang" -c -O1 -Wall -Wextra -I"$HB_ROOT/include" src/native.c -o obj/native.o
for NAME in contaflow loteseguro; do
 "$WINE" "$HB_ROOT/bin/harbour.exe" "src/$NAME.prg" -n -w3 -q0 -I"$HB_ROOT/include" -I"$FWH_INCLUDE" -o"obj/$NAME.c"
 "$CC_PREFIX-clang" -c -O1 -Wall -Wextra -I"$HB_ROOT/include" "obj/$NAME.c" -o "obj/$NAME.o"
 "$CC_PREFIX-clang++" -o "bin$ARCH/$NAME.exe" "obj/$NAME.o" obj/native.o -mwindows -static -L"$FWH_LIB" -L"$HB_ROOT/lib/win/$LIBSUB" -Wl,--start-group $FLIBS -lgtgui -luser32 -lshell32 -lwinspool -lkernel32 -lcomctl32 -lcomdlg32 -lgdi32 -lgdiplus -lole32 -loleaut32 -lpsapi -loledlg -lmsimg32 -lversion -luuid -lwinmm -lvfw32 -lwsock32 -lmpr -lws2_32 -liphlpapi -ldwmapi -luxtheme -lhbcommon -lhbcpage -lhbcplr -lhbct -lhbdebug -lhbhsx -lhblang -lhbmacro -lhbmainwin -lhbmzip -lodbc32 -lhbpcre -lhbpp -lhbrdd -lhbrtl -lhbsix -lhbtip -lhbusrrdd -lhbvm -lhbwin -lhbzlib -lrddcdx -lrddfpt -lrddntx -lxhb -lhbziparc -lcrypt32 -lsecur32 -lminizip -lpng -Wl,--end-group -lc++ -lunwind
done
