#include "FiveWin.ch"
STATIC cHome, cRequest:="Increase the price of the top 20 best-selling seafood products by 5%."
STATIC cReview:="", oReview, aPlan:={}, lReady:=.F., cApprovedRequest:="", cFrozenSQL:=""
STATIC cConn := "host=127.0.0.1 port=55432 dbname=northwind_demo user=sandbox connect_timeout=5"
STATIC cPgDir := "", oReq

FUNCTION Main(cMode)
   LOCAL oDlg, oFont
   cHome:=hb_DirBase()+"..\\"
   cPgDir:=GetEnv("LOTESEGURO_LIBPQ")
   IF Empty(cPgDir) .AND. File(hb_DirBase()+"..\runtime\pgsql\libpq.dll")
      cPgDir:=hb_DirBase()+"..\runtime\pgsql"
   ENDIF
   IF cMode=="--test"
      BulkTests()
      RETURN NIL
   ENDIF
   DEFINE FONT oFont NAME "Segoe UI" SIZE 0,-16
   DEFINE DIALOG oDlg TITLE "LoteSeguro | Northwind change review" SIZE 1120,790 PIXEL FONT oFont
   @ 12,14 SAY "LoteSeguro - propose, challenge, approve" SIZE 520,20 OF oDlg PIXEL
   @ 36,14 SAY "Real PostgreSQL adapter. Restricted language grammar, no LLM. Demo database only." SIZE 520,16 OF oDlg PIXEL
   @ 61,14 SAY "Request: Increase/Decrease the price of the top N best-selling CATEGORY products by P%." SIZE 526,18 OF oDlg PIXEL
   @ 84,14 GET oReq VAR cRequest SIZE 525,24 OF oDlg PIXEL
   @ 120,14 BUTTON "Preview + critic" SIZE 120,26 OF oDlg PIXEL ACTION Preview()
   @ 120,144 BUTTON "Approve + commit" SIZE 130,26 OF oDlg PIXEL ACTION CommitUI()
   @ 120,284 BUTTON "Discard" SIZE 85,26 OF oDlg PIXEL ACTION Discard()
   @ 157,14 GET oReview VAR cReview MEMO READONLY SIZE 525,210 OF oDlg PIXEL
   @ 375,14 SAY "No preview can execute SQL. Approval commits only the frozen plan; any changed row aborts all." SIZE 530,14 OF oDlg PIXEL
   ACTIVATE DIALOG oDlg CENTERED
   PG_CLOSE()
   oFont:End()
RETURN NIL

STATIC FUNCTION ParseRequest(cText)
   LOCAL a:=hb_ATokens(Lower(AllTrim(cText))," "), nTop, nPct, cPct, cCategory, n
   IF Len(a)!=12
      RETURN { .F., "Unsupported wording. Use the displayed grammar.",0,0,"" }
   ENDIF
   IF !(a[1]=="increase" .OR. a[1]=="decrease") .OR. a[2]!="the" .OR. a[3]!="price" .OR. a[4]!="of" .OR. a[5]!="the" .OR. a[6]!="top" .OR. a[8]!="best-selling" .OR. a[10]!="products" .OR. a[11]!="by"
      RETURN {.F.,"Unsupported wording; no SQL generated.",0,0,""}
   ENDIF
   FOR n:=1 TO Len(a[7])
      IF !(SubStr(a[7],n,1) $ "0123456789")
         RETURN {.F.,"N must be an integer.",0,0,""}
      ENDIF
   NEXT
   nTop:=Val(a[7])
   cPct:=a[12]
   IF Right(cPct,1)=="."
      cPct:=Left(cPct,Len(cPct)-1)
   ENDIF
   IF Right(cPct,1)!="%"
      RETURN {.F.,"Percent sign is required.",0,0,""}
   ENDIF
   cPct:=Left(cPct,Len(cPct)-1)
   IF Empty(cPct) .OR. Occurs(".",cPct)>1
      RETURN {.F.,"Invalid percentage.",0,0,""}
   ENDIF
   FOR n:=1 TO Len(cPct)
      IF !(SubStr(cPct,n,1) $ "0123456789.")
         RETURN {.F.,"Invalid percentage; SQL input rejected.",0,0,""}
      ENDIF
   NEXT
   nPct:=Val(cPct)*iif(a[1]=="decrease",-1,1)
   cCategory:=a[9]
   IF AScan({"seafood","beverages","confections","condiments","produce"},cCategory)==0
      RETURN {.F.,"Unsupported category; no SQL generated.",0,0,""}
   ENDIF
   IF nTop<1 .OR. nTop>100 .OR. nPct==0 .OR. Abs(nPct)>25
      RETURN {.F.,"Safety limits: 1-100 rows and nonzero percentage up to 25%.",0,0,""}
   ENDIF
RETURN {.T.,"",nTop,nPct,cCategory}

STATIC FUNCTION ConnectDemo()
   LOCAL cErr, a
   IF Empty(cPgDir)
      RETURN "Set LOTESEGURO_LIBPQ to the directory containing libpq.dll and its dependencies."
   ENDIF
   cErr:=PG_OPEN(cPgDir,cConn)
   IF !Empty(cErr)
      RETURN cErr
   ENDIF
   a:=PG_QUERY("SET client_encoding TO 'WIN1252'")
   IF a[1]!=1
      RETURN "Cannot set client encoding: "+a[2]
   ENDIF
   a:=PG_QUERY("SELECT current_database(), marker FROM demo_guard WHERE marker='LOTESEGURO-FICTIONAL-ONLY'")
   IF a[1]!=2 .OR. Len(a[3])!=1
      PG_CLOSE()
      RETURN "Sandbox marker missing. This example refuses non-demo databases."
   ENDIF
   IF a[3,1,1]!="northwind_demo"
      PG_CLOSE()
      RETURN "Only database northwind_demo is permitted by this example."
   ENDIF
RETURN ""

STATIC FUNCTION BuildPlan(cText)
   LOCAL p:=ParseRequest(cText), cErr, a, aRow, nNew, cSQL:="", cTrail, aRows:={}
   IF !p[1]
      RETURN {.F.,p[2],{},""}
   ENDIF
   cErr:=ConnectDemo()
   IF !Empty(cErr)
      RETURN {.F.,cErr,{},""}
   ENDIF
   a:=PG_QUERY("SELECT p.product_id,p.product_name,p.unit_price::numeric(12,2),SUM(od.quantity)::bigint,p.discontinued FROM products p JOIN categories c ON c.category_id=p.category_id JOIN order_details od ON od.product_id=p.product_id WHERE lower(c.category_name)='"+p[5]+"' GROUP BY p.product_id,p.product_name,p.unit_price,p.discontinued ORDER BY SUM(od.quantity) DESC,p.product_id LIMIT "+hb_ntos(p[3]))
   IF a[1]!=2
      RETURN {.F.,a[2],{},""}
   ENDIF
   IF Empty(a[3])
      RETURN {.F.,"No matching products.",{},""}
   ENDIF
   cTrail:="ADVISORY CRITIC (deterministic rules, not AI):"+Chr(13)+Chr(10)
   cTrail+="- Best-selling = lifetime SUM(order_details.quantity), ties by product_id."+Chr(13)+Chr(10)
   cTrail+="- No date window inferred. All matching products, including discontinued, are eligible."+Chr(13)+Chr(10)
   IF Len(a[3])<p[3]
      cTrail+="- Requested "+hb_ntos(p[3])+", only "+hb_ntos(Len(a[3]))+" products match. No extra categories added."+Chr(13)+Chr(10)
   ENDIF
   IF Abs(p[4])>=10
      cTrail+="- WARNING: price change >= 10%."+Chr(13)+Chr(10)
   ENDIF
   FOR EACH aRow IN a[3]
      nNew:=Round(Val(aRow[3])*(1+p[4]/100),2)
      IF nNew<=0
         RETURN {.F.,"Nonpositive new price rejected.",{},""}
      ENDIF
      IF aRow[5]=="1"
         cTrail+="- WARNING: discontinued product "+aRow[1]+" included."+Chr(13)+Chr(10)
      ENDIF
      AAdd(aRows,{aRow[1],aRow[2],Val(aRow[3]),nNew,aRow[4]})
      cSQL+="UPDATE products SET unit_price="+NText(nNew)+" WHERE product_id="+aRow[1]+" AND unit_price::numeric(12,2)="+aRow[3]+";"+Chr(13)+Chr(10)
   NEXT
   cTrail+="- Row prices and names come from PostgreSQL, not generated text."+Chr(13)+Chr(10)
   cTrail+="- Transaction lock + optimistic price check. Any row mismatch rolls back all."+Chr(13)+Chr(10)
   cTrail+="- Rounding to two decimals; human approval required before BEGIN."+Chr(13)+Chr(10)
   cTrail+=Chr(13)+Chr(10)+"PROPOSED ROWS:"+Chr(13)+Chr(10)
   FOR EACH aRow IN aRows
      cTrail+=aRow[1]+" | "+aRow[2]+" | "+NText(aRow[3])+" -> "+NText(aRow[4])+" | sold "+aRow[5]+Chr(13)+Chr(10)
   NEXT
   cTrail+=Chr(13)+Chr(10)+"FROZEN SQL (not yet run):"+Chr(13)+Chr(10)+"BEGIN;"+Chr(13)+Chr(10)+cSQL+"COMMIT;"
RETURN {.T.,cTrail,aRows,cSQL}

STATIC FUNCTION NText(n)
RETURN AllTrim(Str(n,14,2))

STATIC FUNCTION Preview()
   LOCAL a:=BuildPlan(cRequest)
   lReady:=a[1]
   cReview:=a[2]
   aPlan:=a[3]
   cFrozenSQL:=a[4]
   cApprovedRequest:=cRequest
   oReview:Refresh()
RETURN NIL

STATIC FUNCTION Discard()
   aPlan:={}
   lReady:=.F.
   cFrozenSQL:=""
   cReview:="Discarded. Nothing was changed in PostgreSQL."
   oReview:Refresh()
RETURN NIL

STATIC FUNCTION ExecutePlan(aRows,lForceFailure)
   LOCAL cErr:=ConnectDemo(), a, aRow, cCheck, n, cSQL, cId
   IF !Empty(cErr)
      RETURN {.F.,cErr}
   ENDIF
   a:=PG_QUERY("BEGIN")
   IF a[1]!=1
      RETURN {.F.,a[2]}
   ENDIF
   a:=PG_QUERY("SET LOCAL lock_timeout='3s'")
   IF a[1]==1
      a:=PG_QUERY("LOCK TABLE products IN SHARE ROW EXCLUSIVE MODE")
   ENDIF
   IF a[1]!=1
      PG_QUERY("ROLLBACK")
      RETURN {.F.,"Lock failed: "+a[2]}
   ENDIF
   FOR n:=1 TO Len(aRows)
      aRow:=aRows[n]
      cId:=aRow[1]
      cCheck:="SELECT unit_price::numeric(12,2) FROM products WHERE product_id="+cId+" FOR UPDATE"
      a:=PG_QUERY(cCheck)
      IF a[1]!=2 .OR. Len(a[3])!=1
         PG_QUERY("ROLLBACK")
         RETURN {.F.,"Row missing; entire transaction rolled back."}
      ENDIF
      IF Val(a[3,1,1])!=aRow[3]
         PG_QUERY("ROLLBACK")
         RETURN {.F.,"Preview is stale at product "+cId+"; entire transaction rolled back. Preview again."}
      ENDIF
      cSQL:="UPDATE products SET unit_price="+NText(aRow[4])+" WHERE product_id="+cId+" AND unit_price::numeric(12,2)="+NText(aRow[3])
      a:=PG_QUERY(cSQL)
      IF a[1]!=1 .OR. a[4]!="1"
         PG_QUERY("ROLLBACK")
         RETURN {.F.,"UPDATE failed or affected !=1 row; all changes rolled back. "+a[2]}
      ENDIF
      IF lForceFailure .AND. n==1
         PG_QUERY("ROLLBACK")
         RETURN {.F.,"Test injected failure after first UPDATE; rolled back."}
      ENDIF
   NEXT
   a:=PG_QUERY("COMMIT")
   IF a[1]!=1
      PG_QUERY("ROLLBACK")
      RETURN {.F.,"COMMIT failed: "+a[2]}
   ENDIF
RETURN {.T.,"COMMITTED "+hb_ntos(Len(aRows))+" approved updates to fictional Northwind."}

STATIC FUNCTION CommitUI()
   LOCAL a
   IF !lReady .OR. Empty(aPlan)
      MsgStop("Preview a valid request first.")
      RETURN NIL
   ENDIF
   IF cRequest!=cApprovedRequest
      Discard()
      MsgStop("Request changed. Preview again; no SQL executed.")
      RETURN NIL
   ENDIF
   IF !MsgYesNo("Commit exactly "+hb_ntos(Len(aPlan))+" proposed price changes to FICTIONAL Northwind?"+Chr(13)+Chr(10)+"Review the critic and SQL before choosing Yes.")
      RETURN NIL
   ENDIF
   a:=ExecutePlan(aPlan,.F.)
   cReview:=a[2]+Chr(13)+Chr(10)+Chr(13)+Chr(10)+cReview
   MemoWrit(cHome+"last-approved-batch.sql",cFrozenSQL)
   lReady:=.F.
   aPlan:={}
   oReview:Refresh()
RETURN NIL

STATIC FUNCTION BulkTests()
   LOCAL p, a, before, after, nFail:=0, cReport:="", cErr, row
   p:=ParseRequest(cRequest)
   Test(p[1] .AND. p[3]==20 .AND. p[4]==5,"example request parses",@nFail,@cReport)
   p:=ParseRequest("DROP TABLE products")
   Test(!p[1],"arbitrary SQL rejected",@nFail,@cReport)
   p:=ParseRequest(StrTran(cRequest,"5%","30%"))
   Test(!p[1],"percentage cap enforced",@nFail,@cReport)
   p:=ParseRequest(StrTran(cRequest,"20 best","0 best"))
   Test(!p[1],"zero row limit rejected",@nFail,@cReport)
   cErr:=ConnectDemo()
   Test(Empty(cErr),"real libpq PostgreSQL demo connection: "+cErr,@nFail,@cReport)
   IF Empty(cErr)
      before:=PG_QUERY("SELECT SUM(unit_price::numeric(12,2))::text FROM products")
      a:=BuildPlan(cRequest)
      Test(a[1],"preview queries real Northwind",@nFail,@cReport)
      IF a[1]
         Test(Len(a[3])<=20 .AND. Len(a[3])>0,"bounded top selling seafood rows",@nFail,@cReport)
         after:=PG_QUERY("SELECT SUM(unit_price::numeric(12,2))::text FROM products")
         Test(before[3,1,1]==after[3,1,1],"preview causes no mutation",@nFail,@cReport)
         p:=ExecutePlan(a[3],.T.)
         after:=PG_QUERY("SELECT SUM(unit_price::numeric(12,2))::text FROM products")
         Test(!p[1] .AND. before[3,1,1]==after[3,1,1],"injected failure after first UPDATE fully rolls back",@nFail,@cReport)
         p:={}
         FOR EACH row IN a[3]
            AAdd(p,AClone(row))
         NEXT
         p[Len(p),3]:=p[Len(p),3]+0.01
         p:=ExecutePlan(p,.F.)
         after:=PG_QUERY("SELECT SUM(unit_price::numeric(12,2))::text FROM products")
         Test(!p[1] .AND. before[3,1,1]==after[3,1,1],"stale last row rolls back earlier updates",@nFail,@cReport)
         p:=ExecutePlan(a[3],.F.)
         after:=PG_QUERY("SELECT SUM(unit_price::numeric(12,2))::text FROM products")
         Test(p[1] .AND. before[3,1,1]!=after[3,1,1],"approved executor commits real demo updates",@nFail,@cReport)
         FOR EACH p IN a[3]
            PG_QUERY("UPDATE products SET unit_price="+NText(p[3])+" WHERE product_id="+p[1])
         NEXT
         after:=PG_QUERY("SELECT SUM(unit_price::numeric(12,2))::text FROM products")
         Test(before[3,1,1]==after[3,1,1],"test fixture restored after commit",@nFail,@cReport)
      ENDIF
   ENDIF
   MemoWrit(hb_DirBase()+"bulk-tests.txt",cReport+"FAILURES="+hb_ntos(nFail))
   PG_CLOSE()
RETURN NIL

STATIC FUNCTION Test(lOK,cName,nFail,cReport)
   cReport+=iif(lOK,"PASS ","FAIL ")+cName+Chr(13)+Chr(10)
   IF !lOK
      nFail++
   ENDIF
RETURN NIL
