TOTAL ON visual demo - f91fa20

Contents: demos/totalon.prg and demos/totalon.hbp. No hbide dependency modules,
runtime data or binaries are included. Source corresponds to FiveTechSoft/hbide,
branch designer-robustness, commit f91fa20 (PRG); HBP unchanged from f2bee84.
Olin authorized redistribution of these two demo files for this publication.
This is not a new general license or permission to redistribute dependencies.

Requirements: a Harbour development installation and an hbide checkout with
the modules listed by the HBP. Preserve demos/ paths in that checkout, then
run from its root:

  hbmk2 demos/totalon.hbp

Functional Linux UTF-8 tests are reported by the author. Windows is untested.
The hbide open/edit/save/recompile test was on the older f2bee84 version, not
this f91fa20 version. This package was reviewed, not compiled or run here.

This is a demo, not a complete FoxPro TOTAL ON implementation.
- Scope means REST from the current record; Fields selects numeric fields.
- WHILE stops at the first false condition. FOR skips non-matching records.
- FOR and WHILE share one Expr field. Selecting both evaluates that same
  expression twice on a record that passes WHILE.
- Expressions use Harbour macros and can execute code. Trusted input only.
- An expression error cancels before emitting totals or writing the output.
- Save As creates the requested output path exclusively, without replacing an
  existing file. This is not transactional storage: an I/O failure can leave
  a newly created partial file.
