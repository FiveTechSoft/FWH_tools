/*
 * $Id: getbtn.c,v 1.1 2000/11/20 20:47:07 RRamirez Exp $
 * The author of this program is Ricardo Ramirez.
 * Is included with TSBrowse class only for Harbour tests.
 */

#define __HARBOUR__
#define STRICT

#include <hbApi.h>
#include <WinTen.h>
#include <Windows.h>
#include <ClipApi.h>

#ifdef __cplusplus
 extern "C" {
#endif

#ifdef __cplusplus
 }
#endif

#ifndef __HARBOUR__
   CLIPPER GETBTN( PARAMS )  // ( hWnd, nLen ) --> Nil
#else
   HARBOUR HB_FUN_GETBTN( PARAMS )
#endif
{
    HWND hWnd = ( HWND ) _parnl( 1 );

    RECT rect;

   GetClientRect( hWnd, &rect );
   rect.right -= (short)_parni( 2 ) ;
   SendMessage( hWnd, EM_SETRECTNP, 0, ( LONG ) &rect );
}
/*
builc.bat
set xpath=%path%
PATH=V:.;C:\NOVELL\CLIENT32;C:\WINDOWS;C:\WINDOWS\COMMAND;E:\ETC\CL53\BIN;E:\ETC\MW;E:\ETC\BIN;E:\ETC\B4;E:\ETC\BC\BIN;C:\WINDOWS;Z:.;Y:.;X:.;W:.

BCC.EXE -3 -c -ml -O2 -G -B -Tq -IE:\ETC\CL53\INCLUDE;E:\bc\INCLUDE;e:\fw\include %1%

set path=%xpath%
*/
