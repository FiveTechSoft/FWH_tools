/***************************************************************

This file contains the special painting routines used by TSBrowse Class
Last update: February 26th, 2008

***************************************************************/

#ifdef __HARBOUR__
#include <hbApi.h>   /* set your own path if needed */
#endif

#include <WinTen.h>   /* set your own path if needed */
#include <Windows.h>
#include <ClipApi.h>  /* set your own path if needed */
#include <shellapi.h>
#include <StdLib.h>

void WndBoxDraw( HDC, LPRECT, HPEN, HPEN, int, BOOL ) ;
void cDrawCursor( HWND, LPRECT, long, COLORREF ) ;
void DrawCheck( HDC, LPRECT, HPEN, int, BOOL ) ;
DWORD GetTextExtent( HDC, LPCSTR, int ) ;

extern void DrawBitmap( HDC, HBITMAP, WORD wCol, WORD wRow, WORD wWidth,
                        WORD wHeight, DWORD dwRaster ) ;
extern void DrawMasked( HDC hdc, HBITMAP hbm, WORD y, WORD x ) ;

extern void MaskRegion( HDC hDC, RECT * rct, COLORREF cTransparent ,
		        			   COLORREF cBackground ) ;

static void GoToPoint( HDC, int, int ) ;

static void DegradColor( HDC, RECT *, COLORREF, COLORREF ) ;

//---------------------------------------------------------------------------//

#ifndef __HARBOUR__
CLIPPER TSDrawCell( PARAMS ) // ( hWnd, hDC, nRow, nColumn , nWidth ,
  	                          //   uData, nAlign , nClrFore, nClrBack ,
     	                       //   hFont, nBitmap, nHeightCell,
        	                    //   b3DLook, nLineStyle, nClrLine, nHeadFoot,
           	                 //   nHeightHead, nHeightFoot, hHeightSuper,
              	              //   lAdjBmpl, lMultiLine, nVAlign, nVertText,
                 	           //   nClrTo, lDegrad, hBrush )
#else
HARBOUR HB_FUN_TSDRAWCELL( PARAMS )
#endif
{
   HWND hWnd        = (HWND) _parni( 1 ) ;
   HDC  hDC         = (HDC) _parni( 2 ) ;
   int  nRow        = _parni( 3 ) ;
   int  nColumn     = _parni( 4 ) ;
   int  nWidth      = _parni( 5 ) ;
   LPSTR cData      = _parc( 6 )  ;
   int  nLen        = _parclen( 6 ) ;
   DWORD nAlign     = _parnl( 7 ) ;
   COLORREF clrFore = _parnl( 8 ) ;
   COLORREF clrBack = _parnl( 9 ) ;
   HFONT hFont      = (HFONT) _parni( 10 ) ;
   HBITMAP hBitMap  = (HBITMAP) _parni( 11 ) ;
   int nHeightCell  = _parni( 12 ) ;
   BOOL b3DLook     = _parl( 13 ) ;
   int nLineStyle   = _parni( 14 ) ;
   COLORREF clrLine = _parnl( 15 ) ;
   int nHeadFoot    = _parni( 16 ) ;
   int nHeightHead  = _parni( 17 ) ;
   int nHeightFoot  = _parni( 18 ) ;
   int nHeightSuper = _parni( 19 ) ;
   BOOL bAdjBmp     = _parl( 20 ) ;
   BOOL bMultiLine  = _parl( 21 ) ;
   int nVAlign      = _parni( 22 ) ;
   int nVertText    = _parni( 23 ) ;
   COLORREF clrTo   = _parnl( 24 ) ;
   BOOL bOpaque     = _parl( 25 ) ;
   HBRUSH wBrush    = (HBRUSH) _parnl( 26 ) ;
   BOOL b3DInv      = ( ISLOGICAL( 27 ) ? ! _parl( 27 ) : FALSE ) ;
   BOOL b3D         = ( ISLOGICAL( 27 ) ? TRUE : FALSE ) ;
   COLORREF nClr3DL = _parnl( 28 ) ;
   COLORREF nClr3DS = _parnl( 29 ) ;
   long lCursor     = _parnl( 30 ) ;

   int ixLayOut     = HIWORD( nAlign ) ;
   int iAlign       = LOWORD( nAlign ) ;
   int iTxtW        = LOWORD( GetTextExtent( hDC, cData, nLen ) ) ;
   BOOL bGrid       = ( nLineStyle > 0 ? TRUE : FALSE ) ;
   BOOL bHeader     = ( nHeadFoot == 1 ? TRUE : FALSE ) ;
   BOOL bFooter     = ( nHeadFoot == 2 ? TRUE : FALSE ) ;
   BOOL bSuper      = ( nHeadFoot == 3 ? TRUE : FALSE ) ;
   BOOL bChecked    = ( nVertText == 3 ? TRUE : FALSE ) ;
   BOOL bBrush      = ( wBrush ? TRUE : FALSE ) ;
   BOOL bDegrad     = ( clrTo == clrBack ? FALSE : TRUE ) ;
   HFONT hOldFont ;
   BOOL bDestroyDC  = FALSE ;
   HPEN hGrayPen    = CreatePen( PS_SOLID, 1, clrLine );
   HPEN hWhitePen   = CreatePen( PS_SOLID, 1, GetSysColor( COLOR_BTNHIGHLIGHT ) ) ;

   RECT rct ;
   BITMAP bm ;
   int nTop, nLeft, nBkOld, iFlags ;

   if( ! hDC )
   {
      bDestroyDC = TRUE ;
      hDC = GetDC( hWnd ) ;
   }

   if( hFont )
      hOldFont = SelectObject( hDC, hFont ) ;

   GetClientRect( hWnd, &rct ) ;
   SetTextColor( hDC, clrFore ) ;
   SetBkColor( hDC, clrBack ) ;

   if( nRow == 0 )
   	rct.top = ( bHeader ? nHeightSuper - ( nHeightSuper ? 1 : 0 ) : 0 ) ;
   else
   	rct.top = ( bFooter ? rct.bottom - nHeightFoot + 1 : nHeightHead + nHeightSuper - ( nHeightSuper ? 1 : 0 ) +
                  ( nHeightCell * ( nRow - 1 ) ) ) ;

   rct.bottom = rct.top + ( bHeader ? nHeightHead :( bSuper ? nHeightSuper : nHeightCell ) - 1 ) ;

   /* Don't let left side go beyond rct.right of Client Rect. */
   if( nColumn - ( rct.right - rct.left ) <= 0 )
   {
      rct.left = nColumn ;

        /* if nWidth == -1 or -2, it indicates the last column so go to limit,
         Don't let right side go beyond rct.right of Client Rect. */
      if( ( nWidth >= 0 ) && ((rct.left + nWidth - rct.right) <= 0) )  // negative values have different meanings
         rct.right = rct.left + nWidth ;

      if( ! bDegrad )
      {
        	rct.bottom += ( bHeader ? 0 : 1 ) ;
         rct.right += 1 ;

        	if( ! bBrush )
            ExtTextOut( hDC, rct.left, rct.top, ETO_OPAQUE | ETO_CLIPPED, &rct, "", 0, 0  ) ;
         else
            FillRect( hDC, &rct, wBrush ) ;

        	rct.bottom -= ( bHeader ? 0 : 1 ) ;
         rct.right -= 1 ;
      }
      else
         DegradColor( hDC, &rct, clrBack, clrTo ) ;

      if( hBitMap )
      {

         if( ! bAdjBmp )
         {
             GetObject( hBitMap, sizeof( BITMAP ), ( LPSTR ) &bm ) ;
             nTop = rct.top + ( ( rct.bottom - rct.top + 1 ) / 2 ) - ( bm.bmHeight / 2 ) ;

             switch( ixLayOut ) // bitmap layout x coordinate
             {
              	case 0: // column left
                 	nLeft = rct.left ;
                  break ;
               case 1: // column center (text -if any- may overwrite the bitmap)
                  nLeft = rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) -
                          ( bm.bmWidth / 2 ) - 1 ;
                  break ;
               case 2: // column right
                	nLeft = rct.right - ( bm.bmWidth + 2 ) ;
                  break ;
             	case 3: // left of centered text
                  nLeft = max( rct.left, rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) -
                          ( iTxtW / 2 ) - bm.bmWidth - 2 ) ;
                  break ;
             	case 4: // right of centered text
                  nLeft = rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) +
                          ( iTxtW / 2 ) + 2 ;
                  break ;
             	default: // a value > 4 means specific pixel location from column left
               	nLeft = rct.left + ixLayOut ;
             		break ;
             }
         }
         else
         {
            nTop  = rct.top ;
            nLeft = rct.left ;
         }

         if( b3DLook )
         {
            if( bAdjBmp )
            {
               nTop  = rct.top + 1 ;
               DrawBitmap( hDC, hBitMap,  nTop, rct.left - 1, rct.right - rct.left + 1,
                           rct.bottom - rct.top - 1, 0 ) ;
            	hBitMap = 0 ;

         		if( ! bOpaque )
            		MaskRegion( hDC, &rct, GetPixel( hDC, nLeft, nTop ), GetBkColor( hDC ) ) ;
            }
            else
               if( bOpaque )
               	DrawBitmap( hDC, hBitMap, nTop, nLeft, 0, 0, 0 ) ;
               else
                  DrawMasked( hDC, hBitMap, nTop, nLeft ) ;
         }
         else
         {
            if( bAdjBmp)
            {
               DrawBitmap( hDC, hBitMap,  rct.top, rct.left - 2, rct.right - rct.left + 3,
                           rct.bottom - rct.top - 1, 0 ) ;
            	hBitMap = 0 ;

         		if( ! bOpaque )
            		MaskRegion( hDC, &rct, GetPixel( hDC, nLeft, nTop ), GetBkColor( hDC ) ) ;
            }
            else
               if( bOpaque )
               	DrawBitmap( hDC, hBitMap, nTop, nLeft, 0, 0, 0 ) ;
               else
                  DrawMasked( hDC, hBitMap, nTop, nLeft ) ;
         }
      }

      if( nLen )
      {
         if( iAlign == DT_LEFT )
           	rct.left += ( 2 + ( hBitMap && ixLayOut == 0 ? bm.bmWidth + 1 : 0 ) ) ;

         if( iAlign == DT_RIGHT )
         	rct.right -= ( 2 + ( hBitMap && ixLayOut == 2 ? bm.bmWidth + 1 : 0 ) ) ;

         if( nVertText == 1 )
         {
            rct.right  += ( 4 * nLen ) ;
            rct.bottom += 8 ;
         }

         iFlags = iAlign | DT_NOPREFIX | nVAlign * 4 | ( bMultiLine && nVAlign < 2 ? 0 : DT_SINGLELINE ) ;

         if( ( nVertText == 3 || nVertText == 4 ) )
           	DrawCheck( hDC, &rct, hWhitePen, iAlign, bChecked ) ;
         else
         {
            nBkOld = SetBkMode( hDC, TRANSPARENT ) ;

            if( b3D )
            {
               rct.top    -= 1 ;
               rct.left   -= 1 ;
               rct.bottom -= 1 ;
               rct.right  -= 1 ;
   				SetTextColor( hDC, b3DInv ? nClr3DS : nClr3DL ) ;
             	DrawText( hDC, cData, nLen, &rct, iFlags ) ;

               rct.top    += 2 ;
               rct.left   += 2 ;
               rct.bottom += 2 ;
               rct.right  += 2 ;
   				SetTextColor( hDC, b3DInv ? nClr3DL : nClr3DS ) ;
               DrawText( hDC, cData, nLen, &rct, iFlags ) ;

               rct.top    -= 1 ;
               rct.left   -= 1 ;
               rct.bottom -= 1 ;
               rct.right  -= 1 ;
   				SetTextColor( hDC, clrFore ) ;
			   }

            DrawText( hDC, cData, nLen, &rct, iFlags ) ;
            SetBkMode( hDC, nBkOld ) ;
         }

         if( iAlign == DT_LEFT )
           	rct.left -= ( 2 + ( hBitMap && ixLayOut == 0 ? bm.bmWidth + 1 : 0 ) ) ;

         if( iAlign == DT_RIGHT )
         	rct.right += ( 2 + ( hBitMap && ixLayOut == 2 ? bm.bmWidth + 1 : 0 ) ) ;

         if( nVertText == 1 )
         {
            rct.right -= ( 4 * nLen ) ;
           	rct.bottom -= 8 ;
         }
      }

      if( b3DLook )
      {
        	bHeader = ( bSuper ? bSuper : bHeader ) ;

         if( ( nWidth != -2 ) && bGrid )   // -1 draw gridline in phantom column; -2 don't draw gridline in phantom column
            WndBoxDraw( hDC, &rct, hWhitePen, hGrayPen, b3DLook ? 4 : nLineStyle, bHeader ) ;

         if( lCursor )
           	cDrawCursor( hWnd, &rct, lCursor, clrFore ) ;

      }
      else
      {
         bHeader = ( bFooter ? bFooter : ( bHeader || bSuper ) ) ;

        	if( ( nWidth != -2 ) && bGrid )   // -1 draw gridline in phantom column; -2 don't draw gridline in phantom column
           	   WndBoxDraw( hDC, &rct, hGrayPen, hGrayPen, nLineStyle, bHeader ) ;

         if( lCursor )
         	cDrawCursor( hWnd, &rct, lCursor, clrFore ) ;
      }

   }

   DeleteObject( hGrayPen ) ;
   DeleteObject( hWhitePen ) ;
   if( hFont )
      SelectObject( hDC, hOldFont ) ;

   if( bDestroyDC )
      ReleaseDC( hWnd, hDC ) ;
}

//---------------------------------------------------------------------------//

void WndBoxDraw( HDC hDC, RECT * rct, HPEN hPUpLeft, HPEN hPBotRit, int nLineStyle, \
                 BOOL bHeader )

{
   HPEN hOldPen = SelectObject( hDC, hPUpLeft ) ;
   HPEN hBlack   = CreatePen( PS_SOLID, 1, 0 ) ;

   switch( nLineStyle )
   {
   	case 0 :
      	break ;
 		case 1 :
      	SelectObject( hDC, hPBotRit ) ;
      	GoToPoint( hDC, rct->left, rct->bottom - ( bHeader ? 1 : 0 ) ) ;
	      LineTo( hDC, rct->right - 1, rct->bottom - ( bHeader ? 1 : 0 ) ) ;
	      LineTo( hDC, rct->right - 1, rct->top - 1 ) ;
         if( bHeader )
         	LineTo( hDC, rct->left - 1, rct->top - 1 ) ;
         break ;
		case 2 :
      	SelectObject( hDC, hPBotRit ) ;
      	GoToPoint( hDC, rct->right - 1, rct->bottom ) ;
	      LineTo( hDC, rct->right - 1, rct->top - 1 ) ;
         break ;
		case 3 :
      	SelectObject( hDC, hPBotRit ) ;
      	GoToPoint( hDC, rct->left, rct->bottom ) ;
	      LineTo( hDC, rct->right, rct->bottom ) ;
         break ;
		case 4 :
      	SelectObject( hDC, hPUpLeft ) ;
      	GoToPoint( hDC, rct->left, rct->bottom ) ;
	      LineTo( hDC, rct->left, rct->top ) ;
	      LineTo( hDC, rct->right , rct->top ) ;
      	SelectObject( hDC, hPBotRit ) ;
      	GoToPoint( hDC, rct->left, rct->bottom - ( bHeader ? 1 : 0 ) ) ;
	      LineTo( hDC, rct->right - 1, rct->bottom - ( bHeader ? 1 : 0 ) ) ;
	      LineTo( hDC, rct->right - 1, rct->top - 1 ) ;
         break ;
      case 5 :
	   	rct->top += 1 ;
   		rct->left += 1 ;
		   rct->bottom -= 1 ;
   		rct->right -= 1 ;
   		DrawFocusRect( hDC, rct );
   		break ;
   }

   SelectObject( hDC, hOldPen );
   DeleteObject( hBlack );
}

//---------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER TSBrwScrol( PARAMS )  // l( hWnd, nDir, hFont, nHeightCell, nHeightHead,
                                 //    nHeightFoot, nHeightSuper )
#else
   HARBOUR HB_FUN_TSBRWSCROLL( PARAMS )
#endif
{
   HWND hWnd        = (HWND) _parni( 1 ) ;
   int iRows        = _parni( 2 ) ;
   HFONT hFont      = (HFONT) _parni( 3 ) ;
   int nHeightCell  = _parni( 4 ) ;
   int nHeightHead  = _parni( 5 ) ;
   int nHeightFoot  = _parni( 6 ) ;
   int nHeightSuper = _parni( 7 ) ;

   HFONT hOldFont ;
   HDC hDC = GetDC( hWnd ) ;
   RECT rct;

   if( hFont )
      hOldFont = SelectObject( hDC, hFont ) ;

   GetClientRect( hWnd, &rct ) ;

   rct.top    += ( nHeightHead + nHeightSuper - ( nHeightSuper ? 1 : 0 ) ) ;  // exclude heading from scrolling
   rct.bottom -= nHeightFoot ;                     // exclude footing from scrolling
   rct.bottom -= ( ( rct.bottom - rct.top + 1 ) % nHeightCell );  // exclude unused portion at bottom
   ScrollWindowEx( hWnd, 0, (int) -( nHeightCell * iRows ), 0, &rct, 0, 0, 0 );

   if( hFont )
      SelectObject( hDC, hOldFont );

   ReleaseDC( hWnd, hDC );
}

//----------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER TSBrwHScro( PARAMS )  // ll( hWnd, nCols, nLeft, nRight )
#else
   HARBOUR HB_FUN_TSBRWHSCROLL( PARAMS )
#endif
{
   HWND hWnd  = (HWND) _parni( 1 ) ;
   WORD wCols = _parni( 2 ) ;
   int nLeft  = _parni( 3 ) ;
   int nRight = _parni( 4 ) ;

   HDC hDC    = GetDC( hWnd ) ;
   RECT rct;

   GetClientRect( hWnd, &rct ) ;

   if ( nLeft )
      rct.left = nLeft ;

   if ( nRight )
      rct.right = nRight ;

   ScrollWindowEx( hWnd, wCols, 0, 0, &rct, 0, 0, 0 ) ;

   ReleaseDC( hWnd, hDC ) ;
}


//---------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER RowFromPix( PARAMS ) // ( hWnd, nRowPix, nHeightCell, nHeightHead,
                                //   nHeightFoot, nHeightSuper ) -> nTextRow
#else
   HARBOUR HB_FUN_ROWFROMPIX( PARAMS )
#endif
{
	HWND hWnd = ( HWND ) _parni( 1 ) ;
   int iPixR = _parni( 2 ) ;
   int iCell = _parni( 3 ) ;
   int iHead = _parni( 4 ) ;
   int iFoot = _parni( 5 ) ;
   int iSupH = _parni( 6 ) ;

   RECT rct ;
   int iRow ;

   GetClientRect( hWnd, &rct ) ;

   if( iPixR <= ( rct.top + iHead + iSupH ) )
      iRow = 0 ;
   else
      if( iPixR >= ( rct.bottom - iFoot ) )
         iRow = -1 ;
      else
      {
         rct.top += ( iHead + iSupH ) ;
         iRow = ( ( iPixR - rct.top ) / iCell ) + 1 ;
      }

   _retni( iRow ) ;
}

//---------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER SBGetHeigh( PARAMS ) // t( hWnd, hFont, nTotal )
#else
   HARBOUR HB_FUN_SBGETHEIGHT( PARAMS )
#endif
{
   HWND  hWnd  = (HWND) _parni( 1 ) ;
   HFONT hFont = (HFONT) _parni( 2 ) ;
   int  iTotal = _parni( 3 )  ;

   TEXTMETRIC tm ;

   RECT  rct ;
   HDC   hDC = GetDC( hWnd ) ;
   HFONT hOldFont ;
   LONG  lTotHeight, lReturn ;

   if( iTotal < 2 )
   {
      if( hFont )
         hOldFont = SelectObject( hDC, hFont ) ;
   	GetTextMetrics( hDC, &tm ) ;
      if( hFont )
         SelectObject( hDC, hOldFont ) ;
   	ReleaseDC( hWnd, hDC ) ;
      lReturn = ( iTotal == 1 ? tm.tmAveCharWidth : tm.tmHeight ) ;
      _retnl( lReturn ) ;
   }
   else
   {
   	GetWindowRect( hWnd, &rct ) ;
      lTotHeight = rct.bottom - rct.top + 1 ;
   	ReleaseDC( hWnd, hDC ) ;
      _retnl( lTotHeight ) ;
	}
}

//----------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER CountRows( PARAMS )  // ( hWnd, nHeightCell, nHeightHead,
                                //   nHeightFoot, nHeightSuper ) -> nRows
#else
   HARBOUR HB_FUN_COUNTROWS( PARAMS )
#endif
{
	HWND hWnd = ( HWND ) _parni( 1 ) ;
   int iCell = _parni( 2 ) ;
   int iHead = _parni( 3 ) ;
   int iFoot = _parni( 4 ) ;
   int iSupH = _parni( 5 ) ;

   RECT rct ;
   int iRows, iFree ;

   GetClientRect( hWnd, &rct ) ;

   iFree = rct.bottom - rct.top + 1 - iSupH - iHead - iFoot ;
   iRows = iFree / iCell ;

   _retni( iRows ) ;
}

//---------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER SBmpHeight( PARAMS ) // ( hBmp )
#else
   HARBOUR HB_FUN_SBMPHEIGHT( PARAMS ) // ( hBmp )
#endif
{
   HBITMAP hBmp  = (HBITMAP) _parni( 1 ) ;
   BITMAP bm ;

   GetObject( hBmp, sizeof( BITMAP ), ( LPSTR ) &bm ) ;

   _retni( bm.bmHeight ) ;
}

//---------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER SBmpWidth( PARAMS ) // ( hBmp )
#else
   HARBOUR HB_FUN_SBMPWIDTH( PARAMS )
#endif
{
   HBITMAP hBmp  = (HBITMAP) _parni( 1 ) ;
   BITMAP bm ;

   GetObject( hBmp, sizeof( BITMAP ), ( LPSTR ) &bm ) ;

   _retni( bm.bmWidth ) ;
}

//---------------------------------------------------------------------------//

void DrawCheck( HDC hDC, LPRECT rct, HPEN hWhitePen, int nAlign, BOOL bChecked )
{
   RECT lrct ;
   HPEN hOldPen ;
   HBRUSH hOldBrush ;

   HBRUSH hGrayBrush  = CreateSolidBrush( RGB( 192, 192, 192 ) ) ;
   HBRUSH hWhiteBrush = CreateSolidBrush( RGB( 255, 255, 255 ) ) ;
   HPEN hBlackPen     = CreatePen( PS_SOLID, 1, RGB( 0, 0, 0 ) ) ;
   HPEN hLGrayPen     = CreatePen( PS_SOLID, 1, RGB( 192, 192, 192 ) ) ;
   HPEN hGrayPen      = CreatePen( PS_SOLID, 1, RGB( 128, 128, 128 ) ) ;

   hOldBrush = SelectObject( hDC, hGrayBrush ) ;

   lrct.top = rct->top + ( ( ( rct->bottom - rct->top + 1 ) / 2 ) - 8 );

   switch( nAlign )
   {
   	case 0:
     		lrct.left = rct->left ;
      	break ;
      case 1:
      	lrct.left = rct->left + ( ( rct->right - rct->left + 1 ) / 2 ) - 8 ;
      	break ;
      case 2:
     		lrct.left = rct->right - 16 ;
      	break ;
   }

   lrct.bottom = lrct.top + 16 ;
   lrct.right  = lrct.left + 16 ;

   lrct.left   -= 1 ;
   lrct.top    -= 1 ;
   lrct.right  += 1 ;
   lrct.bottom += 1 ;

   hOldPen = SelectObject( hDC, hBlackPen ) ;
   Rectangle( hDC, lrct.left, lrct.top, lrct.right, lrct.bottom ) ;

   lrct.left   += 1 ;
   lrct.top    += 1 ;
   lrct.right  -= 1 ;
   lrct.bottom -= 1 ;

   FillRect( hDC, &lrct, hGrayBrush ) ;

   lrct.top    += 2 ;
   lrct.left   += 2 ;
   lrct.right  -= 1 ;
   lrct.bottom -= 1 ;

   FillRect( hDC, &lrct, hWhiteBrush ) ;

   SelectObject( hDC, hOldBrush ) ;
   DeleteObject( hGrayBrush ) ;
   DeleteObject( hWhiteBrush ) ;

   lrct.right  -= 1 ;
   lrct.bottom -= 1 ;

   SelectObject( hDC, hGrayPen ) ;
   Rectangle( hDC, lrct.left, lrct.top, lrct.right, lrct.bottom ) ;

   lrct.top    += 1 ;
   lrct.left   += 1 ;
   lrct.right  -= 1 ;
   lrct.bottom -= 1 ;

   SelectObject( hDC, hBlackPen ) ;
   Rectangle( hDC, lrct.left, lrct.top, lrct.right, lrct.bottom ) ;

   lrct.top  += 1 ;
   lrct.left += 1 ;

   SelectObject( hDC, hWhitePen ) ;
   Rectangle( hDC, lrct.left, lrct.top, lrct.right, lrct.bottom ) ;

   lrct.top    += 1 ;
   lrct.right  -= 2 ;
   lrct.bottom -= 1 ;

   if( bChecked )
   {
      GoToPoint( hDC, lrct.right, lrct.top ) ;

   	SelectObject( hDC, hBlackPen ) ;

	   LineTo( hDC, lrct.right - 4 , lrct.bottom - 3 ) ;
   	LineTo( hDC, lrct.right - 6, lrct.bottom - 5 ) ;

      GoToPoint( hDC, lrct.right, lrct.top + 1) ;
   	LineTo( hDC, lrct.right - 4 , lrct.bottom - 2 ) ;
	   LineTo( hDC, lrct.right - 6, lrct.bottom - 4 ) ;

      GoToPoint( hDC, lrct.right, lrct.top + 2) ;
   	LineTo( hDC, lrct.right - 4 , lrct.bottom - 1 ) ;
	   LineTo( hDC, lrct.right - 6, lrct.bottom - 3 ) ;
   }

	SelectObject( hDC, hOldPen ) ;
   DeleteObject( hGrayPen ) ;
   DeleteObject( hLGrayPen ) ;
   DeleteObject( hBlackPen ) ;
}

//----------------------------------------------------------------------------//

static void GoToPoint( HDC hDC, int ix, int iy )
{
   POINT pt;

   #ifdef __FLAT__
      MoveToEx( hDC, ix, iy, &pt ) ;
   #else
      MoveTo( hDC, ix, iy );
   #endif
}

//---------------------------------------------------------------------------//

static void DegradColor( HDC hDC, RECT * rori, COLORREF cFrom, COLORREF cTo )
{
   int clr1r, clr1g, clr1b, clr2r, clr2g, clr2b ;
   signed int iEle, iRed, iGreen, iBlue ;
   int iTot = ( rori->bottom + 2 - rori->top ) ;
   BOOL bDir ;
   RECT rct ;
   HBRUSH hOldBrush, hBrush ;

   rct.top = rori->top ;
   rct.left = rori->left ;
   rct.bottom = rori->bottom ;
   rct.right = rori->right ;

   clr1r = GetRValue( cFrom ) ;
   clr1g = GetGValue( cFrom ) ;
   clr1b = GetBValue( cFrom ) ;

   clr2r = GetRValue( cTo ) ;
   clr2g = GetGValue( cTo ) ;
   clr2b = GetBValue( cTo ) ;

   iRed   =  abs( clr2r - clr1r ) ;
   iGreen =  abs( clr2g - clr1g ) ;
   iBlue  =  abs( clr2b - clr1b ) ;

   iRed   = ( iRed < 0 ? 0 : ( iRed / iTot ) );
   iGreen = ( iGreen < 0 ? 0 : ( iGreen / iTot ) ) ;
   iBlue  = ( iBlue < 0 ? 0 : ( iBlue / iTot ) ) ;

   rct.bottom = rct.top + 1 ;

   hBrush = CreateSolidBrush( RGB( clr1r, clr1g, clr1b ) ) ;
   hOldBrush = SelectObject( hDC, hBrush ) ;
   FillRect( hDC, &rct, hBrush ) ;

   for( iEle = 1; iEle < iTot; iEle++ )
   {
      	bDir = ( clr2r >= clr1r ? TRUE : FALSE ) ;
         if( bDir )
      		clr1r += iRed ;
         else
         	clr1r -= iRed ;

         clr1r = ( clr1r < 0 ? 0 : clr1r > 255 ? 255 : clr1r ) ;

	      bDir = ( clr2g >= clr1g ? TRUE : FALSE  ) ;
         if( bDir )
   	   	clr1g += iGreen ;
         else
   	   	clr1g -= iGreen ;
         clr1g = ( clr1g < 0 ? 0 : clr1g > 255 ? 255 : clr1g ) ;

			bDir = ( clr2b >= clr1b ? TRUE : FALSE  ) ;
         if( bDir )
   	   	clr1b += iBlue ;
   		else
   	   	clr1b -= iBlue ;
         clr1b = ( clr1b < 0 ? 0 : clr1b > 255 ? 255 : clr1b ) ;

      SelectObject( hDC, hOldBrush ) ;
      DeleteObject( hBrush ) ;
      hBrush = CreateSolidBrush( RGB( clr1r, clr1g, clr1b ) ) ;
      SelectObject( hDC, hBrush ) ;
      FillRect( hDC, &rct, hBrush ) ;

      rct.top++ ;
      rct.bottom++ ;
   }
	SelectObject( hDC, hOldBrush ) ;
   DeleteObject( hBrush ) ;
}

//---------------------------------------------------------------------------//

#ifndef __HARBOUR__
   CLIPPER CHANGESYSC( PARAMS ) // OLORS( nItems, aItems, aColors )
#else
   HARBOUR HB_FUN_CHANGESYSCOLORS( PARAMS )
#endif
{
   int iEle, iItems = _parni( 1 ) ;
   int aiElemen[ 28 ] ;
   COLORREF alColors[ 28 ] ;

   for( iEle = 0 ; iEle <= ( iItems - 1 ) ; iEle++ )
   {
      aiElemen[ iEle ] = _parni( 2, ( iEle + 1 ) ) ;
      alColors[ iEle ] = _parnl( 3, ( iEle + 1 ) ) ;
   }

   SetSysColors( iItems, aiElemen, alColors ) ;
}

//----------------------------------------------------------------------------//

void cDrawCursor( HWND hWnd, RECT * rctc, long lCursor, COLORREF nClr )
{
   HDC hDC;
   HRGN hReg;
   COLORREF lclr = ( lCursor == 1 ? RGB( 5, 5, 5 ) : lCursor == 2 ? nClr : lCursor );
   HBRUSH hBr ;
   RECT rct ;

  	if( lCursor != 3 )
   {
	   hBr = CreateSolidBrush( lclr ) ;
	   hReg = CreateRectRgn( rctc->left, rctc->top, rctc->right - 1, rctc->bottom );
   	hDC  = GetDCEx( hWnd, hReg, DCX_CACHE );

	 	FrameRgn( hDC, hReg, hBr, 2, 2 );

	   ReleaseDC( hWnd, hDC );
   	DeleteObject( hReg ) ;
	   DeleteObject( hBr ) ;
   }
   else
   {
      rct.top    = rctc->top + 1 ;
      rct.left   = rctc->left + 1 ;
      rct.bottom = rctc->bottom - 1 ;
      rct.right  = rctc->right - 1 ;

   	hDC  = GetDC( hWnd ) ;
   	DrawFocusRect( hDC, &rct ) ;
   	ReleaseDC( hWnd, hDC ) ;
	}
}

