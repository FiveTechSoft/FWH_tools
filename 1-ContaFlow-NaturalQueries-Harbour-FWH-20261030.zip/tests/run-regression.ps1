# Requires the explicitly prepared FICTIONAL PostgreSQL instance described in README.
# The tests commit a demo batch and restore prices. Never use with real data.
param([ValidateSet('32','64')][string]$Architecture='64')
$root=Split-Path $PSScriptRoot -Parent
$bin=Join-Path $root ('bin'+$Architecture)
Start-Process -FilePath (Join-Path $bin 'contaflow.exe') -ArgumentList '--test' -Wait
Start-Process -FilePath (Join-Path $bin 'naturalqueries.exe') -ArgumentList '--test' -Wait
Get-Content (Join-Path $bin 'invoice-tests.txt')
Get-Content (Join-Path $bin 'bulk-tests.txt')
