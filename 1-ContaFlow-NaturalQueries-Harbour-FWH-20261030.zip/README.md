# ContaFlow y NaturalQueries

Ejemplos originales en Harbour + FWH, inspirados en los dos circuitos pedidos.
Entrega privada de desarrollo, 30 de octubre de 2026. No son sistemas contables de producción.

## Inicio

Descomprime el ZIP en una carpeta con permiso de escritura. Conserva la estructura.

- `bin64/contaflow.exe` y `bin64/naturalqueries.exe`: Windows x64.
- `bin32/contaflow.exe` y `bin32/naturalqueries.exe`: Windows x86.
- `src/`: código de los ejemplos y adaptadores propios. No contiene fuentes ni librerías privadas de FWH.
- `fixtures/`: datos ficticios y Northwind con su licencia.
- `evidence/`: capturas reales del funcionamiento bajo Wine.
- `tests/`: resultados de las pruebas integradas por arquitectura.

ContaFlow funciona con texto sin instalar OCR ni PostgreSQL. El botón Example carga una factura ficticia.
Las funciones OCR y SQL requieren las dependencias descritas abajo. No se incluyen ni se descargan automáticamente.
Esta entrega NO es un paquete autónomo con OCR y servidor PostgreSQL incorporados.
No se necesita una clave de IA: estos ejemplos no llaman a un LLM.

## ContaFlow

1. Example o Load text carga la factura. Scan image utiliza Tesseract real, si está configurado.
2. Revisa el texto extraído. Los errores OCR NO se corrigen por adivinación.
3. Check + route valida proveedor, fecha, duplicado por proveedor+número, importes y pedido.
4. Resultado local: POSTED, APPROVAL o EXCEPTION. El registro se guarda en `sandbox_decisions.dbf` en la raíz.
5. Una factura válida de más de 1000 EUR va a aprobación. Approve queued pide confirmación antes de marcar POSTED.

Catálogo ficticio: V123 activo, V456 bloqueado. Pedidos 12345/V123/100 EUR netos y 45678/V123/2000 EUR netos.
La factura estándar es 100 + 21 = 121 EUR. La de aprobación es 2000 + 420 = 2420 EUR.

El extractor usa etiquetas, no comprensión general: Vendor ID, Invoice, Date, PO, Currency, Net, Tax, Total.
Fecha ISO y cantidades positivas con punto decimal. Un formato desconocido, proveedor dudoso o pedido no coincidente genera excepción.
La cola de aprobación, el ledger y las excepciones son registros DBF de demostración, no un ERP ni un servicio externo de tickets.
Ejecución monousuario. No incorpora autentificación de aprobadores, impuestos legales, auditoría inmutable ni concurrencia de producción.

### OCR

Tesseract Windows x64 5.4.0 fue ejecutado realmente bajo Wine 11.19. Lee PNG/JPG/TIFF, no PDF.
Configura `CONTAFLOW_TESSERACT` con la ruta completa de `tesseract.exe` y conserva sus DLL y tessdata.
Alternativamente coloca tu distribución completa en `runtime/ocr/`, con `tesseract.exe` en esa carpeta.
Si hace falta configura TESSDATA_PREFIX a la carpeta tessdata.

Origen probado: https://github.com/UB-Mannheim/tesseract/releases/tag/v5.4.0.20240606
El EXE32 también puede lanzar el OCR64 en un sistema de64bits; no se validó OCR en Windows puramente32bits.
El fixture final usa PO numérico 12345. En pruebas anteriores Tesseract confundió O/0 en un pedido alfanumérico: la validación lo rechazó correctamente.
No se promete exactitud con escaneos arbitrarios. Revisión humana del texto siempre disponible antes de procesar.

## NaturalQueries

El texto soportado es una gramática limitada, no lenguaje natural abierto:

`Increase the price of the top 20 best-selling seafood products by 5%.`

También Decrease. Categorías: seafood, beverages, confections, condiments y produce.
N debe ser 1..100. Porcentaje no cero, máximo25%. No acepta SQL del usuario ni instrucciones fuera de la gramática.
Best-selling significa cantidad vendida acumulada en order_details, con desempate por product_id.
No supone un intervalo temporal. El crítico explica estas decisiones y advierte límites y productos discontinuados.
El crítico es determinista por reglas, no un modelo de IA.

Preview + critic consulta PostgreSQL real, muestra nombres, cantidades, precio anterior/nuevo y SQL congelado.
Northwind contiene12Seafood: pedir20 muestra12 y avisa, sin completar con otros productos.
El SQL de revisión es solo lectura. Editar la petición invalida la revisión; es necesario previsualizar otra vez.
Approve + commit requiere confirmación humana. La transacción bloquea productos, comprueba precios previos y exige exactamente una fila por UPDATE.
Cualquier discrepancia aborta todo. El archivo last-approved-batch.sql guarda la propuesta tras intentar ejecutar, no certifica que hubiera commit; el resultado de UI es la confirmación.

### PostgreSQL de demostración

Conexión fija: 127.0.0.1:55432, base northwind_demo, usuario sandbox. Nunca apunta por defecto a una base empresarial.
El ejemplo exige además demo_guard con el marcador NATURALQUERIES-FICTIONAL-ONLY. No añadas ese marcador a bases reales.

Crea una instancia desechable local PostgreSQL con base UTF8, carga fixtures/northwind.sql y después fixtures/demo-guard.sql.
El usuario sandbox necesita SELECT sobre las tablas del ejemplo y UPDATE/LOCK sobre products. No necesita superusuario para la aplicación.
La preparación de la base es externa y explícita: el EXE no crea, borra ni importa tablas automáticamente.
La instancia usada en validación era local, temporal y solo accesible por loopback. Nunca se usaron credenciales ni datos empresariales.
En un despliegue propio configura la autentificación PostgreSQL fuera de estos ejemplos. No pongas contraseñas en el código ni en archivos compartidos.

Configura NATURALQUERIES_LIBPQ a una carpeta que contenga libpq.dll y sus dependencias DE LA MISMA ARQUITECTURA que el EXE.
También puedes colocarlas en runtime/pgsql/. Usa una carpeta distinta por arquitectura si vas a alternar32/64.
No se incluyen las DLL de terceros en este ZIP.

Fuentes exactas de las DLL verificadas:
-64: https://get.enterprisedb.com/postgresql/postgresql-14.20-1-windows-x64-binaries.zip
-32: https://get.enterprisedb.com/postgresql/postgresql-10.23-1-windows-binaries.zip

Cliente32probado es antiguo y se usó solo en la instancia ficticia local; no es una recomendación para producción.
Se validó servidor PostgreSQL14.24. En64: libpq.dll, libssl-1_1-x64.dll, libcrypto-1_1-x64.dll, libintl-9.dll, libiconv-2.dll, libwinpthread-1.dll y sus runtime del sistema.
En32: libpq.dll, libssl-1_1.dll, libcrypto-1_1.dll, libintl-8.dll, libiconv-2.dll y runtime MSVCR120.
Wine11.19 proporcionó los runtime del sistema en las pruebas. En Windows puede requerirse el redistribuible oficial correspondiente.

Northwind: https://github.com/pthom/northwind_psql, licencia Ms-PL incluida.

## Compilación y pruebas

Harbour3.2 y FWH con librerías MinGW de la arquitectura elegida. Archivo build.sh parametrizable incluido.
Los cuatro EXE fueron compilados con warnings Harbour -w3 y C -Wall -Wextra, sin warnings.
Las pruebas fueron Wine11.19 en Linux, no Windows real. No se validaron MSVC, BCC ni xHarbour.
11 pruebas de facturas y12 pruebas SQL por arquitectura:46PASS en total.
Incluyen duplicado, proveedor bloqueado/desconocido, fecha imposible, desbalance, aprobación, entradas SQL rechazadas, preview sin mutación, rollback parcial y por obsolescencia, commit y restauración del fixture.
La UI de32/64 se abrió e interactuó. OCR real, aprobación de factura, aprobación SQL y commit se comprobaron desde UI con entradas sintetizadas.
Para ejecutar las pruebas integradas: contaflow.exe --test o naturalqueries.exe --test. Las SQL necesitan la base ficticia configurada. Las pruebas SQL realizan un commit de prueba y restauran sus precios; no usarlas en ninguna base real.

No se ha hecho push ni publicación pública. No contiene toolchains, FWH libs, source/internal ni secretos.
