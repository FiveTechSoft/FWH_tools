#include "FiveWin.ch"
#include "fileio.ch"
STATIC cHome, cLog := "", oLog, cText := "", oText
STATIC aVendors := { {"V123","Demo Supply SL",.T.}, {"V456","Blocked Demo SL",.F.} }
STATIC aPOs := { {"12345","V123",100.00,"EUR"}, {"45678","V123",2000.00,"EUR"} }

FUNCTION Main(cMode)
   LOCAL oDlg, oFont
   cHome := hb_DirBase() + "..\\"
   IF cMode == "--test"
      InvoiceTests()
      RETURN NIL
   ENDIF
   DEFINE FONT oFont NAME "Segoe UI" SIZE 0,-16
   DEFINE DIALOG oDlg TITLE "ContaFlow | Invoice desk - fictional ledger only" SIZE 1040,730 PIXEL FONT oFont
   @ 12,14 SAY "ContaFlow - extract, check, decide" SIZE 480,18 OF oDlg PIXEL
   @ 34,14 SAY "Sandbox ledger. OCR uses Tesseract. Label-based extraction, not general AI." SIZE 490,18 OF oDlg PIXEL
   @ 57,14 BUTTON "Load text" SIZE 90,24 OF oDlg PIXEL ACTION LoadInvoice(.F.)
   @ 57,112 BUTTON "Scan image" SIZE 90,24 OF oDlg PIXEL ACTION LoadInvoice(.T.)
   @ 57,210 BUTTON "Check + route" SIZE 100,24 OF oDlg PIXEL ACTION ProcessUI()
   @ 57,318 BUTTON "Approve queued" SIZE 112,24 OF oDlg PIXEL ACTION ApproveUI()
   @ 57,438 BUTTON "Example" SIZE 66,24 OF oDlg PIXEL ACTION DemoInvoice()
   @ 91,14 SAY "Source text (editable before validation)" SIZE 480,16 OF oDlg PIXEL
   @ 111,14 GET oText VAR cText MEMO SIZE 490,95 OF oDlg PIXEL
   @ 217,14 SAY "Decision trail" SIZE 490,16 OF oDlg PIXEL
   @ 237,14 GET oLog VAR cLog MEMO READONLY SIZE 490,98 OF oDlg PIXEL
   @ 343,14 SAY "No external accounting or ticket service. Entries stay in local sandbox DBF files." SIZE 490,14 OF oDlg PIXEL
   ACTIVATE DIALOG oDlg CENTERED
   oFont:End()
RETURN NIL

STATIC FUNCTION DemoInvoice()
   cText:=MemoRead(cHome+"fixtures\invoice-ok.txt")
   cLog:="Fictional example loaded. Check + route writes only local sandbox_decisions.dbf."
   oText:Refresh()
   oLog:Refresh()
RETURN NIL

STATIC FUNCTION LoadInvoice(lScan)
   LOCAL cFile, cOut, nCode, cOCR
   cFile := cGetFile(iif(lScan,"Images (*.png;*.jpg;*.tif)|*.png;*.jpg;*.tif|","Text (*.txt)|*.txt|"),"Choose fictional invoice")
   IF Empty(cFile)
      RETURN NIL
   ENDIF
   IF lScan
      cOCR := GetEnv("CONTAFLOW_TESSERACT")
      IF Empty(cOCR) .AND. File(hb_DirBase()+"..\runtime\ocr\tesseract.exe")
         cOCR:=hb_DirBase()+"..\runtime\ocr\tesseract.exe"
      ENDIF
      IF Empty(cOCR)
         MsgStop("Set CONTAFLOW_TESSERACT to the full path of tesseract.exe. No OCR is simulated.")
         RETURN NIL
      ENDIF
      cOut := hb_DirBase()+"ocr-result"
      FErase(cOut+".txt")
      nCode := OCR_RUN(cOCR,cFile,cOut)
      IF nCode != 0 .OR. !File(cOut+".txt")
         MsgStop("OCR failed, code "+hb_ntos(nCode)+". No invoice was posted.")
         RETURN NIL
      ENDIF
      cText := MemoRead(cOut+".txt")
      cLog := "OCR: real Tesseract output. Review source before processing."+Chr(13)+Chr(10)
   ELSE
      cText := MemoRead(cFile)
      cLog := "Plain-text source loaded. Review source before processing."+Chr(13)+Chr(10)
   ENDIF
   oText:Refresh()
   oLog:Refresh()
RETURN NIL

STATIC FUNCTION InvField(cInput,cLabel)
   LOCAL aLines := hb_ATokens(StrTran(cInput,Chr(13),""),Chr(10)), cLine
   FOR EACH cLine IN aLines
      IF Upper(Left(AllTrim(cLine),Len(cLabel)+1)) == Upper(cLabel)+":"
         RETURN AllTrim(SubStr(AllTrim(cLine),Len(cLabel)+2))
      ENDIF
   NEXT
RETURN ""

STATIC FUNCTION Amount(cValue)
   LOCAL n, c
   IF Empty(cValue)
      RETURN -1
   ENDIF
   FOR n := 1 TO Len(cValue)
      c := SubStr(cValue,n,1)
      IF !(c $ "0123456789.")
         RETURN -1
      ENDIF
   NEXT
   IF Occurs(".",cValue)>1 .OR. ("." $ cValue .AND. Len(SubStr(cValue,At(".",cValue)+1))>2)
      RETURN -1
   ENDIF
RETURN Val(cValue)

STATIC FUNCTION OpenStore(cName)
   LOCAL cPath := cHome+cName+".dbf"
   IF !File(cPath)
      DbCreate(cPath,{{"KEY","C",90,0},{"STATE","C",16,0},{"VENDOR","C",12,0},{"INVNO","C",48,0},{"TOTAL","N",14,2},{"DETAIL","C",240,0}},"DBFCDX")
   ENDIF
   DbUseArea(.T.,"DBFCDX",cPath,"work",.F.,.F.)
RETURN NIL

STATIC FUNCTION RecordDecision(cKey,cState,cVendor,cInv,nTotal,cDetail)
   OpenStore("sandbox_decisions")
   DbAppend()
   FIELD->KEY := cKey
   FIELD->STATE := cState
   FIELD->VENDOR := cVendor
   FIELD->INVNO := cInv
   FIELD->TOTAL := Max(0,nTotal)
   FIELD->DETAIL := Left(cDetail,240)
   DbCommit()
   DbCloseArea()
RETURN NIL

STATIC FUNCTION Decide(cInput,lWrite)
   LOCAL cVendor:=InvField(cInput,"Vendor ID"), cInv:=InvField(cInput,"Invoice"), cPO:=InvField(cInput,"PO")
   LOCAL cDate:=InvField(cInput,"Date"), cCurrency:=InvField(cInput,"Currency"), cKey, cWhy:="", cState
   LOCAL nNet:=Amount(InvField(cInput,"Net")), nTax:=Amount(InvField(cInput,"Tax")), nTotal:=Amount(InvField(cInput,"Total"))
   LOCAL nV:=AScan(aVendors,{|a|a[1]==cVendor}), nP:=AScan(aPOs,{|a|a[1]==cPO}), lDuplicate:=.F.
   cKey := Upper(cVendor)+"|"+Upper(cInv)
   IF Empty(cInv) .OR. Len(cInv)>48 .OR. Empty(cVendor) .OR. Len(cVendor)>12
      cWhy += "Missing or oversized invoice/vendor identifier. "
   ENDIF
   IF Len(cDate)!=10 .OR. SubStr(cDate,5,1)!="-" .OR. SubStr(cDate,8,1)!="-"
      cWhy += "Invalid ISO invoice date. "
   ELSEIF DToS(SToD(StrTran(cDate,"-",""))) != StrTran(cDate,"-","")
      cWhy += "Invalid calendar date. "
   ENDIF
   IF nV==0
      cWhy += "Unknown vendor. "
   ELSEIF !aVendors[nV,3]
      cWhy += "Vendor is blocked. "
   ENDIF
   IF Min(nNet,Min(nTax,nTotal))<0 .OR. nTotal<=0 .OR. nTotal>999999999.99 .OR. Abs(nNet+nTax-nTotal)>0.005
      cWhy += "Invalid amounts or net + tax != total. "
   ENDIF
   IF nP==0
      cWhy += "Purchase order missing/unknown. "
   ELSE
      IF aPOs[nP,2]!=cVendor .OR. aPOs[nP,4]!=cCurrency .OR. Abs(aPOs[nP,3]-nNet)>0.005
         cWhy += "PO vendor, currency or net amount does not match. "
      ENDIF
   ENDIF
   OpenStore("sandbox_decisions")
   DbGoTop()
   DO WHILE !Eof()
      IF AllTrim(FIELD->KEY)==cKey .AND. AllTrim(FIELD->STATE) $ "POSTED|APPROVAL"
         lDuplicate:=.T.
         EXIT
      ENDIF
      DbSkip()
   ENDDO
   DbCloseArea()
   IF lDuplicate
      cWhy += "Duplicate vendor + invoice already posted or queued. "
   ENDIF
   DO CASE
   CASE !Empty(cWhy)
      cState:="EXCEPTION"
   CASE nTotal>1000
      cState:="APPROVAL"
      cWhy:="Validated. Total > EUR 1000 requires human approval."
   OTHERWISE
      cState:="POSTED"
      cWhy:="Validated vendor, unique invoice, PO, amounts and date. Posted to sandbox ledger only."
   ENDCASE
   IF lWrite
      RecordDecision(cKey,cState,cVendor,cInv,nTotal,cWhy)
   ENDIF
RETURN {cState,cWhy,cKey,nTotal}

STATIC FUNCTION ProcessUI()
   LOCAL a
   IF Empty(AllTrim(cText))
      MsgStop("Load invoice text or a scan first.")
      RETURN NIL
   ENDIF
   a:=Decide(cText,.T.)
   cLog:=a[1]+" | "+a[3]+" | EUR "+Str(a[4],12,2)+Chr(13)+Chr(10)+a[2]+Chr(13)+Chr(10)+"Saved: sandbox_decisions.dbf (local only)."
   oLog:Refresh()
RETURN NIL

STATIC FUNCTION ApproveUI()
   LOCAL cKey:=Upper(InvField(cText,"Vendor ID"))+"|"+Upper(InvField(cText,"Invoice")), lFound:=.F.
   IF !MsgYesNo("Approve this invoice in the FICTIONAL ledger only?"+Chr(13)+Chr(10)+cKey)
      RETURN NIL
   ENDIF
   OpenStore("sandbox_decisions")
   DbGoTop()
   DO WHILE !Eof()
      IF AllTrim(FIELD->KEY)==cKey .AND. AllTrim(FIELD->STATE)=="APPROVAL"
         FIELD->STATE:="POSTED"
         FIELD->DETAIL:="Human approval recorded in sandbox ledger."
         DbCommit()
         lFound:=.T.
         EXIT
      ENDIF
      DbSkip()
   ENDDO
   DbCloseArea()
   cLog:=iif(lFound,"POSTED: human approval saved in fictional ledger.","No pending approval for this vendor/invoice.")
   oLog:Refresh()
RETURN NIL

STATIC FUNCTION InvoiceTests()
   LOCAL cBase:=MemoRead(cHome+"fixtures\\invoice-ok.txt"), a, nFail:=0, cReport:=""
   cHome:=hb_DirBase()+"test-invoice-"
   FErase(cHome+"sandbox_decisions.dbf")
   a:=Decide(cBase,.T.)
   Check(a[1]=="POSTED","valid invoice -> sandbox POSTED",@nFail,@cReport)
   a:=Decide(cBase,.T.)
   Check(a[1]=="EXCEPTION" .AND. "Duplicate" $ a[2],"duplicate -> exception",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"INV-2026-101","INV-102")+" ",.F.)
   Check(a[1]=="POSTED","different invoice accepted",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"V123","V999"),.F.)
   Check(a[1]=="EXCEPTION","unknown vendor blocked",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"Total: 121.00","Total: 122.00"),.F.)
   Check(a[1]=="EXCEPTION","unbalanced total blocked",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"2026-10-30","2026-02-30"),.F.)
   Check(a[1]=="EXCEPTION","impossible date blocked",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"12345","PO999"),.F.)
   Check(a[1]=="EXCEPTION","missing PO blocked",@nFail,@cReport)
   a:=Decide(StrTran(StrTran(StrTran(StrTran(StrTran(cBase,"INV-2026-101","INV-HIGH"),"12345","45678"),"Net: 100.00","Net: 2000.00"),"Tax: 21.00","Tax: 420.00"),"Total: 121.00","Total: 2420.00"),.T.)
   Check(a[1]=="APPROVAL","high total -> human queue",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"V123","V456"),.F.)
   Check(a[1]=="EXCEPTION" .AND. "blocked" $ a[2],"blocked vendor rejected",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"Net: 100.00","Net: 1e2"),.F.)
   Check(a[1]=="EXCEPTION","scientific amount not silently accepted",@nFail,@cReport)
   a:=Decide(StrTran(cBase,"V123","VO0O1"),.F.)
   Check(a[1]=="EXCEPTION","uncertain OCR vendor cannot auto-post",@nFail,@cReport)
   MemoWrit(hb_DirBase()+"invoice-tests.txt",cReport+"FAILURES="+hb_ntos(nFail))
RETURN NIL

STATIC FUNCTION Check(lOK,cName,nFail,cReport)
   cReport+=iif(lOK,"PASS ","FAIL ")+cName+Chr(13)+Chr(10)
   IF !lOK
      nFail++
   ENDIF
RETURN NIL
