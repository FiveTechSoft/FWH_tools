/* Original example adapters. libpq and Tesseract remain external dependencies. */
#include <windows.h>
#include "hbapi.h"
#include "hbapiitm.h"
#include <stdio.h>
typedef void PGconn; typedef void PGresult;
static HMODULE pg = NULL; static PGconn *conn = NULL;
static PGconn *(__cdecl *pConnect)(const char *);
static int (__cdecl *pStatus)(const PGconn *);
static void (__cdecl *pFinish)(PGconn *);
static char *(__cdecl *pError)(const PGconn *);
static PGresult *(__cdecl *pExec)(PGconn *,const char *);
static int (__cdecl *pResultStatus)(const PGresult *);
static char *(__cdecl *pResultError)(const PGresult *);
static int (__cdecl *pRows)(const PGresult *);
static int (__cdecl *pCols)(const PGresult *);
static char *(__cdecl *pValue)(const PGresult *,int,int);
static char *(__cdecl *pAffected)(PGresult *);
static void (__cdecl *pClear)(PGresult *);
#define LOAD(v,n) do { *(FARPROC *)&v=GetProcAddress(pg,n); if(!v){hb_retc("Missing libpq entry: " n);return;} } while(0)
HB_FUNC(PG_OPEN) {
 const char *dir=hb_parc(1); char path[MAX_PATH];
 if(conn){pFinish(conn);conn=NULL;}
 if(!pg){
  snprintf(path,sizeof(path),"%s\\libpq.dll",dir?dir:"");
  SetDllDirectoryA(dir); pg=LoadLibraryA(path); SetDllDirectoryA(NULL);
  if(!pg){char err[512];snprintf(err,sizeof(err),"libpq.dll load failed (%lu): %s",(unsigned long)GetLastError(),path);hb_retc(err);return;}
  LOAD(pConnect,"PQconnectdb"); LOAD(pStatus,"PQstatus"); LOAD(pFinish,"PQfinish");
  LOAD(pError,"PQerrorMessage"); LOAD(pExec,"PQexec"); LOAD(pResultStatus,"PQresultStatus");
  LOAD(pResultError,"PQresultErrorMessage"); LOAD(pRows,"PQntuples"); LOAD(pCols,"PQnfields");
  LOAD(pValue,"PQgetvalue"); LOAD(pAffected,"PQcmdTuples"); LOAD(pClear,"PQclear");
 }
 conn=pConnect(hb_parc(2));
 if(!conn){hb_retc("Connection allocation failed");return;}
 if(pStatus(conn)!=0){hb_retc(pError(conn));pFinish(conn);conn=NULL;return;}
 hb_retc("");
}
HB_FUNC(PG_CLOSE){if(conn){pFinish(conn);conn=NULL;}}
HB_FUNC(PG_QUERY){
 PHB_ITEM out=hb_itemArrayNew(4), rows=hb_itemArrayNew(0); PGresult *r=NULL;
 hb_arraySetNI(out,1,-1); hb_arraySetC(out,2,"Not connected"); hb_arraySetC(out,4,"");
 if(conn){r=pExec(conn,hb_parc(1));if(r){
  int n=pRows(r),m=pCols(r),i,j;
  hb_arraySetNI(out,1,pResultStatus(r));hb_arraySetC(out,2,pResultError(r));hb_arraySetC(out,4,pAffected(r));
  hb_arraySize(rows,(HB_SIZE)n);
  for(i=0;i<n;i++){PHB_ITEM row=hb_itemArrayNew((HB_SIZE)m);for(j=0;j<m;j++)hb_arraySetC(row,(HB_SIZE)j+1,pValue(r,i,j));hb_arraySet(rows,(HB_SIZE)i+1,row);hb_itemRelease(row);}
  pClear(r);
 }}
 hb_arraySet(out,3,rows);hb_itemRelease(rows);hb_itemReturnRelease(out);
}
HB_FUNC(OCR_RUN){
 const char *exe=hb_parc(1), *image=hb_parc(2), *output=hb_parc(3);char cmd[4096];
 STARTUPINFOA si; PROCESS_INFORMATION pi; DWORD code=999,wait;
 if(!exe||!image||!output||strchr(exe,'"')||strchr(image,'"')||strchr(output,'"')){hb_retni(998);return;}
 snprintf(cmd,sizeof(cmd),"\"%s\" \"%s\" \"%s\" -l eng --psm 6",exe,image,output);
 ZeroMemory(&si,sizeof(si));ZeroMemory(&pi,sizeof(pi));si.cb=sizeof(si);
 if(!CreateProcessA(exe,cmd,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi)){hb_retni((int)GetLastError());return;}
 wait=WaitForSingleObject(pi.hProcess,60000);
 if(wait==WAIT_TIMEOUT){TerminateProcess(pi.hProcess,997);code=997;}else GetExitCodeProcess(pi.hProcess,&code);
 CloseHandle(pi.hThread);CloseHandle(pi.hProcess);hb_retni((int)code);
}
