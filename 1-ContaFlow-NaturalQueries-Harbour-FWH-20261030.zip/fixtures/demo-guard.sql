-- Apply ONLY to a throwaway Northwind database named northwind_demo.
-- The app refuses databases without this deliberate sandbox marker.
CREATE TABLE demo_guard(marker text PRIMARY KEY);
INSERT INTO demo_guard VALUES ('NATURALQUERIES-FICTIONAL-ONLY');
