@echo off
cd /d "%~dp0"
rem Configure these externally or place your own dependencies under runtime.
if exist "%~dp0runtime\pgsql\libpq.dll" set "NATURALQUERIES_LIBPQ=%~dp0runtime\pgsql"
if exist "%~dp0runtime\ocr\tesseract.exe" set "CONTAFLOW_TESSERACT=%~dp0runtime\ocr\tesseract.exe"
if exist "%~dp0runtime\ocr\tessdata" set "TESSDATA_PREFIX=%~dp0runtime\ocr\tessdata"
echo 1 ContaFlow   2 NaturalQueries
set /p "APP=Choose 1 or 2: "
if "%APP%"=="1" start "" "%~dp0bin32\contaflow.exe"
if "%APP%"=="2" start "" "%~dp0bin32\naturalqueries.exe"
