#if __POCC__ >= 500
#pragma once
#endif

/* Definitions for controlling GUID initialization */

#define INITGUID
#include <guiddef.h>
