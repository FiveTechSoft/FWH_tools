#ifndef _IMESSAGE_H
#define _IMESSAGE_H

#if __POCC__ >= 500
#pragma once
#endif

/* Messaging Applications Programming Interface (MAPI) IMessage-on-IStorage facility definitions */

#include <winapifamily.h>

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP)

typedef struct _MSGSESS * LPMSGSESS;

typedef void (STDAPICALLTYPE MSGCALLRELEASE)(
    ULONG ulCallerData,
    LPMESSAGE lpMessage
);

STDAPI_(SCODE) OpenIMsgSession(
    LPMALLOC lpMalloc,
    ULONG ulFlags,
    LPMSGSESS *lppMsgSess
);

STDAPI_(void) CloseIMsgSession(
    LPMSGSESS lpMsgSess
);

STDAPI_(SCODE) OpenIMsgOnIStg(
    LPMSGSESS lpMsgSess,
    LPALLOCATEBUFFER lpAllocateBuffer,
    LPALLOCATEMORE lpAllocateMore,
    LPFREEBUFFER lpFreeBuffer,
    LPMALLOC lpMalloc,
    LPVOID lpMapiSup,
    LPSTORAGE lpStg,
    MSGCALLRELEASE *lpfMsgCallRelease,
    ULONG ulCallerData,
    ULONG ulFlags,
    LPMESSAGE *lppMsg
);

#define IMSG_NO_ISTG_COMMIT  ((ULONG)0x00000001)

#define PROPATTR_MANDATORY  ((ULONG)0x00000001)
#define PROPATTR_READABLE  ((ULONG)0x00000002)
#define PROPATTR_WRITEABLE  ((ULONG)0x00000004)
#define PROPATTR_NOT_PRESENT ((ULONG)0x00000008)

typedef struct _SPropAttrArray {
    ULONG cValues;
    ULONG aPropAttr[MAPI_DIM];
} SPropAttrArray, * LPSPropAttrArray;

#define CbNewSPropAttrArray(_cattr) \
    (offsetof(SPropAttrArray,aPropAttr) + (_cattr)*sizeof(ULONG))
#define CbSPropAttrArray(_lparray) \
    (offsetof(SPropAttrArray,aPropAttr) + \
        (UINT)((_lparray)->cValues)*sizeof(ULONG))

#define SizedSPropAttrArray(_cattr, _name) \
    struct _SPropAttrArray_ ## _name \
    { \
     ULONG cValues; \
     ULONG aPropAttr[_cattr]; \
    } _name

STDAPI GetAttribIMsgOnIStg(
    LPVOID lpObject,
    LPSPropTagArray lpPropTagArray,
    LPSPropAttrArray *lppPropAttrArray
);

STDAPI SetAttribIMsgOnIStg(
    LPVOID lpObject,
    LPSPropTagArray lpPropTags,
    LPSPropAttrArray lpPropAttrs,
    LPSPropProblemArray *lppPropProblems
);

STDAPI_(SCODE) MapStorageSCode(
    SCODE StgSCode
);

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP) */

#endif /* _IMESSAGE_H */
