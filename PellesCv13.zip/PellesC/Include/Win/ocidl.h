/* Generated from ocidl.idl by POIDL version 0.80 - Do not edit */

#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include <rpc.h>
#include <rpcndr.h>

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */

#ifndef __ocidl_h__
#define __ocidl_h__

#if __POCC__ >= 500
#pragma once
#endif

/* Forward declarations */

#ifndef __IEnumConnections_FWD_DEFINED__
#define __IEnumConnections_FWD_DEFINED__
typedef interface IEnumConnections IEnumConnections;
#endif /* __IEnumConnections_FWD_DEFINED__ */

#ifndef __IConnectionPoint_FWD_DEFINED__
#define __IConnectionPoint_FWD_DEFINED__
typedef interface IConnectionPoint IConnectionPoint;
#endif /* __IConnectionPoint_FWD_DEFINED__ */

#ifndef __IEnumConnectionPoints_FWD_DEFINED__
#define __IEnumConnectionPoints_FWD_DEFINED__
typedef interface IEnumConnectionPoints IEnumConnectionPoints;
#endif /* __IEnumConnectionPoints_FWD_DEFINED__ */

#ifndef __IConnectionPointContainer_FWD_DEFINED__
#define __IConnectionPointContainer_FWD_DEFINED__
typedef interface IConnectionPointContainer IConnectionPointContainer;
#endif /* __IConnectionPointContainer_FWD_DEFINED__ */

#ifndef __IClassFactory2_FWD_DEFINED__
#define __IClassFactory2_FWD_DEFINED__
typedef interface IClassFactory2 IClassFactory2;
#endif /* __IClassFactory2_FWD_DEFINED__ */

#ifndef __IProvideClassInfo_FWD_DEFINED__
#define __IProvideClassInfo_FWD_DEFINED__
typedef interface IProvideClassInfo IProvideClassInfo;
#endif /* __IProvideClassInfo_FWD_DEFINED__ */

#ifndef __IProvideClassInfo2_FWD_DEFINED__
#define __IProvideClassInfo2_FWD_DEFINED__
typedef interface IProvideClassInfo2 IProvideClassInfo2;
#endif /* __IProvideClassInfo2_FWD_DEFINED__ */

#ifndef __IProvideMultipleClassInfo_FWD_DEFINED__
#define __IProvideMultipleClassInfo_FWD_DEFINED__
typedef interface IProvideMultipleClassInfo IProvideMultipleClassInfo;
#endif /* __IProvideMultipleClassInfo_FWD_DEFINED__ */

#ifndef __IOleControl_FWD_DEFINED__
#define __IOleControl_FWD_DEFINED__
typedef interface IOleControl IOleControl;
#endif /* __IOleControl_FWD_DEFINED__ */

#ifndef __IOleControlSite_FWD_DEFINED__
#define __IOleControlSite_FWD_DEFINED__
typedef interface IOleControlSite IOleControlSite;
#endif /* __IOleControlSite_FWD_DEFINED__ */

#ifndef __IPropertyPage_FWD_DEFINED__
#define __IPropertyPage_FWD_DEFINED__
typedef interface IPropertyPage IPropertyPage;
#endif /* __IPropertyPage_FWD_DEFINED__ */

#ifndef __IPropertyPage2_FWD_DEFINED__
#define __IPropertyPage2_FWD_DEFINED__
typedef interface IPropertyPage2 IPropertyPage2;
#endif /* __IPropertyPage2_FWD_DEFINED__ */

#ifndef __IPropertyPageSite_FWD_DEFINED__
#define __IPropertyPageSite_FWD_DEFINED__
typedef interface IPropertyPageSite IPropertyPageSite;
#endif /* __IPropertyPageSite_FWD_DEFINED__ */

#ifndef __IPropertyNotifySink_FWD_DEFINED__
#define __IPropertyNotifySink_FWD_DEFINED__
typedef interface IPropertyNotifySink IPropertyNotifySink;
#endif /* __IPropertyNotifySink_FWD_DEFINED__ */

#ifndef __ISpecifyPropertyPages_FWD_DEFINED__
#define __ISpecifyPropertyPages_FWD_DEFINED__
typedef interface ISpecifyPropertyPages ISpecifyPropertyPages;
#endif /* __ISpecifyPropertyPages_FWD_DEFINED__ */

#ifndef __IPersistMemory_FWD_DEFINED__
#define __IPersistMemory_FWD_DEFINED__
typedef interface IPersistMemory IPersistMemory;
#endif /* __IPersistMemory_FWD_DEFINED__ */

#ifndef __IPersistStreamInit_FWD_DEFINED__
#define __IPersistStreamInit_FWD_DEFINED__
typedef interface IPersistStreamInit IPersistStreamInit;
#endif /* __IPersistStreamInit_FWD_DEFINED__ */

#ifndef __IPersistPropertyBag_FWD_DEFINED__
#define __IPersistPropertyBag_FWD_DEFINED__
typedef interface IPersistPropertyBag IPersistPropertyBag;
#endif /* __IPersistPropertyBag_FWD_DEFINED__ */

#ifndef __ISimpleFrameSite_FWD_DEFINED__
#define __ISimpleFrameSite_FWD_DEFINED__
typedef interface ISimpleFrameSite ISimpleFrameSite;
#endif /* __ISimpleFrameSite_FWD_DEFINED__ */

#ifndef __IFont_FWD_DEFINED__
#define __IFont_FWD_DEFINED__
typedef interface IFont IFont;
#endif /* __IFont_FWD_DEFINED__ */

#ifndef __IPicture_FWD_DEFINED__
#define __IPicture_FWD_DEFINED__
typedef interface IPicture IPicture;
#endif /* __IPicture_FWD_DEFINED__ */

#ifndef __IPicture2_FWD_DEFINED__
#define __IPicture2_FWD_DEFINED__
typedef interface IPicture2 IPicture2;
#endif /* __IPicture2_FWD_DEFINED__ */

#ifndef __IFontEventsDisp_FWD_DEFINED__
#define __IFontEventsDisp_FWD_DEFINED__
typedef interface IFontEventsDisp IFontEventsDisp;
#endif /* __IFontEventsDisp_FWD_DEFINED__ */

#ifndef __IFontDisp_FWD_DEFINED__
#define __IFontDisp_FWD_DEFINED__
typedef interface IFontDisp IFontDisp;
#endif /* __IFontDisp_FWD_DEFINED__ */

#ifndef __IPictureDisp_FWD_DEFINED__
#define __IPictureDisp_FWD_DEFINED__
typedef interface IPictureDisp IPictureDisp;
#endif /* __IPictureDisp_FWD_DEFINED__ */

#ifndef __IOleInPlaceObjectWindowless_FWD_DEFINED__
#define __IOleInPlaceObjectWindowless_FWD_DEFINED__
typedef interface IOleInPlaceObjectWindowless IOleInPlaceObjectWindowless;
#endif /* __IOleInPlaceObjectWindowless_FWD_DEFINED__ */

#ifndef __IOleInPlaceSiteEx_FWD_DEFINED__
#define __IOleInPlaceSiteEx_FWD_DEFINED__
typedef interface IOleInPlaceSiteEx IOleInPlaceSiteEx;
#endif /* __IOleInPlaceSiteEx_FWD_DEFINED__ */

#ifndef __IOleInPlaceSiteWindowless_FWD_DEFINED__
#define __IOleInPlaceSiteWindowless_FWD_DEFINED__
typedef interface IOleInPlaceSiteWindowless IOleInPlaceSiteWindowless;
#endif /* __IOleInPlaceSiteWindowless_FWD_DEFINED__ */

#ifndef __IViewObjectEx_FWD_DEFINED__
#define __IViewObjectEx_FWD_DEFINED__
typedef interface IViewObjectEx IViewObjectEx;
#endif /* __IViewObjectEx_FWD_DEFINED__ */

#ifndef __IOleUndoUnit_FWD_DEFINED__
#define __IOleUndoUnit_FWD_DEFINED__
typedef interface IOleUndoUnit IOleUndoUnit;
#endif /* __IOleUndoUnit_FWD_DEFINED__ */

#ifndef __IOleParentUndoUnit_FWD_DEFINED__
#define __IOleParentUndoUnit_FWD_DEFINED__
typedef interface IOleParentUndoUnit IOleParentUndoUnit;
#endif /* __IOleParentUndoUnit_FWD_DEFINED__ */

#ifndef __IEnumOleUndoUnits_FWD_DEFINED__
#define __IEnumOleUndoUnits_FWD_DEFINED__
typedef interface IEnumOleUndoUnits IEnumOleUndoUnits;
#endif /* __IEnumOleUndoUnits_FWD_DEFINED__ */

#ifndef __IOleUndoManager_FWD_DEFINED__
#define __IOleUndoManager_FWD_DEFINED__
typedef interface IOleUndoManager IOleUndoManager;
#endif /* __IOleUndoManager_FWD_DEFINED__ */

#ifndef __IPointerInactive_FWD_DEFINED__
#define __IPointerInactive_FWD_DEFINED__
typedef interface IPointerInactive IPointerInactive;
#endif /* __IPointerInactive_FWD_DEFINED__ */

#ifndef __IObjectWithSite_FWD_DEFINED__
#define __IObjectWithSite_FWD_DEFINED__
typedef interface IObjectWithSite IObjectWithSite;
#endif /* __IObjectWithSite_FWD_DEFINED__ */

#ifndef __IPerPropertyBrowsing_FWD_DEFINED__
#define __IPerPropertyBrowsing_FWD_DEFINED__
typedef interface IPerPropertyBrowsing IPerPropertyBrowsing;
#endif /* __IPerPropertyBrowsing_FWD_DEFINED__ */

#ifndef __IPropertyBag2_FWD_DEFINED__
#define __IPropertyBag2_FWD_DEFINED__
typedef interface IPropertyBag2 IPropertyBag2;
#endif /* __IPropertyBag2_FWD_DEFINED__ */

#ifndef __IPersistPropertyBag2_FWD_DEFINED__
#define __IPersistPropertyBag2_FWD_DEFINED__
typedef interface IPersistPropertyBag2 IPersistPropertyBag2;
#endif /* __IPersistPropertyBag2_FWD_DEFINED__ */

#ifndef __IAdviseSinkEx_FWD_DEFINED__
#define __IAdviseSinkEx_FWD_DEFINED__
typedef interface IAdviseSinkEx IAdviseSinkEx;
#endif /* __IAdviseSinkEx_FWD_DEFINED__ */

#ifndef __IQuickActivate_FWD_DEFINED__
#define __IQuickActivate_FWD_DEFINED__
typedef interface IQuickActivate IQuickActivate;
#endif /* __IQuickActivate_FWD_DEFINED__ */

/* Headers for imported files */

#include "oleidl.h"
#include "oaidl.h"
#include "servprov.h"
#include "urlmon.h"


#include <winapifamily.h>

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM)

#ifndef __IEnumConnections_FWD_DEFINED__
#define __IEnumConnections_FWD_DEFINED__
typedef interface IEnumConnections IEnumConnections;
#endif /* __IEnumConnections_FWD_DEFINED__ */

#ifndef __IEnumConnectionPoints_FWD_DEFINED__
#define __IEnumConnectionPoints_FWD_DEFINED__
typedef interface IEnumConnectionPoints IEnumConnectionPoints;
#endif /* __IEnumConnectionPoints_FWD_DEFINED__ */

#ifndef __IConnectionPoint_FWD_DEFINED__
#define __IConnectionPoint_FWD_DEFINED__
typedef interface IConnectionPoint IConnectionPoint;
#endif /* __IConnectionPoint_FWD_DEFINED__ */

#ifndef __IConnectionPointContainer_FWD_DEFINED__
#define __IConnectionPointContainer_FWD_DEFINED__
typedef interface IConnectionPointContainer IConnectionPointContainer;
#endif /* __IConnectionPointContainer_FWD_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)


#ifndef __IClassFactory2_FWD_DEFINED__
#define __IClassFactory2_FWD_DEFINED__
typedef interface IClassFactory2 IClassFactory2;
#endif /* __IClassFactory2_FWD_DEFINED__ */

#ifndef __IProvideClassInfo_FWD_DEFINED__
#define __IProvideClassInfo_FWD_DEFINED__
typedef interface IProvideClassInfo IProvideClassInfo;
#endif /* __IProvideClassInfo_FWD_DEFINED__ */

#ifndef __IProvideClassInfo2_FWD_DEFINED__
#define __IProvideClassInfo2_FWD_DEFINED__
typedef interface IProvideClassInfo2 IProvideClassInfo2;
#endif /* __IProvideClassInfo2_FWD_DEFINED__ */

#ifndef __IProvideMultipleClassInfo_FWD_DEFINED__
#define __IProvideMultipleClassInfo_FWD_DEFINED__
typedef interface IProvideMultipleClassInfo IProvideMultipleClassInfo;
#endif /* __IProvideMultipleClassInfo_FWD_DEFINED__ */

#ifndef __IOleControl_FWD_DEFINED__
#define __IOleControl_FWD_DEFINED__
typedef interface IOleControl IOleControl;
#endif /* __IOleControl_FWD_DEFINED__ */

#ifndef __IOleControlSite_FWD_DEFINED__
#define __IOleControlSite_FWD_DEFINED__
typedef interface IOleControlSite IOleControlSite;
#endif /* __IOleControlSite_FWD_DEFINED__ */

#ifndef __IPropertyPage_FWD_DEFINED__
#define __IPropertyPage_FWD_DEFINED__
typedef interface IPropertyPage IPropertyPage;
#endif /* __IPropertyPage_FWD_DEFINED__ */

#ifndef __IPropertyPage2_FWD_DEFINED__
#define __IPropertyPage2_FWD_DEFINED__
typedef interface IPropertyPage2 IPropertyPage2;
#endif /* __IPropertyPage2_FWD_DEFINED__ */

#ifndef __IPropertyPageSite_FWD_DEFINED__
#define __IPropertyPageSite_FWD_DEFINED__
typedef interface IPropertyPageSite IPropertyPageSite;
#endif /* __IPropertyPageSite_FWD_DEFINED__ */

#ifndef __IPropertyNotifySink_FWD_DEFINED__
#define __IPropertyNotifySink_FWD_DEFINED__
typedef interface IPropertyNotifySink IPropertyNotifySink;
#endif /* __IPropertyNotifySink_FWD_DEFINED__ */

#ifndef __ISpecifyPropertyPages_FWD_DEFINED__
#define __ISpecifyPropertyPages_FWD_DEFINED__
typedef interface ISpecifyPropertyPages ISpecifyPropertyPages;
#endif /* __ISpecifyPropertyPages_FWD_DEFINED__ */

#ifndef __IPersistMemory_FWD_DEFINED__
#define __IPersistMemory_FWD_DEFINED__
typedef interface IPersistMemory IPersistMemory;
#endif /* __IPersistMemory_FWD_DEFINED__ */

#ifndef __IPersistStreamInit_FWD_DEFINED__
#define __IPersistStreamInit_FWD_DEFINED__
typedef interface IPersistStreamInit IPersistStreamInit;
#endif /* __IPersistStreamInit_FWD_DEFINED__ */

#ifndef __IPersistPropertyBag_FWD_DEFINED__
#define __IPersistPropertyBag_FWD_DEFINED__
typedef interface IPersistPropertyBag IPersistPropertyBag;
#endif /* __IPersistPropertyBag_FWD_DEFINED__ */

#ifndef __ISimpleFrameSite_FWD_DEFINED__
#define __ISimpleFrameSite_FWD_DEFINED__
typedef interface ISimpleFrameSite ISimpleFrameSite;
#endif /* __ISimpleFrameSite_FWD_DEFINED__ */

#ifndef __IFont_FWD_DEFINED__
#define __IFont_FWD_DEFINED__
typedef interface IFont IFont;
#endif /* __IFont_FWD_DEFINED__ */

#ifndef __IPicture_FWD_DEFINED__
#define __IPicture_FWD_DEFINED__
typedef interface IPicture IPicture;
#endif /* __IPicture_FWD_DEFINED__ */

#ifndef __IFontEventsDisp_FWD_DEFINED__
#define __IFontEventsDisp_FWD_DEFINED__
typedef interface IFontEventsDisp IFontEventsDisp;
#endif /* __IFontEventsDisp_FWD_DEFINED__ */

#ifndef __IFontDisp_FWD_DEFINED__
#define __IFontDisp_FWD_DEFINED__
typedef interface IFontDisp IFontDisp;
#endif /* __IFontDisp_FWD_DEFINED__ */

#ifndef __IPictureDisp_FWD_DEFINED__
#define __IPictureDisp_FWD_DEFINED__
typedef interface IPictureDisp IPictureDisp;
#endif /* __IPictureDisp_FWD_DEFINED__ */


#ifndef __IAdviseSinkEx_FWD_DEFINED__
#define __IAdviseSinkEx_FWD_DEFINED__
typedef interface IAdviseSinkEx IAdviseSinkEx;
#endif /* __IAdviseSinkEx_FWD_DEFINED__ */

#ifndef __IOleInPlaceObjectWindowless_FWD_DEFINED__
#define __IOleInPlaceObjectWindowless_FWD_DEFINED__
typedef interface IOleInPlaceObjectWindowless IOleInPlaceObjectWindowless;
#endif /* __IOleInPlaceObjectWindowless_FWD_DEFINED__ */

#ifndef __IOleInPlaceSiteEx_FWD_DEFINED__
#define __IOleInPlaceSiteEx_FWD_DEFINED__
typedef interface IOleInPlaceSiteEx IOleInPlaceSiteEx;
#endif /* __IOleInPlaceSiteEx_FWD_DEFINED__ */

#ifndef __IOleInPlaceSiteWindowless_FWD_DEFINED__
#define __IOleInPlaceSiteWindowless_FWD_DEFINED__
typedef interface IOleInPlaceSiteWindowless IOleInPlaceSiteWindowless;
#endif /* __IOleInPlaceSiteWindowless_FWD_DEFINED__ */

#ifndef __IViewObjectEx_FWD_DEFINED__
#define __IViewObjectEx_FWD_DEFINED__
typedef interface IViewObjectEx IViewObjectEx;
#endif /* __IViewObjectEx_FWD_DEFINED__ */

#ifndef __IOleUndoUnit_FWD_DEFINED__
#define __IOleUndoUnit_FWD_DEFINED__
typedef interface IOleUndoUnit IOleUndoUnit;
#endif /* __IOleUndoUnit_FWD_DEFINED__ */

#ifndef __IOleParentUndoUnit_FWD_DEFINED__
#define __IOleParentUndoUnit_FWD_DEFINED__
typedef interface IOleParentUndoUnit IOleParentUndoUnit;
#endif /* __IOleParentUndoUnit_FWD_DEFINED__ */

#ifndef __IEnumOleUndoUnits_FWD_DEFINED__
#define __IEnumOleUndoUnits_FWD_DEFINED__
typedef interface IEnumOleUndoUnits IEnumOleUndoUnits;
#endif /* __IEnumOleUndoUnits_FWD_DEFINED__ */

#ifndef __IOleUndoManager_FWD_DEFINED__
#define __IOleUndoManager_FWD_DEFINED__
typedef interface IOleUndoManager IOleUndoManager;
#endif /* __IOleUndoManager_FWD_DEFINED__ */

#ifndef __IPointerInactive_FWD_DEFINED__
#define __IPointerInactive_FWD_DEFINED__
typedef interface IPointerInactive IPointerInactive;
#endif /* __IPointerInactive_FWD_DEFINED__ */

#ifndef __IObjectWithSite_FWD_DEFINED__
#define __IObjectWithSite_FWD_DEFINED__
typedef interface IObjectWithSite IObjectWithSite;
#endif /* __IObjectWithSite_FWD_DEFINED__ */


#ifndef __IErrorLog_FWD_DEFINED__
#define __IErrorLog_FWD_DEFINED__
typedef interface IErrorLog IErrorLog;
#endif /* __IErrorLog_FWD_DEFINED__ */


#ifndef __IPropertyBag_FWD_DEFINED__
#define __IPropertyBag_FWD_DEFINED__
typedef interface IPropertyBag IPropertyBag;
#endif /* __IPropertyBag_FWD_DEFINED__ */


#ifndef __IPerPropertyBrowsing_FWD_DEFINED__
#define __IPerPropertyBrowsing_FWD_DEFINED__
typedef interface IPerPropertyBrowsing IPerPropertyBrowsing;
#endif /* __IPerPropertyBrowsing_FWD_DEFINED__ */


#ifndef __IPropertyBag2_FWD_DEFINED__
#define __IPropertyBag2_FWD_DEFINED__
typedef interface IPropertyBag2 IPropertyBag2;
#endif /* __IPropertyBag2_FWD_DEFINED__ */

#ifndef __IPersistPropertyBag2_FWD_DEFINED__
#define __IPersistPropertyBag2_FWD_DEFINED__
typedef interface IPersistPropertyBag2 IPersistPropertyBag2;
#endif /* __IPersistPropertyBag2_FWD_DEFINED__ */


#ifndef __IQuickActivate_FWD_DEFINED__
#define __IQuickActivate_FWD_DEFINED__
typedef interface IQuickActivate IQuickActivate;
#endif /* __IQuickActivate_FWD_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)

/*****************************************************************************
 * IOleControlTypes interface (v1.0)
 */
#ifndef __IOleControlTypes_INTERFACE_DEFINED__
#define __IOleControlTypes_INTERFACE_DEFINED__

typedef enum tagUASFLAGS {
    UAS_NORMAL = 0x0,
    UAS_BLOCKED = 0x1,
    UAS_NOPARENTENABLE = 0x2,
    UAS_MASK = 0x3
} UASFLAGS;

/* State values for the DISPID_READYSTATE property */

typedef enum tagREADYSTATE {
    READYSTATE_UNINITIALIZED = 0,
    READYSTATE_LOADING = 1,
    READYSTATE_LOADED = 2,
    READYSTATE_INTERACTIVE = 3,
    READYSTATE_COMPLETE = 4
} READYSTATE;

extern RPC_IF_HANDLE IOleControlTypes_v1_0_c_ifspec;
extern RPC_IF_HANDLE IOleControlTypes_v1_0_s_ifspec;

#endif /* __IOleControlTypes_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)

/*****************************************************************************
 * IEnumConnections interface
 */
#ifndef __IEnumConnections_INTERFACE_DEFINED__
#define __IEnumConnections_INTERFACE_DEFINED__

typedef IEnumConnections *PENUMCONNECTIONS;
typedef IEnumConnections *LPENUMCONNECTIONS;

typedef struct tagCONNECTDATA {
    IUnknown *pUnk;
    DWORD dwCookie;
} CONNECTDATA;

typedef struct tagCONNECTDATA *PCONNECTDATA;
typedef struct tagCONNECTDATA *LPCONNECTDATA;

EXTERN_C const IID IID_IEnumConnections;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IEnumConnectionsVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IEnumConnections *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IEnumConnections *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IEnumConnections *This);

    /*** IEnumConnections methods ***/
    HRESULT (STDMETHODCALLTYPE *Next)(
        IEnumConnections *This,
        ULONG cConnections,
        LPCONNECTDATA rgcd,
        ULONG *pcFetched);

    HRESULT (STDMETHODCALLTYPE *Skip)(
        IEnumConnections *This,
        ULONG cConnections);

    HRESULT (STDMETHODCALLTYPE *Reset)(
        IEnumConnections *This);

    HRESULT (STDMETHODCALLTYPE *Clone)(
        IEnumConnections *This,
        IEnumConnections **ppEnum);

    END_INTERFACE
} IEnumConnectionsVtbl;

interface IEnumConnections {
    CONST_VTBL IEnumConnectionsVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IEnumConnections_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IEnumConnections_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IEnumConnections_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IEnumConnections methods ***/
#define IEnumConnections_Next(This,cConnections,rgcd,pcFetched) \
    ((This)->lpVtbl->Next(This,cConnections,rgcd,pcFetched))
#define IEnumConnections_Skip(This,cConnections) \
    ((This)->lpVtbl->Skip(This,cConnections))
#define IEnumConnections_Reset(This) \
    ((This)->lpVtbl->Reset(This))
#define IEnumConnections_Clone(This,ppEnum) \
    ((This)->lpVtbl->Clone(This,ppEnum))
#endif /* COBJMACROS */

#endif /* C */

HRESULT STDMETHODCALLTYPE IEnumConnections_RemoteNext_Proxy(
    IEnumConnections *This,
    ULONG cConnections,
    LPCONNECTDATA rgcd,
    ULONG *pcFetched);

void __RPC_STUB IEnumConnections_RemoteNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

HRESULT IEnumConnections_Next_Proxy(
    ULONG cConnections,
    LPCONNECTDATA rgcd,
    ULONG *pcFetched);
HRESULT IEnumConnections_Next_Stub(
    ULONG cConnections,
    LPCONNECTDATA rgcd,
    ULONG *pcFetched);
#endif /* __IEnumConnections_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IConnectionPoint interface
 */
#ifndef __IConnectionPoint_INTERFACE_DEFINED__
#define __IConnectionPoint_INTERFACE_DEFINED__

typedef IConnectionPoint *PCONNECTIONPOINT;
typedef IConnectionPoint *LPCONNECTIONPOINT;

EXTERN_C const IID IID_IConnectionPoint;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IConnectionPointVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IConnectionPoint *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IConnectionPoint *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IConnectionPoint *This);

    /*** IConnectionPoint methods ***/
    HRESULT (STDMETHODCALLTYPE *GetConnectionInterface)(
        IConnectionPoint *This,
        IID *pIID);

    HRESULT (STDMETHODCALLTYPE *GetConnectionPointContainer)(
        IConnectionPoint *This,
        IConnectionPointContainer **ppCPC);

    HRESULT (STDMETHODCALLTYPE *Advise)(
        IConnectionPoint *This,
        IUnknown *pUnkSink,
        DWORD *pdwCookie);

    HRESULT (STDMETHODCALLTYPE *Unadvise)(
        IConnectionPoint *This,
        DWORD dwCookie);

    HRESULT (STDMETHODCALLTYPE *EnumConnections)(
        IConnectionPoint *This,
        IEnumConnections **ppEnum);

    END_INTERFACE
} IConnectionPointVtbl;

interface IConnectionPoint {
    CONST_VTBL IConnectionPointVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IConnectionPoint_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IConnectionPoint_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IConnectionPoint_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IConnectionPoint methods ***/
#define IConnectionPoint_GetConnectionInterface(This,pIID) \
    ((This)->lpVtbl->GetConnectionInterface(This,pIID))
#define IConnectionPoint_GetConnectionPointContainer(This,ppCPC) \
    ((This)->lpVtbl->GetConnectionPointContainer(This,ppCPC))
#define IConnectionPoint_Advise(This,pUnkSink,pdwCookie) \
    ((This)->lpVtbl->Advise(This,pUnkSink,pdwCookie))
#define IConnectionPoint_Unadvise(This,dwCookie) \
    ((This)->lpVtbl->Unadvise(This,dwCookie))
#define IConnectionPoint_EnumConnections(This,ppEnum) \
    ((This)->lpVtbl->EnumConnections(This,ppEnum))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IConnectionPoint_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IEnumConnectionPoints interface
 */
#ifndef __IEnumConnectionPoints_INTERFACE_DEFINED__
#define __IEnumConnectionPoints_INTERFACE_DEFINED__

typedef IEnumConnectionPoints *PENUMCONNECTIONPOINTS;
typedef IEnumConnectionPoints *LPENUMCONNECTIONPOINTS;

EXTERN_C const IID IID_IEnumConnectionPoints;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IEnumConnectionPointsVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IEnumConnectionPoints *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IEnumConnectionPoints *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IEnumConnectionPoints *This);

    /*** IEnumConnectionPoints methods ***/
    HRESULT (STDMETHODCALLTYPE *Next)(
        IEnumConnectionPoints *This,
        ULONG cConnections,
        LPCONNECTIONPOINT *ppCP,
        ULONG *pcFetched);

    HRESULT (STDMETHODCALLTYPE *Skip)(
        IEnumConnectionPoints *This,
        ULONG cConnections);

    HRESULT (STDMETHODCALLTYPE *Reset)(
        IEnumConnectionPoints *This);

    HRESULT (STDMETHODCALLTYPE *Clone)(
        IEnumConnectionPoints *This,
        IEnumConnectionPoints **ppEnum);

    END_INTERFACE
} IEnumConnectionPointsVtbl;

interface IEnumConnectionPoints {
    CONST_VTBL IEnumConnectionPointsVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IEnumConnectionPoints_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IEnumConnectionPoints_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IEnumConnectionPoints_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IEnumConnectionPoints methods ***/
#define IEnumConnectionPoints_Next(This,cConnections,ppCP,pcFetched) \
    ((This)->lpVtbl->Next(This,cConnections,ppCP,pcFetched))
#define IEnumConnectionPoints_Skip(This,cConnections) \
    ((This)->lpVtbl->Skip(This,cConnections))
#define IEnumConnectionPoints_Reset(This) \
    ((This)->lpVtbl->Reset(This))
#define IEnumConnectionPoints_Clone(This,ppEnum) \
    ((This)->lpVtbl->Clone(This,ppEnum))
#endif /* COBJMACROS */

#endif /* C */

HRESULT STDMETHODCALLTYPE IEnumConnectionPoints_RemoteNext_Proxy(
    IEnumConnectionPoints *This,
    ULONG cConnections,
    LPCONNECTIONPOINT *ppCP,
    ULONG *pcFetched);

void __RPC_STUB IEnumConnectionPoints_RemoteNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

HRESULT IEnumConnectionPoints_Next_Proxy(
    ULONG cConnections,
    LPCONNECTIONPOINT *ppCP,
    ULONG *pcFetched);
HRESULT IEnumConnectionPoints_Next_Stub(
    ULONG cConnections,
    LPCONNECTIONPOINT *ppCP,
    ULONG *pcFetched);
#endif /* __IEnumConnectionPoints_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IConnectionPointContainer interface
 */
#ifndef __IConnectionPointContainer_INTERFACE_DEFINED__
#define __IConnectionPointContainer_INTERFACE_DEFINED__

typedef IConnectionPointContainer *PCONNECTIONPOINTCONTAINER;
typedef IConnectionPointContainer *LPCONNECTIONPOINTCONTAINER;

EXTERN_C const IID IID_IConnectionPointContainer;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IConnectionPointContainerVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IConnectionPointContainer *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IConnectionPointContainer *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IConnectionPointContainer *This);

    /*** IConnectionPointContainer methods ***/
    HRESULT (STDMETHODCALLTYPE *EnumConnectionPoints)(
        IConnectionPointContainer *This,
        IEnumConnectionPoints **ppEnum);

    HRESULT (STDMETHODCALLTYPE *FindConnectionPoint)(
        IConnectionPointContainer *This,
        REFIID riid,
        IConnectionPoint **ppCP);

    END_INTERFACE
} IConnectionPointContainerVtbl;

interface IConnectionPointContainer {
    CONST_VTBL IConnectionPointContainerVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IConnectionPointContainer_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IConnectionPointContainer_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IConnectionPointContainer_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IConnectionPointContainer methods ***/
#define IConnectionPointContainer_EnumConnectionPoints(This,ppEnum) \
    ((This)->lpVtbl->EnumConnectionPoints(This,ppEnum))
#define IConnectionPointContainer_FindConnectionPoint(This,riid,ppCP) \
    ((This)->lpVtbl->FindConnectionPoint(This,riid,ppCP))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IConnectionPointContainer_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)

/*****************************************************************************
 * IClassFactory2 interface
 */
#ifndef __IClassFactory2_INTERFACE_DEFINED__
#define __IClassFactory2_INTERFACE_DEFINED__

typedef IClassFactory2 *LPCLASSFACTORY2;

typedef struct tagLICINFO {
    LONG cbLicInfo;
    BOOL fRuntimeKeyAvail;
    BOOL fLicVerified;
} LICINFO;

typedef struct tagLICINFO *LPLICINFO;

EXTERN_C const IID IID_IClassFactory2;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IClassFactory2Vtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IClassFactory2 *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IClassFactory2 *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IClassFactory2 *This);

    /*** IClassFactory methods ***/
    HRESULT (STDMETHODCALLTYPE *CreateInstance)(
        IClassFactory2 *This,
        IUnknown *pUnkOuter,
        REFIID riid,
        void **ppvObject);

    HRESULT (STDMETHODCALLTYPE *LockServer)(
        IClassFactory2 *This,
        BOOL fLock);

    /*** IClassFactory2 methods ***/
    HRESULT (STDMETHODCALLTYPE *GetLicInfo)(
        IClassFactory2 *This,
        LICINFO *pLicInfo);

    HRESULT (STDMETHODCALLTYPE *RequestLicKey)(
        IClassFactory2 *This,
        DWORD dwReserved,
        BSTR *pBstrKey);

    HRESULT (STDMETHODCALLTYPE *CreateInstanceLic)(
        IClassFactory2 *This,
        IUnknown *pUnkOuter,
        IUnknown *pUnkReserved,
        REFIID riid,
        BSTR bstrKey,
        PVOID *ppvObj);

    END_INTERFACE
} IClassFactory2Vtbl;

interface IClassFactory2 {
    CONST_VTBL IClassFactory2Vtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IClassFactory2_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IClassFactory2_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IClassFactory2_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IClassFactory methods ***/
#define IClassFactory2_CreateInstance(This,pUnkOuter,riid,ppvObject) \
    ((This)->lpVtbl->CreateInstance(This,pUnkOuter,riid,ppvObject))
#define IClassFactory2_LockServer(This,fLock) \
    ((This)->lpVtbl->LockServer(This,fLock))
/*** IClassFactory2 methods ***/
#define IClassFactory2_GetLicInfo(This,pLicInfo) \
    ((This)->lpVtbl->GetLicInfo(This,pLicInfo))
#define IClassFactory2_RequestLicKey(This,dwReserved,pBstrKey) \
    ((This)->lpVtbl->RequestLicKey(This,dwReserved,pBstrKey))
#define IClassFactory2_CreateInstanceLic(This,pUnkOuter,pUnkReserved,riid,bstrKey,ppvObj) \
    ((This)->lpVtbl->CreateInstanceLic(This,pUnkOuter,pUnkReserved,riid,bstrKey,ppvObj))
#endif /* COBJMACROS */

#endif /* C */

HRESULT STDMETHODCALLTYPE IClassFactory2_RemoteCreateInstanceLic_Proxy(
    IClassFactory2 *This,
    REFIID riid,
    BSTR bstrKey,
    IUnknown **ppvObj);

void __RPC_STUB IClassFactory2_RemoteCreateInstanceLic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

HRESULT IClassFactory2_CreateInstanceLic_Proxy(
    IUnknown *pUnkOuter,
    IUnknown *pUnkReserved,
    REFIID riid,
    BSTR bstrKey,
    PVOID *ppvObj);
HRESULT IClassFactory2_CreateInstanceLic_Stub(
    REFIID riid,
    BSTR bstrKey,
    IUnknown **ppvObj);
#endif /* __IClassFactory2_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IProvideClassInfo interface
 */
#ifndef __IProvideClassInfo_INTERFACE_DEFINED__
#define __IProvideClassInfo_INTERFACE_DEFINED__

typedef IProvideClassInfo *LPPROVIDECLASSINFO;

EXTERN_C const IID IID_IProvideClassInfo;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IProvideClassInfoVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IProvideClassInfo *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IProvideClassInfo *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IProvideClassInfo *This);

    /*** IProvideClassInfo methods ***/
    HRESULT (STDMETHODCALLTYPE *GetClassInfo)(
        IProvideClassInfo *This,
        ITypeInfo **ppTI);

    END_INTERFACE
} IProvideClassInfoVtbl;

interface IProvideClassInfo {
    CONST_VTBL IProvideClassInfoVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IProvideClassInfo_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IProvideClassInfo_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IProvideClassInfo_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IProvideClassInfo methods ***/
#define IProvideClassInfo_GetClassInfo(This,ppTI) \
    ((This)->lpVtbl->GetClassInfo(This,ppTI))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IProvideClassInfo_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IProvideClassInfo2 interface
 */
#ifndef __IProvideClassInfo2_INTERFACE_DEFINED__
#define __IProvideClassInfo2_INTERFACE_DEFINED__

typedef IProvideClassInfo2 *LPPROVIDECLASSINFO2;

typedef enum tagGUIDKIND {
    GUIDKIND_DEFAULT_SOURCE_DISP_IID = 1
} GUIDKIND;

EXTERN_C const IID IID_IProvideClassInfo2;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IProvideClassInfo2Vtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IProvideClassInfo2 *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IProvideClassInfo2 *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IProvideClassInfo2 *This);

    /*** IProvideClassInfo methods ***/
    HRESULT (STDMETHODCALLTYPE *GetClassInfo)(
        IProvideClassInfo2 *This,
        ITypeInfo **ppTI);

    /*** IProvideClassInfo2 methods ***/
    HRESULT (STDMETHODCALLTYPE *GetGUID)(
        IProvideClassInfo2 *This,
        DWORD dwGuidKind,
        GUID *pGUID);

    END_INTERFACE
} IProvideClassInfo2Vtbl;

interface IProvideClassInfo2 {
    CONST_VTBL IProvideClassInfo2Vtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IProvideClassInfo2_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IProvideClassInfo2_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IProvideClassInfo2_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IProvideClassInfo methods ***/
#define IProvideClassInfo2_GetClassInfo(This,ppTI) \
    ((This)->lpVtbl->GetClassInfo(This,ppTI))
/*** IProvideClassInfo2 methods ***/
#define IProvideClassInfo2_GetGUID(This,dwGuidKind,pGUID) \
    ((This)->lpVtbl->GetGUID(This,dwGuidKind,pGUID))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IProvideClassInfo2_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IProvideMultipleClassInfo interface
 */
#ifndef __IProvideMultipleClassInfo_INTERFACE_DEFINED__
#define __IProvideMultipleClassInfo_INTERFACE_DEFINED__

#define MULTICLASSINFO_GETTYPEINFO           0x00000001
#define MULTICLASSINFO_GETNUMRESERVEDDISPIDS 0x00000002
#define MULTICLASSINFO_GETIIDPRIMARY         0x00000004
#define MULTICLASSINFO_GETIIDSOURCE          0x00000008
#define TIFLAGS_EXTENDDISPATCHONLY           0x00000001

typedef IProvideMultipleClassInfo *LPPROVIDEMULTIPLECLASSINFO;

EXTERN_C const IID IID_IProvideMultipleClassInfo;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IProvideMultipleClassInfoVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IProvideMultipleClassInfo *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IProvideMultipleClassInfo *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IProvideMultipleClassInfo *This);

    /*** IProvideClassInfo methods ***/
    HRESULT (STDMETHODCALLTYPE *GetClassInfo)(
        IProvideMultipleClassInfo *This,
        ITypeInfo **ppTI);

    /*** IProvideClassInfo2 methods ***/
    HRESULT (STDMETHODCALLTYPE *GetGUID)(
        IProvideMultipleClassInfo *This,
        DWORD dwGuidKind,
        GUID *pGUID);

    /*** IProvideMultipleClassInfo methods ***/
    HRESULT (STDMETHODCALLTYPE *GetMultiTypeInfoCount)(
        IProvideMultipleClassInfo *This,
        ULONG *pcti);

    HRESULT (STDMETHODCALLTYPE *GetInfoOfIndex)(
        IProvideMultipleClassInfo *This,
        ULONG iti,
        DWORD dwFlags,
        ITypeInfo **pptiCoClass,
        DWORD *pdwTIFlags,
        ULONG *pcdispidReserved,
        IID *piidPrimary,
        IID *piidSource);

    END_INTERFACE
} IProvideMultipleClassInfoVtbl;

interface IProvideMultipleClassInfo {
    CONST_VTBL IProvideMultipleClassInfoVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IProvideMultipleClassInfo_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IProvideMultipleClassInfo_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IProvideMultipleClassInfo_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IProvideClassInfo methods ***/
#define IProvideMultipleClassInfo_GetClassInfo(This,ppTI) \
    ((This)->lpVtbl->GetClassInfo(This,ppTI))
/*** IProvideClassInfo2 methods ***/
#define IProvideMultipleClassInfo_GetGUID(This,dwGuidKind,pGUID) \
    ((This)->lpVtbl->GetGUID(This,dwGuidKind,pGUID))
/*** IProvideMultipleClassInfo methods ***/
#define IProvideMultipleClassInfo_GetMultiTypeInfoCount(This,pcti) \
    ((This)->lpVtbl->GetMultiTypeInfoCount(This,pcti))
#define IProvideMultipleClassInfo_GetInfoOfIndex(This,iti,dwFlags,pptiCoClass,pdwTIFlags,pcdispidReserved,piidPrimary,piidSource) \
    ((This)->lpVtbl->GetInfoOfIndex(This,iti,dwFlags,pptiCoClass,pdwTIFlags,pcdispidReserved,piidPrimary,piidSource))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IProvideMultipleClassInfo_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleControl interface
 */
#ifndef __IOleControl_INTERFACE_DEFINED__
#define __IOleControl_INTERFACE_DEFINED__

typedef IOleControl *LPOLECONTROL;

typedef struct tagCONTROLINFO {
    ULONG cb;
    HACCEL hAccel;
    USHORT cAccel;
    DWORD dwFlags;
} CONTROLINFO;

typedef struct tagCONTROLINFO *LPCONTROLINFO;

typedef enum tagCTRLINFO {
    CTRLINFO_EATS_RETURN = 1,
    CTRLINFO_EATS_ESCAPE = 2
} CTRLINFO;

EXTERN_C const IID IID_IOleControl;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleControlVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleControl *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleControl *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleControl *This);

    /*** IOleControl methods ***/
    HRESULT (STDMETHODCALLTYPE *GetControlInfo)(
        IOleControl *This,
        CONTROLINFO *pCI);

    HRESULT (STDMETHODCALLTYPE *OnMnemonic)(
        IOleControl *This,
        MSG *pMsg);

    HRESULT (STDMETHODCALLTYPE *OnAmbientPropertyChange)(
        IOleControl *This,
        DISPID dispID);

    HRESULT (STDMETHODCALLTYPE *FreezeEvents)(
        IOleControl *This,
        BOOL bFreeze);

    END_INTERFACE
} IOleControlVtbl;

interface IOleControl {
    CONST_VTBL IOleControlVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleControl_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleControl_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleControl_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleControl methods ***/
#define IOleControl_GetControlInfo(This,pCI) \
    ((This)->lpVtbl->GetControlInfo(This,pCI))
#define IOleControl_OnMnemonic(This,pMsg) \
    ((This)->lpVtbl->OnMnemonic(This,pMsg))
#define IOleControl_OnAmbientPropertyChange(This,dispID) \
    ((This)->lpVtbl->OnAmbientPropertyChange(This,dispID))
#define IOleControl_FreezeEvents(This,bFreeze) \
    ((This)->lpVtbl->FreezeEvents(This,bFreeze))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleControl_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleControlSite interface
 */
#ifndef __IOleControlSite_INTERFACE_DEFINED__
#define __IOleControlSite_INTERFACE_DEFINED__

typedef IOleControlSite *LPOLECONTROLSITE;

typedef struct tagPOINTF {
    FLOAT x;
    FLOAT y;
} POINTF;

typedef struct tagPOINTF *LPPOINTF;

typedef enum tagXFORMCOORDS {
    XFORMCOORDS_POSITION = 0x1,
    XFORMCOORDS_SIZE = 0x2,
    XFORMCOORDS_HIMETRICTOCONTAINER = 0x4,
    XFORMCOORDS_CONTAINERTOHIMETRIC = 0x8,
    XFORMCOORDS_EVENTCOMPAT = 0x10
} XFORMCOORDS;

EXTERN_C const IID IID_IOleControlSite;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleControlSiteVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleControlSite *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleControlSite *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleControlSite *This);

    /*** IOleControlSite methods ***/
    HRESULT (STDMETHODCALLTYPE *OnControlInfoChanged)(
        IOleControlSite *This);

    HRESULT (STDMETHODCALLTYPE *LockInPlaceActive)(
        IOleControlSite *This,
        BOOL fLock);

    HRESULT (STDMETHODCALLTYPE *GetExtendedControl)(
        IOleControlSite *This,
        IDispatch **ppDisp);

    HRESULT (STDMETHODCALLTYPE *TransformCoords)(
        IOleControlSite *This,
        POINTL *pPtlHimetric,
        POINTF *pPtfContainer,
        DWORD dwFlags);

    HRESULT (STDMETHODCALLTYPE *TranslateAccelerator)(
        IOleControlSite *This,
        MSG *pMsg,
        DWORD grfModifiers);

    HRESULT (STDMETHODCALLTYPE *OnFocus)(
        IOleControlSite *This,
        BOOL fGotFocus);

    HRESULT (STDMETHODCALLTYPE *ShowPropertyFrame)(
        IOleControlSite *This);

    END_INTERFACE
} IOleControlSiteVtbl;

interface IOleControlSite {
    CONST_VTBL IOleControlSiteVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleControlSite_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleControlSite_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleControlSite_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleControlSite methods ***/
#define IOleControlSite_OnControlInfoChanged(This) \
    ((This)->lpVtbl->OnControlInfoChanged(This))
#define IOleControlSite_LockInPlaceActive(This,fLock) \
    ((This)->lpVtbl->LockInPlaceActive(This,fLock))
#define IOleControlSite_GetExtendedControl(This,ppDisp) \
    ((This)->lpVtbl->GetExtendedControl(This,ppDisp))
#define IOleControlSite_TransformCoords(This,pPtlHimetric,pPtfContainer,dwFlags) \
    ((This)->lpVtbl->TransformCoords(This,pPtlHimetric,pPtfContainer,dwFlags))
#define IOleControlSite_TranslateAccelerator(This,pMsg,grfModifiers) \
    ((This)->lpVtbl->TranslateAccelerator(This,pMsg,grfModifiers))
#define IOleControlSite_OnFocus(This,fGotFocus) \
    ((This)->lpVtbl->OnFocus(This,fGotFocus))
#define IOleControlSite_ShowPropertyFrame(This) \
    ((This)->lpVtbl->ShowPropertyFrame(This))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleControlSite_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPropertyPage interface
 */
#ifndef __IPropertyPage_INTERFACE_DEFINED__
#define __IPropertyPage_INTERFACE_DEFINED__

typedef IPropertyPage *LPPROPERTYPAGE;

typedef struct tagPROPPAGEINFO {
    ULONG cb;
    LPOLESTR pszTitle;
    SIZE size;
    LPOLESTR pszDocString;
    LPOLESTR pszHelpFile;
    DWORD dwHelpContext;
} PROPPAGEINFO;

typedef struct tagPROPPAGEINFO *LPPROPPAGEINFO;

EXTERN_C const IID IID_IPropertyPage;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPropertyPageVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPropertyPage *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPropertyPage *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPropertyPage *This);

    /*** IPropertyPage methods ***/
    HRESULT (STDMETHODCALLTYPE *SetPageSite)(
        IPropertyPage *This,
        IPropertyPageSite *pPageSite);

    HRESULT (STDMETHODCALLTYPE *Activate)(
        IPropertyPage *This,
        HWND hWndParent,
        LPCRECT pRect,
        BOOL bModal);

    HRESULT (STDMETHODCALLTYPE *Deactivate)(
        IPropertyPage *This);

    HRESULT (STDMETHODCALLTYPE *GetPageInfo)(
        IPropertyPage *This,
        PROPPAGEINFO *pPageInfo);

    HRESULT (STDMETHODCALLTYPE *SetObjects)(
        IPropertyPage *This,
        ULONG cObjects,
        IUnknown **ppUnk);

    HRESULT (STDMETHODCALLTYPE *Show)(
        IPropertyPage *This,
        UINT nCmdShow);

    HRESULT (STDMETHODCALLTYPE *Move)(
        IPropertyPage *This,
        LPCRECT pRect);

    HRESULT (STDMETHODCALLTYPE *IsPageDirty)(
        IPropertyPage *This);

    HRESULT (STDMETHODCALLTYPE *Apply)(
        IPropertyPage *This);

    HRESULT (STDMETHODCALLTYPE *Help)(
        IPropertyPage *This,
        LPCOLESTR pszHelpDir);

    HRESULT (STDMETHODCALLTYPE *TranslateAccelerator)(
        IPropertyPage *This,
        MSG *pMsg);

    END_INTERFACE
} IPropertyPageVtbl;

interface IPropertyPage {
    CONST_VTBL IPropertyPageVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPropertyPage_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPropertyPage_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPropertyPage_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPropertyPage methods ***/
#define IPropertyPage_SetPageSite(This,pPageSite) \
    ((This)->lpVtbl->SetPageSite(This,pPageSite))
#define IPropertyPage_Activate(This,hWndParent,pRect,bModal) \
    ((This)->lpVtbl->Activate(This,hWndParent,pRect,bModal))
#define IPropertyPage_Deactivate(This) \
    ((This)->lpVtbl->Deactivate(This))
#define IPropertyPage_GetPageInfo(This,pPageInfo) \
    ((This)->lpVtbl->GetPageInfo(This,pPageInfo))
#define IPropertyPage_SetObjects(This,cObjects,ppUnk) \
    ((This)->lpVtbl->SetObjects(This,cObjects,ppUnk))
#define IPropertyPage_Show(This,nCmdShow) \
    ((This)->lpVtbl->Show(This,nCmdShow))
#define IPropertyPage_Move(This,pRect) \
    ((This)->lpVtbl->Move(This,pRect))
#define IPropertyPage_IsPageDirty(This) \
    ((This)->lpVtbl->IsPageDirty(This))
#define IPropertyPage_Apply(This) \
    ((This)->lpVtbl->Apply(This))
#define IPropertyPage_Help(This,pszHelpDir) \
    ((This)->lpVtbl->Help(This,pszHelpDir))
#define IPropertyPage_TranslateAccelerator(This,pMsg) \
    ((This)->lpVtbl->TranslateAccelerator(This,pMsg))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPropertyPage_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPropertyPage2 interface
 */
#ifndef __IPropertyPage2_INTERFACE_DEFINED__
#define __IPropertyPage2_INTERFACE_DEFINED__

typedef IPropertyPage2 *LPPROPERTYPAGE2;

EXTERN_C const IID IID_IPropertyPage2;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPropertyPage2Vtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPropertyPage2 *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPropertyPage2 *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPropertyPage2 *This);

    /*** IPropertyPage methods ***/
    HRESULT (STDMETHODCALLTYPE *SetPageSite)(
        IPropertyPage2 *This,
        IPropertyPageSite *pPageSite);

    HRESULT (STDMETHODCALLTYPE *Activate)(
        IPropertyPage2 *This,
        HWND hWndParent,
        LPCRECT pRect,
        BOOL bModal);

    HRESULT (STDMETHODCALLTYPE *Deactivate)(
        IPropertyPage2 *This);

    HRESULT (STDMETHODCALLTYPE *GetPageInfo)(
        IPropertyPage2 *This,
        PROPPAGEINFO *pPageInfo);

    HRESULT (STDMETHODCALLTYPE *SetObjects)(
        IPropertyPage2 *This,
        ULONG cObjects,
        IUnknown **ppUnk);

    HRESULT (STDMETHODCALLTYPE *Show)(
        IPropertyPage2 *This,
        UINT nCmdShow);

    HRESULT (STDMETHODCALLTYPE *Move)(
        IPropertyPage2 *This,
        LPCRECT pRect);

    HRESULT (STDMETHODCALLTYPE *IsPageDirty)(
        IPropertyPage2 *This);

    HRESULT (STDMETHODCALLTYPE *Apply)(
        IPropertyPage2 *This);

    HRESULT (STDMETHODCALLTYPE *Help)(
        IPropertyPage2 *This,
        LPCOLESTR pszHelpDir);

    HRESULT (STDMETHODCALLTYPE *TranslateAccelerator)(
        IPropertyPage2 *This,
        MSG *pMsg);

    /*** IPropertyPage2 methods ***/
    HRESULT (STDMETHODCALLTYPE *EditProperty)(
        IPropertyPage2 *This,
        DISPID dispID);

    END_INTERFACE
} IPropertyPage2Vtbl;

interface IPropertyPage2 {
    CONST_VTBL IPropertyPage2Vtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPropertyPage2_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPropertyPage2_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPropertyPage2_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPropertyPage methods ***/
#define IPropertyPage2_SetPageSite(This,pPageSite) \
    ((This)->lpVtbl->SetPageSite(This,pPageSite))
#define IPropertyPage2_Activate(This,hWndParent,pRect,bModal) \
    ((This)->lpVtbl->Activate(This,hWndParent,pRect,bModal))
#define IPropertyPage2_Deactivate(This) \
    ((This)->lpVtbl->Deactivate(This))
#define IPropertyPage2_GetPageInfo(This,pPageInfo) \
    ((This)->lpVtbl->GetPageInfo(This,pPageInfo))
#define IPropertyPage2_SetObjects(This,cObjects,ppUnk) \
    ((This)->lpVtbl->SetObjects(This,cObjects,ppUnk))
#define IPropertyPage2_Show(This,nCmdShow) \
    ((This)->lpVtbl->Show(This,nCmdShow))
#define IPropertyPage2_Move(This,pRect) \
    ((This)->lpVtbl->Move(This,pRect))
#define IPropertyPage2_IsPageDirty(This) \
    ((This)->lpVtbl->IsPageDirty(This))
#define IPropertyPage2_Apply(This) \
    ((This)->lpVtbl->Apply(This))
#define IPropertyPage2_Help(This,pszHelpDir) \
    ((This)->lpVtbl->Help(This,pszHelpDir))
#define IPropertyPage2_TranslateAccelerator(This,pMsg) \
    ((This)->lpVtbl->TranslateAccelerator(This,pMsg))
/*** IPropertyPage2 methods ***/
#define IPropertyPage2_EditProperty(This,dispID) \
    ((This)->lpVtbl->EditProperty(This,dispID))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPropertyPage2_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPropertyPageSite interface
 */
#ifndef __IPropertyPageSite_INTERFACE_DEFINED__
#define __IPropertyPageSite_INTERFACE_DEFINED__

typedef IPropertyPageSite *LPPROPERTYPAGESITE;

typedef enum tagPROPPAGESTATUS {
    PROPPAGESTATUS_DIRTY = 0x1,
    PROPPAGESTATUS_VALIDATE = 0x2,
    PROPPAGESTATUS_CLEAN = 0x4
} PROPPAGESTATUS;

EXTERN_C const IID IID_IPropertyPageSite;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPropertyPageSiteVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPropertyPageSite *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPropertyPageSite *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPropertyPageSite *This);

    /*** IPropertyPageSite methods ***/
    HRESULT (STDMETHODCALLTYPE *OnStatusChange)(
        IPropertyPageSite *This,
        DWORD dwFlags);

    HRESULT (STDMETHODCALLTYPE *GetLocaleID)(
        IPropertyPageSite *This,
        LCID *pLocaleID);

    HRESULT (STDMETHODCALLTYPE *GetPageContainer)(
        IPropertyPageSite *This,
        IUnknown **ppUnk);

    HRESULT (STDMETHODCALLTYPE *TranslateAccelerator)(
        IPropertyPageSite *This,
        MSG *pMsg);

    END_INTERFACE
} IPropertyPageSiteVtbl;

interface IPropertyPageSite {
    CONST_VTBL IPropertyPageSiteVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPropertyPageSite_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPropertyPageSite_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPropertyPageSite_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPropertyPageSite methods ***/
#define IPropertyPageSite_OnStatusChange(This,dwFlags) \
    ((This)->lpVtbl->OnStatusChange(This,dwFlags))
#define IPropertyPageSite_GetLocaleID(This,pLocaleID) \
    ((This)->lpVtbl->GetLocaleID(This,pLocaleID))
#define IPropertyPageSite_GetPageContainer(This,ppUnk) \
    ((This)->lpVtbl->GetPageContainer(This,ppUnk))
#define IPropertyPageSite_TranslateAccelerator(This,pMsg) \
    ((This)->lpVtbl->TranslateAccelerator(This,pMsg))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPropertyPageSite_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPropertyNotifySink interface
 */
#ifndef __IPropertyNotifySink_INTERFACE_DEFINED__
#define __IPropertyNotifySink_INTERFACE_DEFINED__

typedef IPropertyNotifySink *LPPROPERTYNOTIFYSINK;

EXTERN_C const IID IID_IPropertyNotifySink;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPropertyNotifySinkVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPropertyNotifySink *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPropertyNotifySink *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPropertyNotifySink *This);

    /*** IPropertyNotifySink methods ***/
    HRESULT (STDMETHODCALLTYPE *OnChanged)(
        IPropertyNotifySink *This,
        DISPID dispID);

    HRESULT (STDMETHODCALLTYPE *OnRequestEdit)(
        IPropertyNotifySink *This,
        DISPID dispID);

    END_INTERFACE
} IPropertyNotifySinkVtbl;

interface IPropertyNotifySink {
    CONST_VTBL IPropertyNotifySinkVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPropertyNotifySink_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPropertyNotifySink_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPropertyNotifySink_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPropertyNotifySink methods ***/
#define IPropertyNotifySink_OnChanged(This,dispID) \
    ((This)->lpVtbl->OnChanged(This,dispID))
#define IPropertyNotifySink_OnRequestEdit(This,dispID) \
    ((This)->lpVtbl->OnRequestEdit(This,dispID))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPropertyNotifySink_INTERFACE_DEFINED__ */

/*****************************************************************************
 * ISpecifyPropertyPages interface
 */
#ifndef __ISpecifyPropertyPages_INTERFACE_DEFINED__
#define __ISpecifyPropertyPages_INTERFACE_DEFINED__

typedef ISpecifyPropertyPages *LPSPECIFYPROPERTYPAGES;

typedef struct tagCAUUID {
    ULONG cElems;
    GUID *pElems;
} CAUUID;

typedef struct tagCAUUID *LPCAUUID;

EXTERN_C const IID IID_ISpecifyPropertyPages;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct ISpecifyPropertyPagesVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        ISpecifyPropertyPages *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        ISpecifyPropertyPages *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        ISpecifyPropertyPages *This);

    /*** ISpecifyPropertyPages methods ***/
    HRESULT (STDMETHODCALLTYPE *GetPages)(
        ISpecifyPropertyPages *This,
        CAUUID *pPages);

    END_INTERFACE
} ISpecifyPropertyPagesVtbl;

interface ISpecifyPropertyPages {
    CONST_VTBL ISpecifyPropertyPagesVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define ISpecifyPropertyPages_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define ISpecifyPropertyPages_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define ISpecifyPropertyPages_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** ISpecifyPropertyPages methods ***/
#define ISpecifyPropertyPages_GetPages(This,pPages) \
    ((This)->lpVtbl->GetPages(This,pPages))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __ISpecifyPropertyPages_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPersistMemory interface
 */
#ifndef __IPersistMemory_INTERFACE_DEFINED__
#define __IPersistMemory_INTERFACE_DEFINED__

typedef IPersistMemory *LPPERSISTMEMORY;

EXTERN_C const IID IID_IPersistMemory;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPersistMemoryVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPersistMemory *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPersistMemory *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPersistMemory *This);

    /*** IPersist methods ***/
    HRESULT (STDMETHODCALLTYPE *GetClassID)(
        IPersistMemory *This,
        CLSID *pClassID);

    /*** IPersistMemory methods ***/
    HRESULT (STDMETHODCALLTYPE *IsDirty)(
        IPersistMemory *This);

    HRESULT (STDMETHODCALLTYPE *Load)(
        IPersistMemory *This,
        LPVOID pMem,
        ULONG cbSize);

    HRESULT (STDMETHODCALLTYPE *Save)(
        IPersistMemory *This,
        LPVOID pMem,
        BOOL fClearDirty,
        ULONG cbSize);

    HRESULT (STDMETHODCALLTYPE *GetSizeMax)(
        IPersistMemory *This,
        ULONG *pCbSize);

    HRESULT (STDMETHODCALLTYPE *InitNew)(
        IPersistMemory *This);

    END_INTERFACE
} IPersistMemoryVtbl;

interface IPersistMemory {
    CONST_VTBL IPersistMemoryVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPersistMemory_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPersistMemory_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPersistMemory_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPersist methods ***/
#define IPersistMemory_GetClassID(This,pClassID) \
    ((This)->lpVtbl->GetClassID(This,pClassID))
/*** IPersistMemory methods ***/
#define IPersistMemory_IsDirty(This) \
    ((This)->lpVtbl->IsDirty(This))
#define IPersistMemory_Load(This,pMem,cbSize) \
    ((This)->lpVtbl->Load(This,pMem,cbSize))
#define IPersistMemory_Save(This,pMem,fClearDirty,cbSize) \
    ((This)->lpVtbl->Save(This,pMem,fClearDirty,cbSize))
#define IPersistMemory_GetSizeMax(This,pCbSize) \
    ((This)->lpVtbl->GetSizeMax(This,pCbSize))
#define IPersistMemory_InitNew(This) \
    ((This)->lpVtbl->InitNew(This))
#endif /* COBJMACROS */

#endif /* C */

HRESULT STDMETHODCALLTYPE IPersistMemory_RemoteLoad_Proxy(
    IPersistMemory *This,
    BYTE *pMem,
    ULONG cbSize);

void __RPC_STUB IPersistMemory_RemoteLoad_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPersistMemory_RemoteSave_Proxy(
    IPersistMemory *This,
    BYTE *pMem,
    BOOL fClearDirty,
    ULONG cbSize);

void __RPC_STUB IPersistMemory_RemoteSave_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

HRESULT IPersistMemory_Load_Proxy(
    LPVOID pMem,
    ULONG cbSize);
HRESULT IPersistMemory_Load_Stub(
    BYTE *pMem,
    ULONG cbSize);
HRESULT IPersistMemory_Save_Proxy(
    LPVOID pMem,
    BOOL fClearDirty,
    ULONG cbSize);
HRESULT IPersistMemory_Save_Stub(
    BYTE *pMem,
    BOOL fClearDirty,
    ULONG cbSize);
#endif /* __IPersistMemory_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPersistStreamInit interface
 */
#ifndef __IPersistStreamInit_INTERFACE_DEFINED__
#define __IPersistStreamInit_INTERFACE_DEFINED__

typedef IPersistStreamInit *LPPERSISTSTREAMINIT;

EXTERN_C const IID IID_IPersistStreamInit;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPersistStreamInitVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPersistStreamInit *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPersistStreamInit *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPersistStreamInit *This);

    /*** IPersist methods ***/
    HRESULT (STDMETHODCALLTYPE *GetClassID)(
        IPersistStreamInit *This,
        CLSID *pClassID);

    /*** IPersistStreamInit methods ***/
    HRESULT (STDMETHODCALLTYPE *IsDirty)(
        IPersistStreamInit *This);

    HRESULT (STDMETHODCALLTYPE *Load)(
        IPersistStreamInit *This,
        LPSTREAM pStm);

    HRESULT (STDMETHODCALLTYPE *Save)(
        IPersistStreamInit *This,
        LPSTREAM pStm,
        BOOL fClearDirty);

    HRESULT (STDMETHODCALLTYPE *GetSizeMax)(
        IPersistStreamInit *This,
        ULARGE_INTEGER *pCbSize);

    HRESULT (STDMETHODCALLTYPE *InitNew)(
        IPersistStreamInit *This);

    END_INTERFACE
} IPersistStreamInitVtbl;

interface IPersistStreamInit {
    CONST_VTBL IPersistStreamInitVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPersistStreamInit_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPersistStreamInit_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPersistStreamInit_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPersist methods ***/
#define IPersistStreamInit_GetClassID(This,pClassID) \
    ((This)->lpVtbl->GetClassID(This,pClassID))
/*** IPersistStreamInit methods ***/
#define IPersistStreamInit_IsDirty(This) \
    ((This)->lpVtbl->IsDirty(This))
#define IPersistStreamInit_Load(This,pStm) \
    ((This)->lpVtbl->Load(This,pStm))
#define IPersistStreamInit_Save(This,pStm,fClearDirty) \
    ((This)->lpVtbl->Save(This,pStm,fClearDirty))
#define IPersistStreamInit_GetSizeMax(This,pCbSize) \
    ((This)->lpVtbl->GetSizeMax(This,pCbSize))
#define IPersistStreamInit_InitNew(This) \
    ((This)->lpVtbl->InitNew(This))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPersistStreamInit_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPersistPropertyBag interface
 */
#ifndef __IPersistPropertyBag_INTERFACE_DEFINED__
#define __IPersistPropertyBag_INTERFACE_DEFINED__

typedef IPersistPropertyBag *LPPERSISTPROPERTYBAG;

EXTERN_C const IID IID_IPersistPropertyBag;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPersistPropertyBagVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPersistPropertyBag *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPersistPropertyBag *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPersistPropertyBag *This);

    /*** IPersist methods ***/
    HRESULT (STDMETHODCALLTYPE *GetClassID)(
        IPersistPropertyBag *This,
        CLSID *pClassID);

    /*** IPersistPropertyBag methods ***/
    HRESULT (STDMETHODCALLTYPE *InitNew)(
        IPersistPropertyBag *This);

    HRESULT (STDMETHODCALLTYPE *Load)(
        IPersistPropertyBag *This,
        IPropertyBag *pPropBag,
        IErrorLog *pErrorLog);

    HRESULT (STDMETHODCALLTYPE *Save)(
        IPersistPropertyBag *This,
        IPropertyBag *pPropBag,
        BOOL fClearDirty,
        BOOL fSaveAllProperties);

    END_INTERFACE
} IPersistPropertyBagVtbl;

interface IPersistPropertyBag {
    CONST_VTBL IPersistPropertyBagVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPersistPropertyBag_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPersistPropertyBag_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPersistPropertyBag_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPersist methods ***/
#define IPersistPropertyBag_GetClassID(This,pClassID) \
    ((This)->lpVtbl->GetClassID(This,pClassID))
/*** IPersistPropertyBag methods ***/
#define IPersistPropertyBag_InitNew(This) \
    ((This)->lpVtbl->InitNew(This))
#define IPersistPropertyBag_Load(This,pPropBag,pErrorLog) \
    ((This)->lpVtbl->Load(This,pPropBag,pErrorLog))
#define IPersistPropertyBag_Save(This,pPropBag,fClearDirty,fSaveAllProperties) \
    ((This)->lpVtbl->Save(This,pPropBag,fClearDirty,fSaveAllProperties))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPersistPropertyBag_INTERFACE_DEFINED__ */

/*****************************************************************************
 * ISimpleFrameSite interface
 */
#ifndef __ISimpleFrameSite_INTERFACE_DEFINED__
#define __ISimpleFrameSite_INTERFACE_DEFINED__

typedef ISimpleFrameSite *LPSIMPLEFRAMESITE;

EXTERN_C const IID IID_ISimpleFrameSite;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct ISimpleFrameSiteVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        ISimpleFrameSite *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        ISimpleFrameSite *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        ISimpleFrameSite *This);

    /*** ISimpleFrameSite methods ***/
    HRESULT (STDMETHODCALLTYPE *PreMessageFilter)(
        ISimpleFrameSite *This,
        HWND hWnd,
        UINT msg,
        WPARAM wp,
        LPARAM lp,
        LRESULT *plResult,
        DWORD *pdwCookie);

    HRESULT (STDMETHODCALLTYPE *PostMessageFilter)(
        ISimpleFrameSite *This,
        HWND hWnd,
        UINT msg,
        WPARAM wp,
        LPARAM lp,
        LRESULT *plResult,
        DWORD dwCookie);

    END_INTERFACE
} ISimpleFrameSiteVtbl;

interface ISimpleFrameSite {
    CONST_VTBL ISimpleFrameSiteVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define ISimpleFrameSite_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define ISimpleFrameSite_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define ISimpleFrameSite_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** ISimpleFrameSite methods ***/
#define ISimpleFrameSite_PreMessageFilter(This,hWnd,msg,wp,lp,plResult,pdwCookie) \
    ((This)->lpVtbl->PreMessageFilter(This,hWnd,msg,wp,lp,plResult,pdwCookie))
#define ISimpleFrameSite_PostMessageFilter(This,hWnd,msg,wp,lp,plResult,dwCookie) \
    ((This)->lpVtbl->PostMessageFilter(This,hWnd,msg,wp,lp,plResult,dwCookie))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __ISimpleFrameSite_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IFont interface
 */
#ifndef __IFont_INTERFACE_DEFINED__
#define __IFont_INTERFACE_DEFINED__

typedef IFont *LPFONT;

#if (defined(_WIN32) || defined (_WIN64)) && !defined(OLE2ANSI)
typedef TEXTMETRICW TEXTMETRICOLE;
#else
typedef TEXTMETRIC TEXTMETRICOLE;
#endif

typedef TEXTMETRICOLE *LPTEXTMETRICOLE;

EXTERN_C const IID IID_IFont;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IFontVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IFont *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IFont *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IFont *This);

    /*** IFont methods ***/
    HRESULT (STDMETHODCALLTYPE *get_Name)(
        IFont *This,
        BSTR *pName);

    HRESULT (STDMETHODCALLTYPE *put_Name)(
        IFont *This,
        BSTR name);

    HRESULT (STDMETHODCALLTYPE *get_Size)(
        IFont *This,
        CY *pSize);

    HRESULT (STDMETHODCALLTYPE *put_Size)(
        IFont *This,
        CY size);

    HRESULT (STDMETHODCALLTYPE *get_Bold)(
        IFont *This,
        BOOL *pBold);

    HRESULT (STDMETHODCALLTYPE *put_Bold)(
        IFont *This,
        BOOL bold);

    HRESULT (STDMETHODCALLTYPE *get_Italic)(
        IFont *This,
        BOOL *pItalic);

    HRESULT (STDMETHODCALLTYPE *put_Italic)(
        IFont *This,
        BOOL italic);

    HRESULT (STDMETHODCALLTYPE *get_Underline)(
        IFont *This,
        BOOL *pUnderline);

    HRESULT (STDMETHODCALLTYPE *put_Underline)(
        IFont *This,
        BOOL underline);

    HRESULT (STDMETHODCALLTYPE *get_Strikethrough)(
        IFont *This,
        BOOL *pStrikethrough);

    HRESULT (STDMETHODCALLTYPE *put_Strikethrough)(
        IFont *This,
        BOOL strikethrough);

    HRESULT (STDMETHODCALLTYPE *get_Weight)(
        IFont *This,
        SHORT *pWeight);

    HRESULT (STDMETHODCALLTYPE *put_Weight)(
        IFont *This,
        SHORT weight);

    HRESULT (STDMETHODCALLTYPE *get_Charset)(
        IFont *This,
        SHORT *pCharset);

    HRESULT (STDMETHODCALLTYPE *put_Charset)(
        IFont *This,
        SHORT charset);

    HRESULT (STDMETHODCALLTYPE *get_hFont)(
        IFont *This,
        HFONT *phFont);

    HRESULT (STDMETHODCALLTYPE *Clone)(
        IFont *This,
        IFont **ppFont);

    HRESULT (STDMETHODCALLTYPE *IsEqual)(
        IFont *This,
        IFont *pFontOther);

    HRESULT (STDMETHODCALLTYPE *SetRatio)(
        IFont *This,
        LONG cyLogical,
        LONG cyHimetric);

    HRESULT (STDMETHODCALLTYPE *QueryTextMetrics)(
        IFont *This,
        TEXTMETRICOLE *pTM);

    HRESULT (STDMETHODCALLTYPE *AddRefHfont)(
        IFont *This,
        HFONT hFont);

    HRESULT (STDMETHODCALLTYPE *ReleaseHfont)(
        IFont *This,
        HFONT hFont);

    HRESULT (STDMETHODCALLTYPE *SetHdc)(
        IFont *This,
        HDC hDC);

    END_INTERFACE
} IFontVtbl;

interface IFont {
    CONST_VTBL IFontVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IFont_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IFont_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IFont_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IFont methods ***/
#define IFont_get_Name(This,pName) \
    ((This)->lpVtbl->get_Name(This,pName))
#define IFont_put_Name(This,name) \
    ((This)->lpVtbl->put_Name(This,name))
#define IFont_get_Size(This,pSize) \
    ((This)->lpVtbl->get_Size(This,pSize))
#define IFont_put_Size(This,size) \
    ((This)->lpVtbl->put_Size(This,size))
#define IFont_get_Bold(This,pBold) \
    ((This)->lpVtbl->get_Bold(This,pBold))
#define IFont_put_Bold(This,bold) \
    ((This)->lpVtbl->put_Bold(This,bold))
#define IFont_get_Italic(This,pItalic) \
    ((This)->lpVtbl->get_Italic(This,pItalic))
#define IFont_put_Italic(This,italic) \
    ((This)->lpVtbl->put_Italic(This,italic))
#define IFont_get_Underline(This,pUnderline) \
    ((This)->lpVtbl->get_Underline(This,pUnderline))
#define IFont_put_Underline(This,underline) \
    ((This)->lpVtbl->put_Underline(This,underline))
#define IFont_get_Strikethrough(This,pStrikethrough) \
    ((This)->lpVtbl->get_Strikethrough(This,pStrikethrough))
#define IFont_put_Strikethrough(This,strikethrough) \
    ((This)->lpVtbl->put_Strikethrough(This,strikethrough))
#define IFont_get_Weight(This,pWeight) \
    ((This)->lpVtbl->get_Weight(This,pWeight))
#define IFont_put_Weight(This,weight) \
    ((This)->lpVtbl->put_Weight(This,weight))
#define IFont_get_Charset(This,pCharset) \
    ((This)->lpVtbl->get_Charset(This,pCharset))
#define IFont_put_Charset(This,charset) \
    ((This)->lpVtbl->put_Charset(This,charset))
#define IFont_get_hFont(This,phFont) \
    ((This)->lpVtbl->get_hFont(This,phFont))
#define IFont_Clone(This,ppFont) \
    ((This)->lpVtbl->Clone(This,ppFont))
#define IFont_IsEqual(This,pFontOther) \
    ((This)->lpVtbl->IsEqual(This,pFontOther))
#define IFont_SetRatio(This,cyLogical,cyHimetric) \
    ((This)->lpVtbl->SetRatio(This,cyLogical,cyHimetric))
#define IFont_QueryTextMetrics(This,pTM) \
    ((This)->lpVtbl->QueryTextMetrics(This,pTM))
#define IFont_AddRefHfont(This,hFont) \
    ((This)->lpVtbl->AddRefHfont(This,hFont))
#define IFont_ReleaseHfont(This,hFont) \
    ((This)->lpVtbl->ReleaseHfont(This,hFont))
#define IFont_SetHdc(This,hDC) \
    ((This)->lpVtbl->SetHdc(This,hDC))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IFont_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPicture interface
 */
#ifndef __IPicture_INTERFACE_DEFINED__
#define __IPicture_INTERFACE_DEFINED__

typedef IPicture *LPPICTURE;

typedef enum tagPictureAttributes {
    PICTURE_SCALABLE = 0x1,
    PICTURE_TRANSPARENT = 0x2
} PICTUREATTRIBUTES;

typedef UINT OLE_HANDLE;
typedef LONG OLE_XPOS_HIMETRIC;
typedef LONG OLE_YPOS_HIMETRIC;
typedef LONG OLE_XSIZE_HIMETRIC;
typedef LONG OLE_YSIZE_HIMETRIC;

EXTERN_C const IID IID_IPicture;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPictureVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPicture *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPicture *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPicture *This);

    /*** IPicture methods ***/
    HRESULT (STDMETHODCALLTYPE *get_Handle)(
        IPicture *This,
        OLE_HANDLE *pHandle);

    HRESULT (STDMETHODCALLTYPE *get_hPal)(
        IPicture *This,
        OLE_HANDLE *phPal);

    HRESULT (STDMETHODCALLTYPE *get_Type)(
        IPicture *This,
        SHORT *pType);

    HRESULT (STDMETHODCALLTYPE *get_Width)(
        IPicture *This,
        OLE_XSIZE_HIMETRIC *pWidth);

    HRESULT (STDMETHODCALLTYPE *get_Height)(
        IPicture *This,
        OLE_YSIZE_HIMETRIC *pHeight);

    HRESULT (STDMETHODCALLTYPE *Render)(
        IPicture *This,
        HDC hDC,
        LONG x,
        LONG y,
        LONG cx,
        LONG cy,
        OLE_XPOS_HIMETRIC xSrc,
        OLE_YPOS_HIMETRIC ySrc,
        OLE_XSIZE_HIMETRIC cxSrc,
        OLE_YSIZE_HIMETRIC cySrc,
        LPCRECT pRcWBounds);

    HRESULT (STDMETHODCALLTYPE *set_hPal)(
        IPicture *This,
        OLE_HANDLE hPal);

    HRESULT (STDMETHODCALLTYPE *get_CurDC)(
        IPicture *This,
        HDC *phDC);

    HRESULT (STDMETHODCALLTYPE *SelectPicture)(
        IPicture *This,
        HDC hDCIn,
        HDC *phDCOut,
        OLE_HANDLE *phBmpOut);

    HRESULT (STDMETHODCALLTYPE *get_KeepOriginalFormat)(
        IPicture *This,
        BOOL *pKeep);

    HRESULT (STDMETHODCALLTYPE *put_KeepOriginalFormat)(
        IPicture *This,
        BOOL keep);

    HRESULT (STDMETHODCALLTYPE *PictureChanged)(
        IPicture *This);

    HRESULT (STDMETHODCALLTYPE *SaveAsFile)(
        IPicture *This,
        LPSTREAM pStream,
        BOOL fSaveMemCopy,
        LONG *pCbSize);

    HRESULT (STDMETHODCALLTYPE *get_Attributes)(
        IPicture *This,
        DWORD *pDwAttr);

    END_INTERFACE
} IPictureVtbl;

interface IPicture {
    CONST_VTBL IPictureVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPicture_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPicture_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPicture_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPicture methods ***/
#define IPicture_get_Handle(This,pHandle) \
    ((This)->lpVtbl->get_Handle(This,pHandle))
#define IPicture_get_hPal(This,phPal) \
    ((This)->lpVtbl->get_hPal(This,phPal))
#define IPicture_get_Type(This,pType) \
    ((This)->lpVtbl->get_Type(This,pType))
#define IPicture_get_Width(This,pWidth) \
    ((This)->lpVtbl->get_Width(This,pWidth))
#define IPicture_get_Height(This,pHeight) \
    ((This)->lpVtbl->get_Height(This,pHeight))
#define IPicture_Render(This,hDC,x,y,cx,cy,xSrc,ySrc,cxSrc,cySrc,pRcWBounds) \
    ((This)->lpVtbl->Render(This,hDC,x,y,cx,cy,xSrc,ySrc,cxSrc,cySrc,pRcWBounds))
#define IPicture_set_hPal(This,hPal) \
    ((This)->lpVtbl->set_hPal(This,hPal))
#define IPicture_get_CurDC(This,phDC) \
    ((This)->lpVtbl->get_CurDC(This,phDC))
#define IPicture_SelectPicture(This,hDCIn,phDCOut,phBmpOut) \
    ((This)->lpVtbl->SelectPicture(This,hDCIn,phDCOut,phBmpOut))
#define IPicture_get_KeepOriginalFormat(This,pKeep) \
    ((This)->lpVtbl->get_KeepOriginalFormat(This,pKeep))
#define IPicture_put_KeepOriginalFormat(This,keep) \
    ((This)->lpVtbl->put_KeepOriginalFormat(This,keep))
#define IPicture_PictureChanged(This) \
    ((This)->lpVtbl->PictureChanged(This))
#define IPicture_SaveAsFile(This,pStream,fSaveMemCopy,pCbSize) \
    ((This)->lpVtbl->SaveAsFile(This,pStream,fSaveMemCopy,pCbSize))
#define IPicture_get_Attributes(This,pDwAttr) \
    ((This)->lpVtbl->get_Attributes(This,pDwAttr))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPicture_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPicture2 interface
 */
#ifndef __IPicture2_INTERFACE_DEFINED__
#define __IPicture2_INTERFACE_DEFINED__

typedef IPicture2 *LPPICTURE2;

typedef UINT_PTR HHANDLE;

EXTERN_C const IID IID_IPicture2;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPicture2Vtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPicture2 *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPicture2 *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPicture2 *This);

    /*** IPicture2 methods ***/
    HRESULT (STDMETHODCALLTYPE *get_Handle)(
        IPicture2 *This,
        HHANDLE *pHandle);

    HRESULT (STDMETHODCALLTYPE *get_hPal)(
        IPicture2 *This,
        HHANDLE *phPal);

    HRESULT (STDMETHODCALLTYPE *get_Type)(
        IPicture2 *This,
        SHORT *pType);

    HRESULT (STDMETHODCALLTYPE *get_Width)(
        IPicture2 *This,
        OLE_XSIZE_HIMETRIC *pWidth);

    HRESULT (STDMETHODCALLTYPE *get_Height)(
        IPicture2 *This,
        OLE_YSIZE_HIMETRIC *pHeight);

    HRESULT (STDMETHODCALLTYPE *Render)(
        IPicture2 *This,
        HDC hDC,
        LONG x,
        LONG y,
        LONG cx,
        LONG cy,
        OLE_XPOS_HIMETRIC xSrc,
        OLE_YPOS_HIMETRIC ySrc,
        OLE_XSIZE_HIMETRIC cxSrc,
        OLE_YSIZE_HIMETRIC cySrc,
        LPCRECT pRcWBounds);

    HRESULT (STDMETHODCALLTYPE *set_hPal)(
        IPicture2 *This,
        HHANDLE hPal);

    HRESULT (STDMETHODCALLTYPE *get_CurDC)(
        IPicture2 *This,
        HDC *phDC);

    HRESULT (STDMETHODCALLTYPE *SelectPicture)(
        IPicture2 *This,
        HDC hDCIn,
        HDC *phDCOut,
        HHANDLE *phBmpOut);

    HRESULT (STDMETHODCALLTYPE *get_KeepOriginalFormat)(
        IPicture2 *This,
        BOOL *pKeep);

    HRESULT (STDMETHODCALLTYPE *put_KeepOriginalFormat)(
        IPicture2 *This,
        BOOL keep);

    HRESULT (STDMETHODCALLTYPE *PictureChanged)(
        IPicture2 *This);

    HRESULT (STDMETHODCALLTYPE *SaveAsFile)(
        IPicture2 *This,
        LPSTREAM pStream,
        BOOL fSaveMemCopy,
        LONG *pCbSize);

    HRESULT (STDMETHODCALLTYPE *get_Attributes)(
        IPicture2 *This,
        DWORD *pDwAttr);

    END_INTERFACE
} IPicture2Vtbl;

interface IPicture2 {
    CONST_VTBL IPicture2Vtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPicture2_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPicture2_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPicture2_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPicture2 methods ***/
#define IPicture2_get_Handle(This,pHandle) \
    ((This)->lpVtbl->get_Handle(This,pHandle))
#define IPicture2_get_hPal(This,phPal) \
    ((This)->lpVtbl->get_hPal(This,phPal))
#define IPicture2_get_Type(This,pType) \
    ((This)->lpVtbl->get_Type(This,pType))
#define IPicture2_get_Width(This,pWidth) \
    ((This)->lpVtbl->get_Width(This,pWidth))
#define IPicture2_get_Height(This,pHeight) \
    ((This)->lpVtbl->get_Height(This,pHeight))
#define IPicture2_Render(This,hDC,x,y,cx,cy,xSrc,ySrc,cxSrc,cySrc,pRcWBounds) \
    ((This)->lpVtbl->Render(This,hDC,x,y,cx,cy,xSrc,ySrc,cxSrc,cySrc,pRcWBounds))
#define IPicture2_set_hPal(This,hPal) \
    ((This)->lpVtbl->set_hPal(This,hPal))
#define IPicture2_get_CurDC(This,phDC) \
    ((This)->lpVtbl->get_CurDC(This,phDC))
#define IPicture2_SelectPicture(This,hDCIn,phDCOut,phBmpOut) \
    ((This)->lpVtbl->SelectPicture(This,hDCIn,phDCOut,phBmpOut))
#define IPicture2_get_KeepOriginalFormat(This,pKeep) \
    ((This)->lpVtbl->get_KeepOriginalFormat(This,pKeep))
#define IPicture2_put_KeepOriginalFormat(This,keep) \
    ((This)->lpVtbl->put_KeepOriginalFormat(This,keep))
#define IPicture2_PictureChanged(This) \
    ((This)->lpVtbl->PictureChanged(This))
#define IPicture2_SaveAsFile(This,pStream,fSaveMemCopy,pCbSize) \
    ((This)->lpVtbl->SaveAsFile(This,pStream,fSaveMemCopy,pCbSize))
#define IPicture2_get_Attributes(This,pDwAttr) \
    ((This)->lpVtbl->get_Attributes(This,pDwAttr))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPicture2_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IFontEventsDisp interface
 */
#ifndef __IFontEventsDisp_INTERFACE_DEFINED__
#define __IFontEventsDisp_INTERFACE_DEFINED__

typedef IFontEventsDisp *LPFONTEVENTS;

EXTERN_C const IID IID_IFontEventsDisp;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IFontEventsDispVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IFontEventsDisp *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IFontEventsDisp *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IFontEventsDisp *This);

    /*** IDispatch methods ***/
    HRESULT (STDMETHODCALLTYPE *GetTypeInfoCount)(
        IFontEventsDisp *This,
        UINT *pctinfo);

    HRESULT (STDMETHODCALLTYPE *GetTypeInfo)(
        IFontEventsDisp *This,
        UINT iTInfo,
        LCID lcid,
        ITypeInfo **ppTInfo);

    HRESULT (STDMETHODCALLTYPE *GetIDsOfNames)(
        IFontEventsDisp *This,
        REFIID riid,
        LPOLESTR *rgszNames,
        UINT cNames,
        LCID lcid,
        DISPID *rgDispId);

    HRESULT (STDMETHODCALLTYPE *Invoke)(
        IFontEventsDisp *This,
        DISPID dispIdMember,
        REFIID riid,
        LCID lcid,
        WORD wFlags,
        DISPPARAMS *pDispParams,
        VARIANT *pVarResult,
        EXCEPINFO *pExcepInfo,
        UINT *puArgErr);

    END_INTERFACE
} IFontEventsDispVtbl;

interface IFontEventsDisp {
    CONST_VTBL IFontEventsDispVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IFontEventsDisp_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IFontEventsDisp_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IFontEventsDisp_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IDispatch methods ***/
#define IFontEventsDisp_GetTypeInfoCount(This,pctinfo) \
    ((This)->lpVtbl->GetTypeInfoCount(This,pctinfo))
#define IFontEventsDisp_GetTypeInfo(This,iTInfo,lcid,ppTInfo) \
    ((This)->lpVtbl->GetTypeInfo(This,iTInfo,lcid,ppTInfo))
#define IFontEventsDisp_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) \
    ((This)->lpVtbl->GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId))
#define IFontEventsDisp_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) \
    ((This)->lpVtbl->Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IFontEventsDisp_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IFontDisp interface
 */
#ifndef __IFontDisp_INTERFACE_DEFINED__
#define __IFontDisp_INTERFACE_DEFINED__

typedef IFontDisp *LPFONTDISP;

EXTERN_C const IID IID_IFontDisp;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IFontDispVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IFontDisp *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IFontDisp *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IFontDisp *This);

    /*** IDispatch methods ***/
    HRESULT (STDMETHODCALLTYPE *GetTypeInfoCount)(
        IFontDisp *This,
        UINT *pctinfo);

    HRESULT (STDMETHODCALLTYPE *GetTypeInfo)(
        IFontDisp *This,
        UINT iTInfo,
        LCID lcid,
        ITypeInfo **ppTInfo);

    HRESULT (STDMETHODCALLTYPE *GetIDsOfNames)(
        IFontDisp *This,
        REFIID riid,
        LPOLESTR *rgszNames,
        UINT cNames,
        LCID lcid,
        DISPID *rgDispId);

    HRESULT (STDMETHODCALLTYPE *Invoke)(
        IFontDisp *This,
        DISPID dispIdMember,
        REFIID riid,
        LCID lcid,
        WORD wFlags,
        DISPPARAMS *pDispParams,
        VARIANT *pVarResult,
        EXCEPINFO *pExcepInfo,
        UINT *puArgErr);

    END_INTERFACE
} IFontDispVtbl;

interface IFontDisp {
    CONST_VTBL IFontDispVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IFontDisp_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IFontDisp_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IFontDisp_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IDispatch methods ***/
#define IFontDisp_GetTypeInfoCount(This,pctinfo) \
    ((This)->lpVtbl->GetTypeInfoCount(This,pctinfo))
#define IFontDisp_GetTypeInfo(This,iTInfo,lcid,ppTInfo) \
    ((This)->lpVtbl->GetTypeInfo(This,iTInfo,lcid,ppTInfo))
#define IFontDisp_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) \
    ((This)->lpVtbl->GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId))
#define IFontDisp_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) \
    ((This)->lpVtbl->Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IFontDisp_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPictureDisp interface
 */
#ifndef __IPictureDisp_INTERFACE_DEFINED__
#define __IPictureDisp_INTERFACE_DEFINED__

typedef IPictureDisp *LPPICTUREDISP;

EXTERN_C const IID IID_IPictureDisp;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPictureDispVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPictureDisp *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPictureDisp *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPictureDisp *This);

    /*** IDispatch methods ***/
    HRESULT (STDMETHODCALLTYPE *GetTypeInfoCount)(
        IPictureDisp *This,
        UINT *pctinfo);

    HRESULT (STDMETHODCALLTYPE *GetTypeInfo)(
        IPictureDisp *This,
        UINT iTInfo,
        LCID lcid,
        ITypeInfo **ppTInfo);

    HRESULT (STDMETHODCALLTYPE *GetIDsOfNames)(
        IPictureDisp *This,
        REFIID riid,
        LPOLESTR *rgszNames,
        UINT cNames,
        LCID lcid,
        DISPID *rgDispId);

    HRESULT (STDMETHODCALLTYPE *Invoke)(
        IPictureDisp *This,
        DISPID dispIdMember,
        REFIID riid,
        LCID lcid,
        WORD wFlags,
        DISPPARAMS *pDispParams,
        VARIANT *pVarResult,
        EXCEPINFO *pExcepInfo,
        UINT *puArgErr);

    END_INTERFACE
} IPictureDispVtbl;

interface IPictureDisp {
    CONST_VTBL IPictureDispVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPictureDisp_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPictureDisp_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPictureDisp_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IDispatch methods ***/
#define IPictureDisp_GetTypeInfoCount(This,pctinfo) \
    ((This)->lpVtbl->GetTypeInfoCount(This,pctinfo))
#define IPictureDisp_GetTypeInfo(This,iTInfo,lcid,ppTInfo) \
    ((This)->lpVtbl->GetTypeInfo(This,iTInfo,lcid,ppTInfo))
#define IPictureDisp_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) \
    ((This)->lpVtbl->GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId))
#define IPictureDisp_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) \
    ((This)->lpVtbl->Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPictureDisp_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleInPlaceObjectWindowless interface
 */
#ifndef __IOleInPlaceObjectWindowless_INTERFACE_DEFINED__
#define __IOleInPlaceObjectWindowless_INTERFACE_DEFINED__

typedef IOleInPlaceObjectWindowless *LPOLEINPLACEOBJECTWINDOWLESS;

EXTERN_C const IID IID_IOleInPlaceObjectWindowless;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleInPlaceObjectWindowlessVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleInPlaceObjectWindowless *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleInPlaceObjectWindowless *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleInPlaceObjectWindowless *This);

    /*** IOleWindow methods ***/
    HRESULT (STDMETHODCALLTYPE *GetWindow)(
        IOleInPlaceObjectWindowless *This,
        HWND *phwnd);

    HRESULT (STDMETHODCALLTYPE *ContextSensitiveHelp)(
        IOleInPlaceObjectWindowless *This,
        BOOL fEnterMode);

    /*** IOleInPlaceObject methods ***/
    HRESULT (STDMETHODCALLTYPE *InPlaceDeactivate)(
        IOleInPlaceObjectWindowless *This);

    HRESULT (STDMETHODCALLTYPE *UIDeactivate)(
        IOleInPlaceObjectWindowless *This);

    HRESULT (STDMETHODCALLTYPE *SetObjectRects)(
        IOleInPlaceObjectWindowless *This,
        LPCRECT lprcPosRect,
        LPCRECT lprcClipRect);

    HRESULT (STDMETHODCALLTYPE *ReactivateAndUndo)(
        IOleInPlaceObjectWindowless *This);

    /*** IOleInPlaceObjectWindowless methods ***/
    HRESULT (STDMETHODCALLTYPE *OnWindowMessage)(
        IOleInPlaceObjectWindowless *This,
        UINT msg,
        WPARAM wParam,
        LPARAM lParam,
        LRESULT *plResult);

    HRESULT (STDMETHODCALLTYPE *GetDropTarget)(
        IOleInPlaceObjectWindowless *This,
        IDropTarget **ppDropTarget);

    END_INTERFACE
} IOleInPlaceObjectWindowlessVtbl;

interface IOleInPlaceObjectWindowless {
    CONST_VTBL IOleInPlaceObjectWindowlessVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleInPlaceObjectWindowless_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleInPlaceObjectWindowless_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleInPlaceObjectWindowless_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleWindow methods ***/
#define IOleInPlaceObjectWindowless_GetWindow(This,phwnd) \
    ((This)->lpVtbl->GetWindow(This,phwnd))
#define IOleInPlaceObjectWindowless_ContextSensitiveHelp(This,fEnterMode) \
    ((This)->lpVtbl->ContextSensitiveHelp(This,fEnterMode))
/*** IOleInPlaceObject methods ***/
#define IOleInPlaceObjectWindowless_InPlaceDeactivate(This) \
    ((This)->lpVtbl->InPlaceDeactivate(This))
#define IOleInPlaceObjectWindowless_UIDeactivate(This) \
    ((This)->lpVtbl->UIDeactivate(This))
#define IOleInPlaceObjectWindowless_SetObjectRects(This,lprcPosRect,lprcClipRect) \
    ((This)->lpVtbl->SetObjectRects(This,lprcPosRect,lprcClipRect))
#define IOleInPlaceObjectWindowless_ReactivateAndUndo(This) \
    ((This)->lpVtbl->ReactivateAndUndo(This))
/*** IOleInPlaceObjectWindowless methods ***/
#define IOleInPlaceObjectWindowless_OnWindowMessage(This,msg,wParam,lParam,plResult) \
    ((This)->lpVtbl->OnWindowMessage(This,msg,wParam,lParam,plResult))
#define IOleInPlaceObjectWindowless_GetDropTarget(This,ppDropTarget) \
    ((This)->lpVtbl->GetDropTarget(This,ppDropTarget))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleInPlaceObjectWindowless_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleInPlaceSiteEx interface
 */
#ifndef __IOleInPlaceSiteEx_INTERFACE_DEFINED__
#define __IOleInPlaceSiteEx_INTERFACE_DEFINED__

typedef IOleInPlaceSiteEx *LPOLEINPLACESITEEX;

typedef enum tagACTIVATEFLAGS {
    ACTIVATE_WINDOWLESS = 1
} ACTIVATEFLAGS;

EXTERN_C const IID IID_IOleInPlaceSiteEx;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleInPlaceSiteExVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleInPlaceSiteEx *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleInPlaceSiteEx *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleInPlaceSiteEx *This);

    /*** IOleWindow methods ***/
    HRESULT (STDMETHODCALLTYPE *GetWindow)(
        IOleInPlaceSiteEx *This,
        HWND *phwnd);

    HRESULT (STDMETHODCALLTYPE *ContextSensitiveHelp)(
        IOleInPlaceSiteEx *This,
        BOOL fEnterMode);

    /*** IOleInPlaceSite methods ***/
    HRESULT (STDMETHODCALLTYPE *CanInPlaceActivate)(
        IOleInPlaceSiteEx *This);

    HRESULT (STDMETHODCALLTYPE *OnInPlaceActivate)(
        IOleInPlaceSiteEx *This);

    HRESULT (STDMETHODCALLTYPE *OnUIActivate)(
        IOleInPlaceSiteEx *This);

    HRESULT (STDMETHODCALLTYPE *GetWindowContext)(
        IOleInPlaceSiteEx *This,
        IOleInPlaceFrame **ppFrame,
        IOleInPlaceUIWindow **ppDoc,
        LPRECT lprcPosRect,
        LPRECT lprcClipRect,
        LPOLEINPLACEFRAMEINFO lpFrameInfo);

    HRESULT (STDMETHODCALLTYPE *Scroll)(
        IOleInPlaceSiteEx *This,
        SIZE scrollExtant);

    HRESULT (STDMETHODCALLTYPE *OnUIDeactivate)(
        IOleInPlaceSiteEx *This,
        BOOL fUndoable);

    HRESULT (STDMETHODCALLTYPE *OnInPlaceDeactivate)(
        IOleInPlaceSiteEx *This);

    HRESULT (STDMETHODCALLTYPE *DiscardUndoState)(
        IOleInPlaceSiteEx *This);

    HRESULT (STDMETHODCALLTYPE *DeactivateAndUndo)(
        IOleInPlaceSiteEx *This);

    HRESULT (STDMETHODCALLTYPE *OnPosRectChange)(
        IOleInPlaceSiteEx *This,
        LPCRECT lprcPosRect);

    /*** IOleInPlaceSiteEx methods ***/
    HRESULT (STDMETHODCALLTYPE *OnInPlaceActivateEx)(
        IOleInPlaceSiteEx *This,
        BOOL *pfNoRedraw,
        DWORD dwFlags);

    HRESULT (STDMETHODCALLTYPE *OnInPlaceDeactivateEx)(
        IOleInPlaceSiteEx *This,
        BOOL fNoRedraw);

    HRESULT (STDMETHODCALLTYPE *RequestUIActivate)(
        IOleInPlaceSiteEx *This);

    END_INTERFACE
} IOleInPlaceSiteExVtbl;

interface IOleInPlaceSiteEx {
    CONST_VTBL IOleInPlaceSiteExVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleInPlaceSiteEx_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleInPlaceSiteEx_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleInPlaceSiteEx_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleWindow methods ***/
#define IOleInPlaceSiteEx_GetWindow(This,phwnd) \
    ((This)->lpVtbl->GetWindow(This,phwnd))
#define IOleInPlaceSiteEx_ContextSensitiveHelp(This,fEnterMode) \
    ((This)->lpVtbl->ContextSensitiveHelp(This,fEnterMode))
/*** IOleInPlaceSite methods ***/
#define IOleInPlaceSiteEx_CanInPlaceActivate(This) \
    ((This)->lpVtbl->CanInPlaceActivate(This))
#define IOleInPlaceSiteEx_OnInPlaceActivate(This) \
    ((This)->lpVtbl->OnInPlaceActivate(This))
#define IOleInPlaceSiteEx_OnUIActivate(This) \
    ((This)->lpVtbl->OnUIActivate(This))
#define IOleInPlaceSiteEx_GetWindowContext(This,ppFrame,ppDoc,lprcPosRect,lprcClipRect,lpFrameInfo) \
    ((This)->lpVtbl->GetWindowContext(This,ppFrame,ppDoc,lprcPosRect,lprcClipRect,lpFrameInfo))
#define IOleInPlaceSiteEx_Scroll(This,scrollExtant) \
    ((This)->lpVtbl->Scroll(This,scrollExtant))
#define IOleInPlaceSiteEx_OnUIDeactivate(This,fUndoable) \
    ((This)->lpVtbl->OnUIDeactivate(This,fUndoable))
#define IOleInPlaceSiteEx_OnInPlaceDeactivate(This) \
    ((This)->lpVtbl->OnInPlaceDeactivate(This))
#define IOleInPlaceSiteEx_DiscardUndoState(This) \
    ((This)->lpVtbl->DiscardUndoState(This))
#define IOleInPlaceSiteEx_DeactivateAndUndo(This) \
    ((This)->lpVtbl->DeactivateAndUndo(This))
#define IOleInPlaceSiteEx_OnPosRectChange(This,lprcPosRect) \
    ((This)->lpVtbl->OnPosRectChange(This,lprcPosRect))
/*** IOleInPlaceSiteEx methods ***/
#define IOleInPlaceSiteEx_OnInPlaceActivateEx(This,pfNoRedraw,dwFlags) \
    ((This)->lpVtbl->OnInPlaceActivateEx(This,pfNoRedraw,dwFlags))
#define IOleInPlaceSiteEx_OnInPlaceDeactivateEx(This,fNoRedraw) \
    ((This)->lpVtbl->OnInPlaceDeactivateEx(This,fNoRedraw))
#define IOleInPlaceSiteEx_RequestUIActivate(This) \
    ((This)->lpVtbl->RequestUIActivate(This))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleInPlaceSiteEx_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleInPlaceSiteWindowless interface
 */
#ifndef __IOleInPlaceSiteWindowless_INTERFACE_DEFINED__
#define __IOleInPlaceSiteWindowless_INTERFACE_DEFINED__

typedef IOleInPlaceSiteWindowless *LPOLEINPLACESITEWINDOWLESS;

typedef enum tagOLEDCFLAGS {
    OLEDC_NODRAW = 0x1,
    OLEDC_PAINTBKGND = 0x2,
    OLEDC_OFFSCREEN = 0x4
} OLEDCFLAGS;

EXTERN_C const IID IID_IOleInPlaceSiteWindowless;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleInPlaceSiteWindowlessVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleInPlaceSiteWindowless *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleInPlaceSiteWindowless *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleInPlaceSiteWindowless *This);

    /*** IOleWindow methods ***/
    HRESULT (STDMETHODCALLTYPE *GetWindow)(
        IOleInPlaceSiteWindowless *This,
        HWND *phwnd);

    HRESULT (STDMETHODCALLTYPE *ContextSensitiveHelp)(
        IOleInPlaceSiteWindowless *This,
        BOOL fEnterMode);

    /*** IOleInPlaceSite methods ***/
    HRESULT (STDMETHODCALLTYPE *CanInPlaceActivate)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *OnInPlaceActivate)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *OnUIActivate)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *GetWindowContext)(
        IOleInPlaceSiteWindowless *This,
        IOleInPlaceFrame **ppFrame,
        IOleInPlaceUIWindow **ppDoc,
        LPRECT lprcPosRect,
        LPRECT lprcClipRect,
        LPOLEINPLACEFRAMEINFO lpFrameInfo);

    HRESULT (STDMETHODCALLTYPE *Scroll)(
        IOleInPlaceSiteWindowless *This,
        SIZE scrollExtant);

    HRESULT (STDMETHODCALLTYPE *OnUIDeactivate)(
        IOleInPlaceSiteWindowless *This,
        BOOL fUndoable);

    HRESULT (STDMETHODCALLTYPE *OnInPlaceDeactivate)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *DiscardUndoState)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *DeactivateAndUndo)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *OnPosRectChange)(
        IOleInPlaceSiteWindowless *This,
        LPCRECT lprcPosRect);

    /*** IOleInPlaceSiteEx methods ***/
    HRESULT (STDMETHODCALLTYPE *OnInPlaceActivateEx)(
        IOleInPlaceSiteWindowless *This,
        BOOL *pfNoRedraw,
        DWORD dwFlags);

    HRESULT (STDMETHODCALLTYPE *OnInPlaceDeactivateEx)(
        IOleInPlaceSiteWindowless *This,
        BOOL fNoRedraw);

    HRESULT (STDMETHODCALLTYPE *RequestUIActivate)(
        IOleInPlaceSiteWindowless *This);

    /*** IOleInPlaceSiteWindowless methods ***/
    HRESULT (STDMETHODCALLTYPE *CanWindowlessActivate)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *GetCapture)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *SetCapture)(
        IOleInPlaceSiteWindowless *This,
        BOOL fCapture);

    HRESULT (STDMETHODCALLTYPE *GetFocus)(
        IOleInPlaceSiteWindowless *This);

    HRESULT (STDMETHODCALLTYPE *SetFocus)(
        IOleInPlaceSiteWindowless *This,
        BOOL fFocus);

    HRESULT (STDMETHODCALLTYPE *GetDC)(
        IOleInPlaceSiteWindowless *This,
        LPCRECT pRect,
        DWORD grfFlags,
        HDC *phDC);

    HRESULT (STDMETHODCALLTYPE *ReleaseDC)(
        IOleInPlaceSiteWindowless *This,
        HDC hDC);

    HRESULT (STDMETHODCALLTYPE *InvalidateRect)(
        IOleInPlaceSiteWindowless *This,
        LPCRECT pRect,
        BOOL fErase);

    HRESULT (STDMETHODCALLTYPE *InvalidateRgn)(
        IOleInPlaceSiteWindowless *This,
        HRGN hRGN,
        BOOL fErase);

    HRESULT (STDMETHODCALLTYPE *ScrollRect)(
        IOleInPlaceSiteWindowless *This,
        INT dx,
        INT dy,
        LPCRECT pRectScroll,
        LPCRECT pRectClip);

    HRESULT (STDMETHODCALLTYPE *AdjustRect)(
        IOleInPlaceSiteWindowless *This,
        LPRECT prc);

    HRESULT (STDMETHODCALLTYPE *OnDefWindowMessage)(
        IOleInPlaceSiteWindowless *This,
        UINT msg,
        WPARAM wParam,
        LPARAM lParam,
        LRESULT *plResult);

    END_INTERFACE
} IOleInPlaceSiteWindowlessVtbl;

interface IOleInPlaceSiteWindowless {
    CONST_VTBL IOleInPlaceSiteWindowlessVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleInPlaceSiteWindowless_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleInPlaceSiteWindowless_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleInPlaceSiteWindowless_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleWindow methods ***/
#define IOleInPlaceSiteWindowless_GetWindow(This,phwnd) \
    ((This)->lpVtbl->GetWindow(This,phwnd))
#define IOleInPlaceSiteWindowless_ContextSensitiveHelp(This,fEnterMode) \
    ((This)->lpVtbl->ContextSensitiveHelp(This,fEnterMode))
/*** IOleInPlaceSite methods ***/
#define IOleInPlaceSiteWindowless_CanInPlaceActivate(This) \
    ((This)->lpVtbl->CanInPlaceActivate(This))
#define IOleInPlaceSiteWindowless_OnInPlaceActivate(This) \
    ((This)->lpVtbl->OnInPlaceActivate(This))
#define IOleInPlaceSiteWindowless_OnUIActivate(This) \
    ((This)->lpVtbl->OnUIActivate(This))
#define IOleInPlaceSiteWindowless_GetWindowContext(This,ppFrame,ppDoc,lprcPosRect,lprcClipRect,lpFrameInfo) \
    ((This)->lpVtbl->GetWindowContext(This,ppFrame,ppDoc,lprcPosRect,lprcClipRect,lpFrameInfo))
#define IOleInPlaceSiteWindowless_Scroll(This,scrollExtant) \
    ((This)->lpVtbl->Scroll(This,scrollExtant))
#define IOleInPlaceSiteWindowless_OnUIDeactivate(This,fUndoable) \
    ((This)->lpVtbl->OnUIDeactivate(This,fUndoable))
#define IOleInPlaceSiteWindowless_OnInPlaceDeactivate(This) \
    ((This)->lpVtbl->OnInPlaceDeactivate(This))
#define IOleInPlaceSiteWindowless_DiscardUndoState(This) \
    ((This)->lpVtbl->DiscardUndoState(This))
#define IOleInPlaceSiteWindowless_DeactivateAndUndo(This) \
    ((This)->lpVtbl->DeactivateAndUndo(This))
#define IOleInPlaceSiteWindowless_OnPosRectChange(This,lprcPosRect) \
    ((This)->lpVtbl->OnPosRectChange(This,lprcPosRect))
/*** IOleInPlaceSiteEx methods ***/
#define IOleInPlaceSiteWindowless_OnInPlaceActivateEx(This,pfNoRedraw,dwFlags) \
    ((This)->lpVtbl->OnInPlaceActivateEx(This,pfNoRedraw,dwFlags))
#define IOleInPlaceSiteWindowless_OnInPlaceDeactivateEx(This,fNoRedraw) \
    ((This)->lpVtbl->OnInPlaceDeactivateEx(This,fNoRedraw))
#define IOleInPlaceSiteWindowless_RequestUIActivate(This) \
    ((This)->lpVtbl->RequestUIActivate(This))
/*** IOleInPlaceSiteWindowless methods ***/
#define IOleInPlaceSiteWindowless_CanWindowlessActivate(This) \
    ((This)->lpVtbl->CanWindowlessActivate(This))
#define IOleInPlaceSiteWindowless_GetCapture(This) \
    ((This)->lpVtbl->GetCapture(This))
#define IOleInPlaceSiteWindowless_SetCapture(This,fCapture) \
    ((This)->lpVtbl->SetCapture(This,fCapture))
#define IOleInPlaceSiteWindowless_GetFocus(This) \
    ((This)->lpVtbl->GetFocus(This))
#define IOleInPlaceSiteWindowless_SetFocus(This,fFocus) \
    ((This)->lpVtbl->SetFocus(This,fFocus))
#define IOleInPlaceSiteWindowless_GetDC(This,pRect,grfFlags,phDC) \
    ((This)->lpVtbl->GetDC(This,pRect,grfFlags,phDC))
#define IOleInPlaceSiteWindowless_ReleaseDC(This,hDC) \
    ((This)->lpVtbl->ReleaseDC(This,hDC))
#define IOleInPlaceSiteWindowless_InvalidateRect(This,pRect,fErase) \
    ((This)->lpVtbl->InvalidateRect(This,pRect,fErase))
#define IOleInPlaceSiteWindowless_InvalidateRgn(This,hRGN,fErase) \
    ((This)->lpVtbl->InvalidateRgn(This,hRGN,fErase))
#define IOleInPlaceSiteWindowless_ScrollRect(This,dx,dy,pRectScroll,pRectClip) \
    ((This)->lpVtbl->ScrollRect(This,dx,dy,pRectScroll,pRectClip))
#define IOleInPlaceSiteWindowless_AdjustRect(This,prc) \
    ((This)->lpVtbl->AdjustRect(This,prc))
#define IOleInPlaceSiteWindowless_OnDefWindowMessage(This,msg,wParam,lParam,plResult) \
    ((This)->lpVtbl->OnDefWindowMessage(This,msg,wParam,lParam,plResult))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleInPlaceSiteWindowless_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IViewObjectEx interface
 */
#ifndef __IViewObjectEx_INTERFACE_DEFINED__
#define __IViewObjectEx_INTERFACE_DEFINED__

typedef IViewObjectEx *LPVIEWOBJECTEX;

typedef enum tagVIEWSTATUS {
    VIEWSTATUS_OPAQUE = 1,
    VIEWSTATUS_SOLIDBKGND = 2,
    VIEWSTATUS_DVASPECTOPAQUE = 4,
    VIEWSTATUS_DVASPECTTRANSPARENT = 8,
    VIEWSTATUS_SURFACE = 16,
    VIEWSTATUS_3DSURFACE = 32
} VIEWSTATUS;

typedef enum tagHITRESULT {
    HITRESULT_OUTSIDE = 0,
    HITRESULT_TRANSPARENT = 1,
    HITRESULT_CLOSE = 2,
    HITRESULT_HIT = 3
} HITRESULT;

typedef enum tagDVASPECT2 {
    DVASPECT_OPAQUE = 16,
    DVASPECT_TRANSPARENT = 32
} DVASPECT2;

typedef struct tagExtentInfo {
    ULONG cb;
    DWORD dwExtentMode;
    SIZEL sizelProposed;
} DVEXTENTINFO;

typedef enum tagExtentMode {
    DVEXTENT_CONTENT = 0,
    DVEXTENT_INTEGRAL = 1
} DVEXTENTMODE;

typedef enum tagAspectInfoFlag {
    DVASPECTINFOFLAG_CANOPTIMIZE = 1
} DVASPECTINFOFLAG;

typedef struct tagAspectInfo {
    ULONG cb;
    DWORD dwFlags;
} DVASPECTINFO;

EXTERN_C const IID IID_IViewObjectEx;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IViewObjectExVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IViewObjectEx *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IViewObjectEx *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IViewObjectEx *This);

    /*** IViewObject methods ***/
    HRESULT (STDMETHODCALLTYPE *Draw)(
        IViewObjectEx *This,
        DWORD dwDrawAspect,
        LONG lindex,
        void *pvAspect,
        DVTARGETDEVICE *ptd,
        HDC hdcTargetDev,
        HDC hdcDraw,
        LPCRECTL lprcBounds,
        LPCRECTL lprcWBounds,
        BOOL (*pfnContinue)(
            ULONG_PTR dwContinue),
        ULONG_PTR dwContinue);

    HRESULT (STDMETHODCALLTYPE *GetColorSet)(
        IViewObjectEx *This,
        DWORD dwDrawAspect,
        LONG lindex,
        void *pvAspect,
        DVTARGETDEVICE *ptd,
        HDC hicTargetDev,
        LOGPALETTE **ppColorSet);

    HRESULT (STDMETHODCALLTYPE *Freeze)(
        IViewObjectEx *This,
        DWORD dwDrawAspect,
        LONG lindex,
        void *pvAspect,
        DWORD *pdwFreeze);

    HRESULT (STDMETHODCALLTYPE *Unfreeze)(
        IViewObjectEx *This,
        DWORD dwFreeze);

    HRESULT (STDMETHODCALLTYPE *SetAdvise)(
        IViewObjectEx *This,
        DWORD aspects,
        DWORD advf,
        IAdviseSink *pAdvSink);

    HRESULT (STDMETHODCALLTYPE *GetAdvise)(
        IViewObjectEx *This,
        DWORD *pAspects,
        DWORD *pAdvf,
        IAdviseSink **ppAdvSink);

    /*** IViewObject2 methods ***/
    HRESULT (STDMETHODCALLTYPE *GetExtent)(
        IViewObjectEx *This,
        DWORD dwDrawAspect,
        LONG lindex,
        DVTARGETDEVICE *ptd,
        LPSIZEL lpsizel);

    /*** IViewObjectEx methods ***/
    HRESULT (STDMETHODCALLTYPE *GetRect)(
        IViewObjectEx *This,
        DWORD dwAspect,
        LPRECTL pRect);

    HRESULT (STDMETHODCALLTYPE *GetViewStatus)(
        IViewObjectEx *This,
        DWORD *pdwStatus);

    HRESULT (STDMETHODCALLTYPE *QueryHitPoint)(
        IViewObjectEx *This,
        DWORD dwAspect,
        LPCRECT pRectBounds,
        POINT ptlLoc,
        LONG lCloseHint,
        DWORD *pHitResult);

    HRESULT (STDMETHODCALLTYPE *QueryHitRect)(
        IViewObjectEx *This,
        DWORD dwAspect,
        LPCRECT pRectBounds,
        LPCRECT pRectLoc,
        LONG lCloseHint,
        DWORD *pHitResult);

    HRESULT (STDMETHODCALLTYPE *GetNaturalExtent)(
        IViewObjectEx *This,
        DWORD dwAspect,
        LONG lindex,
        DVTARGETDEVICE *ptd,
        HDC hicTargetDev,
        DVEXTENTINFO *pExtentInfo,
        LPSIZEL pSizel);

    END_INTERFACE
} IViewObjectExVtbl;

interface IViewObjectEx {
    CONST_VTBL IViewObjectExVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IViewObjectEx_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IViewObjectEx_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IViewObjectEx_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IViewObject methods ***/
#define IViewObjectEx_Draw(This,dwDrawAspect,lindex,pvAspect,ptd,hdcTargetDev,hdcDraw,lprcBounds,lprcWBounds,pfnContinue,dwContinue) \
    ((This)->lpVtbl->Draw(This,dwDrawAspect,lindex,pvAspect,ptd,hdcTargetDev,hdcDraw,lprcBounds,lprcWBounds,pfnContinue,dwContinue))
#define IViewObjectEx_GetColorSet(This,dwDrawAspect,lindex,pvAspect,ptd,hicTargetDev,ppColorSet) \
    ((This)->lpVtbl->GetColorSet(This,dwDrawAspect,lindex,pvAspect,ptd,hicTargetDev,ppColorSet))
#define IViewObjectEx_Freeze(This,dwDrawAspect,lindex,pvAspect,pdwFreeze) \
    ((This)->lpVtbl->Freeze(This,dwDrawAspect,lindex,pvAspect,pdwFreeze))
#define IViewObjectEx_Unfreeze(This,dwFreeze) \
    ((This)->lpVtbl->Unfreeze(This,dwFreeze))
#define IViewObjectEx_SetAdvise(This,aspects,advf,pAdvSink) \
    ((This)->lpVtbl->SetAdvise(This,aspects,advf,pAdvSink))
#define IViewObjectEx_GetAdvise(This,pAspects,pAdvf,ppAdvSink) \
    ((This)->lpVtbl->GetAdvise(This,pAspects,pAdvf,ppAdvSink))
/*** IViewObject2 methods ***/
#define IViewObjectEx_GetExtent(This,dwDrawAspect,lindex,ptd,lpsizel) \
    ((This)->lpVtbl->GetExtent(This,dwDrawAspect,lindex,ptd,lpsizel))
/*** IViewObjectEx methods ***/
#define IViewObjectEx_GetRect(This,dwAspect,pRect) \
    ((This)->lpVtbl->GetRect(This,dwAspect,pRect))
#define IViewObjectEx_GetViewStatus(This,pdwStatus) \
    ((This)->lpVtbl->GetViewStatus(This,pdwStatus))
#define IViewObjectEx_QueryHitPoint(This,dwAspect,pRectBounds,ptlLoc,lCloseHint,pHitResult) \
    ((This)->lpVtbl->QueryHitPoint(This,dwAspect,pRectBounds,ptlLoc,lCloseHint,pHitResult))
#define IViewObjectEx_QueryHitRect(This,dwAspect,pRectBounds,pRectLoc,lCloseHint,pHitResult) \
    ((This)->lpVtbl->QueryHitRect(This,dwAspect,pRectBounds,pRectLoc,lCloseHint,pHitResult))
#define IViewObjectEx_GetNaturalExtent(This,dwAspect,lindex,ptd,hicTargetDev,pExtentInfo,pSizel) \
    ((This)->lpVtbl->GetNaturalExtent(This,dwAspect,lindex,ptd,hicTargetDev,pExtentInfo,pSizel))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IViewObjectEx_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleUndoUnit interface
 */
#ifndef __IOleUndoUnit_INTERFACE_DEFINED__
#define __IOleUndoUnit_INTERFACE_DEFINED__

typedef IOleUndoUnit *LPOLEUNDOUNIT;

EXTERN_C const IID IID_IOleUndoUnit;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleUndoUnitVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleUndoUnit *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleUndoUnit *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleUndoUnit *This);

    /*** IOleUndoUnit methods ***/
    HRESULT (STDMETHODCALLTYPE *Do)(
        IOleUndoUnit *This,
        IOleUndoManager *pUndoManager);

    HRESULT (STDMETHODCALLTYPE *GetDescription)(
        IOleUndoUnit *This,
        BSTR *pBstr);

    HRESULT (STDMETHODCALLTYPE *GetUnitType)(
        IOleUndoUnit *This,
        CLSID *pClsid,
        LONG *plID);

    HRESULT (STDMETHODCALLTYPE *OnNextAdd)(
        IOleUndoUnit *This);

    END_INTERFACE
} IOleUndoUnitVtbl;

interface IOleUndoUnit {
    CONST_VTBL IOleUndoUnitVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleUndoUnit_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleUndoUnit_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleUndoUnit_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleUndoUnit methods ***/
#define IOleUndoUnit_Do(This,pUndoManager) \
    ((This)->lpVtbl->Do(This,pUndoManager))
#define IOleUndoUnit_GetDescription(This,pBstr) \
    ((This)->lpVtbl->GetDescription(This,pBstr))
#define IOleUndoUnit_GetUnitType(This,pClsid,plID) \
    ((This)->lpVtbl->GetUnitType(This,pClsid,plID))
#define IOleUndoUnit_OnNextAdd(This) \
    ((This)->lpVtbl->OnNextAdd(This))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleUndoUnit_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleParentUndoUnit interface
 */
#ifndef __IOleParentUndoUnit_INTERFACE_DEFINED__
#define __IOleParentUndoUnit_INTERFACE_DEFINED__

typedef IOleParentUndoUnit *LPOLEPARENTUNDOUNIT;

EXTERN_C const IID IID_IOleParentUndoUnit;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleParentUndoUnitVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleParentUndoUnit *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleParentUndoUnit *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleParentUndoUnit *This);

    /*** IOleUndoUnit methods ***/
    HRESULT (STDMETHODCALLTYPE *Do)(
        IOleParentUndoUnit *This,
        IOleUndoManager *pUndoManager);

    HRESULT (STDMETHODCALLTYPE *GetDescription)(
        IOleParentUndoUnit *This,
        BSTR *pBstr);

    HRESULT (STDMETHODCALLTYPE *GetUnitType)(
        IOleParentUndoUnit *This,
        CLSID *pClsid,
        LONG *plID);

    HRESULT (STDMETHODCALLTYPE *OnNextAdd)(
        IOleParentUndoUnit *This);

    /*** IOleParentUndoUnit methods ***/
    HRESULT (STDMETHODCALLTYPE *Open)(
        IOleParentUndoUnit *This,
        IOleParentUndoUnit *pPUU);

    HRESULT (STDMETHODCALLTYPE *Close)(
        IOleParentUndoUnit *This,
        IOleParentUndoUnit *pPUU,
        BOOL fCommit);

    HRESULT (STDMETHODCALLTYPE *Add)(
        IOleParentUndoUnit *This,
        IOleUndoUnit *pUU);

    HRESULT (STDMETHODCALLTYPE *FindUnit)(
        IOleParentUndoUnit *This,
        IOleUndoUnit *pUU);

    HRESULT (STDMETHODCALLTYPE *GetParentState)(
        IOleParentUndoUnit *This,
        DWORD *pdwState);

    END_INTERFACE
} IOleParentUndoUnitVtbl;

interface IOleParentUndoUnit {
    CONST_VTBL IOleParentUndoUnitVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleParentUndoUnit_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleParentUndoUnit_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleParentUndoUnit_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleUndoUnit methods ***/
#define IOleParentUndoUnit_Do(This,pUndoManager) \
    ((This)->lpVtbl->Do(This,pUndoManager))
#define IOleParentUndoUnit_GetDescription(This,pBstr) \
    ((This)->lpVtbl->GetDescription(This,pBstr))
#define IOleParentUndoUnit_GetUnitType(This,pClsid,plID) \
    ((This)->lpVtbl->GetUnitType(This,pClsid,plID))
#define IOleParentUndoUnit_OnNextAdd(This) \
    ((This)->lpVtbl->OnNextAdd(This))
/*** IOleParentUndoUnit methods ***/
#define IOleParentUndoUnit_Open(This,pPUU) \
    ((This)->lpVtbl->Open(This,pPUU))
#define IOleParentUndoUnit_Close(This,pPUU,fCommit) \
    ((This)->lpVtbl->Close(This,pPUU,fCommit))
#define IOleParentUndoUnit_Add(This,pUU) \
    ((This)->lpVtbl->Add(This,pUU))
#define IOleParentUndoUnit_FindUnit(This,pUU) \
    ((This)->lpVtbl->FindUnit(This,pUU))
#define IOleParentUndoUnit_GetParentState(This,pdwState) \
    ((This)->lpVtbl->GetParentState(This,pdwState))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleParentUndoUnit_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IEnumOleUndoUnits interface
 */
#ifndef __IEnumOleUndoUnits_INTERFACE_DEFINED__
#define __IEnumOleUndoUnits_INTERFACE_DEFINED__

typedef IEnumOleUndoUnits *LPENUMOLEUNDOUNITS;

EXTERN_C const IID IID_IEnumOleUndoUnits;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IEnumOleUndoUnitsVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IEnumOleUndoUnits *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IEnumOleUndoUnits *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IEnumOleUndoUnits *This);

    /*** IEnumOleUndoUnits methods ***/
    HRESULT (STDMETHODCALLTYPE *Next)(
        IEnumOleUndoUnits *This,
        ULONG cElt,
        IOleUndoUnit **rgElt,
        ULONG *pcEltFetched);

    HRESULT (STDMETHODCALLTYPE *Skip)(
        IEnumOleUndoUnits *This,
        ULONG cElt);

    HRESULT (STDMETHODCALLTYPE *Reset)(
        IEnumOleUndoUnits *This);

    HRESULT (STDMETHODCALLTYPE *Clone)(
        IEnumOleUndoUnits *This,
        IEnumOleUndoUnits **ppEnum);

    END_INTERFACE
} IEnumOleUndoUnitsVtbl;

interface IEnumOleUndoUnits {
    CONST_VTBL IEnumOleUndoUnitsVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IEnumOleUndoUnits_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IEnumOleUndoUnits_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IEnumOleUndoUnits_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IEnumOleUndoUnits methods ***/
#define IEnumOleUndoUnits_Next(This,cElt,rgElt,pcEltFetched) \
    ((This)->lpVtbl->Next(This,cElt,rgElt,pcEltFetched))
#define IEnumOleUndoUnits_Skip(This,cElt) \
    ((This)->lpVtbl->Skip(This,cElt))
#define IEnumOleUndoUnits_Reset(This) \
    ((This)->lpVtbl->Reset(This))
#define IEnumOleUndoUnits_Clone(This,ppEnum) \
    ((This)->lpVtbl->Clone(This,ppEnum))
#endif /* COBJMACROS */

#endif /* C */

HRESULT STDMETHODCALLTYPE IEnumOleUndoUnits_RemoteNext_Proxy(
    IEnumOleUndoUnits *This,
    ULONG cElt,
    IOleUndoUnit **rgElt,
    ULONG *pcEltFetched);

void __RPC_STUB IEnumOleUndoUnits_RemoteNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

HRESULT IEnumOleUndoUnits_Next_Proxy(
    ULONG cElt,
    IOleUndoUnit **rgElt,
    ULONG *pcEltFetched);
HRESULT IEnumOleUndoUnits_Next_Stub(
    ULONG cElt,
    IOleUndoUnit **rgElt,
    ULONG *pcEltFetched);
#endif /* __IEnumOleUndoUnits_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IOleUndoManager interface
 */
#ifndef __IOleUndoManager_INTERFACE_DEFINED__
#define __IOleUndoManager_INTERFACE_DEFINED__

#define SID_SOleUndoManager IID_IOleUndoManager

typedef IOleUndoManager *LPOLEUNDOMANAGER;

EXTERN_C const IID IID_IOleUndoManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IOleUndoManagerVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IOleUndoManager *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IOleUndoManager *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IOleUndoManager *This);

    /*** IOleUndoManager methods ***/
    HRESULT (STDMETHODCALLTYPE *Open)(
        IOleUndoManager *This,
        IOleParentUndoUnit *pPUU);

    HRESULT (STDMETHODCALLTYPE *Close)(
        IOleUndoManager *This,
        IOleParentUndoUnit *pPUU,
        BOOL fCommit);

    HRESULT (STDMETHODCALLTYPE *Add)(
        IOleUndoManager *This,
        IOleUndoUnit *pUU);

    HRESULT (STDMETHODCALLTYPE *GetOpenParentState)(
        IOleUndoManager *This,
        DWORD *pdwState);

    HRESULT (STDMETHODCALLTYPE *DiscardFrom)(
        IOleUndoManager *This,
        IOleUndoUnit *pUU);

    HRESULT (STDMETHODCALLTYPE *UndoTo)(
        IOleUndoManager *This,
        IOleUndoUnit *pUU);

    HRESULT (STDMETHODCALLTYPE *RedoTo)(
        IOleUndoManager *This,
        IOleUndoUnit *pUU);

    HRESULT (STDMETHODCALLTYPE *EnumUndoable)(
        IOleUndoManager *This,
        IEnumOleUndoUnits **ppEnum);

    HRESULT (STDMETHODCALLTYPE *EnumRedoable)(
        IOleUndoManager *This,
        IEnumOleUndoUnits **ppEnum);

    HRESULT (STDMETHODCALLTYPE *GetLastUndoDescription)(
        IOleUndoManager *This,
        BSTR *pBstr);

    HRESULT (STDMETHODCALLTYPE *GetLastRedoDescription)(
        IOleUndoManager *This,
        BSTR *pBstr);

    HRESULT (STDMETHODCALLTYPE *Enable)(
        IOleUndoManager *This,
        BOOL fEnable);

    END_INTERFACE
} IOleUndoManagerVtbl;

interface IOleUndoManager {
    CONST_VTBL IOleUndoManagerVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IOleUndoManager_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IOleUndoManager_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IOleUndoManager_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IOleUndoManager methods ***/
#define IOleUndoManager_Open(This,pPUU) \
    ((This)->lpVtbl->Open(This,pPUU))
#define IOleUndoManager_Close(This,pPUU,fCommit) \
    ((This)->lpVtbl->Close(This,pPUU,fCommit))
#define IOleUndoManager_Add(This,pUU) \
    ((This)->lpVtbl->Add(This,pUU))
#define IOleUndoManager_GetOpenParentState(This,pdwState) \
    ((This)->lpVtbl->GetOpenParentState(This,pdwState))
#define IOleUndoManager_DiscardFrom(This,pUU) \
    ((This)->lpVtbl->DiscardFrom(This,pUU))
#define IOleUndoManager_UndoTo(This,pUU) \
    ((This)->lpVtbl->UndoTo(This,pUU))
#define IOleUndoManager_RedoTo(This,pUU) \
    ((This)->lpVtbl->RedoTo(This,pUU))
#define IOleUndoManager_EnumUndoable(This,ppEnum) \
    ((This)->lpVtbl->EnumUndoable(This,ppEnum))
#define IOleUndoManager_EnumRedoable(This,ppEnum) \
    ((This)->lpVtbl->EnumRedoable(This,ppEnum))
#define IOleUndoManager_GetLastUndoDescription(This,pBstr) \
    ((This)->lpVtbl->GetLastUndoDescription(This,pBstr))
#define IOleUndoManager_GetLastRedoDescription(This,pBstr) \
    ((This)->lpVtbl->GetLastRedoDescription(This,pBstr))
#define IOleUndoManager_Enable(This,fEnable) \
    ((This)->lpVtbl->Enable(This,fEnable))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IOleUndoManager_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IPointerInactive interface
 */
#ifndef __IPointerInactive_INTERFACE_DEFINED__
#define __IPointerInactive_INTERFACE_DEFINED__

typedef IPointerInactive *LPPOINTERINACTIVE;

typedef enum tagPOINTERINACTIVE {
    POINTERINACTIVE_ACTIVATEONENTRY = 1,
    POINTERINACTIVE_DEACTIVATEONLEAVE = 2,
    POINTERINACTIVE_ACTIVATEONDRAG = 4
} POINTERINACTIVE;

EXTERN_C const IID IID_IPointerInactive;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPointerInactiveVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPointerInactive *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPointerInactive *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPointerInactive *This);

    /*** IPointerInactive methods ***/
    HRESULT (STDMETHODCALLTYPE *GetActivationPolicy)(
        IPointerInactive *This,
        DWORD *pdwPolicy);

    HRESULT (STDMETHODCALLTYPE *OnInactiveMouseMove)(
        IPointerInactive *This,
        LPCRECT pRectBounds,
        LONG x,
        LONG y,
        DWORD grfKeyState);

    HRESULT (STDMETHODCALLTYPE *OnInactiveSetCursor)(
        IPointerInactive *This,
        LPCRECT pRectBounds,
        LONG x,
        LONG y,
        DWORD dwMouseMsg,
        BOOL fSetAlways);

    END_INTERFACE
} IPointerInactiveVtbl;

interface IPointerInactive {
    CONST_VTBL IPointerInactiveVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPointerInactive_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPointerInactive_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPointerInactive_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPointerInactive methods ***/
#define IPointerInactive_GetActivationPolicy(This,pdwPolicy) \
    ((This)->lpVtbl->GetActivationPolicy(This,pdwPolicy))
#define IPointerInactive_OnInactiveMouseMove(This,pRectBounds,x,y,grfKeyState) \
    ((This)->lpVtbl->OnInactiveMouseMove(This,pRectBounds,x,y,grfKeyState))
#define IPointerInactive_OnInactiveSetCursor(This,pRectBounds,x,y,dwMouseMsg,fSetAlways) \
    ((This)->lpVtbl->OnInactiveSetCursor(This,pRectBounds,x,y,dwMouseMsg,fSetAlways))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPointerInactive_INTERFACE_DEFINED__ */

/*****************************************************************************
 * IObjectWithSite interface
 */
#ifndef __IObjectWithSite_INTERFACE_DEFINED__
#define __IObjectWithSite_INTERFACE_DEFINED__

typedef IObjectWithSite *LPOBJECTWITHSITE;

EXTERN_C const IID IID_IObjectWithSite;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IObjectWithSiteVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IObjectWithSite *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IObjectWithSite *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IObjectWithSite *This);

    /*** IObjectWithSite methods ***/
    HRESULT (STDMETHODCALLTYPE *SetSite)(
        IObjectWithSite *This,
        IUnknown *pUnkSite);

    HRESULT (STDMETHODCALLTYPE *GetSite)(
        IObjectWithSite *This,
        REFIID riid,
        void **ppvSite);

    END_INTERFACE
} IObjectWithSiteVtbl;

interface IObjectWithSite {
    CONST_VTBL IObjectWithSiteVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IObjectWithSite_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IObjectWithSite_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IObjectWithSite_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IObjectWithSite methods ***/
#define IObjectWithSite_SetSite(This,pUnkSite) \
    ((This)->lpVtbl->SetSite(This,pUnkSite))
#define IObjectWithSite_GetSite(This,riid,ppvSite) \
    ((This)->lpVtbl->GetSite(This,riid,ppvSite))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IObjectWithSite_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)

/*****************************************************************************
 * IPerPropertyBrowsing interface
 */
#ifndef __IPerPropertyBrowsing_INTERFACE_DEFINED__
#define __IPerPropertyBrowsing_INTERFACE_DEFINED__

typedef IPerPropertyBrowsing *LPPERPROPERTYBROWSING;

typedef struct tagCALPOLESTR {
    ULONG cElems;
    LPOLESTR *pElems;
} CALPOLESTR;

typedef struct tagCALPOLESTR *LPCALPOLESTR;

typedef struct tagCADWORD {
    ULONG cElems;
    DWORD *pElems;
} CADWORD;

typedef struct tagCADWORD *LPCADWORD;

EXTERN_C const IID IID_IPerPropertyBrowsing;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPerPropertyBrowsingVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPerPropertyBrowsing *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPerPropertyBrowsing *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPerPropertyBrowsing *This);

    /*** IPerPropertyBrowsing methods ***/
    HRESULT (STDMETHODCALLTYPE *GetDisplayString)(
        IPerPropertyBrowsing *This,
        DISPID dispID,
        BSTR *pBstr);

    HRESULT (STDMETHODCALLTYPE *MapPropertyToPage)(
        IPerPropertyBrowsing *This,
        DISPID dispID,
        CLSID *pClsid);

    HRESULT (STDMETHODCALLTYPE *GetPredefinedStrings)(
        IPerPropertyBrowsing *This,
        DISPID dispID,
        CALPOLESTR *pCaStringsOut,
        CADWORD *pCaCookiesOut);

    HRESULT (STDMETHODCALLTYPE *GetPredefinedValue)(
        IPerPropertyBrowsing *This,
        DISPID dispID,
        DWORD dwCookie,
        VARIANT *pVarOut);

    END_INTERFACE
} IPerPropertyBrowsingVtbl;

interface IPerPropertyBrowsing {
    CONST_VTBL IPerPropertyBrowsingVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPerPropertyBrowsing_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPerPropertyBrowsing_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPerPropertyBrowsing_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPerPropertyBrowsing methods ***/
#define IPerPropertyBrowsing_GetDisplayString(This,dispID,pBstr) \
    ((This)->lpVtbl->GetDisplayString(This,dispID,pBstr))
#define IPerPropertyBrowsing_MapPropertyToPage(This,dispID,pClsid) \
    ((This)->lpVtbl->MapPropertyToPage(This,dispID,pClsid))
#define IPerPropertyBrowsing_GetPredefinedStrings(This,dispID,pCaStringsOut,pCaCookiesOut) \
    ((This)->lpVtbl->GetPredefinedStrings(This,dispID,pCaStringsOut,pCaCookiesOut))
#define IPerPropertyBrowsing_GetPredefinedValue(This,dispID,dwCookie,pVarOut) \
    ((This)->lpVtbl->GetPredefinedValue(This,dispID,dwCookie,pVarOut))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPerPropertyBrowsing_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)

/*****************************************************************************
 * IPropertyBag2 interface
 */
#ifndef __IPropertyBag2_INTERFACE_DEFINED__
#define __IPropertyBag2_INTERFACE_DEFINED__

typedef IPropertyBag2 *LPPROPERTYBAG2;

typedef enum tagPROPBAG2_TYPE {
    PROPBAG2_TYPE_UNDEFINED = 0,
    PROPBAG2_TYPE_DATA = 1,
    PROPBAG2_TYPE_URL = 2,
    PROPBAG2_TYPE_OBJECT = 3,
    PROPBAG2_TYPE_STREAM = 4,
    PROPBAG2_TYPE_STORAGE = 5,
    PROPBAG2_TYPE_MONIKER = 6
} PROPBAG2_TYPE;

typedef struct tagPROPBAG2 {
    DWORD dwType;
    VARTYPE vt;
    CLIPFORMAT cfType;
    DWORD dwHint;
    LPOLESTR pstrName;
    CLSID clsid;
} PROPBAG2;

EXTERN_C const IID IID_IPropertyBag2;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPropertyBag2Vtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPropertyBag2 *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPropertyBag2 *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPropertyBag2 *This);

    /*** IPropertyBag2 methods ***/
    HRESULT (STDMETHODCALLTYPE *Read)(
        IPropertyBag2 *This,
        ULONG cProperties,
        PROPBAG2 *pPropBag,
        IErrorLog *pErrLog,
        VARIANT *pvarValue,
        HRESULT *phrError);

    HRESULT (STDMETHODCALLTYPE *Write)(
        IPropertyBag2 *This,
        ULONG cProperties,
        PROPBAG2 *pPropBag,
        VARIANT *pvarValue);

    HRESULT (STDMETHODCALLTYPE *CountProperties)(
        IPropertyBag2 *This,
        ULONG *pcProperties);

    HRESULT (STDMETHODCALLTYPE *GetPropertyInfo)(
        IPropertyBag2 *This,
        ULONG iProperty,
        ULONG cProperties,
        PROPBAG2 *pPropBag,
        ULONG *pcProperties);

    HRESULT (STDMETHODCALLTYPE *LoadObject)(
        IPropertyBag2 *This,
        LPCOLESTR pstrName,
        DWORD dwHint,
        IUnknown *pUnkObject,
        IErrorLog *pErrLog);

    END_INTERFACE
} IPropertyBag2Vtbl;

interface IPropertyBag2 {
    CONST_VTBL IPropertyBag2Vtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPropertyBag2_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPropertyBag2_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPropertyBag2_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPropertyBag2 methods ***/
#define IPropertyBag2_Read(This,cProperties,pPropBag,pErrLog,pvarValue,phrError) \
    ((This)->lpVtbl->Read(This,cProperties,pPropBag,pErrLog,pvarValue,phrError))
#define IPropertyBag2_Write(This,cProperties,pPropBag,pvarValue) \
    ((This)->lpVtbl->Write(This,cProperties,pPropBag,pvarValue))
#define IPropertyBag2_CountProperties(This,pcProperties) \
    ((This)->lpVtbl->CountProperties(This,pcProperties))
#define IPropertyBag2_GetPropertyInfo(This,iProperty,cProperties,pPropBag,pcProperties) \
    ((This)->lpVtbl->GetPropertyInfo(This,iProperty,cProperties,pPropBag,pcProperties))
#define IPropertyBag2_LoadObject(This,pstrName,dwHint,pUnkObject,pErrLog) \
    ((This)->lpVtbl->LoadObject(This,pstrName,dwHint,pUnkObject,pErrLog))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPropertyBag2_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)

/*****************************************************************************
 * IPersistPropertyBag2 interface
 */
#ifndef __IPersistPropertyBag2_INTERFACE_DEFINED__
#define __IPersistPropertyBag2_INTERFACE_DEFINED__

typedef IPersistPropertyBag2 *LPPERSISTPROPERTYBAG2;

EXTERN_C const IID IID_IPersistPropertyBag2;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IPersistPropertyBag2Vtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IPersistPropertyBag2 *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IPersistPropertyBag2 *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IPersistPropertyBag2 *This);

    /*** IPersist methods ***/
    HRESULT (STDMETHODCALLTYPE *GetClassID)(
        IPersistPropertyBag2 *This,
        CLSID *pClassID);

    /*** IPersistPropertyBag2 methods ***/
    HRESULT (STDMETHODCALLTYPE *InitNew)(
        IPersistPropertyBag2 *This);

    HRESULT (STDMETHODCALLTYPE *Load)(
        IPersistPropertyBag2 *This,
        IPropertyBag2 *pPropBag,
        IErrorLog *pErrLog);

    HRESULT (STDMETHODCALLTYPE *Save)(
        IPersistPropertyBag2 *This,
        IPropertyBag2 *pPropBag,
        BOOL fClearDirty,
        BOOL fSaveAllProperties);

    HRESULT (STDMETHODCALLTYPE *IsDirty)(
        IPersistPropertyBag2 *This);

    END_INTERFACE
} IPersistPropertyBag2Vtbl;

interface IPersistPropertyBag2 {
    CONST_VTBL IPersistPropertyBag2Vtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IPersistPropertyBag2_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IPersistPropertyBag2_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IPersistPropertyBag2_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IPersist methods ***/
#define IPersistPropertyBag2_GetClassID(This,pClassID) \
    ((This)->lpVtbl->GetClassID(This,pClassID))
/*** IPersistPropertyBag2 methods ***/
#define IPersistPropertyBag2_InitNew(This) \
    ((This)->lpVtbl->InitNew(This))
#define IPersistPropertyBag2_Load(This,pPropBag,pErrLog) \
    ((This)->lpVtbl->Load(This,pPropBag,pErrLog))
#define IPersistPropertyBag2_Save(This,pPropBag,fClearDirty,fSaveAllProperties) \
    ((This)->lpVtbl->Save(This,pPropBag,fClearDirty,fSaveAllProperties))
#define IPersistPropertyBag2_IsDirty(This) \
    ((This)->lpVtbl->IsDirty(This))
#endif /* COBJMACROS */

#endif /* C */

#endif /* __IPersistPropertyBag2_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)

/*****************************************************************************
 * IAdviseSinkEx interface
 */
#ifndef __IAdviseSinkEx_INTERFACE_DEFINED__
#define __IAdviseSinkEx_INTERFACE_DEFINED__

typedef IAdviseSinkEx *LPADVISESINKEX;

EXTERN_C const IID IID_IAdviseSinkEx;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IAdviseSinkExVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IAdviseSinkEx *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IAdviseSinkEx *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IAdviseSinkEx *This);

    /*** IAdviseSink methods ***/
    void (STDMETHODCALLTYPE *OnDataChange)(
        IAdviseSinkEx *This,
        FORMATETC *pFormatetc,
        STGMEDIUM *pStgmed);

    void (STDMETHODCALLTYPE *OnViewChange)(
        IAdviseSinkEx *This,
        DWORD dwAspect,
        LONG lindex);

    void (STDMETHODCALLTYPE *OnRename)(
        IAdviseSinkEx *This,
        IMoniker *pmk);

    void (STDMETHODCALLTYPE *OnSave)(
        IAdviseSinkEx *This);

    void (STDMETHODCALLTYPE *OnClose)(
        IAdviseSinkEx *This);

    /*** IAdviseSinkEx methods ***/
    void (STDMETHODCALLTYPE *OnViewStatusChange)(
        IAdviseSinkEx *This,
        DWORD dwViewStatus);

    END_INTERFACE
} IAdviseSinkExVtbl;

interface IAdviseSinkEx {
    CONST_VTBL IAdviseSinkExVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IAdviseSinkEx_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IAdviseSinkEx_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IAdviseSinkEx_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IAdviseSink methods ***/
#define IAdviseSinkEx_OnDataChange(This,pFormatetc,pStgmed) \
    ((This)->lpVtbl->OnDataChange(This,pFormatetc,pStgmed))
#define IAdviseSinkEx_OnViewChange(This,dwAspect,lindex) \
    ((This)->lpVtbl->OnViewChange(This,dwAspect,lindex))
#define IAdviseSinkEx_OnRename(This,pmk) \
    ((This)->lpVtbl->OnRename(This,pmk))
#define IAdviseSinkEx_OnSave(This) \
    ((This)->lpVtbl->OnSave(This))
#define IAdviseSinkEx_OnClose(This) \
    ((This)->lpVtbl->OnClose(This))
/*** IAdviseSinkEx methods ***/
#define IAdviseSinkEx_OnViewStatusChange(This,dwViewStatus) \
    ((This)->lpVtbl->OnViewStatusChange(This,dwViewStatus))
#endif /* COBJMACROS */

#endif /* C */

HRESULT STDMETHODCALLTYPE IAdviseSinkEx_RemoteOnViewStatusChange_Proxy(
    IAdviseSinkEx *This,
    DWORD dwViewStatus);

void __RPC_STUB IAdviseSinkEx_RemoteOnViewStatusChange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

void IAdviseSinkEx_OnViewStatusChange_Proxy(
    DWORD dwViewStatus);
HRESULT IAdviseSinkEx_OnViewStatusChange_Stub(
    DWORD dwViewStatus);
#endif /* __IAdviseSinkEx_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM) */

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)

/*****************************************************************************
 * IQuickActivate interface
 */
#ifndef __IQuickActivate_INTERFACE_DEFINED__
#define __IQuickActivate_INTERFACE_DEFINED__

typedef IQuickActivate *LPQUICKACTIVATE;

typedef enum tagQACONTAINERFLAGS {
    QACONTAINER_SHOWHATCHING = 0x1,
    QACONTAINER_SHOWGRABHANDLES = 0x2,
    QACONTAINER_USERMODE = 0x4,
    QACONTAINER_DISPLAYASDEFAULT = 0x8,
    QACONTAINER_UIDEAD = 0x10,
    QACONTAINER_AUTOCLIP = 0x20,
    QACONTAINER_MESSAGEREFLECT = 0x40,
    QACONTAINER_SUPPORTSMNEMONICS = 0x80
} QACONTAINERFLAGS;

typedef DWORD OLE_COLOR;

typedef struct tagQACONTAINER {
    ULONG cbSize;
    IOleClientSite *pClientSite;
    IAdviseSinkEx *pAdviseSink;
    IPropertyNotifySink *pPropertyNotifySink;
    IUnknown *pUnkEventSink;
    DWORD dwAmbientFlags;
    OLE_COLOR colorFore;
    OLE_COLOR colorBack;
    IFont *pFont;
    IOleUndoManager *pUndoMgr;
    DWORD dwAppearance;
    LONG lcid;
    HPALETTE hpal;
    IBindHost *pBindHost;
    IOleControlSite *pOleControlSite;
    IServiceProvider *pServiceProvider;
} QACONTAINER;

typedef struct tagQACONTROL {
    ULONG cbSize;
    DWORD dwMiscStatus;
    DWORD dwViewStatus;
    DWORD dwEventCookie;
    DWORD dwPropNotifyCookie;
    DWORD dwPointerActivationPolicy;
} QACONTROL;

EXTERN_C const IID IID_IQuickActivate;

#if defined(__cplusplus) && !defined(CINTERFACE)
#error no support for C++
#else /* C */
typedef struct IQuickActivateVtbl {
    BEGIN_INTERFACE

    /*** IUnknown methods ***/
    HRESULT (STDMETHODCALLTYPE *QueryInterface)(
        IQuickActivate *This,
        REFIID riid,
        void **ppvObject);

    ULONG (STDMETHODCALLTYPE *AddRef)(
        IQuickActivate *This);

    ULONG (STDMETHODCALLTYPE *Release)(
        IQuickActivate *This);

    /*** IQuickActivate methods ***/
    HRESULT (STDMETHODCALLTYPE *QuickActivate)(
        IQuickActivate *This,
        QACONTAINER *pQaContainer,
        QACONTROL *pQaControl);

    HRESULT (STDMETHODCALLTYPE *SetContentExtent)(
        IQuickActivate *This,
        LPSIZEL pSizel);

    HRESULT (STDMETHODCALLTYPE *GetContentExtent)(
        IQuickActivate *This,
        LPSIZEL pSizel);

    END_INTERFACE
} IQuickActivateVtbl;

interface IQuickActivate {
    CONST_VTBL IQuickActivateVtbl* lpVtbl;
};

#ifdef COBJMACROS
/*** IUnknown methods ***/
#define IQuickActivate_QueryInterface(This,riid,ppvObject) \
    ((This)->lpVtbl->QueryInterface(This,riid,ppvObject))
#define IQuickActivate_AddRef(This) \
    ((This)->lpVtbl->AddRef(This))
#define IQuickActivate_Release(This) \
    ((This)->lpVtbl->Release(This))
/*** IQuickActivate methods ***/
#define IQuickActivate_QuickActivate(This,pQaContainer,pQaControl) \
    ((This)->lpVtbl->QuickActivate(This,pQaContainer,pQaControl))
#define IQuickActivate_SetContentExtent(This,pSizel) \
    ((This)->lpVtbl->SetContentExtent(This,pSizel))
#define IQuickActivate_GetContentExtent(This,pSizel) \
    ((This)->lpVtbl->GetContentExtent(This,pSizel))
#endif /* COBJMACROS */

#endif /* C */

HRESULT STDMETHODCALLTYPE IQuickActivate_RemoteQuickActivate_Proxy(
    IQuickActivate *This,
    QACONTAINER *pQaContainer,
    QACONTROL *pQaControl);

void __RPC_STUB IQuickActivate_RemoteQuickActivate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *pRpcChannelBuffer,
    PRPC_MESSAGE pRpcMessage,
    DWORD *pdwStubPhase);

HRESULT IQuickActivate_QuickActivate_Proxy(
    QACONTAINER *pQaContainer,
    QACONTROL *pQaControl);
HRESULT IQuickActivate_QuickActivate_Stub(
    QACONTAINER *pQaContainer,
    QACONTROL *pQaControl);
#endif /* __IQuickActivate_INTERFACE_DEFINED__ */

#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES) */

/* Begin additional prototypes for all interfaces */

ULONG __RPC_USER BSTR_UserSize(ULONG *, ULONG, BSTR *);
unsigned char * __RPC_USER BSTR_UserMarshal(ULONG *, unsigned char *, BSTR *);
unsigned char * __RPC_USER BSTR_UserUnmarshal(ULONG *, unsigned char *, BSTR *);
void __RPC_USER BSTR_UserFree(ULONG *, BSTR *);
ULONG __RPC_USER HACCEL_UserSize(ULONG *, ULONG, HACCEL *);
unsigned char * __RPC_USER HACCEL_UserMarshal(ULONG *, unsigned char *, HACCEL *);
unsigned char * __RPC_USER HACCEL_UserUnmarshal(ULONG *, unsigned char *, HACCEL *);
void __RPC_USER HACCEL_UserFree(ULONG *, HACCEL *);
ULONG __RPC_USER HWND_UserSize(ULONG *, ULONG, HWND *);
unsigned char * __RPC_USER HWND_UserMarshal(ULONG *, unsigned char *, HWND *);
unsigned char * __RPC_USER HWND_UserUnmarshal(ULONG *, unsigned char *, HWND *);
void __RPC_USER HWND_UserFree(ULONG *, HWND *);
ULONG __RPC_USER HFONT_UserSize(ULONG *, ULONG, HFONT *);
unsigned char * __RPC_USER HFONT_UserMarshal(ULONG *, unsigned char *, HFONT *);
unsigned char * __RPC_USER HFONT_UserUnmarshal(ULONG *, unsigned char *, HFONT *);
void __RPC_USER HFONT_UserFree(ULONG *, HFONT *);
ULONG __RPC_USER HDC_UserSize(ULONG *, ULONG, HDC *);
unsigned char * __RPC_USER HDC_UserMarshal(ULONG *, unsigned char *, HDC *);
unsigned char * __RPC_USER HDC_UserUnmarshal(ULONG *, unsigned char *, HDC *);
void __RPC_USER HDC_UserFree(ULONG *, HDC *);
ULONG __RPC_USER HRGN_UserSize(ULONG *, ULONG, HRGN *);
unsigned char * __RPC_USER HRGN_UserMarshal(ULONG *, unsigned char *, HRGN *);
unsigned char * __RPC_USER HRGN_UserUnmarshal(ULONG *, unsigned char *, HRGN *);
void __RPC_USER HRGN_UserFree(ULONG *, HRGN *);
ULONG __RPC_USER VARIANT_UserSize(ULONG *, ULONG, VARIANT *);
unsigned char * __RPC_USER VARIANT_UserMarshal(ULONG *, unsigned char *, VARIANT *);
unsigned char * __RPC_USER VARIANT_UserUnmarshal(ULONG *, unsigned char *, VARIANT *);
void __RPC_USER VARIANT_UserFree(ULONG *, VARIANT *);
ULONG __RPC_USER CLIPFORMAT_UserSize(ULONG *, ULONG, CLIPFORMAT *);
unsigned char * __RPC_USER CLIPFORMAT_UserMarshal(ULONG *, unsigned char *, CLIPFORMAT *);
unsigned char * __RPC_USER CLIPFORMAT_UserUnmarshal(ULONG *, unsigned char *, CLIPFORMAT *);
void __RPC_USER CLIPFORMAT_UserFree(ULONG *, CLIPFORMAT *);
ULONG __RPC_USER HPALETTE_UserSize(ULONG *, ULONG, HPALETTE *);
unsigned char * __RPC_USER HPALETTE_UserMarshal(ULONG *, unsigned char *, HPALETTE *);
unsigned char * __RPC_USER HPALETTE_UserUnmarshal(ULONG *, unsigned char *, HPALETTE *);
void __RPC_USER HPALETTE_UserFree(ULONG *, HPALETTE *);

/* End additional prototypes for all interfaces */

#endif /* __ocidl_h__ */
