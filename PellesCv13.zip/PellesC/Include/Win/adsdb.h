#ifndef _ADSDB_H
#define _ADSDB_H

#if __POCC__ >= 500
#pragma once
#endif

/* OLE DB provider for ADSI definitions */

#include <winapifamily.h>

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP)
#define DBPROPFLAGS_ADSISEARCH  0x0000C000
#endif /* WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP) */

#endif /* _ADSDB_H */
