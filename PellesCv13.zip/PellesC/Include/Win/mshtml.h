#ifndef _MSHTML_H
#define _MSHTML_H

#if __POCC__ >= 500
#pragma once
#endif

#include "mshtmlc.h"

#endif /* _MSHTML_H */
