ResEdit Portable 1.6.6 Release Notes
===

[ResEditPortable_1.6.6_Development_Test_1.paf.exe](https://sourceforge.net/projects/resedit-portable/files/ResEditPortable_1.6.6_Development_Test_1.paf.exe/download)

The development release for ResEdit Portable 1.6.6 installs the ResEdit *free* resource editor for Windows programs. This package uses the ResEdit 1.6.6 stable release but the Portable edition is still under development and need to do further testing.

Visit [ResEdit changelog page](http://www.resedit.net/changelog.txt) for a complete list of new features and bug fixes in version 1.6.6

Show your appreciation and support its development by [making a donation](http://www.resedit.net/).

