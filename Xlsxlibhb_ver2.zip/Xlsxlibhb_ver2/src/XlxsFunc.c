
/*
*Funciones para Harbour
*libxlsxwrite
*Arturo Tamayo Daza 
*Mayo 2015 2023
*Derechos Reservados
*/

/*
// -----------------------------------------------------------------------------
// xlsxwriter
//
// XlsxLibHb.lib (version 2.0) wrappers for Harbour
//
// Copyright 2015-2023 Arturo Tamayo Daza <arturotamayo@hotmail.com>
//
// -----------------------------------------------------------------------------
*/
/*
 * libxlsxwriter
 *
 * Copyright 2014-2023 John McNamara, jmcnamara@cpan.org. See LICENSE.txt.
 */

#include <windows.h>
#include <shlobj.h>
#include "hbapi.h"
#include "hbvm.h"
#include "hbstack.h"
#include "hbapiitm.h"

#include "xlsxwriter.h"

//*********************//
//      workbook
//*********************//	

 static char bufeo[12];
 
HB_FUNC( NEW_WORKBOOK)
{
	const char* filename = ( const char*) hb_parc(1); 
	lxw_workbook *workbook  = new_workbook(filename); 
	hb_retptr( workbook );
}

HB_FUNC( NEW_WORKBOOK_OPT)
{
	const char* filename = ( const char*) hb_parc(1);
	lxw_workbook_options *options =	( lxw_workbook_options *) hb_parc(2);	
	lxw_workbook *workbook  = new_workbook_opt (filename, options); 
	hb_retptr( workbook );
}

HB_FUNC( WORKBOOK_ADD_WORKSHEET )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char *sname = ( const char*) hb_parc(2);
	lxw_worksheet *worksheet = workbook_add_worksheet(workbook, sname);
	hb_retptr( worksheet );
}

HB_FUNC( WORKBOOK_ADD_CHARTSHEET )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char* sname = ( const char*) hb_parc(2);
	lxw_chartsheet *chartsheet = workbook_add_chartsheet(workbook, sname); 

	hb_retptr( chartsheet );
}

HB_FUNC( WORKBOOK_ADD_FORMAT )
{
	lxw_format *format;
	format = workbook_add_format ( (lxw_workbook *) hb_parptr(1) );
	hb_retptr( format );
}

HB_FUNC( WORKBOOK_ADD_CHART )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	uint16_t chart_type =  hb_parni(2);
	lxw_chart *Chart_Graf = workbook_add_chart( workbook, chart_type);
	
	hb_retptr( Chart_Graf );
}

HB_FUNC( WORKBOOK_CLOSE )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
   	hb_retl( (int) workbook_close(workbook) );
}
HB_FUNC( WORKBOOK_SET_PROPERTIES )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	lxw_doc_properties  *propiedad  = (lxw_doc_properties *) hb_parvptr(2);
	
	hb_retl( (int) workbook_set_properties (workbook, propiedad ) );
}

HB_FUNC( WORKBOOK_SET_CUSTOM_PROPERTY_STRING)
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char* sname = ( const char*) hb_parc(2);
	const char* svalue = ( const char*) hb_parc(3);
	
	hb_retl( (int) workbook_set_custom_property_string (workbook, sname, svalue) );
}

HB_FUNC( WORKBOOK_SET_CUSTOM_PROPERTY_NUMBER)
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char* sname = ( const char*) hb_parc(2);
	double svalue = ( double ) hb_parni(3);
	
	hb_retl( (int) workbook_set_custom_property_number (workbook, sname, svalue) );
}

HB_FUNC( WORKBOOK_SET_CUSTOM_PROPERTY_BOOLEAN)
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char* sname = ( const char*) hb_parc(2);
	uint8_t svalue =   hb_parni(3);
	
	hb_retl( (int) workbook_set_custom_property_boolean (workbook, sname, svalue) );
}

HB_FUNC( WORKBOOK_SET_CUSTOM_PROPERTY_DATETIME)
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char* sname = ( const char*) hb_parc(2);
	lxw_datetime *datetime = ( lxw_datetime *) hb_pards(4);
	
	hb_retl( (int) workbook_set_custom_property_datetime (workbook, sname, datetime) );
}
	
HB_FUNC( WORKBOOK_DEFINE_NAME )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char *name = ( const char*) hb_parc(2);
	const char *formula = ( const char*) hb_parc(3);
	
	hb_retl( (int) workbook_define_name (workbook, name, formula) );
}
	
HB_FUNC( WORKBOOK_GET_DEFAULT_URL_FORMAT )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	lxw_format  *format  = workbook_get_default_url_format (workbook );
	
	hb_retptr( format );
}

HB_FUNC( WORKBOOK_GET_WORKSHEET_BY_NAME )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char *name = ( const char*) hb_parc(2);
	lxw_worksheet *worksheet = workbook_get_worksheet_by_name(workbook, name);
	
	hb_retptr( worksheet );
}

HB_FUNC( WORKBOOK_GET_CHARTSHEET_BY_NAME )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char *name = ( const char*) hb_parc(2);
	lxw_chartsheet *chartsheet = workbook_get_chartsheet_by_name(workbook, name);
	
	hb_retptr( chartsheet );
}

HB_FUNC( WORKBOOK_VALIDATE_SHEET_NAME )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char *sheetname = ( const char*) hb_parc(2);
		
	hb_retl( (int) workbook_validate_sheet_name ( workbook, sheetname ) );
}

HB_FUNC( WORKBOOK_ADD_VBA_PROJECT )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char *filename = ( const char*) hb_parc(2);
		
	hb_retl( (int) workbook_add_vba_project ( workbook, filename ) );
}

HB_FUNC( WORKBOOK_SET_VBA_NAME )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
	const char *name = ( const char*) hb_parc(2);
		
	hb_retl( (int) workbook_set_vba_name ( workbook, name ) );
}

HB_FUNC( WORKBOOK_READ_ONLY_RECOMMENDED )
{
	lxw_workbook  *workbook  = (lxw_workbook *) hb_parptr(1);
    workbook_read_only_recommended ( workbook );
	hb_ret();
}

	
//*********************//
//      worksheet
//*********************//	


HB_FUNC( WORKSHEET_WRITE_NUMBER )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	double number = (double) hb_parnd(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_number(worksheet, row, col, number, format) );
}

HB_FUNC( WORKSHEET_WRITE_STRING )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const char *string = ( const char*) hb_parc(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_string (worksheet, row, col, string, format) );
}	

HB_FUNC( WORKSHEET_WRITE_FORMULA )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	lxw_col_t col_num= hb_parni(3);
	const char *formula = ( const char*) hb_parc(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_formula (worksheet, row_num, col_num, formula, format) );
}
 
HB_FUNC( WORKSHEET_WRITE_ARRAY_FORMULA )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col= hb_parni(3);
	lxw_row_t last_row= hb_parni(4);
	lxw_col_t last_col= hb_parni(5);
	const char *formula = ( const char*) hb_parc(6);
	lxw_format *format = (lxw_format *) hb_parptr(7);
	
	hb_retl( (int) worksheet_write_array_formula( worksheet, first_row, first_col, last_row, last_col, formula, format) );
}

HB_FUNC( WORKSHEET_WRITE_DYNAMIC_ARRAY_FORMULA )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col= hb_parni(3);
	lxw_row_t last_row= hb_parni(4);
	lxw_col_t last_col= hb_parni(5);
	const char *formula = ( const char*) hb_parc(6);
	lxw_format *format = (lxw_format *) hb_parptr(7);
 	
	hb_retl( (int) worksheet_write_dynamic_array_formula ( worksheet, first_row, first_col, last_row, last_col, formula, format ) );
}

HB_FUNC( WORKSHEET_WRITE_DYNAMIC_ARRAY_FORMULA_NUM )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col= hb_parni(3);
	lxw_row_t last_row= hb_parni(4);
	lxw_col_t last_col= hb_parni(5);
	const char *formula = ( const char*) hb_parc(6);
	lxw_format *format = (lxw_format *) hb_parptr(7);
 	double result= hb_parni(8);
	hb_retl( (int) worksheet_write_dynamic_array_formula_num ( worksheet, first_row, first_col, last_row, last_col, formula, format, result ) );
}
 
HB_FUNC( WORKSHEET_WRITE_DYNAMIC_FORMULA )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const char *formula = ( const char*) hb_parc(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_dynamic_formula(worksheet, row, col, formula, format) );
}
								
HB_FUNC( WORKSHEET_WRITE_DATETIME )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	lxw_datetime *datetime = ( lxw_datetime *)  hb_parvptr(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_datetime (worksheet, row, col, datetime, format) );
}	
								
HB_FUNC( WORKSHEET_WRITE_UNIXTIME )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	lxw_col_t col_num = hb_parni(3);
	int64_t unixtime = hb_parni(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_unixtime(worksheet, row_num, col_num, unixtime, format) );
}	
 
HB_FUNC( WORKSHEET_WRITE_URL )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const char *url = ( const char*) hb_parc(4); 
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_url (worksheet, row, col, url, format) );
}	

HB_FUNC( WORKSHEET_WRITE_BOOLEAN )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	int value = ( int ) hb_parni(4); 
	lxw_format *format = (lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_boolean (worksheet, row, col, value, format) );
}	

HB_FUNC( WORKSHEET_WRITE_BLANK )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	lxw_format *format = (lxw_format *) hb_parptr(4);
	
	hb_retl( (int) worksheet_write_blank (worksheet, row, col, format) );
}		

HB_FUNC( WORKSHEET_WRITE_FORMULA_NUM )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const char *formula = ( const char*) hb_parc(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	double result  = (double) hb_parnd(6);
	
	hb_retl( (int) worksheet_write_formula_num (worksheet, row, col, formula, format, result)  );
}

HB_FUNC( WORKSHEET_WRITE_FORMULA_STR )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	lxw_col_t col_num = hb_parni(3);
	const char *formula = ( const char*) hb_parc(4);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	const char *result  = (const char *) hb_parc(6);
	
	hb_retl( (int) worksheet_write_formula_str( worksheet, row_num, col_num, formula, format, result)  );
}
 
HB_FUNC( WORKSHEET_WRITE_RICH_STRING )
{
	PHB_ITEM pItem = hb_param( 4, HB_IT_ANY );
	int array  = hb_arrayLen( pItem );
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	lxw_col_t col_num = hb_parni(3);
	lxw_format *format = (lxw_format *) hb_parptr(5);
	lxw_rich_string_tuple *rich_strings[1258] = {NULL}; 
	int i;
	for (i = 0; i < array; i++)
        rich_strings[i] = hb_parvptr(4,i+1);
	rich_strings[i+1] = NULL;
	
	hb_retl( (int) worksheet_write_rich_string (worksheet, row_num, col_num, rich_strings, format)  );
}

HB_FUNC( WORKSHEET_WRITE_COMMENT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	lxw_col_t col_num = hb_parni(3);
	const char *string = ( const char *) hb_parc(4);

	
	hb_retl( (int) worksheet_write_comment(worksheet, row_num, col_num, string)  );
}

HB_FUNC( WORKSHEET_WRITE_COMMENT_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	lxw_col_t col_num = hb_parni(3);
	const char *text = ( const char *) hb_parc(4);
	lxw_comment_options *options = (lxw_comment_options *) hb_parptr(5);
	
	hb_retl( (int) worksheet_write_comment_opt(worksheet, row_num, col_num, text, options)  );
}
							
HB_FUNC( WORKSHEET_SET_ROW )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	double height = (double) hb_parnd(3);
	lxw_format *format =(lxw_format *) hb_parptr(4);
	
	hb_retl( (int) worksheet_set_row (worksheet,row,height,format) );  
}

HB_FUNC( WORKSHEET_SET_ROW_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	double height = (double) hb_parnd(3);
	lxw_format *format =(lxw_format *) hb_parptr(4);
    lxw_row_col_options *options =(lxw_row_col_options *) hb_parptr(5);
	
	hb_retl( (int) worksheet_set_row_opt (worksheet,row,height,format,options) );
}
							
HB_FUNC( WORKSHEET_SET_ROW_PIXELS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	uint32_t pixels = (uint32_t) hb_parnd(3);
	lxw_format *format =(lxw_format *) hb_parptr(4);
	
	hb_retl( (int) worksheet_set_row_pixels(worksheet, row_num, pixels, format) );  
}
							
HB_FUNC( WORKSHEET_SET_ROW_PIXELS_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	uint32_t pixels = (uint32_t) hb_parnd(3);
	lxw_format *format =(lxw_format *) hb_parptr(4);
	lxw_row_col_options *user_options =(lxw_row_col_options *) hb_parvptr(5);
	
	hb_retl( (int) worksheet_set_row_pixels_opt(worksheet, row_num, pixels, format, user_options) );  
}

HB_FUNC( WORKSHEET_SET_COLUMN )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t first_col = hb_parni(2);
	lxw_col_t last_col = hb_parni(3);
	double width = (double) hb_parnd(4);
	lxw_format *format =(lxw_format *) hb_parptr(5);
	
	hb_retl( (int) worksheet_set_column (worksheet, first_col, last_col, width, format) );  
}

HB_FUNC( WORKSHEET_SET_COLUMN_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t first_col = hb_parni(2);
	lxw_col_t last_col = hb_parni(3);
	double width = (double) hb_parnd(4);
	lxw_format *format =(lxw_format *) hb_parptr(5);
	lxw_row_col_options *options =(lxw_row_col_options *) hb_parptr(6);
	
	hb_retl( (int) worksheet_set_column_opt (worksheet, first_col, last_col, width, format, options) );
}

HB_FUNC( WORKSHEET_SET_COLUMN_PIXELS  )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t first_col = hb_parni(2);
	lxw_col_t last_col = hb_parni(3);
	double pixels = (double) hb_parnd(4);
	lxw_format *format =(lxw_format *) hb_parptr(5);
	 
	hb_retl( (int) worksheet_set_column_pixels (worksheet, first_col, last_col, pixels, format ) );
}

HB_FUNC( WORKSHEET_SET_COLUMN_PIXELS_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t first_col = hb_parni(2);
	lxw_col_t last_col = hb_parni(3);
	double pixels = (double) hb_parnd(4);
	lxw_format *format =(lxw_format *) hb_parptr(5);
	lxw_row_col_options *options =(lxw_row_col_options *) hb_parptr(6);
	
	hb_retl( (int) worksheet_set_column_pixels_opt (worksheet, first_col, last_col, pixels, format, options) );
}
 
HB_FUNC( WORKSHEET_INSERT_IMAGE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const char *filename = ( const char*) hb_parc(4);
	worksheet_insert_image (worksheet, row, col, filename) ;
	hb_ret( );
}

HB_FUNC( WORKSHEET_INSERT_IMAGE_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const char *filename = ( const char*) hb_parc(4);
	lxw_image_options *options = (lxw_image_options * ) hb_parvptr(5) ; 
	
    hb_retl( (int) worksheet_insert_image_opt (worksheet, row, col, filename, options) );
}

HB_FUNC( WORKSHEET_INSERT_IMAGE_BUFFER )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const unsigned char *image_buffer = ( const unsigned char*) hb_parc(4);
	size_t image_size = hb_parni(5);
	 
	
    hb_retl( (int) worksheet_insert_image_buffer (worksheet, row, col, image_buffer,image_size ) );
}

HB_FUNC( WORKSHEET_INSERT_IMAGE_BUFFER_OPT)
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	const unsigned char *image_buffer = ( const unsigned char*) hb_parc(4);
	size_t image_size = hb_parni(5);
	lxw_image_options *options = (lxw_image_options * ) hb_parvptr(6) ; 
	
    hb_retl( (int) worksheet_insert_image_buffer_opt (worksheet, row, col, image_buffer,image_size, options) );
}
								  
HB_FUNC( WORKSHEET_SET_BACKGROUND )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *filename = ( const char*) hb_parc(2);
	
	hb_retl( (int) worksheet_set_background ( worksheet, filename) );
}

								  
HB_FUNC( WORKSHEET_SET_BACKGROUND_BUFFER )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *image_buffer = ( const char*) hb_parc(2);
	size_t image_size = hb_parni(3);
	
	hb_retl( (int) worksheet_set_background_buffer ( worksheet, image_buffer, image_size ) );
}

HB_FUNC( WORKSHEET_INSERT_CHART )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	lxw_chart *chart = (lxw_chart *) hb_parptr(4);
	worksheet_insert_chart (worksheet, row, col, chart);
	hb_ret( );
}

HB_FUNC( WORKSHEET_INSERT_CHART_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	lxw_chart *chart = (lxw_chart *) hb_parptr(4);
	lxw_chart_options *options = (lxw_chart_options *) hb_parvptr(5);; 
		
		
  	worksheet_insert_chart_opt (worksheet, row, col, chart, options);
	hb_ret( );
}

HB_FUNC( WORKSHEET_MERGE_RANGE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	lxw_row_t last_row = hb_parni(4);
	lxw_col_t last_col = hb_parni(5);
	const char *string = ( const char*) hb_parc(6);
	lxw_format *format =(lxw_format *) hb_parvptr(7);
	
	hb_retl( (int) worksheet_merge_range (worksheet, first_row, first_col, last_row, last_col, string, format) );
}

HB_FUNC( WORKSHEET_AUTOFILTER )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	lxw_row_t last_row = hb_parni(4);
	lxw_col_t last_col = hb_parni(5);
		
	hb_retl( (int) worksheet_autofilter (worksheet, first_row, first_col, last_row, last_col) );
}

HB_FUNC( WORKSHEET_FILTER_COLUMN )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t col = hb_parni(2);
	lxw_filter_rule *rule =(lxw_filter_rule *) hb_parvptr(3);
	
	hb_retl( (int) worksheet_filter_column(worksheet, col, rule) );
}

HB_FUNC( WORKSHEET_FILTER_COLUMN2 )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t col = hb_parni(2);
	lxw_filter_rule *rule1 =(lxw_filter_rule *) hb_parvptr(3);
	lxw_filter_rule *rule2 =(lxw_filter_rule *) hb_parvptr(4);
	uint8_t and_or =  (uint32_t) hb_parni(5);
	
	hb_retl( (int) worksheet_filter_column2(worksheet,  col, rule1, rule2, and_or) );
}

HB_FUNC( WORKSHEET_FILTER_LIST )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t col = hb_parni(2);
	char **list =  (char **) hb_parc(3);
	
	hb_retl( (int) worksheet_filter_list( worksheet,col, list) );
}
 
HB_FUNC( WORKSHEET_DATA_VALIDATION_CELL )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	lxw_data_validation *validation =(lxw_data_validation *) hb_parvptr(4);
	
	hb_retl( (int) worksheet_data_validation_cell(worksheet,  row, col, validation) );
}

HB_FUNC( WORKSHEET_DATA_VALIDATION_RANGE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	lxw_row_t last_row = hb_parni(4);
	lxw_col_t last_col = hb_parni(5);
	lxw_data_validation *validation =(lxw_data_validation *) hb_parvptr(6);
	
	hb_retl( (int) worksheet_data_validation_range(worksheet, first_row, first_col, last_row, last_col, validation) );
}

HB_FUNC( WORKSHEET_CONDITIONAL_FORMAT_CELL )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t  row = hb_parni(2);
	lxw_col_t  col = hb_parni(3);
	lxw_conditional_format *options =(lxw_conditional_format *) hb_parptr(6);
	
	hb_retl( (int) worksheet_conditional_format_cell(worksheet, row, col, options) );
}

HB_FUNC( WORKSHEET_CONDITIONAL_FORMAT_RANGE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	lxw_row_t last_row = hb_parni(4);
	lxw_col_t last_col = hb_parni(5);
	lxw_conditional_format *user_options =(lxw_conditional_format *) hb_parptr(6);
	
	hb_retl( (int) worksheet_conditional_format_range(worksheet, first_row, first_col, last_row, last_col, user_options) );
}

HB_FUNC( WORKSHEET_INSERT_BUTTON )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row_num = hb_parni(2);
	lxw_col_t col_num = hb_parni(3);
	lxw_button_options *options =(lxw_button_options *) hb_parptr(4);
	
	hb_retl( (int) worksheet_insert_button(worksheet, row_num, col_num, options) );
}
						
HB_FUNC( WORKSHEET_ADD_TABLE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	lxw_row_t last_row = hb_parni(4);
	lxw_col_t last_col = hb_parni(5);
	lxw_table_options *user_options =(lxw_table_options *) hb_parvptr(6);
	
	hb_retl( (int) worksheet_add_table(worksheet, first_row, first_col, last_row, last_col, user_options) );
}

HB_FUNC( WORKSHEET_ACTIVATE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
    worksheet_activate (worksheet);
	hb_ret();
}

HB_FUNC( WORKSHEET_SELECT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	worksheet_select (worksheet);
	hb_ret();
}

HB_FUNC( WORKSHEET_HIDE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	worksheet_hide (worksheet);
	hb_ret();
}

HB_FUNC( WORKSHEET_SET_FIRST_SHEET )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	worksheet_set_first_sheet (worksheet);
	hb_ret();
}

HB_FUNC( WORKSHEET_FREEZE_PANES )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	worksheet_freeze_panes (worksheet, first_row, first_col );
	hb_ret();
}

HB_FUNC( WORKSHEET_SPLIT_PANES )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	double y_split = hb_parni(2);
	double x_split = hb_parni(3);
	worksheet_split_panes (worksheet, y_split, x_split );
	hb_ret();
}

HB_FUNC( WORKSHEET_SET_SELECTION )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	lxw_row_t last_row = hb_parni(4);
	lxw_col_t last_col = hb_parni(5);
	worksheet_set_selection (worksheet, first_row, first_col, last_row, last_col );
	hb_ret();
}

HB_FUNC( WORKSHEET_SET_TOP_LEFT_CELL )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t row = hb_parni(2);
	lxw_col_t col = hb_parni(3);
	worksheet_set_top_left_cell (worksheet, row, col );
	hb_ret();
}

HB_FUNC( WORKSHEET_SET_LANDSCAPE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	worksheet_set_landscape (worksheet);
	hb_ret();
}

HB_FUNC( WORKSHEET_SET_PORTRAIT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	worksheet_set_portrait (worksheet);
	hb_ret();
}
 	
HB_FUNC( WORKSHEET_SET_PAGE_VIEW )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	worksheet_set_page_view (worksheet);
	hb_ret();
}

HB_FUNC( WORKSHEET_SET_PAPER )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint8_t paper_type = hb_parni(2);
	worksheet_set_paper (worksheet, paper_type);
	hb_ret( );
}

HB_FUNC( WORKSHEET_SET_MARGINS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	double left = (double) hb_parnd(2);
	double right = (double) hb_parnd(3);
	double top = (double) hb_parnd(4);
	double bottom = (double) hb_parnd(5);
	worksheet_set_margins (worksheet, left, right, top, bottom);
	hb_ret( );
}

HB_FUNC( WORKSHEET_SET_HEADER )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *string = ( const char*) hb_parc(2);
	
	hb_retl( (int) worksheet_set_header (worksheet, string) );
}	
 
HB_FUNC( WORKSHEET_SET_FOOTER )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *string = ( const char*) hb_parc(2);
	
	hb_retl( (int) worksheet_set_footer (worksheet, string) );
}	

HB_FUNC( WORKSHEET_SET_HEADER_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *string = ( const char*) hb_parc(2);
	lxw_header_footer_options *options = (lxw_header_footer_options *) hb_parvptr(3);
	
	hb_retl( (int) worksheet_set_header_opt (worksheet, string, options) );
}	

HB_FUNC( WORKSHEET_SET_FOOTER_OPT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *string = ( const char*) hb_parc(2);
	lxw_header_footer_options *options = (lxw_header_footer_options *) hb_parvptr(3);
	
	hb_retl( (int) worksheet_set_footer_opt (worksheet, string, options) );
}	

HB_FUNC( WORKSHEET_SET_H_PAGEBREAKS )
{
	PHB_ITEM pItem = hb_param( 2, HB_IT_ANY );
	int array  = hb_arrayLen( pItem );
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t breaks[1258] = {0}; 
	int i;
	
	for (i = 0; i < array; i++)
        breaks[i] = hb_parvni(2,i+1);
	breaks[i+1] = 0;
	worksheet_set_h_pagebreaks (worksheet, breaks ) ;
	hb_ret(  );
}

HB_FUNC( WORKSHEET_SET_V_PAGEBREAKS )
{
	PHB_ITEM pItem = hb_param( 3, HB_IT_ANY );
	int array  = hb_arrayLen( pItem );
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t breaks[1258] = {0}; 
	int i;
		
	for (i = 0; i < array; i++)
        breaks[i] = hb_parvni(3,i+1);
	
	breaks[i+1] = 0;
	worksheet_set_v_pagebreaks (worksheet, breaks ) ;
	
	hb_ret( );
}

HB_FUNC( WORKSHEET_PRINT_ACROSS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	worksheet_print_across (worksheet);	
	hb_ret( );
}	

HB_FUNC( WORKSHEET_SET_ZOOM )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint16_t scale = hb_parni(2);
	
	worksheet_set_zoom(worksheet, scale);
	hb_ret( );
}

HB_FUNC( WORKSHEET_GRIDLINES )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint8_t option = hb_parni(2);
	worksheet_gridlines (worksheet, option);
	hb_ret( );
}

HB_FUNC( WORKSHEET_CENTER_HORIZONTALLY )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	
	worksheet_center_horizontally (worksheet);
	hb_ret( );
}

HB_FUNC( WORKSHEET_CENTER_VERTICALLY )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	
	worksheet_center_vertically (worksheet);
	hb_ret( );
}

HB_FUNC( WORKSHEET_PRINT_ROW_COL_HEADERS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	
	worksheet_print_row_col_headers (worksheet);
	hb_ret( );
}

HB_FUNC( WORKSHEET_REPEAT_ROWS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_row_t last_row = hb_parni(3);
		
	hb_retl( (int) worksheet_repeat_rows (worksheet, first_row, last_row) );
}

HB_FUNC( WORKSHEET_REPEAT_COLUMNS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_col_t first_col = hb_parni(2);
	lxw_col_t last_col = hb_parni(3);
		
	hb_retl( (int) worksheet_repeat_columns (worksheet, first_col, last_col) );
}

HB_FUNC( WORKSHEET_PRINT_AREA )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_row_t first_row = hb_parni(2);
	lxw_col_t first_col = hb_parni(3);
	lxw_row_t last_row = hb_parni(4);
	lxw_col_t last_col = hb_parni(5);
		
	hb_retl( (int) worksheet_print_area (worksheet, first_row, first_col, last_row, last_col) );
}

HB_FUNC( WORKSHEET_FIR_TO_PAGES )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint16_t width = hb_parni(2);
	uint16_t height = hb_parni(3);
	worksheet_fit_to_pages (worksheet, width,height);
	hb_ret( );
}

HB_FUNC( WORKSHEET_SET_START_PAGE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint16_t start_page = hb_parni(2);
	
	worksheet_set_start_page (worksheet, start_page);
	hb_ret( );
}

HB_FUNC( WORKSHEET_SET_PRINT_SCALE )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint16_t scale = hb_parni(2);
	
	worksheet_set_print_scale (worksheet, scale);
	hb_ret( );
}

HB_FUNC( WORKSHEET_RIGHT_TO_LEFT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	
	worksheet_right_to_left (worksheet);
	hb_ret( );
}

HB_FUNC( WORKSHEET_HIDE_ZERO )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	
	worksheet_hide_zero (worksheet);
	hb_ret( );
}

HB_FUNC( WORKSHEET_SET_TAB_COLOR )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	
	worksheet_set_tab_color (worksheet, color);
	hb_ret( );
}

HB_FUNC( WORKSHEET_PROTECT )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *password = ( const char *) hb_parc(2);
	lxw_protection *options 	= hb_parvptr(3);

	worksheet_protect(worksheet, password, options);
	hb_ret( );
}

HB_FUNC( WORKSHEET_OUTLINE_SETTINGS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint8_t visible = hb_parni(2);
	uint8_t symbols_below = hb_parni(3);
	uint8_t symbols_right = hb_parni(4);
	uint8_t auto_style = hb_parni(5);
	
	worksheet_outline_settings( worksheet, visible, symbols_below, symbols_right, auto_style);
	hb_ret( );
}

HB_FUNC( WORKSHEET_SET_DEFAULT_ROW )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	double height = hb_parni(2);
	uint8_t hide_unused_rows = hb_parni(3);
			
  	worksheet_set_default_row( worksheet, height, hide_unused_rows);
	hb_ret( );
}

HB_FUNC( WORKSHEET_SET_VBA_NAME)
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *name = ( const char*) hb_parc(2);
 
    hb_retl( (int) worksheet_set_vba_name(worksheet, name) );
}

HB_FUNC( WORKSHEET_SHOW_COMMENTS )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);

  	worksheet_show_comments( worksheet );
	hb_ret( );
}

HB_FUNC( WORKSHEET_SHOW_COMMENTS_AUTHOR )
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	const char *author = ( const char*) hb_parc(2);

  	worksheet_set_comments_author(worksheet, author);
	hb_ret( );
}
 
HB_FUNC( WORKSHEET_IGNORE_ERRORS)
{
	lxw_worksheet *worksheet  = (lxw_worksheet *) hb_parptr(1);
	uint8_t type = hb_parni(2);
	const char *range = ( const char*) hb_parc(3);
 
    hb_retl( (int) worksheet_ignore_errors(worksheet, type, range) );
}
 
 

//***************//
//      chart
//***************//
HB_FUNC( CHART_ADD_SERIES )
{
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	const char *categories = ( const char*) hb_parc(2);
	const char *values = ( const char*) hb_parc(3);
	
	hb_retptr( chart_add_series (chart, categories, values ) );
}
HB_FUNC( CHART_SERIES_SET_CATEGORIES)
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	const char *sheetname = ( const char*) hb_parc(2);
	lxw_row_t first_row = hb_parni(3);
	lxw_col_t first_col = hb_parni(4);
	lxw_row_t last_row = hb_parni(5);
	lxw_col_t last_col = hb_parni(6);
	
	chart_series_set_categories (series, sheetname, first_row, first_col, last_row, last_col);
	
	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_VALUES )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	const char *sheetname = ( const char*) hb_parc(2);
	lxw_row_t first_row = hb_parni(3);
	lxw_col_t first_col = hb_parni(4);
	lxw_row_t last_row = hb_parni(5);
	lxw_col_t last_col = hb_parni(6);
	
	chart_series_set_values (series, sheetname, first_row, first_col, last_row, last_col) ;
 
	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_NAME )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	const char *name = ( const char*) hb_parc(2);

	chart_series_set_name (series, name);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_NAME_RANGE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	const char *sheetname = ( const char*) hb_parc(2);
	lxw_row_t row = hb_parni(3);
	lxw_col_t col = hb_parni(4);

	chart_series_set_name_range (series,sheetname, row, col)	;
	
	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_LINE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_line *line  = ( lxw_chart_line *)  hb_parvptr(2);
		
	chart_series_set_line (series, line);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_FILL )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_fill *fill  = ( lxw_chart_fill *) hb_parvptr(2);
	
	chart_series_set_fill (series, fill);

	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_INVERT_IF_NEGATIVE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);

	chart_series_set_invert_if_negative (series);

	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_PATTERN )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_pattern *pattern = ( lxw_chart_pattern *) hb_parvptr(2);
		
	chart_series_set_pattern (series, pattern);	
	
	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_MARKER_TYPE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	uint8_t type = hb_parni(2);
	
	chart_series_set_marker_type (series, type);

	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_MARKER_SIZE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	uint8_t size = hb_parni(2);

	chart_series_set_marker_size (series, size);

	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_MARKER_LINE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_line *line   = ( lxw_chart_line *)  hb_parvptr(2);

	chart_series_set_marker_line (series, line);

	hb_ret( );
}
HB_FUNC( CHART_SERIES_SET_MARKER_FILL )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_fill *fill  = ( lxw_chart_fill *) hb_parvptr(2);
	
	chart_series_set_marker_fill (series, fill);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_MARKER_PATTERN )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_pattern *pattern = (lxw_chart_pattern *) hb_parvptr(2); 

	chart_series_set_marker_pattern (series, pattern);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_POINTS )
{
	PHB_ITEM pItem = hb_param( 2, HB_IT_ANY );
	int array  = hb_arrayLen( pItem );
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_point *points[1258] = {NULL}; 
	int i;
	
	for (i = 0; i < array; i++)
        points[i] = hb_parvptr(2,i+1);
	points[i+1] = NULL;
		
	chart_series_set_points (series, points ) ;
	
	hb_ret( );
	
}

HB_FUNC( CHART_SERIES_SET_SMOOTH )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	uint8_t smooth = hb_parni(2);
	
	chart_series_set_smooth (series, smooth);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);

	chart_series_set_labels (series );

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_OPTIONS )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	uint8_t show_name		=   hb_parni(2);
	uint8_t show_category	=   hb_parni(3);
	uint8_t show_value		=   hb_parni(4);
	
	chart_series_set_labels_options(series, show_name,show_category, show_value);

	hb_ret( );
}
 
HB_FUNC( CHART_SERIES_SET_LABELS_CUSTOM )
{
	PHB_ITEM pItem = hb_param( 2, HB_IT_ANY );
	int array  = hb_arrayLen( pItem );
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_data_label *data_labels[1258] = {NULL}; 
	int i;

	for (i = 0; i < array; i++)
        data_labels[i] = hb_parvptr(2,i+1);
	data_labels[i+1] = NULL;
	
	hb_retl( (int) chart_series_set_labels_custom(series, data_labels )); 

}
 
HB_FUNC( CHART_SERIES_SET_LABELS_SEPARATOR )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	uint8_t separator		=   hb_parni(2);
	
	chart_series_set_labels_separator( series, separator);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_POSITION )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	uint8_t position		=   hb_parni(2);
	
	chart_series_set_labels_position( series, position);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_LEADER_LINE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	
	chart_series_set_labels_leader_line( series);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_LEGEND )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	
	chart_series_set_labels_legend(series);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_PERCENTAGE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	
	chart_series_set_labels_percentage(series);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_NUM_FORMAT )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	const char *num_format		=   ( const char*) hb_parc(2);
	
	chart_series_set_labels_num_format(series, num_format);
	
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_FONT )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_font *font	 = (lxw_chart_font *)  hb_parvptr(2);
	
	chart_series_set_labels_font( series,  font);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_LINE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_line *line	 = ( lxw_chart_line *)  hb_parvptr(2);
	
	chart_series_set_labels_line(series, line);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_FILL )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_fill *fill	 = ( lxw_chart_fill *)  hb_parvptr(2);
	
	chart_series_set_labels_fill(series, fill);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_LABELS_PATTERN )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_pattern *pattern	 = ( lxw_chart_pattern *)  hb_parvptr(2);
	
	chart_series_set_labels_pattern( series, pattern);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_TRENDLINE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	uint8_t type		=   hb_parni(2);
	uint8_t value		=   hb_parni(3);
	
	chart_series_set_trendline( series, type, value);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_TRENDLINE_FORECAST )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	double forward		=   hb_parni(2);
	double backward		=   hb_parni(3);
	
	chart_series_set_trendline_forecast(series, forward,  backward);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_TRENDLINE_EQUATION )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	
	chart_series_set_trendline_equation(series);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_TRENDLINE_R_SQUARED )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	
	chart_series_set_trendline_r_squared(series);
	hb_ret( );
}
 
HB_FUNC( CHART_SERIES_SET_TRENDLINE_INTERCEPT )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	double intercept		=   hb_parni(2);
	
	chart_series_set_trendline_intercept(series, intercept);
	hb_ret( );
}
 
HB_FUNC( CHART_SERIES_SET_TRENDLINE_NAME )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	 const char *name		=   hb_parc(2);
	
	chart_series_set_trendline_name(series, name);
	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_TRENDLINE_LINE )
{
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_line *line	 = ( lxw_chart_line *)  hb_parvptr(2);

	chart_series_set_trendline_line( series, line);
	
	hb_ret( );
}

HB_FUNC( CHART_SERIES_GET_ERROR_BARS )
{
 
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	lxw_chart_error_bar_axis axis_type = (lxw_chart_error_bar_axis) hb_parvptr(2); 
	
	chart_series_get_error_bars( series,  axis_type);

	hb_ret( );
}
							
HB_FUNC( CHART_SERIES_SET_ERROR_BARS )
{
	int iSp = hb_parni(4);
	lxw_chart_series *series = (lxw_chart_series *) hb_parptr(1);
	int8_t type	=   hb_parni(2);
	double value		=   hb_parni(3);
	lxw_series_error_bars *error_bars;
	
	if ( iSp )
		error_bars = series->x_error_bars ;
	else
		error_bars= series->y_error_bars;
	
	chart_series_set_error_bars( error_bars, type ,  value);

	hb_ret( );
}

HB_FUNC( CHART_SERIES_SET_ERROR_BARS_DIRECTION )
{
	lxw_series_error_bars *error_bars = (lxw_series_error_bars *) hb_parptr(1);
	uint8_t direction  =  hb_parni(2);
	
	chart_series_set_error_bars_direction( error_bars,  direction);

	hb_ret( );
}
							
HB_FUNC( CHART_SERIES_SET_ERROR_BARS_ENDCAP )
{
	lxw_series_error_bars *error_bars = (lxw_series_error_bars *) hb_parptr(1);
	uint8_t endcap  =  hb_parni(2);
	
	chart_series_set_error_bars_endcap( error_bars,  endcap);

	hb_ret( );
}
	
	
HB_FUNC( CHART_SERIES_SET_ERROR_BARS_LINE )
{
	lxw_series_error_bars *error_bars = (lxw_series_error_bars *) hb_parptr(1);
	lxw_chart_line *line  =  hb_parptr(2);
	
	chart_series_set_error_bars_line( error_bars,  line);

	hb_ret( );
}

 	
HB_FUNC( CHART_AXIS_GET )
{
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis_type axis_type  =  ( lxw_chart_axis_type ) hb_parptr(2);
 
	chart_axis_get( chart,  axis_type);

	hb_ret( );
}
 
HB_FUNC( CHART_AXIS_SET_NAME )
{
	int iSp = hb_parni(3);
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis ;
	const char *name = hb_parc(2);
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_name (axis, name);	

	hb_ret( );
}
HB_FUNC( CHART_X_AXIS_SET_NAME_RANGE )
{
	int iSp = hb_parni(5);

	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	const char *sheetname = ( const char*) hb_parc(2);
	lxw_row_t row = hb_parni(3);
	lxw_col_t col = hb_parni(4);	
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_name_range (axis, sheetname, row, col);

	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_NAME_FONT )
{
	int iSp = hb_parni(3);
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	lxw_chart_font *font  = ( lxw_chart_font *) hb_parvptr(2);
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_name_font (axis, font );

	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_NUM_FONT )
{
	int iSp = hb_parni(3);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	lxw_chart_font *font  = ( lxw_chart_font *) hb_parvptr(2);
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_num_font (axis, font);

	hb_ret( );
}
HB_FUNC( CHART_AXIS_SET_NUM_FORMAT )
{
	int iSp = hb_parni(3);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	const char* num_format =  hb_parc(2);
		
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_num_format (axis, num_format);

	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_LINE )
{
	int iSp = hb_parni(3);
 
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	lxw_chart_line *line  = ( lxw_chart_line *)  hb_parvptr(2);
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_line (axis, line);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_REVERSE )
{
	int iSp = hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_reverse (axis);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_CROSSING )
{
	int iSp = hb_parni(3);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	double value = (double) hb_parnd(2);	
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_crossing (axis, value);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_CROSSING_MAX )
{
	int iSp = hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_crossing_max (axis);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_CROSSING_min )
{
	int iSp = hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_crossing_min (axis);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_OFF )
{
	int iSp = hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_off (axis);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_POSITION )
{
	int iSp = hb_parni(3);
	uint8_t position =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_position (axis, position);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_LABEL_POSITION )
{
	int iSp = hb_parni(3);
	uint8_t position =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_label_position (axis, position);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_LABEL_ALIGN)
{
	int iSp = hb_parni(3);
	uint8_t align =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_label_align(axis, align);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_MIN )
{
	int iSp = hb_parni(3);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	double min = (double) hb_parnd(2);	
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_min ( axis, min);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_MAX )
{
	int iSp = hb_parni(3);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	double max = (double) hb_parnd(2);	
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_max ( axis, max);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_LOG_BASE )
{
	int iSp = hb_parni(3);
	uint16_t log_base =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_log_base (axis, log_base);
	
	hb_ret( );
}


HB_FUNC( CHART_AXIS_SET_MAJOR_TICK_MARK )
{
	int iSp = hb_parni(3);
	uint8_t type =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_major_tick_mark (axis, type);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_MINOR_TICK_MARK )
{
	int iSp = hb_parni(3);
	uint8_t type =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_minor_tick_mark (axis, type);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_INTERVAL_UNIT )
{
	int iSp = hb_parni(3);
	uint8_t unit =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_interval_unit (axis, unit);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_INTERVAL_TICK )
{
	int iSp = hb_parni(3);
	uint8_t unit =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_interval_tick (axis, unit);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_MAJOR_UNIT )
{
	int iSp = hb_parni(3);
	double unit =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_major_unit (axis, unit);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_MINOR_UNIT )
{
	int iSp = hb_parni(3);
	double unit =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_minor_unit (axis, unit);
	
	hb_ret( );
}

HB_FUNC( CHART_AXIS_SET_DISPLAY_UNITS )
{
	int iSp = hb_parni(3);
	uint8_t unit =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_display_units (axis, unit);
	
	hb_ret( );
} 

HB_FUNC( CHART_AXIS_SET_DISPLAY_UNITS_VISIBLE )
{
	int iSp = hb_parni(3);
	uint8_t unit =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_set_display_units_visible (axis, unit);
	
	hb_ret( );
}  

HB_FUNC( CHART_AXIS_MAJOR_GRIDLINES_SET_VISIBLE )
{
	int iSp = hb_parni(3);
	uint8_t visible =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_major_gridlines_set_visible (axis, visible);
	
	hb_ret( );
}  

HB_FUNC( CHART_AXIS_MINOR_GRIDLINES_SET_VISIBLE )
{
	int iSp = hb_parni(3);
	uint8_t visible =  hb_parni(2);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
		
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_minor_gridlines_set_visible (axis, visible);
	
	hb_ret( );
}  

HB_FUNC( CHART_AXIS_MAJOR_GRIDLINES_SET_LINE )
{
	
	int iSp = hb_parni(3);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	lxw_chart_line *line  = ( lxw_chart_line *)  hb_parvptr(2);
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_major_gridlines_set_line (axis, line);

	hb_ret( );
}
	
HB_FUNC( CHART_AXIS_MINOR_GRIDLINES_SET_LINE )
{
	
	int iSp = hb_parni(3);
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_axis *axis;
	lxw_chart_line *line  = ( lxw_chart_line *)  hb_parvptr(2);
	
	if ( iSp )
		axis = chart->x_axis;
	else
		axis = chart->y_axis;
	
	chart_axis_minor_gridlines_set_line (axis, line);

	hb_ret( );
}
	
HB_FUNC( CHART_TITLE_SET_NAME )
{
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	const char *sheetname = ( const char*) hb_parc(2);
			
	chart_title_set_name (chart, sheetname );

	hb_ret( );
}		
	
HB_FUNC( CHART_TITLE_SET_NAME_RANGE )
{
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	const char *sheetname = ( const char*) hb_parc(2);
	lxw_row_t row = hb_parni(3);
	lxw_col_t col = hb_parni(4);
	
		
	chart_title_set_name_range (chart, sheetname, row, col);

	hb_ret( );
}		

HB_FUNC( CHART_TITLE_SET_NAME_FONT )
{
		
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_font *font  = ( lxw_chart_font *) hb_parvptr(2);

	chart_title_set_name_font (chart, font);

	hb_ret( );
}

HB_FUNC( CHART_TITLE_OFF )
{

	lxw_chart *chart = (lxw_chart *) hb_parptr(1);

		
	chart_title_off( chart );

	hb_ret( );
}		

HB_FUNC( CHART_LEGEND_SET_POSITION )
{
		
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	uint8_t position =  hb_parni(2);
			
	chart_legend_set_position ( chart, position);
	
	hb_ret( );
}  

HB_FUNC( CHART_LEGEND_SET_FONT )
{
		
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_font *font  = ( lxw_chart_font *) hb_parvptr(2);
	
	chart_legend_set_font (chart, font);

	hb_ret( );
}
 
HB_FUNC( CHART_LEGEND_DELETE_SERIES )
{
	PHB_ITEM pItem = hb_param( 2, HB_IT_ANY );
	int array  = hb_arrayLen( pItem );
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);

	int16_t  delete_series[1258] = {0}; 
	int i;
	for (i = 0; i < array; i++)
        delete_series[i] = hb_parvni(2,i+1);
	delete_series[i+1] = NULL;
	
	hb_retl( (int) chart_legend_delete_series (chart, delete_series)  );
}

HB_FUNC( CHART_CHARTAREA_SET_LINE )
{
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_line *line  = ( lxw_chart_line *)  hb_parvptr(2);
	
	
	chart_chartarea_set_line ( chart, line);
	
	hb_ret( );
}

HB_FUNC( CHART_CHARTAREA_SET_FILL )
{
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_fill *fill  = ( lxw_chart_fill *) hb_parvptr(2);
	
	chart_chartarea_set_fill ( chart, fill);
	
	hb_ret( );
}

HB_FUNC( CHART_CHARTAREA_SET_PATTERN )
{
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_pattern *pattern  = (lxw_chart_pattern *) hb_parvptr(2);
	
	chart_chartarea_set_pattern ( chart, pattern);
	
	hb_ret( );
}

HB_FUNC( CHART_PLOTAREA_SET_LINE )
{
		
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_line *line  = ( lxw_chart_line *)  hb_parvptr(2);
		
	
	chart_plotarea_set_line ( chart, line);

	hb_ret( );
}

HB_FUNC( CHART_PLOTAREA_SET_FILL )
{
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_fill *fill = ( lxw_chart_fill *) hb_parvptr(2);
	
	chart_plotarea_set_fill ( chart, fill);
	
	hb_ret( );
}

HB_FUNC( CHART_PLOTAREA_SET_PATTERN )
{
	
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	lxw_chart_pattern *pattern  = (lxw_chart_pattern *) hb_parvptr(2);
	
	chart_plotarea_set_pattern (chart, pattern);
	
	hb_ret( );
}

HB_FUNC( CHART_SET_STYLE )
{
		
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
	uint8_t style_id =  hb_parni(2);
			
	chart_set_style ( chart, style_id);
	
	hb_ret( );
}  

HB_FUNC( CHART_SET_TABLE )
{
		
	lxw_chart *chart = (lxw_chart *) hb_parptr(1);
			
	chart_set_table ( chart );
	
	hb_ret( );
}  

HB_FUNC( CHART_SET_TABLE_GRID )
{
		
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	uint8_t horizontal	=  hb_parni(2);
	uint8_t vertical  	=  hb_parni(3);
	uint8_t outline		=  hb_parni(4);
	uint8_t legend_keys	=  hb_parni(5);
			
	chart_set_table_grid ( chart, horizontal, vertical, outline, legend_keys);
	
	hb_ret( );
}  

HB_FUNC( CHART_SET_UP_DOWN_BARS )
{
		
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
			
	chart_set_up_down_bars (chart);
	
	hb_ret( );
}  

HB_FUNC( CHART_SET_UP_DOWN_BARS_FORMAT )
{
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	lxw_chart_line *up_bar_line   	= ( lxw_chart_line *)  hb_parvptr(2);
	lxw_chart_fill *up_bar_fill 	= ( lxw_chart_fill *) hb_parvptr(3);
	lxw_chart_line *down_bar_line  	= ( lxw_chart_line *)  hb_parvptr(4);
	lxw_chart_fill *down_bar_fill 	= ( lxw_chart_fill *) hb_parvptr(5);
	
	chart_set_up_down_bars_format (chart, up_bar_line, up_bar_fill, down_bar_line, down_bar_fill);
	
	hb_ret( );
}

HB_FUNC( CHART_SET_DROP_LINES )
{
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	lxw_chart_line *line   	 = (lxw_chart_line *) hb_parvptr(2);
	
	chart_set_drop_lines ( chart, line);
	
	hb_ret( );
}

HB_FUNC( CHART_SET_HIGH_LOW_LINES )
{
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	lxw_chart_line *line   	 = ( lxw_chart_line *)  hb_parvptr(2);
	
	chart_set_high_low_lines (chart, line);
	
	hb_ret( );
}

HB_FUNC( CHART_SET_SERIES_OVERLAP )
{
		
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	int8_t overlap		= hb_parni(2);
			
	chart_set_series_overlap ( chart, overlap);
	
	hb_ret( );
}  

HB_FUNC( CHART_SET_SERIES_GAP )
{
		
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	uint8_t gap			= hb_parni(2);
			
	chart_set_series_gap ( chart,  gap);
	
	hb_ret( );
}  

HB_FUNC( CHART_SHOW_BLANKS_AS )
{
		
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	uint8_t option		= hb_parni(2);
			
	chart_show_blanks_as ( chart, option);
	
	hb_ret( );
}  

HB_FUNC( CHART_SHOW_HIDDEN_DATA )
{
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
			
	chart_show_hidden_data (chart);
	
	hb_ret( );
}  

HB_FUNC( CHART_SET_ROTATION )
{
		
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	uint8_t rotation		= hb_parni(2);
			
	chart_set_rotation ( chart, rotation);
	
	hb_ret( );
}  

HB_FUNC( CHART_SET_HOLE_SIZE )
{
		
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(1);
	uint8_t size		= hb_parni(2);
			
	chart_set_hole_size ( chart, size);
	
	hb_ret( );
}  
//***************//
//   Chartsheet
//***************//  
 
HB_FUNC( CHARTSHEET_SET_CHART )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	lxw_chart *chart 	= (lxw_chart *) hb_parptr(2);
	 
	hb_retl( (int) chartsheet_set_chart(chartsheet, chart) );
	
	//hb_ret( );
}  

HB_FUNC( CHARTSHEET_ACTIVATE )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1); 
	 
	chartsheet_activate(chartsheet);
	
	 hb_ret( );
}  

HB_FUNC( CHARTSHEET_SELECT )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	 
	chartsheet_select(chartsheet);
	
	 hb_ret( );
}  

HB_FUNC( CHARTSHEET_HIDE )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	 
	chartsheet_hide(chartsheet);
	
	 hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_FIRST_SHEET )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	 
	chartsheet_set_first_sheet(chartsheet);
	
	 hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_TAB_COLOR )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	lxw_color_t color = hb_parni(2);
	
	chartsheet_set_tab_color(chartsheet, color);
	
	 hb_ret( );
}  

HB_FUNC( CHARTSHEET_PROTECT )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	const char *password = (const char *) hb_parc(2);
	lxw_protection *options = (lxw_protection *)	 hb_parptr(3);
	
	chartsheet_protect(chartsheet, password, options);
	
	 hb_ret( );
}  
 
HB_FUNC( CHARTSHEET_SET_ZOOM )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	uint16_t scale = hb_parni(2);
	 
	
	chartsheet_set_zoom(chartsheet, scale);
	
	 hb_ret( );
}  
 
HB_FUNC( CHARTSHEET_SET_LANDSCAPE )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	 
	chartsheet_set_landscape(chartsheet);
	
	hb_ret( );
}  
 
HB_FUNC( CHARTSHEET_SET_PORTRAIT )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	 
	chartsheet_set_portrait(chartsheet);
	
	hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_PAPER )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	uint8_t paper_size = hb_parni(2);
 	
	chartsheet_set_paper(chartsheet, paper_size);
	
	hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_MARGINS )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	double left = hb_parni(2);
	double right = hb_parni(3);
	double top = hb_parni(4);
	double bottom = hb_parni(5);
  	
	chartsheet_set_margins(chartsheet, left, right, top, bottom);
	
	hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_HEADER )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	const char *string = hb_parc(2);
   	
	chartsheet_set_header(chartsheet, string);
	
	hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_FOOTER )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	const char *string = hb_parc(2);
   	
	chartsheet_set_footer(chartsheet, string);
	
	hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_HEADER_OPT )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	const char *string = hb_parc(2);
	lxw_header_footer_options *options = (lxw_header_footer_options *)	 hb_parptr(3);
 	
	chartsheet_set_header_opt(chartsheet, string, options);
	
	hb_ret( );
}  

HB_FUNC( CHARTSHEET_SET_FOOTER_OPT )
{
	
	lxw_chartsheet *chartsheet = (lxw_chartsheet *)	 hb_parptr(1);
	const char *string = hb_parc(2);
	lxw_header_footer_options *options = (lxw_header_footer_options *)	 hb_parptr(3);
 	
	chartsheet_set_footer_opt(chartsheet, string, options);
	
	hb_ret( );
}  


//***************//
//      format
//***************//

HB_FUNC( FORMAT_SET_FONT_NAME )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	const char *font_name = ( const char*) hb_parc(2);
	format_set_font_name (format, font_name);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_FONT_SIZE )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint16_t size =  hb_parni(2);
	format_set_font_size (format, size);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_FONT_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_font_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_BOLD )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	format_set_bold (format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_ITALIC )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	format_set_italic (format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_UNDERLINE )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t style =  hb_parni(2);
	format_set_underline (format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_FONT_STRIKEOUT )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	format_set_font_strikeout (format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_FONT_SCRIPT )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t style =  hb_parni(2);
	format_set_font_script (format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_NUM_FORMAT )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	const char *num_format = ( const char*) hb_parc(2);
	format_set_num_format (format, num_format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_NUM_FORMAT_INDEX )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t index =  hb_parni(2);
	format_set_num_format_index (format, index);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_UNLOCKED )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	format_set_unlocked (format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_HIDDEN )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	format_set_hidden (format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_ALIGN )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t alignment =  hb_parni(2);
	format_set_align (format, alignment);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_TEXT_WRAP )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	format_set_text_wrap (format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_ROTATION )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	int16_t angle =  hb_parni(2);
	format_set_rotation (format, angle);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_INDENT )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t level =  hb_parni(2);
	format_set_indent (format, level);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_SHRINK )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	format_set_shrink (format);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_PATTERN )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t index =  hb_parni(2);
	format_set_pattern (format, index);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_BG_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_bg_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_FG_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_fg_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_BORDER )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t style =  hb_parni(2);
	format_set_border (format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_BOTTOM )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t style =  hb_parni(2);
	format_set_bottom (format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_TOP )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t style =  hb_parni(2);
	format_set_top (format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_LEFT )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t style =  hb_parni(2);
	format_set_left (format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_RIGHT )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t style =  hb_parni(2);
	format_set_right (format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_BORDER_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_border_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_BOTTOM_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_bottom_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_TOP_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_top_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_LEFT_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_left_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_RIGHT_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_right_color (format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_DIAG_TYPE )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t type =  hb_parni(2);
	format_set_diag_type(format, type);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_DIAG_BORDER )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	uint8_t  style =  hb_parni(2);
	format_set_diag_border(format, style);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_DIAG_COLOR )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
	lxw_color_t color =  hb_parni(2);
	format_set_diag_color(format, color);
	hb_retptr( format );
}

HB_FUNC( FORMAT_SET_QUOTE_PREFIX )
{
	lxw_format *format = (lxw_format *) hb_parptr(1);
 
	format_set_quote_prefix(format );
	hb_retptr( format );
}

 
HB_FUNC( LXW_NAME_TO_ROW )
{
	
	lxw_row_t row_num = 0;
    const char *p =  ( const char*) hb_parc(1);

    while (p && !isdigit((unsigned char) *p))
        p++;

    if (p)
        row_num = atoi(p);

    if (row_num)
		hb_retni(   row_num - 1);
    else
        hb_retni( 0 );
	
	
}

HB_FUNC( LXW_NAME_TO_ROW_2 )
{
	const char *p = ( const char*) hb_parc(1);

    /* Find the : separator in the range. */
    while (p && *p != ':')
        p++;

    if (p)
        hb_retni( lxw_name_to_row(++p) );
    else
        hb_retni( -1 );
	
}

HB_FUNC( LXW_NAME_TO_COL )
{
	
	lxw_col_t col_num = 0;
		
    const char *p = ( const char*) hb_parc(1);;

    /* Convert leading column letters of A1 cell. Ignore absolute $ marker. */
    while (p && (isupper((unsigned char) *p) || *p == '$')) {
        if (*p != '$')
            col_num = (col_num * 26) + (*p - 'A' + 1);
        p++;
    }
 
    hb_retni(col_num - 1);
}

HB_FUNC( LXW_NAME_TO_COL_2 )
{
	 
	
	const char *p =  (const char*) hb_parc(1);

    /* Find the : separator in the range. */
    while (p && *p != ':')
        p++;

    if (p)
         hb_retni( lxw_name_to_col(++p));
    else
         hb_retni(-1);
}
 
HB_FUNC( DATA_VALID )
{
	lxw_data_validation *data_validation = calloc(1, sizeof(lxw_data_validation));
	data_validation->validate       = LXW_VALIDATION_TYPE_INTEGER;
	data_validation->criteria       = LXW_VALIDATION_CRITERIA_BETWEEN;
	data_validation->minimum_number = 1;
	data_validation->maximum_number = 10;
	 
	hb_retptr(  data_validation );
 
}
 



