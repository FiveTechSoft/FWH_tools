#-------------------------------------------------------------------------------
#  AUTOR.....: Manuel Expósito Suárez   Soft4U 2002-2020
#  CLASE.....: lib
#  FECHA MOD.: 20/02/2020
#  VERSION...: 1.00
#  PROPOSITO.: Script de borrado de las LIB para linux
#-------------------------------------------------------------------------------

echo Limpia entorno
if [ -d lib ]
then

    rm -r ./lib
fi
cd ./cmd/linux
if [ -f clang.log ] || [ -f gcc.log ]
then

    rm *.log
fi
echo Proceso terminado....
