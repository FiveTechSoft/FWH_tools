cd test
if [ -x $demo ];
then
    gnome-terminal -e ./demo
else
    echo ---------------------------------
    echo    No existe el ejecutable...
    echo ---------------------------------
fi
