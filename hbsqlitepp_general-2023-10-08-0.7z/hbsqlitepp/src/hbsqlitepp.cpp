//-----------------------------------------------------------------------------
// Archivo: hbsqlitepp.cpp
// Clase: THbSQLitepp
//-----------------------------------------------------------------------------

#include "hbsqlitepp.h"
#include "hbinit.h"

//-----------------------------------------------------------------------------
// Declaracion de funciones privadas de los metodos de Harbour

HB_FUNC_STATIC( THBSQLITEPP_NEW );
HB_FUNC_STATIC( THBSQLITEPP_OPEN );
HB_FUNC_STATIC( THBSQLITEPP_CLOSE );
HB_FUNC_STATIC( THBSQLITEPP_EXEC );
HB_FUNC_STATIC( THBSQLITEPP_QUERY );
HB_FUNC_STATIC( THBSQLITEPP_GETLASTERROR );
HB_FUNC_STATIC( THBSQLITEPP_GETERRCODE );
HB_FUNC_STATIC( THBSQLITEPP_ISFAILURE );
HB_FUNC_STATIC( THBSQLITEPP_END );

// Lista de Metodos xBase
void THbSQLitepp::addMethods( HB_USHORT usClassH ) const
{
	hb_clsAdd( usClassH, "NEW", HB_FUNCNAME( THBSQLITEPP_NEW ) );
	hb_clsAdd( usClassH, "OPEN", HB_FUNCNAME( THBSQLITEPP_OPEN ) );
	hb_clsAdd( usClassH, "CLOSE", HB_FUNCNAME( THBSQLITEPP_CLOSE ) );
	hb_clsAdd( usClassH, "EXEC", HB_FUNCNAME( THBSQLITEPP_EXEC ) );
	hb_clsAdd( usClassH, "QUERY", HB_FUNCNAME( THBSQLITEPP_QUERY ) );
	hb_clsAdd( usClassH, "GETLASTERROR", HB_FUNCNAME( THBSQLITEPP_GETLASTERROR ) );
	hb_clsAdd( usClassH, "GETERRCODE", HB_FUNCNAME( THBSQLITEPP_GETERRCODE ) );
	hb_clsAdd( usClassH, "ISFAILURE", HB_FUNCNAME( THBSQLITEPP_ISFAILURE ) );
	hb_clsAdd( usClassH, "END", HB_FUNCNAME( THBSQLITEPP_END ) );
}

//---------------------------------------------------------------------
// Constructores C++

THbSQLitepp::THbSQLitepp( void )
{
	db = nullptr;
	szDbName = nullptr;
}

THbSQLitepp::~THbSQLitepp( void )
{
	close();
	sqlite3_shutdown();

	if( szDbName )
	{
		hb_xfree( szDbName );
		szDbName = nullptr;
	}
}

// Constructor. Inicializa las variables de instancia
void THbSQLitepp::init( void )
{
	sqlite3_initialize();
}

void THbSQLitepp::init( PHB_ITEM cDbFileName )
{
	szDbName = hb_itemGetC( cDbFileName );
	sqlite3_initialize();
}

// Abre la db y si no existe la crea por defecto
bool THbSQLitepp::open( void )
{
	bool bRet;

	bRet = ( sqlite3_open( szDbName, &db ) == SQLITE_OK );

	if( !bRet )
	{
		sqlite3_close( db );
	}

	return bRet;
}

// Cierra la base de datos
void THbSQLitepp::close( void ) const
{
	sqlite3_close( db );
}

// Ejecuta una sentencia que no devuelve un conjunto de resultados
bool THbSQLitepp::exec( const char *szStmt )
{
	bool bRet;
	char *errMsg;

	bRet = ( sqlite3_exec( db, szStmt, nullptr, nullptr, &errMsg ) ) == SQLITE_OK;

	if( !bRet )
	{
		sqlite3_free( errMsg );
	}

	return bRet;
}

// Ejecuta una sentencia que devuelve un conjunto de resultados
PHB_ITEM THbSQLitepp::query( const char *szQuery, PHB_ITEM aColName )
{
	PHB_ITEM aRet;
	char **result;
	int nRow, nCol;
	char *errMsg;
	bool bRet;

	bRet = ( sqlite3_get_table( db, szQuery, &result, &nRow, &nCol, &errMsg ) == SQLITE_OK );

	if( bRet )
	{
		int nTotDat, n, i, x = 0;
		PHB_ITEM aRec = hb_itemNew( nullptr );

		hb_arraySize( aColName, nCol );

		//---------------------------------------
		// Nombres de campo
		i = 0;

		for( n = 0; n < nCol; n++ )
		{
			hb_arraySetC( aColName, n + 1, result[ i++ ] );
		}

		//---------------------------------------
		// Datos
		aRet = hb_itemArrayNew( nRow );
		nTotDat = nRow * nCol + 1;

		while( i < nTotDat )
		{
			hb_arrayNew( aRec, nCol );

			for( n = 0; n < nCol; n++ )
			{
				hb_arraySetC( aRec, n + 1, result[ i++ ] );
			}

			hb_arraySet( aRet, ++x, aRec );
		}

		hb_itemRelease( aRec );
	}
	else
	{
		aRet = hb_itemArrayNew( 0 );
		hb_arrayNew( aColName, 0 );
	}

	sqlite3_free( errMsg );
	sqlite3_free_table( result );

	return aRet;
}

const char *THbSQLitepp::getLastError( void )
{
	return sqlite3_errmsg( db );
}

int THbSQLitepp::getErrCode( void )
{
	return sqlite3_extended_errcode( db );
}

//=============================================================================
// Funcion de clase para usar desde Harbour
//=============================================================================

HB_FUNC( THBSQLITEPP )
{
	static HB_USHORT usClassH = 0;
	THbSQLitepp *pObjC = new THbSQLitepp;

	if( usClassH == 0 )
	{
		usClassH = pObjC->createClass( _NUN_VARS, "THBSQLITEPP" );
	}

	hb_clsAssociate( usClassH );
	hb_arraySetPtr( hb_stackReturnItem(), _OBJC_POS, pObjC );
}

//=============================================================================
// Metodos de la clase THbSQLitepp (harbour)
//=============================================================================

HB_FUNC_STATIC( THBSQLITEPP_NEW )
{
	PHB_ITEM pSelf = hb_stackSelfItem();
	THbSQLitepp *pObjC = _GETOBJC1( pSelf );
	PHB_ITEM cDbName = hb_param( 1, HB_IT_STRING );

	pObjC->init( cDbName );

	hb_itemReturn( pSelf );
}

HB_FUNC_STATIC( THBSQLITEPP_OPEN )
{
	THbSQLitepp *pObjC = _GETOBJC0();

	hb_retl( pObjC->open() );
}

HB_FUNC_STATIC( THBSQLITEPP_CLOSE )
{
	THbSQLitepp *pObjC = _GETOBJC0();

	pObjC->close();
}

HB_FUNC_STATIC( THBSQLITEPP_EXEC )
{
	THbSQLitepp *pObjC = _GETOBJC0();

	hb_retl( pObjC->exec( hb_parc( 1 ) ) );
}

HB_FUNC_STATIC( THBSQLITEPP_QUERY )
{
	THbSQLitepp *pObjC = _GETOBJC0();

	hb_itemReturnRelease( pObjC->query( hb_parc( 1 ), hb_param( 2, HB_IT_ARRAY ) ) );
}

HB_FUNC_STATIC( THBSQLITEPP_GETLASTERROR )
{
	THbSQLitepp *pObjC = _GETOBJC0();

	hb_itemReturnRelease( hb_itemPutC( nullptr, pObjC->getLastError() ) );
}

HB_FUNC_STATIC( THBSQLITEPP_GETERRCODE )
{
	THbSQLitepp *pObjC = _GETOBJC0();

	hb_itemReturnRelease( hb_itemPutNI( nullptr, pObjC->getErrCode() ) );
}

HB_FUNC_STATIC( THBSQLITEPP_ISFAILURE )
{
	THbSQLitepp *pObjC = _GETOBJC0();
	int iErr = pObjC->getErrCode();
	HB_BOOL bErr = ( iErr != 0 );

	if( bErr )
	{
		PHB_ITEM nCodErr = hb_param( 1, HB_IT_BYREF );
		PHB_ITEM cErrMsg = hb_param( 2, HB_IT_BYREF );

		if( nCodErr )
		{
			hb_storni( iErr, 1 );
		}

		if( cErrMsg )
		{
			hb_storc( pObjC->getLastError(), 2 );
		}
	}

	hb_itemReturnRelease( hb_itemPutL( nullptr, bErr ) );
}

HB_FUNC_STATIC( THBSQLITEPP_END )
{
	PHB_ITEM pSelf = hb_stackSelfItem();
	THbSQLitepp *pObjC = _GETOBJC1( pSelf );

	delete pObjC;
	hb_arraySetPtr( pSelf, _OBJC_POS, nullptr );
}

//=============================================================================
// Inicializa los simbolos de las clase en la tabla de simbolos de harbour.
//=============================================================================

HB_INIT_SYMBOLS_BEGIN( THBSQLITEPP__InitSymbols )
{
	"THBSQLITEPP", { HB_FS_PUBLIC | HB_FS_LOCAL }, { HB_FUNCNAME( THBSQLITEPP ) }, nullptr
}
HB_INIT_SYMBOLS_END( THBSQLITEPP__InitSymbols )

#if defined( HB_PRAGMA_STARTUP )
	#pragma startup THBSQLITEPP__InitSymbols
#elif defined( HB_DATASEG_STARTUP )
	#define HB_DATASEG_BODY HB_DATASEG_FUNC( THBSQLITEPP__InitSymbols )
	#include "hbiniseg.h"
#endif

//-----------------------------------------------------------------------------
