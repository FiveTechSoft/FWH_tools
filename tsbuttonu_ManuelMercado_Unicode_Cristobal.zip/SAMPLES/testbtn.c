/*
 * xHarbour 1.2.3 Intl. (SimpLex) (Build 20150603)
 * Generated C source code from <testbtn.prg>
 * Command: testbtn /n /id:\fwh1506\include;d:\xharbour1506\include /w /p 
 * Created: 2015.07.28 16:29:16 (Borland/Embarcadero C++ 7.0 (32-bit))
 */

#include "hbvmpub.h"
#include "hbpcode.h"
#include "hbinit.h"

#define __PRG_SOURCE__ "testbtn.prg"

/* Forward declarations of all PRG defined Functions. */
HB_FUNC( MAIN );
HB_FUNC_STATIC( CHILD1 );
HB_FUNC_STATIC( BUILDMENU );
HB_FUNC_STATIC( SHOWBITMAPS );
HB_FUNC_STATIC( FRESOURCE );
HB_FUNC_STATIC( MENUPOP );
HB_FUNC_STATIC( MENUARCH );
HB_FUNC_STATIC( CHILD2 );
HB_FUNC_STATIC( CHILD3 );
HB_FUNC_STATIC( FCANCEL );
HB_FUNC_STATIC( FCODIGO );
HB_FUNC_INITSTATICS();

/* Forward declarations of all externally defined Functions. */
/* Skipped DEFERRED call to: 'DIVERTCONSTRUCTORCALL' */
HB_FUNC_EXTERN( GETPROCADD );
HB_FUNC_EXTERN( TACTIVEX );
HB_FUNC_EXTERN( ERRORSYS );
HB_FUNC_EXTERN( TICON );
HB_FUNC_EXTERN( TMDIFRAME );
HB_FUNC_EXTERN( TFONT );
HB_FUNC_EXTERN( TBRUSH );
HB_FUNC_EXTERN( TMDICHILD );
HB_FUNC_EXTERN( NOR );
HB_FUNC_EXTERN( TSBAR );
HB_FUNC_EXTERN( TSBUTTON );
HB_FUNC_EXTERN( TONE );
HB_FUNC_EXTERN( ASEND );
HB_FUNC_EXTERN( NRGB );
HB_FUNC_EXTERN( TMSGBAR );
HB_FUNC_EXTERN( MSGBLINK );
HB_FUNC_EXTERN( AEVAL );
HB_FUNC_EXTERN( DELETEOBJECT );
HB_FUNC_EXTERN( MENUBEGIN );
HB_FUNC_EXTERN( MENUADDITEM );
HB_FUNC_EXTERN( WINEXEC );
HB_FUNC_EXTERN( MENUEND );
HB_FUNC_EXTERN( TSAY );
HB_FUNC_EXTERN( TBITMAP );
HB_FUNC_EXTERN( ARRAY );
HB_FUNC_EXTERN( SPACE );
HB_FUNC_EXTERN( TDIALOG );
HB_FUNC_EXTERN( TGET );
HB_FUNC_EXTERN( PCOUNT );
HB_FUNC_EXTERN( EMPTY );
HB_FUNC_EXTERN( MSGINFO );
HB_FUNC_EXTERN( TSLINES );
HB_FUNC_EXTERN( GETCLIENTRECT );
HB_FUNC_EXTERN( AFILL );
HB_FUNC_EXTERN( NAND );
HB_FUNC_EXTERN( NNOT );
HB_FUNC_EXTERN( TBAR );
HB_FUNC_EXTERN( LEN );

#undef HB_PRG_PCODE_VER
#define HB_PRG_PCODE_VER 10

#include "hbapi.h"

HB_INIT_SYMBOLS_BEGIN( hb_vm_SymbolInit_TESTBTN )
{ "DIVERTCONSTRUCTORCALL", {HB_FS_PUBLIC | HB_FS_DEFERRED}, {NULL}, NULL },
{ "GETPROCADD", {HB_FS_PUBLIC}, {HB_FUNCNAME( GETPROCADD )}, NULL },
{ "TACTIVEX", {HB_FS_PUBLIC}, {HB_FUNCNAME( TACTIVEX )}, NULL },
{ "ERRORSYS", {HB_FS_PUBLIC}, {HB_FUNCNAME( ERRORSYS )}, NULL },
{ "MAIN", {HB_FS_PUBLIC | HB_FS_LOCAL | HB_FS_FIRST}, {HB_FUNCNAME( MAIN )}, &ModuleFakeDyn },
{ "NEW", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TICON", {HB_FS_PUBLIC}, {HB_FUNCNAME( TICON )}, NULL },
{ "TMDIFRAME", {HB_FS_PUBLIC}, {HB_FUNCNAME( TMDIFRAME )}, NULL },
{ "BUILDMENU", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( BUILDMENU )}, &ModuleFakeDyn },
{ "ACTIVATE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BLCLICKED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BRCLICKED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BMOVED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BRESIZED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BPAINTED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BKEYDOWN", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BINIT", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "END", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "BLBUTTONUP", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "CHILD1", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( CHILD1 )}, &ModuleFakeDyn },
{ "LACTIVE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "LMOUSEOVER", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "LPRESSED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TFONT", {HB_FS_PUBLIC}, {HB_FUNCNAME( TFONT )}, NULL },
{ "TBRUSH", {HB_FS_PUBLIC}, {HB_FUNCNAME( TBRUSH )}, NULL },
{ "TMDICHILD", {HB_FS_PUBLIC}, {HB_FUNCNAME( TMDICHILD )}, NULL },
{ "NOR", {HB_FS_PUBLIC}, {HB_FUNCNAME( NOR )}, NULL },
{ "TSBAR", {HB_FS_PUBLIC}, {HB_FUNCNAME( TSBAR )}, NULL },
{ "SETBRUSH", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "NEWBAR", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TSBUTTON", {HB_FS_PUBLIC}, {HB_FUNCNAME( TSBUTTON )}, NULL },
{ "CHILD2", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( CHILD2 )}, &ModuleFakeDyn },
{ "CHILD3", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( CHILD3 )}, &ModuleFakeDyn },
{ "MENUPOP", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( MENUPOP )}, &ModuleFakeDyn },
{ "SETTEXT", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TONE", {HB_FS_PUBLIC}, {HB_FUNCNAME( TONE )}, NULL },
{ "REFRESH", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "AEVALWHEN", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "ASEND", {HB_FS_PUBLIC}, {HB_FUNCNAME( ASEND )}, NULL },
{ "ACONTROLS", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "SHOWBITMAPS", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( SHOWBITMAPS )}, &ModuleFakeDyn },
{ "_LEVERPRESS", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "SHAPE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "NRGB", {HB_FS_PUBLIC}, {HB_FUNCNAME( NRGB )}, NULL },
{ "FRESOURCE", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( FRESOURCE )}, &ModuleFakeDyn },
{ "FCODIGO", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( FCODIGO )}, &ModuleFakeDyn },
{ "_OMSGBAR", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TMSGBAR", {HB_FS_PUBLIC}, {HB_FUNCNAME( TMSGBAR )}, NULL },
{ "_BINIT", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "SETFOCUS", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "MSGBLINK", {HB_FS_PUBLIC}, {HB_FUNCNAME( MSGBLINK )}, NULL },
{ "AEVAL", {HB_FS_PUBLIC}, {HB_FUNCNAME( AEVAL )}, NULL },
{ "DELETEOBJECT", {HB_FS_PUBLIC}, {HB_FUNCNAME( DELETEOBJECT )}, NULL },
{ "MENUBEGIN", {HB_FS_PUBLIC}, {HB_FUNCNAME( MENUBEGIN )}, NULL },
{ "MENUADDITEM", {HB_FS_PUBLIC}, {HB_FUNCNAME( MENUADDITEM )}, NULL },
{ "WINEXEC", {HB_FS_PUBLIC}, {HB_FUNCNAME( WINEXEC )}, NULL },
{ "MENUEND", {HB_FS_PUBLIC}, {HB_FUNCNAME( MENUEND )}, NULL },
{ "TSAY", {HB_FS_PUBLIC}, {HB_FUNCNAME( TSAY )}, NULL },
{ "TBITMAP", {HB_FS_PUBLIC}, {HB_FUNCNAME( TBITMAP )}, NULL },
{ "ARRAY", {HB_FS_PUBLIC}, {HB_FUNCNAME( ARRAY )}, NULL },
{ "SPACE", {HB_FS_PUBLIC}, {HB_FUNCNAME( SPACE )}, NULL },
{ "TDIALOG", {HB_FS_PUBLIC}, {HB_FUNCNAME( TDIALOG )}, NULL },
{ "REDEFINE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TGET", {HB_FS_PUBLIC}, {HB_FUNCNAME( TGET )}, NULL },
{ "PCOUNT", {HB_FS_PUBLIC}, {HB_FUNCNAME( PCOUNT )}, NULL },
{ "EMPTY", {HB_FS_PUBLIC}, {HB_FUNCNAME( EMPTY )}, NULL },
{ "MSGINFO", {HB_FS_PUBLIC}, {HB_FUNCNAME( MSGINFO )}, NULL },
{ "MENUARCH", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( MENUARCH )}, &ModuleFakeDyn },
{ "_BPAINTED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TSLINES", {HB_FS_PUBLIC}, {HB_FUNCNAME( TSLINES )}, NULL },
{ "GETCLIENTRECT", {HB_FS_PUBLIC}, {HB_FUNCNAME( GETCLIENTRECT )}, NULL },
{ "HWND", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "AFILL", {HB_FS_PUBLIC}, {HB_FUNCNAME( AFILL )}, NULL },
{ "SETCOLOR", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "_NSTYLE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "NAND", {HB_FS_PUBLIC}, {HB_FUNCNAME( NAND )}, NULL },
{ "NSTYLE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "NNOT", {HB_FS_PUBLIC}, {HB_FUNCNAME( NNOT )}, NULL },
{ "_CCAPTION", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "DISABLE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "TBAR", {HB_FS_PUBLIC}, {HB_FUNCNAME( TBAR )}, NULL },
{ "NEWGROUP", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "LEN", {HB_FS_PUBLIC}, {HB_FUNCNAME( LEN )}, NULL },
{ "_CARGO", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "_BRCLICKED", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "FCANCEL", {HB_FS_STATIC | HB_FS_LOCAL}, {HB_FUNCNAME( FCANCEL )}, &ModuleFakeDyn },
{ "ENABLE", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "CARGO", {HB_FS_PUBLIC}, {NULL}, NULL },
{ "(_INITSTATICS00003)", {HB_FS_INITEXIT}, {hb_INITSTATICS}, &ModuleFakeDyn }
HB_INIT_SYMBOLS_END( hb_vm_SymbolInit_TESTBTN )

#if defined( HB_PRAGMA_STARTUP )
   #pragma startup hb_vm_SymbolInit_TESTBTN
#elif defined( HB_DATASEG_STARTUP )
   #define HB_DATASEG_BODY    HB_DATASEG_FUNC( hb_vm_SymbolInit_TESTBTN )
   #include "hbiniseg.h"
#endif

HB_FUNC( MAIN )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 3, 0,	/* locals, params */
	HB_P_SFRAME, 88, 0,	/* symbol (_INITSTATICS) */
/* 00006 */ HB_P_BASELINE, 13, 0,	/* 13 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYDIM, 1, 0,	/* 1 */
	HB_P_POPLOCALNEAR, 3,	/* OBTN */
/* 00016 */ HB_P_LINEOFFSET, 3,	/* 16 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 6,	/* TICON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'u', 'p', 'e', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 5,
	HB_P_POPLOCALNEAR, 2,	/* OICO */
/* 00042 */ HB_P_LINEOFFSET, 10,	/* 23 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 7,	/* TMDIFRAME */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_PUSHINT, 234, 1,	/* 490 */
	HB_P_PUSHINT, 88, 2,	/* 600 */
	HB_P_PUSHSTRSHORT, 35,	/* 35 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', ' ', 161, ' ', 'N', 'O', ' ', 'D', 'L', 'L', 39, 's', ' ', 'a', 't', ' ', 'a', 'l', 'l', ' ', '!', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSYMNEAR, 8,	/* BUILDMENU */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OICO */
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'o', 'W', 'n', 'd', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 19,
	HB_P_POPSTATIC, 2, 0,	/* OWND */
/* 00133 */ HB_P_LINEOFFSET, 13,	/* 26 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 10, 0,	/* BLCLICKED */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 11, 0,	/* BRCLICKED */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 12, 0,	/* BMOVED */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 13, 0,	/* BRESIZED */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 14, 0,	/* BPAINTED */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 15, 0,	/* BKEYDOWN */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 16, 0,	/* BINIT */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 19, 0,	/* 19 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	2, 0,	/* OICO */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_TRUE,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 18, 0,	/* BLBUTTONUP */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_FALSE,
	HB_P_SENDSHORT, 20,
	HB_P_POP,
/* 00238 */ HB_P_LINEOFFSET, 15,	/* 28 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 00243 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( CHILD1 )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 9, 0,	/* locals, params */
	HB_P_SFRAME, 88, 0,	/* symbol (_INITSTATICS) */
/* 00006 */ HB_P_BASELINE, 36, 0,	/* 36 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYDIM, 1, 0,	/* 1 */
	HB_P_POPLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHBYTE, 13,	/* 13 */
	HB_P_ARRAYDIM, 1, 0,	/* 1 */
	HB_P_POPLOCALNEAR, 6,	/* OBTN */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYDIM, 1, 0,	/* 1 */
	HB_P_POPLOCALNEAR, 7,	/* OBMP */
	HB_P_FALSE,
	HB_P_POPLOCALNEAR, 9,	/* LENABLE */
/* 00033 */ HB_P_LINEOFFSET, 6,	/* 42 */
	HB_P_PUSHBLOCK, 56, 0,	/* 56 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_NOT,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00059) */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_JUMPNEAR, 33,	/* 33 (abs: 00090) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00075) */
	HB_P_PUSHLONG, 0, 0, 255, 0, 	/* 16711680 */
	HB_P_JUMPNEAR, 17,	/* 17 (abs: 00090) */
	HB_P_MESSAGE, 22, 0,	/* LPRESSED */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 7,	/* 7 (abs: 00089) */
	HB_P_PUSHINT, 255, 0,	/* 255 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 00090) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_POPLOCALNEAR, 4,	/* BTCOLOR */
/* 00093 */ HB_P_LINEOFFSET, 8,	/* 44 */
	HB_P_PUSHBLOCK, 29, 0,	/* 29 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00118) */
	HB_P_PUSHLONG, 192, 192, 192, 0, 	/* 12632256 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 00123) */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_ENDBLOCK,
	HB_P_POPLOCALNEAR, 5,	/* BBCOLOR */
/* 00126 */ HB_P_LINEOFFSET, 10,	/* 46 */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSE, 148, 11,	/* 2964 (abs: 03099) */
/* 00138 */ HB_P_LINEOFFSET, 13,	/* 49 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 23,	/* TFONT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTRSHORT, 14,	/* 14 */
	'M', 'S', ' ', 'S', 'a', 'n', 's', ' ', 'S', 'e', 'r', 'i', 'f', 0, 
	HB_P_ZERO,
	HB_P_PUSHBYTE, 250,	/* -6 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 17,
	HB_P_PUSHLOCALREF, 2, 0,	/* OFONT */
	HB_P_ONE,
	HB_P_ARRAYPOP,
/* 00188 */ HB_P_LINEOFFSET, 14,	/* 50 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 23,	/* TFONT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTRSHORT, 14,	/* 14 */
	'M', 'S', ' ', 'S', 'a', 'n', 's', ' ', 'S', 'e', 'r', 'i', 'f', 0, 
	HB_P_ZERO,
	HB_P_PUSHBYTE, 248,	/* -8 */
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 17,
	HB_P_PUSHLOCALREF, 2, 0,	/* OFONT */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
/* 00239 */ HB_P_LINEOFFSET, 15,	/* 51 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 6,	/* TICON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'u', 'p', 'e', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 5,
	HB_P_POPLOCALNEAR, 1,	/* OICO */
/* 00265 */ HB_P_LINEOFFSET, 16,	/* 52 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 24,	/* TBRUSH */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'W', 'P', 'a', 'p', 'e', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 6,
	HB_P_POPLOCALNEAR, 3,	/* OBRUSH */
/* 00293 */ HB_P_LINEOFFSET, 22,	/* 58 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 25,	/* TMDICHILD */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_ZERO,
	HB_P_PUSHINT, 90, 1,	/* 346 */
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_PUSHSTRSHORT, 53,	/* 53 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', ' ', 161, ' ', 'A', 'n', 'y', ' ', 'p', 'u', 'r', 'p', 'o', 's', 'e', ' ', 'b', 'u', 't', 't', 'o', 'n', 's', ' ', 'w', 'i', 't', 'h', ' ', 'N', 'O', ' ', 'D', 'L', 'L', 39, 's', ' ', '!', 0, 
	HB_P_PUSHSYMNEAR, 26,	/* NOR */
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 0, 0, 64, 0, 	/* 4194304 */
	HB_P_PUSHLONG, 0, 0, 0, 16, 	/* 268435456 */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHNIL,
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_PUSHLOCALNEAR, 1,	/* OICO */
	HB_P_FALSE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 24,
	HB_P_PUSHSTATICREF, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPOP,
/* 00413 */ HB_P_LINEOFFSET, 24,	/* 60 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 27,	/* TSBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 12,
	HB_P_POPLOCALNEAR, 8,	/* OBAR */
/* 00445 */ HB_P_LINEOFFSET, 25,	/* 61 */
	HB_P_MESSAGE, 28, 0,	/* SETBRUSH */
	HB_P_PUSHLOCALNEAR, 8,	/* OBAR */
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00457 */ HB_P_LINEOFFSET, 34,	/* 70 */
	HB_P_MESSAGE, 29, 0,	/* NEWBAR */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 8,	/* OBAR */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 17,	/* 17 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'T', 'r', 'a', 'f', 'i', 'c', 'a', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 13, 0,	/* 13 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 31,	/* CHILD2 */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	9, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 37,	/* 37 */
	'A', 'n', 'i', 'm', 'a', 't', 'e', 'd', ' ', 'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'B', 'u', 't', 't', 'o', 'n', 'b', 'a', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'A', 'n', 'i', 'm', 'a', 't', 'e', 'd', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 23,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_ONE,
	HB_P_ARRAYPOP,
/* 00601 */ HB_P_LINEOFFSET, 43,	/* 79 */
	HB_P_MESSAGE, 29, 0,	/* NEWBAR */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 8,	/* OBAR */
	HB_P_PUSHBYTE, 40,	/* 40 */
	HB_P_PUSHBYTE, 40,	/* 40 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'S', 'u', 'p', 'e', 'r', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'S', 'u', 'p', 'e', 'r', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'S', 'u', 'p', 'e', 'r', '3', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'S', 'u', 'p', 'e', 'r', '2', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 13, 0,	/* 13 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 32,	/* CHILD3 */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 17,	/* 17 */
	'B', 'u', 's', ' ', 'r', 'e', 's', 'e', 'r', 'v', 'a', 't', 'i', 'o', 'n', 's', 0, 
	HB_P_PUSHSTRSHORT, 16,	/* 16 */
	'B', 'u', 't', 't', 'o', 'n', ' ', 'M', 'a', 't', 'r', 'i', 'x', 'e', 's', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_PUSHBLOCK, 19, 0,	/* 19 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	6, 0,	/* OBTN */
	HB_P_PUSHSYMNEAR, 33,	/* MENUPOP */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 23,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 7,	/* 7 */
	HB_P_ARRAYPOP,
/* 00763 */ HB_P_LINEOFFSET, 51,	/* 87 */
	HB_P_MESSAGE, 29, 0,	/* NEWBAR */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 8,	/* OBAR */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'C', 'u', 't', '1', 0, 
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'C', 'u', 't', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'C', 'u', 't', '2', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'B', 'u', 't', 't', 'o', 'n', 'b', 'a', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 23,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYPOP,
/* 00879 */ HB_P_LINEOFFSET, 58,	/* 94 */
	HB_P_MESSAGE, 29, 0,	/* NEWBAR */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 8,	/* OBAR */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'P', 'a', 's', 't', 'e', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'P', 'a', 's', 't', 'e', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'P', 'a', 's', 't', 'e', '2', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'B', 'u', 't', 't', 'o', 'n', 'b', 'a', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 23,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 9,	/* 9 */
	HB_P_ARRAYPOP,
/* 01001 */ HB_P_LINEOFFSET, 65,	/* 101 */
	HB_P_MESSAGE, 29, 0,	/* NEWBAR */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 8,	/* OBAR */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'D', 'e', 'l', '1', 0, 
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'D', 'e', 'l', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'D', 'e', 'l', '2', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'B', 'u', 't', 't', 'o', 'n', 'b', 'a', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 23,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_ARRAYPOP,
/* 01117 */ HB_P_LINEOFFSET, 75,	/* 111 */
	HB_P_MESSAGE, 29, 0,	/* NEWBAR */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 8,	/* OBAR */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'E', 'x', 'i', 't', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 48,	/* 48 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'B', 'u', 't', 't', 'o', 'n', 'b', 'a', 'r', 's', ' ', 'w', 'i', 't', 'h', ' ', '3', 'D', ' ', 't', 'e', 'x', 't', ' ', 'r', 'a', 'i', 's', 'e', 'd', 0, 
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 23,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
/* 01255 */ HB_P_LINEOFFSET, 78,	/* 114 */
	HB_P_MESSAGE, 34, 0,	/* SETTEXT */
	HB_P_PUSHLOCALNEAR, 6,	/* OBTN */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_SENDSHORT, 4,
	HB_P_POP,
/* 01272 */ HB_P_LINEOFFSET, 83,	/* 119 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 60,	/* 60 */
	HB_P_PUSHBYTE, 80,	/* 80 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 15,	/* 15 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'B', 'u', 's', 'I', 'n', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 36,	/* 36 */
	HB_P_PUSHBYTE, 36,	/* 36 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 16, 0,	/* 16 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 35,	/* TONE */
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	9, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 16,	/* 16 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'B', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 11,	/* 11 */
	HB_P_ARRAYPOP,
/* 01389 */ HB_P_LINEOFFSET, 101,	/* 137 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 60,	/* 60 */
	HB_P_PUSHINT, 140, 0,	/* 140 */
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'A', 'c', 't', 'i', 'v', 'a', 't', 'e', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'L', 'a', 'm', 'p', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'L', 'a', 'm', 'p', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'L', 'a', 'm', 'p', '3', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'S', 'h', 'a', 'p', 'e', '3', 0, 
	HB_P_ARRAYGEN, 5, 0,	/* 5 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 74,	/* 74 */
	HB_P_PUSHBYTE, 26,	/* 26 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 116, 0,	/* 116 */
	1, 0,	/* number of local parameters (1) */
	5, 0,	/* number of local variables (5) */
	9, 0,	/* LENABLE */
	6, 0,	/* OBTN */
	8, 0,	/* OBAR */
	2, 0,	/* OFONT */
	7, 0,	/* OBMP */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_NOT,
	HB_P_POPLOCALNEAR, 255,	/* localvar1 */
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 37, 0,	/* AEVALWHEN */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 37, 0,	/* AEVALWHEN */
	HB_P_PUSHLOCALNEAR, 253,	/* localvar3 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_PUSHSYMNEAR, 38,	/* ASEND */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 39, 0,	/* ACONTROLS */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'R', 'e', 'f', 'r', 'e', 's', 'h', 0, 
	HB_P_DOSHORT, 2,
	HB_P_PUSHSYMNEAR, 40,	/* SHOWBITMAPS */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 252,	/* localvar4 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 251,	/* localvar5 */
	HB_P_DOSHORT, 2,
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_JUMPFALSENEAR, 15,	/* 15 (abs: 01570) */
	HB_P_MESSAGE, 41, 0,	/* _LEVERPRESS */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_TRUE,
	HB_P_SENDSHORT, 1,
	HB_P_JUMPNEAR, 13,	/* 13 (abs: 01581) */
	HB_P_MESSAGE, 41, 0,	/* _LEVERPRESS */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_FALSE,
	HB_P_SENDSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 101,	/* 101 */
	'S', 'e', 'e', ' ', 'n', 'e', 'w', ' ', 34, 'S', 'h', 'a', 'p', 'e', 34, ' ', 'f', 'e', 'a', 't', 'u', 'r', 'e', ' ', 'a', 'n', 'd', ' ', '3', 'D', ' ', 't', 'e', 'x', 't', ' ', '(', 'b', 'a', 's', '-', 'r', 'e', 'l', 'i', 'e', 'f', ')', ',', ' ', 's', 'p', 'e', 'c', 'i', 'f', 'i', 'c', ' ', 'p', 'o', 's', 'i', 't', 'i', 'o', 'n', ',', ' ', 's', 'p', 'e', 'c', 'i', 'f', 'i', 'c', ' ', '3', 'D', ' ', 'c', 'o', 'l', 'o', 'r', 's', ',', ' ', 'E', 'v', 'e', 'r', 'p', 'r', 'e', 's', 's', 'e', 'd', 0, 
	HB_P_PUSHSTRSHORT, 30,	/* 30 */
	'A', 'c', 't', 'i', 'v', 'a', 't', 'e', ' ', '/', ' ', 'D', 'e', 'a', 'c', 't', 'i', 'v', 'a', 't', 'e', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_ZERO,
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_DUPLICATE,
	HB_P_POPVARIABLE, 42, 0,	/* SHAPE */
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
/* 01751 */ HB_P_LINEOFFSET, 104,	/* 140 */
	HB_P_MESSAGE, 34, 0,	/* SETTEXT */
	HB_P_PUSHLOCALNEAR, 6,	/* OBTN */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 7,	/* 7 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_FALSE,
	HB_P_PUSHSYMNEAR, 43,	/* NRGB */
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 192, 0,	/* 192 */
	HB_P_PUSHINT, 192, 0,	/* 192 */
	HB_P_PUSHBYTE, 56,	/* 56 */
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PUSHSYMNEAR, 43,	/* NRGB */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 102,	/* 102 */
	HB_P_PUSHBYTE, 51,	/* 51 */
	HB_P_ZERO,
	HB_P_FUNCTIONSHORT, 3,
	HB_P_SENDSHORT, 6,
	HB_P_POP,
/* 01793 */ HB_P_LINEOFFSET, 109,	/* 145 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 60,	/* 60 */
	HB_P_PUSHINT, 237, 0,	/* 237 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 14,	/* 14 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'R', 'o', 'l', 'l', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 36,	/* 36 */
	HB_P_PUSHBYTE, 36,	/* 36 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 16, 0,	/* 16 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 35,	/* TONE */
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	9, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 16,	/* 16 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'B', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 11,	/* 11 */
	HB_P_ARRAYPOP,
/* 01910 */ HB_P_LINEOFFSET, 121,	/* 157 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 60,	/* 60 */
	HB_P_PUSHINT, 44, 1,	/* 300 */
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'E', 'x', 'i', 't', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'L', 'a', 'm', 'p', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'L', 'a', 'm', 'p', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'L', 'a', 'm', 'p', '3', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'S', 'h', 'a', 'p', 'e', '3', 0, 
	HB_P_ARRAYGEN, 5, 0,	/* 5 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 74,	/* 74 */
	HB_P_PUSHBYTE, 26,	/* 26 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 87,	/* 87 */
	'S', 'e', 'e', ' ', 'n', 'e', 'w', ' ', 34, 'S', 'h', 'a', 'p', 'e', 34, ' ', 'f', 'e', 'a', 't', 'u', 'r', 'e', ' ', 'a', 'n', 'd', ' ', '3', 'D', ' ', 't', 'e', 'x', 't', ' ', '(', 'b', 'a', 's', '-', 'r', 'e', 'l', 'i', 'e', 'f', ')', ',', ' ', 'd', 'e', 'f', 'a', 'u', 'l', 't', ' ', 'p', 'o', 's', 'i', 't', 'i', 'o', 'n', ',', ' ', 's', 'p', 'e', 'c', 'i', 'f', 'i', 'c', ' ', '3', 'D', ' ', 'c', 'o', 'l', 'o', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 12,	/* 12 */
	'E', 'n', 'd', ' ', 'P', 'r', 'o', 'g', 'r', 'a', 'm', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_ZERO,
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPOP,
/* 02134 */ HB_P_LINEOFFSET, 124,	/* 160 */
	HB_P_MESSAGE, 34, 0,	/* SETTEXT */
	HB_P_PUSHLOCALNEAR, 6,	/* OBTN */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHSYMNEAR, 43,	/* NRGB */
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 192, 0,	/* 192 */
	HB_P_PUSHINT, 192, 0,	/* 192 */
	HB_P_PUSHBYTE, 56,	/* 56 */
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PUSHSYMNEAR, 43,	/* NRGB */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 102,	/* 102 */
	HB_P_PUSHBYTE, 51,	/* 51 */
	HB_P_ZERO,
	HB_P_FUNCTIONSHORT, 3,
	HB_P_SENDSHORT, 6,
	HB_P_POP,
/* 02174 */ HB_P_LINEOFFSET, 129,	/* 165 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 60,	/* 60 */
	HB_P_PUSHINT, 138, 1,	/* 394 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 16,	/* 16 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'B', 'u', 's', 'O', 'u', 't', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 36,	/* 36 */
	HB_P_PUSHBYTE, 36,	/* 36 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 16, 0,	/* 16 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 35,	/* TONE */
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	9, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 16,	/* 16 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'B', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_ARRAYPOP,
/* 02293 */ HB_P_LINEOFFSET, 141,	/* 177 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 120,	/* 120 */
	HB_P_PUSHBYTE, 90,	/* 90 */
	HB_P_PUSHSTRSHORT, 25,	/* 25 */
	'B', 'u', 't', 't', 'o', 'n', 's', 13, 10, 'F', 'r', 'o', 'm', 13, 10, 'R', 'e', 's', 'o', 'u', 'r', 'c', 'e', 's', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 13, 0,	/* 13 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 44,	/* FRESOURCE */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	9, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ':', ' ', 'M', 'u', 'l', 't', 'i', 'l', 'i', 'n', 'e', ' ', 't', 'e', 'x', 't', ',', ' ', 'D', 'i', 'n', 'a', 'm', 'i', 'c', ' ', 'C', 'o', 'l', 'o', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 24,	/* 24 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', ' ', 'R', 'I', 'G', 'H', 'T', ' ', '(', 'D', 'e', 'f', 'a', 'u', 'l', 't', ')', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 4,	/* BTCOLOR */
	HB_P_PUSHLOCALNEAR, 5,	/* BBCOLOR */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'R', 'Y', 'S', 'T', 'A', 'L', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYPOP,
/* 02518 */ HB_P_LINEOFFSET, 156,	/* 192 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 120,	/* 120 */
	HB_P_PUSHINT, 64, 1,	/* 320 */
	HB_P_PUSHSTRSHORT, 20,	/* 20 */
	'B', 'u', 't', 't', 'o', 'n', 's', 13, 10, 'F', 'r', 'o', 'm', 13, 10, 'C', 'o', 'd', 'e', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 16,	/* 16 */
	'A', 'N', 'I', 'M', 'A', 'T', 'E', 'D', ' ', 'D', 'i', 'r', 'e', 'c', 'M', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 13, 0,	/* 13 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 45,	/* FCODIGO */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	9, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ':', ' ', 'M', 'u', 'l', 't', 'i', 'l', 'i', 'n', 'e', ' ', 't', 'e', 'x', 't', ',', ' ', 'D', 'i', 'n', 'a', 'm', 'i', 'c', ' ', 'C', 'o', 'l', 'o', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 13,	/* 13 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'L', 'E', 'F', 'T', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 4,	/* BTCOLOR */
	HB_P_PUSHLOCALNEAR, 5,	/* BBCOLOR */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'X', 'P', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 6, 0,	/* OBTN */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_ARRAYPOP,
/* 02713 */ HB_P_LINEOFFSET, 159,	/* 195 */
	HB_P_MESSAGE, 46, 0,	/* _OMSGBAR */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 47,	/* TMSGBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 80,	/* 80 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ',', ' ', 161, ' ', 'A', 'l', 'l', ' ', 'o', 'f', ' ', 't', 'h', 'e', ' ', 'b', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'a', ' ', 's', 't', 'a', 'n', 'd', ' ', 'a', 'l', 'o', 'n', 'e', ' ', 'c', 'l', 'a', 's', 's', ' ', '(', 'N', 'O', ' ', 'B', 't', 'n', 'B', 'm', 'p', ' ', 's', 'u', 'b', 'c', 'l', 'a', 's', 's', ')', 0, 
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 14,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 02835 */ HB_P_LINEOFFSET, 168,	/* 204 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 10, 0,	/* BLCLICKED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 11, 0,	/* BRCLICKED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 12, 0,	/* BMOVED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 13, 0,	/* BRESIZED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 14, 0,	/* BPAINTED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 15, 0,	/* BKEYDOWN */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 48, 0,	/* _BINIT */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHBLOCK, 64, 0,	/* 64 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	6, 0,	/* OBTN */
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_PUSHSYMNEAR, 50,	/* MSGBLINK */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 27,	/* 27 */
	'W', 'e', 'l', 'l', 'c', 'o', 'm', 'e', ' ', 't', 'o', ';', ' ', 'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FUNCTIONSHORT, 6,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 1,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 94, 0,	/* 94 */
	1, 0,	/* number of local parameters (1) */
	4, 0,	/* number of local variables (4) */
	2, 0,	/* OFONT */
	1, 0,	/* OICO */
	3, 0,	/* OBRUSH */
	7, 0,	/* OBMP */
	HB_P_PUSHNIL,
	HB_P_PUSHSTATICREF, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPOP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 253,	/* localvar3 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_PUSHLOCALNEAR, 252,	/* localvar4 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_NOTEQUAL,
	HB_P_JUMPFALSENEAR, 26,	/* 26 (abs: 03078) */
	HB_P_PUSHSYMNEAR, 51,	/* AEVAL */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 252,	/* localvar4 */
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 52,	/* DELETEOBJECT */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 03079) */
	HB_P_PUSHNIL,
	HB_P_POP,
	HB_P_TRUE,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 18, 0,	/* BLBUTTONUP */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_FALSE,
	HB_P_SENDSHORT, 20,
	HB_P_POP,
	HB_P_JUMPNEAR, 15,	/* 15 (abs: 03112) */
/* 03099 */ HB_P_LINEOFFSET, 171,	/* 207 */
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 03112 */ HB_P_LINEOFFSET, 174,	/* 210 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 03117 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( BUILDMENU )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 1, 0,	/* locals, params */
	HB_P_SFRAME, 88, 0,	/* symbol (_INITSTATICS) */
/* 00006 */ HB_P_BASELINE, 218, 0,	/* 218 */
	HB_P_PUSHSYMNEAR, 53,	/* MENUBEGIN */
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FUNCTIONSHORT, 20,
	HB_P_POPLOCALNEAR, 1,	/* OMENU */
/* 00036 */ HB_P_LINEOFFSET, 1,	/* 219 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'&', 'T', 'S', 'B', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 13, 0,	/* 13 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 19,	/* CHILD1 */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00097 */ HB_P_LINEOFFSET, 2,	/* 220 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'H', 'e', 'l', 'p', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 42, 0,	/* 42 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 55,	/* WINEXEC */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 26,	/* 26 */
	'S', 't', 'a', 'r', 't', ' ', '.', '.', 92, 'd', 'o', 'c', 92, 'T', 's', 'b', 'u', 't', 't', 'o', 'n', '.', 'h', 't', 'm', 0, 
	HB_P_ZERO,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00183 */ HB_P_LINEOFFSET, 3,	/* 221 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'E', 'x', 'i', 't', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 16, 0,	/* 16 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00243 */ HB_P_LINEOFFSET, 4,	/* 222 */
	HB_P_PUSHSYMNEAR, 56,	/* MENUEND */
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 0,
/* 00250 */ HB_P_LINEOFFSET, 6,	/* 224 */
	HB_P_PUSHLOCALNEAR, 1,	/* OMENU */
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 00256 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( SHOWBITMAPS )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 0, 2,	/* locals, params */
	HB_P_SFRAME, 88, 0,	/* symbol (_INITSTATICS) */
/* 00006 */ HB_P_BASELINE, 231, 0,	/* 231 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 57,	/* TSAY */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 198, 0,	/* 198 */
	HB_P_PUSHINT, 160, 0,	/* 160 */
	HB_P_PUSHBLOCK, 40, 0,	/* 40 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSTRSHORT, 30,	/* 30 */
	'B', 'i', 't', 'm', 'a', 'p', 's', ' ', 'u', 's', 'e', 'd', ' ', 'b', 'y', ' ', 't', 'h', 'e', 's', 'e', ' ', 'b', 'u', 't', 't', 'o', 'n', 's', 0, 
	HB_P_ENDBLOCK,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHINT, 200, 0,	/* 200 */
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 22,
	HB_P_POP,
/* 00097 */ HB_P_LINEOFFSET, 2,	/* 233 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 58,	/* TBITMAP */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 215, 0,	/* 215 */
	HB_P_PUSHBYTE, 80,	/* 80 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', '1', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 19,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBMP */
	HB_P_ONE,
	HB_P_ARRAYPOP,
/* 00148 */ HB_P_LINEOFFSET, 3,	/* 234 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 58,	/* TBITMAP */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 215, 0,	/* 215 */
	HB_P_PUSHBYTE, 120,	/* 120 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 19,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBMP */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
/* 00200 */ HB_P_LINEOFFSET, 4,	/* 235 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 58,	/* TBITMAP */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 215, 0,	/* 215 */
	HB_P_PUSHINT, 165, 0,	/* 165 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', '3', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 19,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBMP */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
/* 00253 */ HB_P_LINEOFFSET, 5,	/* 236 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 58,	/* TBITMAP */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 215, 0,	/* 215 */
	HB_P_PUSHINT, 205, 0,	/* 205 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', '4', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 19,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBMP */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPOP,
/* 00306 */ HB_P_LINEOFFSET, 6,	/* 237 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 58,	/* TBITMAP */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 215, 0,	/* 215 */
	HB_P_PUSHINT, 59, 1,	/* 315 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'i', 'r', 'e', 'c', 'M', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 19,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBMP */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYPOP,
/* 00359 */ HB_P_LINEOFFSET, 9,	/* 240 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 57,	/* TSAY */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 247, 0,	/* 247 */
	HB_P_PUSHBYTE, 90,	/* 90 */
	HB_P_PUSHBLOCK, 51, 0,	/* 51 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSTRSHORT, 41,	/* 41 */
	' ', ' ', '1', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '2', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '3', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '4', 0, 
	HB_P_ENDBLOCK,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHINT, 200, 0,	/* 200 */
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 22,
	HB_P_POP,
/* 00459 */ HB_P_LINEOFFSET, 12,	/* 243 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 57,	/* TSAY */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 247, 0,	/* 247 */
	HB_P_PUSHINT, 74, 1,	/* 330 */
	HB_P_PUSHBLOCK, 43, 0,	/* 43 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSTRSHORT, 33,	/* 33 */
	' ', '1', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '2', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '3', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '4', 0, 
	HB_P_ENDBLOCK,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHBYTE, 120,	/* 120 */
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 22,
	HB_P_POP,
/* 00551 */ HB_P_LINEOFFSET, 15,	/* 246 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 57,	/* TSAY */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 4, 1,	/* 260 */
	HB_P_PUSHBYTE, 80,	/* 80 */
	HB_P_PUSHBLOCK, 45, 0,	/* 45 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSTRSHORT, 35,	/* 35 */
	'N', 'o', 'r', 'm', 'a', 'l', ' ', ' ', 'P', 'r', 'e', 's', 's', 'e', 'd', ' ', ' ', 'I', 'n', 'a', 'c', 't', 'i', 'v', 'e', ' ', ' ', 'P', 'o', 'i', 'n', 't', 'e', 'd', 0, 
	HB_P_ENDBLOCK,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHINT, 200, 0,	/* 200 */
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 22,
	HB_P_POP,
/* 00645 */ HB_P_LINEOFFSET, 18,	/* 249 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 57,	/* TSAY */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 4, 1,	/* 260 */
	HB_P_PUSHINT, 54, 1,	/* 310 */
	HB_P_PUSHBLOCK, 41, 0,	/* 41 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSTRSHORT, 31,	/* 31 */
	'F', 'o', 'u', 'r', ' ', 's', 't', 'a', 't', 'e', 's', ' ', 'i', 'n', ' ', 'a', ' ', 's', 'i', 'n', 'g', 'l', 'e', ' ', 'B', 'i', 't', 'm', 'a', 'p', 0, 
	HB_P_ENDBLOCK,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHINT, 150, 0,	/* 150 */
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 22,
	HB_P_POP,
/* 00736 */ HB_P_LINEOFFSET, 20,	/* 251 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 00741 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( FRESOURCE )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 8, 0,	/* locals, params */
/* 00003 */ HB_P_BASELINE, 3, 1,	/* 259 */
	HB_P_FALSE,
	HB_P_POPLOCALNEAR, 7,	/* LENABLE */
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 9,	/* 9 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 8,	/* OBTN */
/* 00018 */ HB_P_LINEOFFSET, 2,	/* 261 */
	HB_P_PUSHSYMNEAR, 60,	/* SPACE */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 5,	/* CVAR */
/* 00029 */ HB_P_LINEOFFSET, 5,	/* 264 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 24,	/* TBRUSH */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'B', 'a', 'c', 'k', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 6,
	HB_P_POPLOCALNEAR, 4,	/* OBRUSH */
/* 00056 */ HB_P_LINEOFFSET, 6,	/* 265 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 23,	/* TFONT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTRSHORT, 14,	/* 14 */
	'M', 'S', ' ', 'S', 'a', 'n', 's', ' ', 'S', 'e', 'r', 'i', 'f', 0, 
	HB_P_ZERO,
	HB_P_PUSHBYTE, 244,	/* -12 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 17,
	HB_P_POPLOCALNEAR, 2,	/* OFONT */
/* 00103 */ HB_P_LINEOFFSET, 9,	/* 268 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 61,	/* TDIALOG */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 40,	/* 40 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'd', 'i', 'a', 'l', 'o', 'g', 's', ' ', 'f', 'r', 'o', 'm', ' ', 'r', 'e', 's', 'o', 'u', 'r', 'c', 'e', 's', 0, 
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'D', 'I', 'A', 'L', 'O', 'G', '_', '1', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'o', 'D', 'l', 'g', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 24,
	HB_P_POPLOCALNEAR, 1,	/* ODLG */
/* 00199 */ HB_P_LINEOFFSET, 14,	/* 273 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 63,	/* TGET */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 101,	/* 101 */
	HB_P_PUSHBLOCK, 28, 0,	/* 28 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* CVAR */
	HB_P_PUSHSYMNEAR, 64,	/* PCOUNT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 6,	/* 6 (abs: 00233) */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 00238) */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_DUPLICATE,
	HB_P_POPLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 65, 0,	/* 65 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* CVAR */
	HB_P_PUSHSYMNEAR, 65,	/* EMPTY */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_JUMPFALSENEAR, 47,	/* 47 (abs: 00306) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 35,	/* 35 */
	'Y', 'o', 'u', ' ', 'm', 'u', 's', 't', ' ', 't', 'o', ' ', 'w', 'r', 'i', 't', 'e', ' ', 's', 'o', 'm', 'e', 't', 'h', 'i', 'n', 'g', ' ', 'i', 'n', ' ', 'g', 'e', 't', 0, 
	HB_P_DOSHORT, 1,
	HB_P_FALSE,
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 00307) */
	HB_P_TRUE,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'c', 'V', 'a', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 24,
	HB_P_POPLOCALNEAR, 3,	/* OGET */
/* 00336 */ HB_P_LINEOFFSET, 21,	/* 280 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 208, 0,	/* 208 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'E', 'm', 'u', 'l', 'a', 't', 'i', 'n', 'g', ' ', 'm', 'e', 'n', 'u', 's', ' ', 'i', 'n', ' ', 'd', 'i', 'a', 'l', 'o', 'g', 's', ' ', 'w', 'i', 't', 'h', ' ', 'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', 0, 
	HB_P_PUSHBLOCK, 29, 0,	/* 29 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	8, 0,	/* OBTN */
	3, 0,	/* OGET */
	HB_P_PUSHSYMNEAR, 67,	/* MENUARCH */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYPUSH,
	HB_P_DOSHORT, 1,
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', ',', ' ', 'T', 'e', 'x', 't', ' ', 'o', 'n', 'l', 'y', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'F', 'i', 'l', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYPOP,
/* 00501 */ HB_P_LINEOFFSET, 28,	/* 287 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 209, 0,	/* 209 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'E', 'm', 'u', 'l', 'a', 't', 'i', 'n', 'g', ' ', 'm', 'e', 'n', 'u', 's', ' ', 'i', 'n', ' ', 'd', 'i', 'a', 'l', 'o', 'g', 's', ' ', 'w', 'i', 't', 'h', ' ', 'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', 0, 
	HB_P_PUSHBLOCK, 17, 0,	/* 17 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', ',', ' ', 'T', 'e', 'x', 't', ' ', 'o', 'n', 'l', 'y', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'E', 'x', 'i', 't', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 9,	/* 9 */
	HB_P_ARRAYPOP,
/* 00654 */ HB_P_LINEOFFSET, 40,	/* 299 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 201, 0,	/* 201 */
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '1', 0, 
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '2', 0, 
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '3', 0, 
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 41,	/* 41 */
	'W', 'r', 'i', 't', 'e', ' ', 'a', 'n', 'y', 't', 'h', 'i', 'n', 'g', ' ', 'i', 'n', ' ', 'G', 'e', 't', ' ', 't', 'o', ' ', 'u', 's', 'e', ' ', 't', 'h', 'i', 's', ' ', 'b', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_PUSHBLOCK, 38, 0,	/* 38 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	7, 0,	/* LENABLE */
	8, 0,	/* OBTN */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_NOT,
	HB_P_POPLOCALNEAR, 255,	/* localvar1 */
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'B', 'O', 'R', 'D', 'E', 'R', 0, 
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 27,	/* 27 */
	'B', 'R', 'U', 'S', 'H', ',', ' ', 'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'T', 'O', 'P', ',', ' ', 'B', 'O', 'R', 'D', 'E', 'R', 0, 
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'A', '&', 'c', 't', 'i', 'v', 'a', 't', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_FALSE,
	HB_P_ONE,
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00859) */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 00860) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHLONG, 0, 128, 0, 0, 	/* 32768 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_FALSE,
	HB_P_PUSHLOCALNEAR, 4,	/* OBRUSH */
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'R', 'O', 'U', 'N', 'D', 'R', 'E', 'C', 'T', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_ONE,
	HB_P_ARRAYPOP,
/* 00893 */ HB_P_LINEOFFSET, 52,	/* 311 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 202, 0,	/* 202 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '1', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '2', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '3', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 24,	/* 24 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'e', 'n', 'u', 0, 
	HB_P_PUSHBLOCK, 17, 0,	/* 17 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 38,	/* 38 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', ' ', 'R', 'I', 'G', 'H', 'T', ' ', '(', 'D', 'e', 'f', 'a', 'u', 'l', 't', ')', ',', ' ', 'M', 'E', 'N', 'U', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'E', 'x', 'i', 't', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_TRUE,
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ZERO,
	HB_P_PUSHBLOCK, 45, 0,	/* 45 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 17,	/* 17 (abs: 01085) */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 0, 0, 128, 0, 	/* 8388608 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_JUMPNEAR, 15,	/* 15 (abs: 01098) */
	HB_P_PUSHLONG, 0, 0, 128, 0, 	/* 8388608 */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_ENDBLOCK,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 20, 0,	/* 20 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	8, 0,	/* OBTN */
	HB_P_PUSHSYMNEAR, 33,	/* MENUPOP */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
/* 01134 */ HB_P_LINEOFFSET, 64,	/* 323 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 203, 0,	/* 203 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ':', ' ', 'M', 'u', 'l', 't', 'i', 'l', 'i', 'n', 'e', ' ', 't', 'e', 'x', 't', ',', ' ', 'D', 'i', 'n', 'a', 'm', 'i', 'c', ' ', 'C', 'o', 'l', 'o', 'r', 's', 0, 
	HB_P_PUSHBLOCK, 13, 0,	/* 13 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 45,	/* FCODIGO */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	7, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 24,	/* 24 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', ' ', 'R', 'I', 'G', 'H', 'T', ' ', '(', 'd', 'e', 'f', 'a', 'u', 'l', 't', ')', 0, 
	HB_P_PUSHSTRSHORT, 21,	/* 21 */
	'&', 'S', 'B', 'u', 't', 't', 'o', 'n', 13, 10, 'F', 'r', 'o', 'm', 13, 10, 'C', 'o', 'd', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_FALSE,
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_PUSHBLOCK, 37, 0,	/* 37 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 21,	/* 21 (abs: 01351) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01348) */
	HB_P_PUSHLONG, 0, 0, 255, 0, 	/* 16711680 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01349) */
	HB_P_ZERO,
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01352) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 38, 0,	/* 38 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 18,	/* 18 (abs: 01385) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_PUSHLONG, 0, 0, 128, 0, 	/* 8388608 */
	HB_P_TRUE,
	HB_P_ARRAYGEN, 3, 0,	/* 3 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 01390) */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_ENDBLOCK,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
/* 01407 */ HB_P_LINEOFFSET, 75,	/* 334 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 204, 0,	/* 204 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 24,	/* 24 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'e', 'n', 'u', 0, 
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 26,	/* 26 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'T', 'O', 'P', ',', ' ', 'M', 'E', 'N', 'U', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'&', 'P', 'r', 'u', 'e', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_TRUE,
	HB_P_ONE,
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01572) */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01573) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHLONG, 0, 128, 0, 0, 	/* 32768 */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 33,	/* MENUPOP */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPOP,
/* 01617 */ HB_P_LINEOFFSET, 86,	/* 345 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 205, 0,	/* 205 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 27, 0,	/* 27 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	3, 0,	/* OGET */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_DOSHORT, 1,
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	7, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 22,	/* 22 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'B', 'O', 'T', 'T', 'O', 'M', ' ', 'C', 'A', 'N', 'C', 'E', 'L', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'P', '&', 'r', 'u', 'e', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_TRUE,
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01774) */
	HB_P_PUSHLONG, 0, 0, 128, 0, 	/* 8388608 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01775) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 35, 0,	/* 35 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 15,	/* 15 (abs: 01805) */
	HB_P_PUSHINT, 128, 0,	/* 128 */
	HB_P_PUSHLONG, 192, 192, 192, 0, 	/* 12632256 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 01810) */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_ENDBLOCK,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYPOP,
/* 01827 */ HB_P_LINEOFFSET, 96,	/* 355 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 206, 0,	/* 206 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 41,	/* 41 */
	'W', 'r', 'i', 't', 'e', ' ', 'a', 'n', 'y', 't', 'h', 'i', 'n', 'g', ' ', 'i', 'n', ' ', 'G', 'e', 't', ' ', 't', 'o', ' ', 'u', 's', 'e', ' ', 't', 'h', 'i', 's', ' ', 'b', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 25,	/* 25 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'B', 'O', 'T', 'T', 'O', 'M', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'P', 'r', '&', 'u', 'e', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_FALSE,
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_ARRAYPOP,
/* 02010 */ HB_P_LINEOFFSET, 99,	/* 358 */
	HB_P_MESSAGE, 34, 0,	/* SETTEXT */
	HB_P_PUSHLOCALNEAR, 8,	/* OBTN */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_SENDSHORT, 4,
	HB_P_POP,
/* 02027 */ HB_P_LINEOFFSET, 109,	/* 368 */
	HB_P_MESSAGE, 62, 0,	/* REDEFINE */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 207, 0,	/* 207 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 35,	/* 35 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'e', 'n', 'u', ' ', '&', ' ', 'L', 'o', 'o', 'k', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'M', 'E', 'N', 'U', ',', ' ', 'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'T', 'O', 'P', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'P', 'r', 'u', 'e', '&', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_FALSE,
	HB_P_ONE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 33,	/* MENUPOP */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 21,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 7,	/* 7 */
	HB_P_ARRAYPOP,
/* 02220 */ HB_P_LINEOFFSET, 112,	/* 371 */
	HB_P_MESSAGE, 34, 0,	/* SETTEXT */
	HB_P_PUSHLOCALNEAR, 8,	/* OBTN */
	HB_P_PUSHBYTE, 7,	/* 7 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 4,
	HB_P_POP,
/* 02237 */ HB_P_LINEOFFSET, 118,	/* 377 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_MESSAGE, 10, 0,	/* BLCLICKED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 12, 0,	/* BMOVED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 68, 0,	/* _BPAINTED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHBLOCK, 47, 0,	/* 47 */
	2, 0,	/* number of local parameters (2) */
	1, 0,	/* number of local variables (1) */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 69,	/* TSLINES */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 17,	/* 17 */
	HB_P_ZERO,
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'L', 'I', 'N', 'E', 0, 
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_SENDSHORT, 8,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 1,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 121, 0,	/* 121 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	3, 0,	/* OGET */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 46, 0,	/* _OMSGBAR */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 47,	/* TMSGBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHSTRSHORT, 80,	/* 80 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ',', ' ', 161, ' ', 'A', 'l', 'l', ' ', 'o', 'f', ' ', 't', 'h', 'e', ' ', 'b', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'a', ' ', 's', 't', 'a', 'n', 'd', ' ', 'a', 'l', 'o', 'n', 'e', ' ', 'c', 'l', 'a', 's', 's', ' ', '(', 'N', 'O', ' ', 'B', 't', 'n', 'B', 'm', 'p', ' ', 's', 'u', 'b', 'c', 'l', 'a', 's', 's', ')', 0, 
	HB_P_SENDSHORT, 2,
	HB_P_SENDSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_MESSAGE, 11, 0,	/* BRCLICKED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_SENDSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 11,
	HB_P_POP,
/* 02449 */ HB_P_LINEOFFSET, 120,	/* 379 */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 02459 */ HB_P_LINEOFFSET, 121,	/* 380 */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 4,	/* OBRUSH */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 02469 */ HB_P_LINEOFFSET, 123,	/* 382 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 02474 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( MENUPOP )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 2, 1,	/* locals, params */
/* 00003 */ HB_P_BASELINE, 134, 1,	/* 390 */
	HB_P_PUSHSYMNEAR, 70,	/* GETCLIENTRECT */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 71, 0,	/* HWND */
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_SENDSHORT, 0,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 3,	/* ARECT */
/* 00020 */ HB_P_LINEOFFSET, 2,	/* 392 */
	HB_P_PUSHSYMNEAR, 53,	/* MENUBEGIN */
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FUNCTIONSHORT, 20,
	HB_P_POPLOCALNEAR, 2,	/* OMENU */
/* 00049 */ HB_P_LINEOFFSET, 3,	/* 393 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'U', 'n', 'd', 'o', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'D', 'e', 's', 'h', 'a', 'c', 'e', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00104 */ HB_P_LINEOFFSET, 4,	/* 394 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 35,
/* 00146 */ HB_P_LINEOFFSET, 5,	/* 395 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'C', 'u', '&', 't', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'C', 'o', 'r', 't', 'a', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00198 */ HB_P_LINEOFFSET, 6,	/* 396 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'C', 'o', 'p', 'y', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'C', 'o', 'p', 'i', 'a', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00251 */ HB_P_LINEOFFSET, 7,	/* 397 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'&', 'P', 'a', 's', 't', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'P', 'e', 'g', 'a', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00304 */ HB_P_LINEOFFSET, 8,	/* 398 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'&', 'D', 'e', 'l', 'e', 't', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'B', 'o', 'r', 'r', 'a', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00359 */ HB_P_LINEOFFSET, 9,	/* 399 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 35,
/* 00401 */ HB_P_LINEOFFSET, 10,	/* 400 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 12,	/* 12 */
	'&', 'S', 'e', 'l', 'e', 'c', 't', ' ', 'A', 'l', 'l', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00452 */ HB_P_LINEOFFSET, 11,	/* 401 */
	HB_P_PUSHSYMNEAR, 56,	/* MENUEND */
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 0,
/* 00459 */ HB_P_LINEOFFSET, 13,	/* 403 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHLOCALNEAR, 2,	/* OMENU */
	HB_P_PUSHLOCALNEAR, 3,	/* ARECT */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_ADDINT, 1, 0,	/* 1*/
	HB_P_PUSHLOCALNEAR, 3,	/* ARECT */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 5,
	HB_P_POP,
/* 00486 */ HB_P_LINEOFFSET, 15,	/* 405 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 00491 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( MENUARCH )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 2, 3,	/* locals, params */
/* 00003 */ HB_P_BASELINE, 157, 1,	/* 413 */
	HB_P_PUSHSYMNEAR, 70,	/* GETCLIENTRECT */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 71, 0,	/* HWND */
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_SENDSHORT, 0,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 5,	/* ARECT */
/* 00020 */ HB_P_LINEOFFSET, 3,	/* 416 */
	HB_P_PUSHLOCALNEAR, 2,	/* NROW */
	HB_P_PUSHNIL,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 15,	/* 15 (abs: 00041) */
	HB_P_PUSHLOCALNEAR, 5,	/* ARECT */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_ADDINT, 1, 0,	/* 1*/
	HB_P_DUPLICATE,
	HB_P_POPLOCALNEAR, 2,	/* NROW */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 00042) */
	HB_P_PUSHNIL,
	HB_P_POP,
	HB_P_PUSHLOCALNEAR, 3,	/* NCOL */
	HB_P_PUSHNIL,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 12,	/* 12 (abs: 00059) */
	HB_P_PUSHLOCALNEAR, 5,	/* ARECT */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_DUPLICATE,
	HB_P_POPLOCALNEAR, 3,	/* NCOL */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 00060) */
	HB_P_PUSHNIL,
	HB_P_POP,
	HB_P_PUSHSYMNEAR, 53,	/* MENUBEGIN */
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FUNCTIONSHORT, 20,
	HB_P_POPLOCALNEAR, 4,	/* OMENU */
/* 00088 */ HB_P_LINEOFFSET, 6,	/* 419 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'&', 'N', 'e', 'w', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00132 */ HB_P_LINEOFFSET, 7,	/* 420 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'O', 'p', 'e', 'n', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00177 */ HB_P_LINEOFFSET, 8,	/* 421 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 35,
/* 00219 */ HB_P_LINEOFFSET, 9,	/* 422 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'S', 'a', 'v', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00264 */ HB_P_LINEOFFSET, 10,	/* 423 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'S', 'a', 'v', 'e', ' ', '&', 'A', 's', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00312 */ HB_P_LINEOFFSET, 11,	/* 424 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'&', 'C', 'l', 'o', 's', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00358 */ HB_P_LINEOFFSET, 12,	/* 425 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'&', 'P', 'r', 'i', 'n', 't', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00404 */ HB_P_LINEOFFSET, 13,	/* 426 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 35,
/* 00446 */ HB_P_LINEOFFSET, 14,	/* 427 */
	HB_P_PUSHSYMNEAR, 54,	/* MENUADDITEM */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 15,	/* 15 */
	'P', '&', 'r', 'i', 'n', 't', 'e', 'r', ' ', 'S', 'e', 't', 'u', 'p', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 30,
/* 00500 */ HB_P_LINEOFFSET, 15,	/* 428 */
	HB_P_PUSHSYMNEAR, 56,	/* MENUEND */
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 0,
/* 00507 */ HB_P_LINEOFFSET, 17,	/* 430 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHLOCALNEAR, 4,	/* OMENU */
	HB_P_PUSHLOCALNEAR, 2,	/* NROW */
	HB_P_PUSHLOCALNEAR, 3,	/* NCOL */
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 5,
	HB_P_POP,
/* 00525 */ HB_P_LINEOFFSET, 19,	/* 432 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 00530 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( CHILD2 )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 5, 0,	/* locals, params */
	HB_P_SFRAME, 88, 0,	/* symbol (_INITSTATICS) */
/* 00006 */ HB_P_BASELINE, 183, 1,	/* 439 */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_ARRAYDIM, 1, 0,	/* 1 */
	HB_P_POPLOCALNEAR, 2,	/* OBTN */
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 5,	/* AVISIT */
/* 00025 */ HB_P_LINEOFFSET, 2,	/* 441 */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSE, 92, 6,	/* 1628 (abs: 01663) */
/* 00038 */ HB_P_LINEOFFSET, 4,	/* 443 */
	HB_P_PUSHSYMNEAR, 72,	/* AFILL */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 5,	/* AVISIT */
	HB_P_FALSE,
	HB_P_DOSHORT, 2,
/* 00048 */ HB_P_LINEOFFSET, 6,	/* 445 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 23,	/* TFONT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTRSHORT, 14,	/* 14 */
	'M', 'S', ' ', 'S', 'a', 'n', 's', ' ', 'S', 'e', 'r', 'i', 'f', 0, 
	HB_P_ZERO,
	HB_P_PUSHBYTE, 246,	/* -10 */
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 17,
	HB_P_POPLOCALNEAR, 1,	/* OFONT */
/* 00095 */ HB_P_LINEOFFSET, 7,	/* 446 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 24,	/* TBRUSH */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'B', 'a', 'c', 'k', '1', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 6,
	HB_P_POPLOCALNEAR, 3,	/* OBRUSH */
/* 00122 */ HB_P_LINEOFFSET, 14,	/* 453 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 25,	/* TMDICHILD */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_ZERO,
	HB_P_PUSHINT, 90, 1,	/* 346 */
	HB_P_PUSHINT, 144, 1,	/* 400 */
	HB_P_PUSHSTRSHORT, 47,	/* 47 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', ' ', 161, ' ', 'T', 'o', 'd', 'o', 's', ' ', 'l', 'o', 's', ' ', 'B', 'o', 't', 'o', 'n', 'e', 's', ' ', 'S', 'I', 'N', ' ', 'D', 'L', 'L', 39, 's', ' ', '!', 0, 
	HB_P_PUSHSYMNEAR, 26,	/* NOR */
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 0, 0, 64, 0, 	/* 4194304 */
	HB_P_PUSHLONG, 0, 0, 0, 16, 	/* 268435456 */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHNIL,
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBRUSH */
	HB_P_TRUE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 24,
	HB_P_PUSHSTATICREF, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
/* 00237 */ HB_P_LINEOFFSET, 26,	/* 465 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'P', 'r', 'o', 'd', 'u', 'c', 't', 's', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 75,	/* 75 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 55, 0,	/* 55 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	2, 0,	/* OBTN */
	HB_P_MESSAGE, 34, 0,	/* SETTEXT */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'P', 'r', 'o', 'd', 'u', 'c', 't', 'o', 's', 0, 
	HB_P_SENDSHORT, 1,
	HB_P_POP,
	HB_P_MESSAGE, 73, 0,	/* SETCOLOR */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_PUSHINT, 255, 0,	/* 255 */
	HB_P_ZERO,
	HB_P_SENDSHORT, 2,
	HB_P_POP,
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 42,	/* 42 */
	'h', 't', 't', 'p', ':', '/', '/', 'w', 'w', 'w', '.', 's', 'u', 'p', 'e', 'r', 'b', 'u', 't', 't', 'o', 'n', 's', '.', 'c', 'o', 'm', '/', 'p', 'r', 'o', 'd', 'u', 'c', 't', 's', '.', 'h', 't', 'm', 'l', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'N', 'O', 'B', 'O', 'X', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 28, 0,	/* 28 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* AVISIT */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ONE,
	HB_P_ARRAYPUSH,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00425) */
	HB_P_PUSHLONG, 0, 255, 0, 0, 	/* 65280 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 00430) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_ENDBLOCK,
	HB_P_ZERO,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBTN */
	HB_P_ONE,
	HB_P_ARRAYPOP,
/* 00447 */ HB_P_LINEOFFSET, 35,	/* 474 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHBYTE, 110,	/* 110 */
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'D', 'o', 'w', 'n', 'l', 'o', 'a', 'd', 's', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 75,	/* 75 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 34, 0,	/* 34 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	5, 0,	/* AVISIT */
	2, 0,	/* OBTN */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_NOT,
	HB_P_PUSHLOCALREF, 255, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 42,	/* 42 */
	'h', 't', 't', 'p', ':', '/', '/', 'w', 'w', 'w', '.', 's', 'u', 'p', 'e', 'r', 'b', 'u', 't', 't', 'o', 'n', 's', '.', 'c', 'o', 'm', '/', 'D', 'o', 'w', 'l', 'o', 'a', 'd', 's', '.', 'h', 't', 'm', 'l', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'N', 'O', 'B', 'O', 'X', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 29, 0,	/* 29 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* AVISIT */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00616) */
	HB_P_PUSHLONG, 0, 255, 0, 0, 	/* 65280 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 00621) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_ENDBLOCK,
	HB_P_ZERO,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBTN */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
/* 00639 */ HB_P_LINEOFFSET, 43,	/* 482 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHINT, 190, 0,	/* 190 */
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'S', 'h', 'o', 'p', 'p', 'i', 'n', 'g', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 75,	/* 75 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 34, 0,	/* 34 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	5, 0,	/* AVISIT */
	2, 0,	/* OBTN */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_NOT,
	HB_P_PUSHLOCALREF, 255, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 42,	/* 42 */
	'h', 't', 't', 'p', ':', '/', '/', 'w', 'w', 'w', '.', 's', 'u', 'p', 'e', 'r', 'b', 'u', 't', 't', 'o', 'n', 's', '.', 'c', 'o', 'm', '/', 'S', 'h', 'o', 'p', 'p', 'i', 'n', 'g', '.', 'h', 't', 'm', 'l', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'N', 'O', 'B', 'O', 'X', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 29, 0,	/* 29 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* AVISIT */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00808) */
	HB_P_PUSHLONG, 0, 255, 0, 0, 	/* 65280 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 00813) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_ENDBLOCK,
	HB_P_ZERO,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBTN */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
/* 00831 */ HB_P_LINEOFFSET, 51,	/* 490 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHINT, 14, 1,	/* 270 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'L', 'i', 'n', 'k', 's', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 75,	/* 75 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 34, 0,	/* 34 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	5, 0,	/* AVISIT */
	2, 0,	/* OBTN */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPUSH,
	HB_P_NOT,
	HB_P_PUSHLOCALREF, 255, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPOP,
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 39,	/* 39 */
	'h', 't', 't', 'p', ':', '/', '/', 'w', 'w', 'w', '.', 's', 'u', 'p', 'e', 'r', 'b', 'u', 't', 't', 'o', 'n', 's', '.', 'c', 'o', 'm', '/', 'l', 'i', 'n', 'k', 's', '.', 'h', 't', 'm', 'l', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'N', 'O', 'B', 'O', 'X', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 29, 0,	/* 29 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* AVISIT */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPUSH,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00994) */
	HB_P_PUSHLONG, 0, 255, 0, 0, 	/* 65280 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 00999) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_ENDBLOCK,
	HB_P_ZERO,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBTN */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPOP,
/* 01017 */ HB_P_LINEOFFSET, 59,	/* 498 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 250, 0,	/* 250 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'H', 'o', 'm', 'e', ' ', 'P', 'a', 'g', 'e', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 75,	/* 75 */
	HB_P_PUSHBYTE, 15,	/* 15 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 19, 0,	/* 19 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'h', 't', 't', 'p', ':', '/', '/', 'w', 'w', 'w', '.', 's', 'u', 'p', 'e', 'r', 'b', 'u', 't', 't', 'o', 'n', 's', '.', 'c', 'o', 'm', 0, 
	HB_P_PUSHSTRSHORT, 13,	/* 13 */
	'B', 'R', 'U', 'S', 'H', ',', ' ', 'N', 'O', 'B', 'O', 'X', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01165) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01166) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHLONG, 192, 192, 192, 0, 	/* 12632256 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBTN */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYPOP,
/* 01188 */ HB_P_LINEOFFSET, 67,	/* 506 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 14, 1,	/* 270 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHSTRSHORT, 29,	/* 29 */
	'W', 'e', 'b', ' ', 'M', 'a', 's', 't', 'e', 'r', ':', ' ', ' ', ' ', 'M', 'a', 'n', 'u', 'e', 'l', ' ', 'M', 'e', 'r', 'c', 'a', 'd', 'o', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 200, 0,	/* 200 */
	HB_P_PUSHBYTE, 15,	/* 15 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 19, 0,	/* 19 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 25,	/* 25 */
	'm', 'm', 'e', 'r', 'c', 'a', 'd', 'o', 'g', '@', 'p', 'r', 'o', 'd', 'i', 'g', 'y', '.', 'n', 'e', 't', '.', 'm', 'x', 0, 
	HB_P_PUSHSTRSHORT, 13,	/* 13 */
	'B', 'R', 'U', 'S', 'H', ',', ' ', 'N', 'O', 'B', 'O', 'X', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01353) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01354) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 2, 0,	/* OBTN */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_ARRAYPOP,
/* 01371 */ HB_P_LINEOFFSET, 70,	/* 509 */
	HB_P_LOCALNEARSETINT, 4, 1, 0,	/* NELE 1*/
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_LESSEQUAL,
	HB_P_JUMPFALSENEAR, 46,	/* 46 (abs: 01428) */
/* 01384 */ HB_P_LINEOFFSET, 71,	/* 510 */
	HB_P_MESSAGE, 74, 0,	/* _NSTYLE */
	HB_P_PUSHLOCALNEAR, 2,	/* OBTN */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSYMNEAR, 75,	/* NAND */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 76, 0,	/* NSTYLE */
	HB_P_PUSHLOCALNEAR, 2,	/* OBTN */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_PUSHSYMNEAR, 77,	/* NNOT */
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 0, 0, 1, 0, 	/* 65536 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 01422 */ HB_P_LINEOFFSET, 72,	/* 511 */
	HB_P_LOCALNEARINC, 4,	/* NELE */
	HB_P_JUMPNEAR, 207,	/* -49 (abs: 01377) */
/* 01428 */ HB_P_LINEOFFSET, 74,	/* 513 */
	HB_P_MESSAGE, 46, 0,	/* _OMSGBAR */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 47,	/* TMSGBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 40,	/* 40 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ',', ' ', 161, ' ', 'E', 'm', 'u', 'l', 'a', 't', 'i', 'n', 'g', ' ', 'H', 'i', 'p', 'e', 'r', 'l', 'i', 'n', 'k', 's', ' ', '!', 0, 
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 14,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 01512 */ HB_P_LINEOFFSET, 77,	/* 516 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 10, 0,	/* BLCLICKED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 11, 0,	/* BRCLICKED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 12, 0,	/* BMOVED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 13, 0,	/* BRESIZED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 14, 0,	/* BPAINTED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 15, 0,	/* BKEYDOWN */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 16, 0,	/* BINIT */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 36, 0,	/* 36 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	1, 0,	/* OFONT */
	3, 0,	/* OBRUSH */
	HB_P_PUSHNIL,
	HB_P_PUSHSTATICREF, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_TRUE,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 18, 0,	/* BLBUTTONUP */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_FALSE,
	HB_P_SENDSHORT, 20,
	HB_P_POP,
	HB_P_JUMPNEAR, 16,	/* 16 (abs: 01677) */
/* 01663 */ HB_P_LINEOFFSET, 80,	/* 519 */
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 01677 */ HB_P_LINEOFFSET, 83,	/* 522 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 01682 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( CHILD3 )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 16, 0,	/* locals, params */
	HB_P_SFRAME, 88, 0,	/* symbol (_INITSTATICS) */
/* 00006 */ HB_P_BASELINE, 20, 2,	/* 532 */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSE, 59, 7,	/* 1851 (abs: 01868) */
/* 00020 */ HB_P_LINEOFFSET, 7,	/* 539 */
	HB_P_PUSHBLOCK, 36, 0,	/* 36 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 78, 0,	/* _CCAPTION */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_PUSHSTRSHORT, 1,	/* 1 */
	0, 
	HB_P_SENDSHORT, 1,
	HB_P_POP,
	HB_P_MESSAGE, 79, 0,	/* DISABLE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_SENDSHORT, 1,
	HB_P_POP,
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_POPLOCALNEAR, 5,	/* BACTION */
/* 00060 */ HB_P_LINEOFFSET, 9,	/* 541 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 23,	/* TFONT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'A', 'r', 'i', 'a', 'l', 0, 
	HB_P_ZERO,
	HB_P_PUSHBYTE, 244,	/* -12 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 17,
	HB_P_POPLOCALNEAR, 1,	/* OFONT */
/* 00099 */ HB_P_LINEOFFSET, 10,	/* 542 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 23,	/* TFONT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'A', 'r', 'i', 'a', 'l', 0, 
	HB_P_ZERO,
	HB_P_PUSHBYTE, 248,	/* -8 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 17,
	HB_P_POPLOCALNEAR, 2,	/* OFONT1 */
/* 00138 */ HB_P_LINEOFFSET, 11,	/* 543 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 24,	/* TBRUSH */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'P', 'a', 'p', 'e', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 6,
	HB_P_POPLOCALNEAR, 3,	/* OBR */
/* 00165 */ HB_P_LINEOFFSET, 16,	/* 548 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 25,	/* TMDICHILD */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_ZERO,
	HB_P_PUSHINT, 14, 1,	/* 270 */
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_PUSHSTRSHORT, 54,	/* 54 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', ' ', 'M', 'a', 't', 'r', 'i', 'x', 'e', 's', ' ', 'o', 'f', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', '.', ' ', ' ', 'B', 'u', 's', ' ', 'R', 'e', 's', 'e', 'r', 'v', 'a', 't', 'i', 'o', 'n', 's', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTATIC, 2, 0,	/* OWND */
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 3,	/* OBR */
	HB_P_TRUE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 24,
	HB_P_PUSHSTATICREF, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
/* 00273 */ HB_P_LINEOFFSET, 19,	/* 551 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 80,	/* TBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_FALSE,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'L', 'E', 'F', 'T', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_SENDSHORT, 10,
	HB_P_POPLOCALNEAR, 9,	/* OBAR */
/* 00310 */ HB_P_LINEOFFSET, 20,	/* 552 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 80,	/* TBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_FALSE,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'R', 'I', 'G', 'H', 'T', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_SENDSHORT, 10,
	HB_P_POPLOCALNEAR, 10,	/* OBAR1 */
/* 00348 */ HB_P_LINEOFFSET, 24,	/* 556 */
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_POPLOCALNEAR, 11,	/* ABTN1 */
/* 00369 */ HB_P_LINEOFFSET, 28,	/* 560 */
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 15,	/* AACT1 */
/* 00380 */ HB_P_LINEOFFSET, 29,	/* 561 */
	HB_P_PUSHSYMNEAR, 72,	/* AFILL */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 15,	/* AACT1 */
	HB_P_PUSHLOCALNEAR, 5,	/* BACTION */
	HB_P_DOSHORT, 2,
/* 00391 */ HB_P_LINEOFFSET, 33,	/* 565 */
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'4', 0, 
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'8', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '2', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '6', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '0', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '4', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '8', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '2', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '6', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'4', '0', 0, 
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'3', 0, 
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'7', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '1', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '5', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '9', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '3', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '7', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '1', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '5', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '9', 0, 
	HB_P_ARRAYGEN, 20, 0,	/* 20 */
	HB_P_POPLOCALNEAR, 13,	/* ACAPT1 */
/* 00494 */ HB_P_LINEOFFSET, 44,	/* 576 */
	HB_P_MESSAGE, 81, 0,	/* NEWGROUP */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 11,	/* ABTN1 */
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_PUSHBYTE, 90,	/* 90 */
	HB_P_PUSHLOCALNEAR, 13,	/* ACAPT1 */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 12,	/* 12 */
	'M', 'U', 'L', 'T', 'I', ' ', 'S', 'e', 'a', 't', 'm', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 34,	/* 34 */
	HB_P_PUSHBYTE, 34,	/* 34 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHLOCALNEAR, 15,	/* AACT1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 82,	/* 82 */
	'C', 'l', 'i', 'c', 'k', ' ', 'i', 'z', 'q', 'u', 'i', 'e', 'r', 'd', 'o', ' ', 'p', 'a', 'r', 'a', ' ', 'r', 'e', 's', 'e', 'r', 'v', 'a', 'r', ' ', 'a', 's', 'i', 'e', 'n', 't', 'o', 's', '.', ' ', ' ', 'C', 'l', 'i', 'c', 'k', ' ', 'd', 'e', 'r', 'e', 'c', 'h', 'o', ' ', 'p', 'a', 'r', 'a', ' ', 'c', 'a', 'n', 'c', 'e', 'l', 'a', 'r', ' ', 'r', 'e', 's', 'e', 'r', 'v', 'a', 'c', 'i', 243, 'n', '.', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 26,
	HB_P_POP,
/* 00671 */ HB_P_LINEOFFSET, 48,	/* 580 */
	HB_P_LOCALNEARSETINT, 7, 1, 0,	/* NACT 1*/
/* 00677 */ HB_P_LINEOFFSET, 54,	/* 586 */
	HB_P_LOCALNEARSETINT, 4, 1, 0,	/* NELE 1*/
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_PUSHSYMNEAR, 82,	/* LEN */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 11,	/* ABTN1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_LESSEQUAL,
	HB_P_JUMPFALSENEAR, 89,	/* 89 (abs: 00782) */
/* 00695 */ HB_P_LINEOFFSET, 55,	/* 587 */
	HB_P_LOCALNEARSETINT, 8, 1, 0,	/* NSUB 1*/
	HB_P_PUSHLOCALNEAR, 8,	/* NSUB */
	HB_P_PUSHSYMNEAR, 82,	/* LEN */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 11,	/* ABTN1 */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_LESSEQUAL,
	HB_P_JUMPFALSENEAR, 62,	/* 62 (abs: 00776) */
/* 00716 */ HB_P_LINEOFFSET, 56,	/* 588 */
	HB_P_MESSAGE, 83, 0,	/* _CARGO */
	HB_P_PUSHLOCALNEAR, 11,	/* ABTN1 */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 8,	/* NSUB */
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 13,	/* ACAPT1 */
	HB_P_PUSHLOCALNEAR, 7,	/* NACT */
	HB_P_LOCALNEARINC, 7,	/* NACT */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00739 */ HB_P_LINEOFFSET, 57,	/* 589 */
	HB_P_MESSAGE, 84, 0,	/* _BRCLICKED */
	HB_P_PUSHLOCALNEAR, 11,	/* ABTN1 */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 8,	/* NSUB */
	HB_P_ARRAYPUSH,
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 85,	/* FCANCEL */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00770 */ HB_P_LINEOFFSET, 58,	/* 590 */
	HB_P_LOCALNEARINC, 8,	/* NSUB */
	HB_P_JUMPNEAR, 183,	/* -73 (abs: 00701) */
/* 00776 */ HB_P_LINEOFFSET, 59,	/* 591 */
	HB_P_LOCALNEARINC, 4,	/* NELE */
	HB_P_JUMPNEAR, 159,	/* -97 (abs: 00683) */
/* 00782 */ HB_P_LINEOFFSET, 62,	/* 594 */
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_POPLOCALNEAR, 12,	/* ABTN2 */
/* 00803 */ HB_P_LINEOFFSET, 63,	/* 595 */
	HB_P_PUSHSYMNEAR, 72,	/* AFILL */
	HB_P_PUSHNIL,
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_DUPLICATE,
	HB_P_POPLOCALNEAR, 16,	/* AACT2 */
	HB_P_PUSHLOCALNEAR, 5,	/* BACTION */
	HB_P_DOSHORT, 2,
/* 00822 */ HB_P_LINEOFFSET, 65,	/* 597 */
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'2', 0, 
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'6', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '0', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '4', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '8', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '2', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '6', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '0', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '4', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '8', 0, 
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'1', 0, 
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'5', 0, 
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	'9', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '3', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'1', '7', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '1', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '5', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'2', '9', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '3', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'3', '7', 0, 
	HB_P_ARRAYGEN, 20, 0,	/* 20 */
	HB_P_POPLOCALNEAR, 14,	/* ACAPT2 */
/* 00924 */ HB_P_LINEOFFSET, 75,	/* 607 */
	HB_P_MESSAGE, 81, 0,	/* NEWGROUP */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 12,	/* ABTN2 */
	HB_P_PUSHBYTE, 108,	/* 108 */
	HB_P_PUSHBYTE, 90,	/* 90 */
	HB_P_PUSHLOCALNEAR, 14,	/* ACAPT2 */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 12,	/* 12 */
	'M', 'U', 'L', 'T', 'I', ' ', 'S', 'e', 'a', 't', 'm', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 34,	/* 34 */
	HB_P_PUSHBYTE, 34,	/* 34 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHLOCALNEAR, 16,	/* AACT2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHSTRSHORT, 67,	/* 67 */
	'L', 'e', 'f', 't', ' ', 'C', 'l', 'i', 'c', 'k', ' ', 't', 'o', ' ', 'r', 'e', 's', 'e', 'r', 'v', 'a', 't', 'e', ' ', 's', 'e', 'a', 't', 's', '.', ' ', ' ', 'R', 'i', 'g', 'h', 't', ' ', 'C', 'l', 'i', 'c', 'k', ' ', 't', 'o', ' ', 'c', 'a', 'n', 'c', 'e', 'l', ' ', 'r', 'e', 's', 'e', 'r', 'v', 'a', 't', 'i', 'o', 'n', '.', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 26,
	HB_P_POP,
/* 01086 */ HB_P_LINEOFFSET, 77,	/* 609 */
	HB_P_LOCALNEARSETINT, 7, 1, 0,	/* NACT 1*/
/* 01092 */ HB_P_LINEOFFSET, 79,	/* 611 */
	HB_P_LOCALNEARSETINT, 4, 1, 0,	/* NELE 1*/
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_PUSHSYMNEAR, 82,	/* LEN */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 12,	/* ABTN2 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_LESSEQUAL,
	HB_P_JUMPFALSENEAR, 89,	/* 89 (abs: 01197) */
/* 01110 */ HB_P_LINEOFFSET, 80,	/* 612 */
	HB_P_LOCALNEARSETINT, 8, 1, 0,	/* NSUB 1*/
	HB_P_PUSHLOCALNEAR, 8,	/* NSUB */
	HB_P_PUSHSYMNEAR, 82,	/* LEN */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 12,	/* ABTN2 */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_LESSEQUAL,
	HB_P_JUMPFALSENEAR, 62,	/* 62 (abs: 01191) */
/* 01131 */ HB_P_LINEOFFSET, 81,	/* 613 */
	HB_P_MESSAGE, 83, 0,	/* _CARGO */
	HB_P_PUSHLOCALNEAR, 12,	/* ABTN2 */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 8,	/* NSUB */
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 14,	/* ACAPT2 */
	HB_P_PUSHLOCALNEAR, 7,	/* NACT */
	HB_P_LOCALNEARINC, 7,	/* NACT */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 01154 */ HB_P_LINEOFFSET, 82,	/* 614 */
	HB_P_MESSAGE, 84, 0,	/* _BRCLICKED */
	HB_P_PUSHLOCALNEAR, 12,	/* ABTN2 */
	HB_P_PUSHLOCALNEAR, 4,	/* NELE */
	HB_P_ARRAYPUSH,
	HB_P_PUSHLOCALNEAR, 8,	/* NSUB */
	HB_P_ARRAYPUSH,
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 85,	/* FCANCEL */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 01185 */ HB_P_LINEOFFSET, 83,	/* 615 */
	HB_P_LOCALNEARINC, 8,	/* NSUB */
	HB_P_JUMPNEAR, 183,	/* -73 (abs: 01116) */
/* 01191 */ HB_P_LINEOFFSET, 84,	/* 616 */
	HB_P_LOCALNEARINC, 4,	/* NELE */
	HB_P_JUMPNEAR, 159,	/* -97 (abs: 01098) */
/* 01197 */ HB_P_LINEOFFSET, 89,	/* 621 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'E', 'x', 'i', 't', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 60,	/* 60 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 19, 0,	/* 19 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* OFONT */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_ZERO,
	HB_P_PUSHLONG, 192, 192, 192, 0, 	/* 12632256 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'X', 'P', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_POPLOCALNEAR, 6,	/* OBUT */
/* 01286 */ HB_P_LINEOFFSET, 94,	/* 626 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 128, 0,	/* 128 */
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'D', 'r', 'i', 'v', 'e', 'r', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 33,	/* 33 */
	'P', 'l', 'e', 'a', 's', 'e', ',', ' ', 'd', 'o', 'n', 39, 't', ' ', 'd', 'i', 's', 't', 'u', 'r', 'b', ' ', 't', 'h', 'e', ' ', 'd', 'r', 'i', 'v', 'e', 'r', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'N', 'O', 'B', 'O', 'X', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_ZERO,
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_POP,
/* 01392 */ HB_P_LINEOFFSET, 101,	/* 633 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 176, 0,	/* 176 */
	HB_P_PUSHBYTE, 60,	/* 60 */
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'T', 'V', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'T', 'V', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_POP,
/* 01472 */ HB_P_LINEOFFSET, 108,	/* 640 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 176, 0,	/* 176 */
	HB_P_PUSHINT, 200, 0,	/* 200 */
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'T', 'V', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'T', 'V', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_POP,
/* 01553 */ HB_P_LINEOFFSET, 115,	/* 647 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHINT, 176, 0,	/* 176 */
	HB_P_PUSHINT, 54, 1,	/* 310 */
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'T', 'V', 0, 
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'T', 'V', 0, 
	HB_P_ARRAYGEN, 1, 0,	/* 1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT1 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'N', 'O', 'B', 'O', 'X', 'T', 'R', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 0, 128, 128, 0, 	/* 8421376 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_POP,
/* 01634 */ HB_P_LINEOFFSET, 117,	/* 649 */
	HB_P_MESSAGE, 46, 0,	/* _OMSGBAR */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 47,	/* TMSGBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSTRSHORT, 39,	/* 39 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ',', ' ', 161, ' ', 'M', 'a', 't', 'r', 'i', 'x', 'e', 's', ' ', 'o', 'f', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', '!', 0, 
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_SENDSHORT, 14,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 01717 */ HB_P_LINEOFFSET, 120,	/* 652 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 10, 0,	/* BLCLICKED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 11, 0,	/* BRCLICKED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 12, 0,	/* BMOVED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 13, 0,	/* BRESIZED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 14, 0,	/* BPAINTED */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 15, 0,	/* BKEYDOWN */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 16, 0,	/* BINIT */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 36, 0,	/* 36 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	1, 0,	/* OFONT */
	2, 0,	/* OFONT1 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTATICREF, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_TRUE,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 18, 0,	/* BLBUTTONUP */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_FALSE,
	HB_P_SENDSHORT, 20,
	HB_P_POP,
	HB_P_JUMPNEAR, 16,	/* 16 (abs: 01882) */
/* 01868 */ HB_P_LINEOFFSET, 123,	/* 655 */
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHSTATIC, 3, 0,	/* ACHILD */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 01882 */ HB_P_LINEOFFSET, 126,	/* 658 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 01887 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( FCANCEL )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 0, 1,	/* locals, params */
/* 00003 */ HB_P_BASELINE, 152, 2,	/* 664 */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 21,	/* 21 */
	'R', 'e', 's', 'e', 'r', 'v', 'a', 't', 'i', 'o', 'n', ' ', 'C', 'a', 'n', 'c', 'e', 'l', 'e', 'd', 0, 
	HB_P_DOSHORT, 1,
/* 00034 */ HB_P_LINEOFFSET, 1,	/* 665 */
	HB_P_MESSAGE, 86, 0,	/* ENABLE */
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 00044 */ HB_P_LINEOFFSET, 2,	/* 666 */
	HB_P_MESSAGE, 78, 0,	/* _CCAPTION */
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_MESSAGE, 87, 0,	/* CARGO */
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_SENDSHORT, 0,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00061 */ HB_P_LINEOFFSET, 3,	/* 667 */
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 1,	/* OBTN */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 00071 */ HB_P_LINEOFFSET, 5,	/* 669 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 00076 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_STATIC( FCODIGO )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 8, 0,	/* locals, params */
/* 00003 */ HB_P_BASELINE, 165, 2,	/* 677 */
	HB_P_FALSE,
	HB_P_POPLOCALNEAR, 7,	/* LENABLE */
	HB_P_PUSHSYMNEAR, 59,	/* ARRAY */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 9,	/* 9 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 8,	/* OBTN */
/* 00018 */ HB_P_LINEOFFSET, 2,	/* 679 */
	HB_P_PUSHSYMNEAR, 60,	/* SPACE */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_POPLOCALNEAR, 5,	/* CVAR */
/* 00029 */ HB_P_LINEOFFSET, 4,	/* 681 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 24,	/* TBRUSH */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'B', 'a', 'c', 'k', '1', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 6,
	HB_P_POPLOCALNEAR, 4,	/* OBRUSH */
/* 00056 */ HB_P_LINEOFFSET, 5,	/* 682 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 23,	/* TFONT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHSTRSHORT, 14,	/* 14 */
	'M', 'S', ' ', 'S', 'a', 'n', 's', ' ', 'S', 'e', 'r', 'i', 'f', 0, 
	HB_P_ZERO,
	HB_P_PUSHBYTE, 248,	/* -8 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 17,
	HB_P_POPLOCALNEAR, 2,	/* OFONT */
/* 00103 */ HB_P_LINEOFFSET, 9,	/* 686 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 61,	/* TDIALOG */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_ZERO,
	HB_P_PUSHINT, 60, 1,	/* 316 */
	HB_P_PUSHINT, 104, 1,	/* 360 */
	HB_P_PUSHSTRSHORT, 35,	/* 35 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'd', 'i', 'a', 'l', 'o', 'g', 's', ' ', 'f', 'r', 'o', 'm', ' ', 'c', 'o', 'd', 'e', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_ZERO,
	HB_P_PUSHLONG, 192, 192, 192, 0, 	/* 12632256 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'o', 'D', 'l', 'g', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 24,
	HB_P_POPLOCALNEAR, 1,	/* ODLG */
/* 00191 */ HB_P_LINEOFFSET, 11,	/* 688 */
	HB_P_MESSAGE, 74, 0,	/* _NSTYLE */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSYMNEAR, 26,	/* NOR */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 76, 0,	/* NSTYLE */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_SENDSHORT, 0,
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00215 */ HB_P_LINEOFFSET, 19,	/* 696 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_ONE,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'F', 'i', 'l', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 18,	/* 18 */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 29, 0,	/* 29 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	8, 0,	/* OBTN */
	3, 0,	/* OGET */
	HB_P_PUSHSYMNEAR, 67,	/* MENUARCH */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYPUSH,
	HB_P_DOSHORT, 1,
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'E', 'm', 'u', 'l', 'a', 't', 'i', 'n', 'g', ' ', 'm', 'e', 'n', 'u', 's', ' ', 'i', 'n', ' ', 'd', 'i', 'a', 'l', 'o', 'g', 's', ' ', 'w', 'i', 't', 'h', ' ', 'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', 0, 
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', ',', ' ', 'T', 'e', 'x', 't', ' ', 'o', 'n', 'l', 'y', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYPOP,
/* 00388 */ HB_P_LINEOFFSET, 22,	/* 699 */
	HB_P_MESSAGE, 74, 0,	/* _NSTYLE */
	HB_P_PUSHLOCALNEAR, 8,	/* OBTN */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSYMNEAR, 75,	/* NAND */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 76, 0,	/* NSTYLE */
	HB_P_PUSHLOCALNEAR, 8,	/* OBTN */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_PUSHSYMNEAR, 77,	/* NNOT */
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 0, 0, 1, 0, 	/* 65536 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00426 */ HB_P_LINEOFFSET, 30,	/* 707 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_PUSHBYTE, 20,	/* 20 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'&', 'E', 'x', 'i', 't', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_PUSHBYTE, 8,	/* 8 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 17, 0,	/* 17 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'E', 'm', 'u', 'l', 'a', 't', 'i', 'n', 'g', ' ', 'm', 'e', 'n', 'u', 's', ' ', 'i', 'n', ' ', 'd', 'i', 'a', 'l', 'o', 'g', 's', ' ', 'w', 'i', 't', 'h', ' ', 'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', 0, 
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', ',', ' ', 't', 'e', 'x', 't', ' ', 'o', 'n', 'l', 'y', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 9,	/* 9 */
	HB_P_ARRAYPOP,
/* 00588 */ HB_P_LINEOFFSET, 33,	/* 710 */
	HB_P_MESSAGE, 74, 0,	/* _NSTYLE */
	HB_P_PUSHLOCALNEAR, 8,	/* OBTN */
	HB_P_PUSHBYTE, 9,	/* 9 */
	HB_P_ARRAYPUSH,
	HB_P_PUSHSYMNEAR, 75,	/* NAND */
	HB_P_PUSHNIL,
	HB_P_MESSAGE, 76, 0,	/* NSTYLE */
	HB_P_PUSHLOCALNEAR, 8,	/* OBTN */
	HB_P_PUSHBYTE, 9,	/* 9 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_PUSHSYMNEAR, 77,	/* NNOT */
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 0, 0, 1, 0, 	/* 65536 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00626 */ HB_P_LINEOFFSET, 36,	/* 713 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 63,	/* TGET */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 31,	/* 31 */
	HB_P_PUSHBYTE, 62,	/* 62 */
	HB_P_PUSHBLOCK, 28, 0,	/* 28 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* CVAR */
	HB_P_PUSHSYMNEAR, 64,	/* PCOUNT */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ZERO,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 6,	/* 6 (abs: 00662) */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 00667) */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_DUPLICATE,
	HB_P_POPLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHBYTE, 51,	/* 51 */
	HB_P_PUSHBYTE, 11,	/* 11 */
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 65, 0,	/* 65 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	5, 0,	/* CVAR */
	HB_P_PUSHSYMNEAR, 65,	/* EMPTY */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_JUMPFALSENEAR, 47,	/* 47 (abs: 00738) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 35,	/* 35 */
	'Y', 'o', 'u', ' ', 'm', 'u', 's', 't', ' ', 't', 'o', ' ', 'w', 'r', 'i', 't', 'e', ' ', 's', 'o', 'm', 'e', 't', 'h', 'i', 'n', 'g', ' ', 'i', 'n', ' ', 'g', 'e', 't', 0, 
	HB_P_DOSHORT, 1,
	HB_P_FALSE,
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 00739) */
	HB_P_TRUE,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'o', 'G', 'e', 't', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 33,
	HB_P_POPLOCALNEAR, 3,	/* OGET */
/* 00775 */ HB_P_LINEOFFSET, 49,	/* 726 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 59,	/* 59 */
	HB_P_ONE,
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'A', '&', 'c', 't', 'i', 'v', 'a', 't', 'e', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '1', 0, 
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '2', 0, 
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '3', 0, 
	HB_P_PUSHSTRSHORT, 4,	/* 4 */
	'O', 'K', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 25,	/* 25 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 38, 0,	/* 38 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	7, 0,	/* LENABLE */
	8, 0,	/* OBTN */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_NOT,
	HB_P_POPLOCALNEAR, 255,	/* localvar1 */
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 36, 0,	/* REFRESH */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYPUSH,
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHSTRSHORT, 41,	/* 41 */
	'W', 'r', 'i', 't', 'e', ' ', 'a', 'n', 'y', 't', 'h', 'i', 'n', 'g', ' ', 'i', 'n', ' ', 'G', 'e', 't', ' ', 't', 'o', ' ', 'u', 's', 'e', ' ', 't', 'h', 'i', 's', ' ', 'b', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_PUSHSTRSHORT, 19,	/* 19 */
	'B', 'R', 'U', 'S', 'H', ',', ' ', 'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'T', 'O', 'P', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 00973) */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 00974) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHLONG, 192, 192, 192, 0, 	/* 12632256 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_ONE,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 4,	/* OBRUSH */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_ONE,
	HB_P_ARRAYPOP,
/* 00996 */ HB_P_LINEOFFSET, 62,	/* 739 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 59,	/* 59 */
	HB_P_PUSHBYTE, 61,	/* 61 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'a', '&', 'n', 'c', 'e', 'l', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '1', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '2', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '3', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'C', 'A', 'N', 'C', 'E', 'L', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 25,	/* 25 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 17, 0,	/* 17 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHSTRSHORT, 24,	/* 24 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'e', 'n', 'u', 0, 
	HB_P_PUSHSTRSHORT, 45,	/* 45 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', ' ', 'R', 'I', 'G', 'H', 'T', ' ', '(', 'D', 'e', 'f', 'a', 'u', 'l', 't', ')', ',', ' ', 'R', 'O', 'U', 'N', 'D', ',', ' ', 'M', 'E', 'N', 'U', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHINT, 255, 0,	/* 255 */
	HB_P_ZERO,
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYGEN, 3, 0,	/* 3 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'R', 'O', 'U', 'N', 'D', 'R', 'E', 'C', 'T', 0, 
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 33,	/* MENUPOP */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_ARRAYPOP,
/* 01229 */ HB_P_LINEOFFSET, 77,	/* 754 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 59,	/* 59 */
	HB_P_PUSHBYTE, 121,	/* 121 */
	HB_P_PUSHSTRSHORT, 19,	/* 19 */
	'&', 'M', 'u', 'l', 't', 'i', 13, 10, 'L', 'i', 'n', 'e', 13, 10, 'T', 'e', 'x', 't', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 25,	/* 25 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	7, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHSTRSHORT, 46,	/* 46 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ':', ' ', 'M', 'u', 'l', 't', 'i', 'l', 'i', 'n', 'e', ' ', 't', 'e', 'x', 't', ',', ' ', 'D', 'i', 'n', 'a', 'm', 'i', 'c', ' ', 'C', 'o', 'l', 'o', 'r', 's', 0, 
	HB_P_PUSHSTRSHORT, 21,	/* 21 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', ' ', 'R', 'I', 'G', 'H', 'T', ',', ' ', 'R', 'O', 'U', 'N', 'D', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 41, 0,	/* 41 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 25,	/* 25 (abs: 01459) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01452) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 01457) */
	HB_P_PUSHLONG, 0, 0, 255, 0, 	/* 16711680 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01460) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 39, 0,	/* 39 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 19,	/* 19 (abs: 01494) */
	HB_P_PUSHLONG, 255, 255, 0, 0, 	/* 65535 */
	HB_P_PUSHLONG, 0, 128, 0, 0, 	/* 32768 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYGEN, 3, 0,	/* 3 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 01499) */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_ENDBLOCK,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'R', 'O', 'U', 'N', 'D', 'R', 'E', 'C', 'T', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYPOP,
/* 01528 */ HB_P_LINEOFFSET, 93,	/* 770 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 98,	/* 98 */
	HB_P_PUSHBYTE, 7,	/* 7 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'&', 'P', 'r', 'u', 'e', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 28,	/* 28 */
	HB_P_PUSHBYTE, 28,	/* 28 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 27, 0,	/* 27 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	3, 0,	/* OGET */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_DOSHORT, 1,
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 52,	/* 52 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'e', 'n', 'u', '.', ' ', 'D', 'e', 'g', 'r', 'a', 'd', 'e', 'd', ' ', 'b', 'a', 'c', 'k', 'g', 'r', 'o', 'u', 'n', 'd', ' ', 'c', 'o', 'l', 'o', 'r', '.', 0, 
	HB_P_PUSHSTRSHORT, 51,	/* 51 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'T', 'O', 'P', ',', ' ', 'B', 'I', 'T', 'M', 'A', 'P', ' ', 'O', 'P', 'A', 'Q', 'U', 'E', ',', ' ', 'M', 'E', 'N', 'U', ',', ' ', 'N', 'O', 'B', 'O', 'R', 'D', 'E', 'R', ',', ' ', 'C', 'A', 'N', 'C', 'E', 'L', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'N', 'O', 'B', 'O', 'R', 'D', 'E', 'R', 0, 
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01774) */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01775) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHLONG, 0, 0, 128, 0, 	/* 8388608 */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_ARRAYGEN, 3, 0,	/* 3 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_ONE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 33,	/* MENUPOP */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYPOP,
/* 01821 */ HB_P_LINEOFFSET, 108,	/* 785 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 98,	/* 98 */
	HB_P_PUSHBYTE, 52,	/* 52 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'P', '&', 'r', 'u', 'e', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'T', 'O', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 28,	/* 28 */
	HB_P_PUSHBYTE, 28,	/* 28 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 27, 0,	/* 27 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	3, 0,	/* OGET */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_DOSHORT, 1,
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 12, 0,	/* 12 */
	1, 0,	/* number of local parameters (1) */
	1, 0,	/* number of local variables (1) */
	7, 0,	/* LENABLE */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 29,	/* 29 */
	'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'B', 'O', 'T', 'T', 'O', 'M', ' ', 'C', 'A', 'N', 'C', 'E', 'L', ',', ' ', 'R', 'O', 'U', 'N', 'D', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 25, 0,	/* 25 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 21, 0,	/* LMOUSEOVER */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 9,	/* 9 (abs: 01994) */
	HB_P_PUSHLONG, 0, 0, 128, 0, 	/* 8388608 */
	HB_P_JUMPNEAR, 3,	/* 3 (abs: 01995) */
	HB_P_ZERO,
	HB_P_ENDBLOCK,
	HB_P_PUSHBLOCK, 36, 0,	/* 36 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_MESSAGE, 20, 0,	/* LACTIVE */
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_JUMPFALSENEAR, 16,	/* 16 (abs: 02026) */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHINT, 128, 0,	/* 128 */
	HB_P_ONE,
	HB_P_ARRAYGEN, 3, 0,	/* 3 */
	HB_P_JUMPNEAR, 7,	/* 7 (abs: 02031) */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_ENDBLOCK,
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'R', 'O', 'U', 'N', 'D', 0, 
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_ARRAYPOP,
/* 02056 */ HB_P_LINEOFFSET, 118,	/* 795 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 98,	/* 98 */
	HB_P_PUSHBYTE, 95,	/* 95 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'P', 'r', '&', 'u', 'e', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 27,	/* 27 */
	HB_P_PUSHBYTE, 28,	/* 28 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHSTRSHORT, 41,	/* 41 */
	'W', 'r', 'i', 't', 'e', ' ', 'a', 'n', 'y', 't', 'h', 'i', 'n', 'g', ' ', 'i', 'n', ' ', 'G', 'e', 't', ' ', 't', 'o', ' ', 'u', 's', 'e', ' ', 't', 'h', 'i', 's', ' ', 'b', 'u', 't', 't', 'o', 'n', 0, 
	HB_P_PUSHSTRSHORT, 25,	/* 25 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'B', 'O', 'T', 'T', 'O', 'M', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_ARRAYPOP,
/* 02249 */ HB_P_LINEOFFSET, 129,	/* 806 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 30,	/* TSBUTTON */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 98,	/* 98 */
	HB_P_PUSHINT, 138, 0,	/* 138 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'P', 'r', '&', 'u', 'e', 'b', 'a', 0, 
	HB_P_MACROTEXT,
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '1', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '2', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '3', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'E', 'L', 'P', '4', 0, 
	HB_P_ARRAYGEN, 4, 0,	/* 4 */
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 27,	/* 27 */
	HB_P_PUSHBYTE, 28,	/* 28 */
	HB_P_ARRAYGEN, 2, 0,	/* 2 */
	HB_P_TRUE,
	HB_P_PUSHBLOCK, 18, 0,	/* 18 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 66,	/* MSGINFO */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_PUSHSTRSHORT, 37,	/* 37 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ' ', 'w', 'i', 't', 'h', ' ', 'm', 'e', 'n', 'u', ' ', 'a', 'n', 'd', ' ', 'L', 'o', 'o', 'k', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', ',', ' ', 'M', 'E', 'N', 'U', ',', ' ', 'T', 'E', 'X', 'T', ' ', 'O', 'N', '_', 'T', 'O', 'P', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'L', 'O', 'O', 'K', ' ', 'W', '9', '7', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_ONE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 15, 0,	/* 15 */
	1, 0,	/* number of local parameters (1) */
	0, 0,	/* number of local variables (0) */
	HB_P_PUSHSYMNEAR, 33,	/* MENUPOP */
	HB_P_PUSHNIL,
	HB_P_PUSHLOCALNEAR, 1,	/* codeblockvar1 */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 25,
	HB_P_PUSHLOCALREF, 8, 0,	/* OBTN */
	HB_P_PUSHBYTE, 7,	/* 7 */
	HB_P_ARRAYPOP,
/* 02455 */ HB_P_LINEOFFSET, 135,	/* 812 */
	HB_P_MESSAGE, 9, 0,	/* ACTIVATE */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_MESSAGE, 10, 0,	/* BLCLICKED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 12, 0,	/* BMOVED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_SENDSHORT, 0,
	HB_P_MESSAGE, 68, 0,	/* _BPAINTED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_PUSHBLOCK, 47, 0,	/* 47 */
	2, 0,	/* number of local parameters (2) */
	1, 0,	/* number of local variables (1) */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 69,	/* TSLINES */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHBYTE, 19,	/* 19 */
	HB_P_ZERO,
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'H', 'L', 'I', 'N', 'E', 0, 
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_PUSHLONG, 255, 255, 255, 0, 	/* 16777215 */
	HB_P_PUSHLONG, 128, 128, 128, 0, 	/* 8421504 */
	HB_P_SENDSHORT, 8,
	HB_P_ENDBLOCK,
	HB_P_SENDSHORT, 1,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHBLOCK, 121, 0,	/* 121 */
	1, 0,	/* number of local parameters (1) */
	2, 0,	/* number of local variables (2) */
	3, 0,	/* OGET */
	1, 0,	/* ODLG */
	HB_P_MESSAGE, 49, 0,	/* SETFOCUS */
	HB_P_PUSHLOCALNEAR, 255,	/* localvar1 */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
	HB_P_MESSAGE, 46, 0,	/* _OMSGBAR */
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_MESSAGE, 5, 0,	/* NEW */
	HB_P_PUSHSYMNEAR, 47,	/* TMSGBAR */
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHLOCALNEAR, 254,	/* localvar2 */
	HB_P_PUSHSTRSHORT, 80,	/* 80 */
	'S', 'u', 'p', 'e', 'r', ' ', 'B', 'u', 't', 't', 'o', 'n', 's', ',', ' ', 161, ' ', 'A', 'l', 'l', ' ', 'o', 'f', ' ', 't', 'h', 'e', ' ', 'b', 'u', 't', 't', 'o', 'n', 's', ' ', 'i', 'n', ' ', 'a', ' ', 's', 't', 'a', 'n', 'd', ' ', 'a', 'l', 'o', 'n', 'e', ' ', 'c', 'l', 'a', 's', 's', ' ', '(', 'N', 'O', ' ', 'B', 't', 'n', 'B', 'm', 'p', ' ', 's', 'u', 'b', 'c', 'l', 'a', 's', 's', ')', 0, 
	HB_P_SENDSHORT, 2,
	HB_P_SENDSHORT, 1,
	HB_P_ENDBLOCK,
	HB_P_MESSAGE, 11, 0,	/* BRCLICKED */
	HB_P_PUSHLOCALNEAR, 1,	/* ODLG */
	HB_P_SENDSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 11,
	HB_P_POP,
/* 02667 */ HB_P_LINEOFFSET, 137,	/* 814 */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 2,	/* OFONT */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 02677 */ HB_P_LINEOFFSET, 138,	/* 815 */
	HB_P_MESSAGE, 17, 0,	/* END */
	HB_P_PUSHLOCALNEAR, 4,	/* OBRUSH */
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 02687 */ HB_P_LINEOFFSET, 140,	/* 817 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 02692 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC_INITSTATICS()
{
   static const BYTE pcode[] =
   {
	HB_P_STATICS, 88, 0, 3, 0,	/* symbol (_INITSTATICS), 3 statics */
	HB_P_SFRAME, 88, 0,	/* symbol (_INITSTATICS) */
	HB_P_ARRAYGEN, 0, 0,	/* 0 */
	HB_P_POPSTATIC, 1, 0,	/* AFWSTACK */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_ARRAYDIM, 1, 0,	/* 1 */
	HB_P_POPSTATIC, 3, 0,	/* ACHILD */
	HB_P_ENDPROC
/* 00023 */
   };

   hb_vmExecute( pcode, symbols );
}

