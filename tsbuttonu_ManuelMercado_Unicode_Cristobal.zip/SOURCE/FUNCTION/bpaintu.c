/* TSButton Class, paint routines
   Author: Manuel Mercado
   Last update: Sept 11th, 2009
*/

#ifdef __HARBOUR__
#ifndef __XHARBOUR__
   #define _HB_API_INTERNAL_
   #define HB_LEGACY_TYPES_ON
#endif
#endif

#include <windows.h>
#include <hbdefs.h>
#include <hbapiitm.h>
#include <hbvm.h>

#ifdef __XHARBOUR__
   int  hb_parvni(  int  iParam, int iIndex );
   long hb_parvnl(  int  iParam, int iIndex );
   void hb_storvni( int  iValue, int iParam, int iIndex );
   void hb_storvnl( LONG lValue, int iParam, int iIndex );
#endif


#define NOTSRCAND 0x220326

int hue, sat, lig ;

static void RectDisable( HDC , LPRECT ) ;
static void DrawMasked( HDC hdc, HBITMAP hbm, signed int y, signed int x ) ;
static void DrawGrayed( HDC hDC, HBITMAP hBmp, signed int iRow, signed int iCol ) ;
static void DegradColor( HDC hDC, RECT * rori, COLORREF cFrom, COLORREF cTo ) ;

void DrawBitmap( HDC hdc, HBITMAP hbm, WORD wCol, WORD wRow, WORD wWidth, WORD wHeight, DWORD dwRaster ) ;
void DrawGray( HDC hDC, HBITMAP hBmp, signed int iRow, signed int iCol, signed int width, signed int height ) ;
void GoPoint( HDC, int, int ) ;
void SBtnBox( HDC, RECT *, COLORREF, BOOL, int ) ;
void VertSeparator( HDC, HWND, int, COLORREF, BOOL ) ;
void HorzSeparator( HDC, HWND, int, COLORREF, BOOL ) ;
void ColorDegrad( HDC hDC, RECT * rori, COLORREF cFrom, COLORREF cTo, int nDegType, int iRound, int iCorner ) ;
void SBtnRoundBox( HDC, RECT *, COLORREF, BOOL, BOOL ) ;
void cDrawBoxes( HDC, RECT *, int, LPSTR, HFONT, int, COLORREF, COLORREF, COLORREF, BOOL, int ) ;

int GetTextExtent( HDC, LPSTR, int ) ;

COLORREF MakeDarker( COLORREF, signed long ) ;

BOOL AlphaPaint( HDC dcDest, int x, int y, int cx, int cy, HDC dcSrc, int sx, int sy, int scx, int scy, int alpha ) ;
BOOL DetectAlpha( HDC dcSrc, int sx, int sy, int scx, int scy ) ;

int DrawTextAW( HDC hDC, LPSTR lpchText, int nCount, LPRECT lpRect, UINT uFormat );

//---------------------------------------------------------------------------//

 // ( hWnd, hBitmaP, lPressed,
 //   hFont, cText, nPos, nClrText, ClrBack,
 //   lMouseOver, lOpaque, hBrush, nRows, lW97,
 //   lAdjust, lMenu, lMenuPress, lFocused,
 //   nShape, lBorder, lBox, nClip, nClrTo, lHorz, lRound )

HB_FUNC( SBTNPAINT )
{
   HWND  hWnd         = ( HWND    ) hb_parnl( 1 ) ;
   HBITMAP hBitMap1   = ( HBITMAP ) hb_parnl( 2 ) ;
   BOOL  bPressed     = hb_parl( 3 ) ;
   HFONT hFont        = ( HFONT   ) hb_parnl( 4 ) ;
   LPSTR cText        = ( LPSTR   ) hb_parc( 5 ) ;
   int   nPos         = hb_parni( 6 ) ;
   COLORREF nClrText  = hb_parnl( 7 ) ;
   COLORREF ClrBack   = hb_parnl( 8 ) ;
   BOOL bMOver        = hb_parl( 9 ) ;
   BOOL bOpaque       = hb_parl( 10 ) ;
   HBRUSH wBrush      = ( HBRUSH  ) hb_parnl( 11 ) ;
   int  nRows         = hb_parni( 12 ) ;
   int  iBorder       = hb_parni( 13 ) ;
   BOOL bAdjust       = hb_parl( 14 ) ;
   BOOL bMenu         = hb_parl( 15 ) ;
   BOOL bMPress       = hb_parl( 16 ) ;
   BOOL bFocused      = hb_parl( 17 ) ;
   int  iShape        = hb_parni( 18 ) ;
   int  iClip         = hb_parni( 19 ) ;
   COLORREF nClrTo    = hb_parnl( 20 ) ;
   int iDegType       = hb_parni( 21 ) ;
   HBITMAP hShape     = ( HBITMAP ) hb_parnl( 22 ) ;
   BOOL bDisable      = hb_parl( 23 ) ;
   BOOL b3DInv        = ( ISLOG( 24 ) ? ! hb_parl( 24 ) : FALSE ) ;
   BOOL b3D           = ( ISLOG( 24 ) ? TRUE : FALSE ) ;
   COLORREF nClr3DL   = ( ISNUM( 25 ) ? hb_parnl( 25 ) : GetSysColor( COLOR_BTNHIGHLIGHT ) ) ;
   COLORREF nClr3DS   = ( ISNUM( 26 ) ? hb_parnl( 26 ) : GetSysColor( COLOR_BTNSHADOW ) ) ;
   int iTTop          = hb_parni( 27 ) ;
   int iTLeft         = hb_parni( 28 ) ;
   BOOL bClrRct       = hb_parl( 29 ) ;
   int iClipTot       = hb_parni( 30 ) ;
   COLORREF ClrBord   = hb_parnl( 31 ) ;
   BOOL bBBar         = hb_parl( 32 ) ;
   int iCorner        = ( ISNUM( 33 ) ? hb_parni( 33 ) : 0 ) ;
   int iAlpha         = hb_parni( 34 ) ;
   BOOL bTPos         = ISNUM( 27 ) ;
   LOGBRUSH lb ;
   RECT rct, rctt, rctm, rctb ;
   HBRUSH hBrush, hBOld ;
   BITMAP bm, bs ;
   TEXTMETRIC tm ;
   HFONT hOldFont ;
   WORD nTop, nLeft, nBkOld ;
   int iROP, iType, iBottom, iTop, iLeft, iRight ;
   WORD nWidth, nHeight, ibmWidth ;
   COLORREF lBkColor ;
   HDC hdcBmp, mDC, nDC, hDC = GetDC( hWnd ) ;
   HRGN hRgn, hRgn1, hOldRgn, hOldRg1 ;
   HPEN hPen, hOldPen ;
   POINT pt ;
   LPBYTE lpBits ;
   HBITMAP hBmOld1, hBmOld2, hMask ;
 
   bOpaque = ( bAdjust ? TRUE : bOpaque ) ;
   hOldFont = SelectObject( hDC, hFont ) ;
   GetClientRect( hWnd, &rctt ) ;
   GetClientRect( hWnd, &rctb ) ;
   GetClientRect( hWnd, &rct ) ;
   GetTextMetrics( hDC, &tm ) ;
   SetTextColor( hDC, nClrText ) ;
   SetBkColor( hDC, ClrBack ) ;
   lBkColor = GetBkColor( hDC ) ;
   nHeight  = ( nRows > 0 ? nRows * tm.tmHeight : tm.tmHeight ) ;

   if( nPos )
   {
      switch( nPos )
      {
         case 6 : // text on top out of button
            rct.top += nHeight ;
            rctb.top += nHeight ;
            rct.bottom += nHeight ;
            rctb.bottom += nHeight ;
            break ;

         case 7 : // text on bottom out of button
            rct.bottom -= nHeight ;
            rctb.bottom -= nHeight ;
            break ;
      }
   }

   if( wBrush )
   {
      hBOld = SelectObject( hDC, wBrush ) ;
   }

   if( hShape || ! iBorder || iBorder == 3 )
   {
      nBkOld = SetBkMode( hDC, TRANSPARENT ) ;
   }

   if( nPos && hBitMap1 )
   {
      GetObject( ( HGDIOBJ ) hBitMap1, sizeof( BITMAP ), ( LPSTR ) &bm ) ;
   }

   switch( iShape )
   {
      case 4 :  // bitmap shape
      {
         DrawMasked( hDC, hShape, rct.top, rct.left ) ;
         break ;
      }

      case 5 :  // office shape
      {
         hRgn = CreateRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
         hOldRgn = SelectObject( hDC, hRgn ) ;
         iLeft   = rct.left ;
         iRight  = rct.right ;
         iTop    = rct.top ;
         iBottom = rct.bottom ;
         rct.bottom = ( rct.bottom / 4 ) ;
         DegradColor( hDC, &rct, nClrTo, ClrBack ) ;
         rct.top    = rct.bottom ;
         rct.bottom = iBottom ;

         DegradColor( hDC, &rct, ClrBack, nClrTo ) ;

         if( bMOver && bBBar )
         {
            rct.top    = iTop + 1 ;
            rct.bottom = iBottom  - 2 ;
            rct.left   = iLeft + 1 ;
            rct.right  = iRight - 1 ;
            cDrawBoxes( hDC, &rct, 12, "", 0, 0, 0, RGB( 255, 212, 142 ), 0, FALSE, 0 ) ;
         }

         rct.top    = iTop ;
         rct.left   = iLeft ;
         rct.bottom = iBottom + 1 ;
         rct.right  = iRight ;

         if( iBorder && ! bBBar )
         {
            if( iBorder == 2 )
               cDrawBoxes( hDC, &rct, 12, "", 0, 0, 0, ClrBord, 0, FALSE, 0 ) ;

            rct.top += ( iBorder > 1 ? 1 : 0 ) ;
            rct.left += ( iBorder > 1 ? 1 : 0 ) ;
            rct.right -= ( iBorder > 1 ? 1 : 0 ) ;
            rct.bottom -= ( iBorder > 1 ? 1 : 0 ) ;

            cDrawBoxes( hDC, &rct, 3, "", 0, 0, MakeDarker( ClrBack, -40 ), MakeDarker( ClrBack, 40 ), 0, FALSE, 0 ) ;

            rct.top    = iTop ;
            rct.left   = iLeft ;
            rct.bottom = iBottom ;
            rct.right  = iRight ;
         }
         break ;
      }
      case 6 :  // XP shape
      {
         hRgn = CreateRoundRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1, 5, 5 ) ;
         hOldRgn = SelectObject( hDC, hRgn ) ;
         DegradColor( hDC, &rct, RGB( 255, 255, 255 ), RGB( 210, 210, 210 ) ) ;
         if( bFocused || bMOver || bPressed )
         {
            ExcludeClipRect( hDC, rct.left + 3, rct.top + 3, rct.right - 3, rct.bottom - 3 ) ;
         }

         if( bFocused && ! bMOver && ! bPressed )
            DegradColor( hDC, &rct, MakeDarker( GetSysColor( COLOR_HIGHLIGHT ), -120 ), GetSysColor( COLOR_HIGHLIGHT ) ) ;
         else if( bMOver )
            DegradColor( hDC, &rct, RGB( 255, 212, 142 ), RGB( 185, 122, 0 ) ) ;
         else if( bPressed )
            DegradColor( hDC, &rct, GetSysColor( COLOR_ACTIVECAPTION ),
                         MakeDarker( GetSysColor( COLOR_ACTIVECAPTION ), -40 ) ) ;

         cDrawBoxes( hDC, &rct, 11, "", 0, 0, 0,
                     ( bDisable ? RGB( 192, 192, 192 ) : MakeDarker( GetSysColor( COLOR_HIGHLIGHT ), 30 ) ), 0,
                     FALSE, 0 ) ;
         SelectObject( hDC, hOldRgn ) ;
         DeleteObject( hRgn ) ;
         hRgn = CreateRoundRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1, 5, 5 ) ;
         SelectObject( hDC, hRgn ) ;
         break ;
      }
      case 7 :  // crystal theme shape
      {
         if( ! bBBar || bMOver )
         {
            hRgn = CreateRoundRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1, 5, 5 ) ;
         }
         else
         {
            hRgn = CreateRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
         }

         hOldRgn = SelectObject( hDC, hRgn ) ;
         iLeft   = rct.left ;
         iRight  = rct.right ;
         iTop    = rct.top ;
         iBottom = rct.bottom ;
         rct.bottom = ( rct.bottom / 4 ) ;
         DegradColor( hDC, &rct, ( ! bMOver ? nClrTo : MakeDarker( nClrTo, -10 ) ),
                                 ( ! bMOver ? MakeDarker( ClrBack, -40 ) : MakeDarker( ClrBack, -40 ) ) ) ;

         rct.top    = rct.bottom ;
         rct.bottom = iBottom ;

         DegradColor( hDC, &rct, ( ! bMOver ? ClrBack : MakeDarker( ClrBack, -10 ) ),
                                 ( ! bMOver ? MakeDarker( ClrBack, -10 ) : MakeDarker( ClrBack, -20 ) ) ) ;

         if( ! bBBar )
         {
             rct.top    = iTop + 1 ;
             rct.left   += 1 ;
             rct.bottom -= 1 ;
             rct.right  -= 1 ;
         }
         else
         {
            rct.top = iTop ;
            rct.bottom -= 1 ;
         }

         if( ! bBBar || ( bBBar && bMOver ) )
         {
            cDrawBoxes( hDC, &rct, 11, "", 0, 0, 0, MakeDarker( ClrBack, - ( ! bMOver ? 40 : 120 ) ) , 0, FALSE, 0 ) ;
         }

         rct.top    = iTop ;
         rct.left   = iLeft ;
         rct.bottom = iBottom ;
         rct.right  = iRight ;
         break ;
      }
      case 8 :  // sunset shape
      {

         if( ! iCorner )
         {
            iCorner = 9 ;
         }

         hRgn = CreateRoundRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1, iCorner,
                                    iCorner ) ;
         hOldRgn = SelectObject( hDC, hRgn ) ;
         iLeft   = rct.left ;
         iRight  = rct.right ;
         iTop    = rct.top ;
         iBottom = rct.bottom ;

         DegradColor( hDC, &rct, ClrBack, nClrTo ) ;

         hPen   = CreatePen( PS_SOLID, 1, ClrBack ) ;
         hOldPen = SelectObject( hDC, hPen ) ;
         hBrush = CreateSolidBrush( ClrBack ) ;
         hBOld  = SelectObject( hDC, hBrush ) ;
         Ellipse( hDC, rct.left - ( rct.right / 2 ), rct.bottom / 2, rct.left + (rct.right *2), ( rct.bottom / 2 ) + rct.bottom * 2 ) ;
         SelectObject( hDC, hBOld ) ;
         DeleteObject( hBrush ) ;
         SelectObject( hDC, hOldPen ) ;
         DeleteObject( hPen ) ;
         rct.top    = iTop ;
         rct.bottom = iBottom - ( nPos == 6 ? nHeight : 0 ) ;
         cDrawBoxes( hDC, &rct, 11, "", 0, 0, 0, RGB( 255, 255, 255 ), 0, FALSE, iCorner ) ;
         rct.top    = iTop ;
         rct.left   = iLeft ;
         rct.right  = iRight ;
         break ;
      }
      default :  // rect, round, round rect shapes
      {
         if( iShape == 1 )
         {
            hRgn = CreateRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
         }
         else
            if( iShape == 2 )
            {
               hRgn = CreateEllipticRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
            }

         else
         {
            if( iShape == 3 )
            {
               if( ! iCorner )
               {
                  iCorner = 9 ;
               }
               hRgn = CreateRoundRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1,
                                       iCorner, iCorner ) ;
            }
         }

         hOldRgn = SelectObject( hDC, hRgn ) ;

         if( iDegType )
         {
            if( iBorder )
            {
               rct.top += ( iBorder > 1 ? 1 : 0 ) ;
               rct.left += ( iBorder > 1 ? 1 : 0 ) ;
               rct.bottom -= ( iBorder > 1 ? 1 : 0 ) ;
               rct.right -= ( iBorder > 1 ? 1 : 0 ) ;
            }

            ColorDegrad( hDC, &rct, ClrBack, nClrTo, iDegType, iShape, iCorner ) ;

            if( iBorder )
            {
               rct.top -= ( iBorder > 1 ? 1 : 0 ) ;
               rct.left -= ( iBorder > 1 ? 1 : 0 ) ;
               rct.bottom += ( iBorder > 1 ? 1 : 0 ) ;
               rct.right += ( iBorder > 1 ? 1 : 0 ) ;
            }
         }
         else
            if( wBrush )
            {
               FillRect( hDC, &rct, wBrush ) ;
            }
         else
            if( iBorder )
            {
               hBrush = CreateSolidBrush( lBkColor ) ;
               hBOld  = SelectObject( hDC, hBrush ) ;
               FillRect( hDC, &rct, hBrush ) ;
               SelectObject( hDC, hBOld ) ;
            }

         break ;
      }
   }

   if( bMenu )
   {
      rctm.top    = rctb.top + 1 ;
      rctm.left   = rctb.right - 13 ;
      rctm.bottom = rctb.bottom - 1 ;
      rctm.right  = rctb.right ;

      if( bMOver )
      {
         cDrawBoxes( hDC, &rctm, 8, "", 0, 0, MakeDarker( iDegType ? ClrBack : lBkColor, bMPress ? 128 : -128 ),
                     MakeDarker( iDegType ? ClrBack : lBkColor, bMPress ? -128 : 128 ), 0, FALSE, iCorner ) ;
      }

      rctm.right  += ( bMPress ? 1 : 0 ) ;
      rctm.top    -= ( bMPress ? 1 : 0 ) ;
      rctm.bottom += ( bMPress ? 1 : 0 ) ;

      if( ( ! iDegType || ( iDegType && ( iDegType == 2 || iDegType == 4 || iDegType == 5 ) ) ) &&
          iShape != 5 && iShape != 7 )
      {
          iROP = SetROP2( hDC, R2_NOT ) ;
      }

      GoPoint( hDC, rctm.right - 5, ( ( rctm.bottom - rctm.top + 1 ) / 2 ) - 1 ) ;
      LineTo( hDC, rctm.right - 10, ( ( rctm.bottom - rctm.top + 1 ) / 2 ) - 1 ) ;

      GoPoint( hDC, rctm.right - 6, ( ( rctm.bottom - rctm.top + 1 ) / 2 ) ) ;
      LineTo( hDC, rctm.right - 9, ( ( rctm.bottom - rctm.top + 1 ) / 2 ) ) ;

      GoPoint( hDC, rctm.right - 7, ( ( rctm.bottom - rctm.top + 1 ) / 2 ) + 1 ) ;
      LineTo( hDC, rctm.right - 8, ( ( rctm.bottom - rctm.top + 1 ) / 2 ) + 1 ) ;

      if( ( ! iDegType || ( iDegType && ( iDegType == 2 || iDegType == 4 || iDegType == 5 ) ) ) &&
          iShape != 5 && iShape != 7 )
      {
          SetROP2( hDC, iROP ) ;
      }
   }

   if( iBorder && iShape < 5 )
   {
      if( iBorder == 2 )
      {
         if( iShape != 2 )
         {
            cDrawBoxes( hDC, &rct, iShape == 3 ? 10 : 9, "", 0, 0, 0, ClrBord, 0, FALSE, iCorner ) ;
         }
         else
         {
            SBtnRoundBox( hDC, &rct, 0, bPressed, TRUE ) ;
         }
         rct.top += 1 ;
         rct.left += 1 ;
      }


      if( bPressed )
      {
         iType = ( iShape == 3 ? 6 : 3 ) ;
      }
      else
      {
         iType = ( iShape == 3 ? 4 : 1 ) ;
      }
      if( iShape != 2 && ! iAlpha )
      {
         if( iBorder < 3 || bMOver || bPressed || iShape == 5 )
         {
            cDrawBoxes( hDC, &rct, iType, "", 0, 0, MakeDarker( iDegType ? ClrBack : lBkColor, -64 ),
                        MakeDarker( iDegType ? ClrBack : lBkColor, 64 ), 0, FALSE, iCorner ) ;
         }
      }
      else
         if( ! iAlpha )
         {
            SBtnRoundBox( hDC, &rct, iDegType ? nClrTo : ClrBack, bPressed, FALSE ) ;
         }
   }

   if( bMenu )
   {
      rct.right  -= 12 ;
      rctt.right -= 12 ;
   }

   nHeight  = ( nRows > 0 ? nRows * ( b3D ? ( tm.tmHeight + 2 ) : tm.tmHeight ) : tm.tmHeight + b3D ? 2 : 0 ) ;
   ibmWidth = ( iClip > 0 ? ( bm.bmWidth / iClipTot ) : bm.bmWidth ) ;

   if( nPos )
   {
      switch( nPos )
      {
         case 1 :  // text on top
            nTop  = ( ( rct.bottom - rct.top + nHeight ) / 2 ) - ( bm.bmHeight / 2 ) ;
            nLeft = rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) - ( ibmWidth / 2 ) - 1 ;
            break ;

         case 2 :  // text on left
            nTop  = ( ( rct.bottom - rct.top ) / 2 ) - ( bm.bmHeight / 2 ) ;
            nLeft = rct.right - ( 4 + ibmWidth ) ;
            break ;

         case 3 :  // text on bottom
            nTop  = ( ( rct.bottom - rct.top - nHeight ) / 2 ) - ( bm.bmHeight / 2 ) ;
            nLeft = rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) - ( ibmWidth / 2 ) - 1 ;
            break ;

         case 4 :   // text on right
            nTop  = ( ( rct.bottom - rct.top ) / 2 ) - ( bm.bmHeight / 2 ) ;
            nLeft = rct.left + 4 ;
            break ;

         case 5 :   // text on center
            if( ! hShape )
            {
               nTop  = bAdjust ? rct.top : ( ( ( rct.bottom - rct.top ) / 2 ) - ( bm.bmHeight / 2 ) ) ;
               nLeft = bAdjust ? rct.left : ( rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) - ( ibmWidth / 2 ) - 1 ) ;
            }
            break ;

         case 6 : // text on top out of button
            nTop  = ( ( ( ( rct.bottom + nHeight ) - ( rct.top - nHeight ) ) / 2 ) - ( bm.bmHeight / 2 ) ) ;
            nLeft = ( rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) - ( ibmWidth / 2 ) - 1 ) ;
            break ;

         default : // text on bottom out of button
            nTop  = ( ( ( rct.bottom - rct.top ) / 2 ) - ( bm.bmHeight / 2 ) ) ;
            nLeft = ( rct.left + ( ( rct.right - rct.left + 1 ) / 2 ) - ( ibmWidth / 2 ) - 1 ) ;
            break ;
      }

   }

   nWidth  = rct.right - rct.left + 1 ;
   nHeight = rct.bottom - rct.top + 1 ;

   if( nPos )
   {
      nTop  += ( bPressed ? 1 : 0 ) ;
      nLeft += ( bPressed ? 1 : 0 ) ;

      if( hBitMap1 )
      {
         if( iClip )
         {
            hRgn1   = CreateRectRgn( nLeft, nTop, nLeft + ibmWidth, nTop + bm.bmHeight ) ;
            hOldRg1 = SelectObject( hDC, hRgn1 ) ;
         }

         if( bOpaque )
         {
            if( iClip )
            {
               DrawBitmap( hDC, hBitMap1, nTop, nLeft - ( ibmWidth * ( iClip - 1 ) ), 0, 0, 0 ) ;
            }
            else
            {
               DrawBitmap( hDC, hBitMap1, nTop, nLeft, ( bAdjust ?  nWidth - 2 : 0 ),
                           ( bAdjust ?  nHeight - 2 : 0 ), 0 ) ;
            }
         }
         else if( bDisable )
         {
            if( iClip )
            {
               DrawGrayed( hDC, hBitMap1, nTop, nLeft - ( ibmWidth * ( iClip - 1 ) ) ) ;
            }
            else
            {
               DrawGray( hDC, hBitMap1, nTop, nLeft ,0 ,0 ) ;
            }
         }
         else
         {
            if( iAlpha )
            {
               hdcBmp  = CreateCompatibleDC( hDC ) ;
               hBmOld1 = SelectObject( hdcBmp, ( HBITMAP ) hBitMap1 ) ;
               AlphaPaint( hDC, nLeft, nTop, bm.bmWidth, bm.bmHeight, hdcBmp, 0, 0, bm.bmWidth, bm.bmHeight, iAlpha ) ;
               SelectObject( hDC, hBmOld1 ) ;
               DeleteObject( hBmOld1 ) ;
               DeleteDC( hdcBmp ) ;
            }
            else if( iClip )
            {
               DrawMasked( hDC, hBitMap1, nTop, nLeft - ( ibmWidth * ( iClip - 1 ) ) ) ;
            }
            else if( ! iAlpha )
            {
               DrawMasked( hDC, hBitMap1, nTop, nLeft ) ;
            }
         }

         if( iClip )
         {
           DeleteObject( hRgn1 ) ;
           GetClientRect( hWnd, &rctm ) ;
           hRgn1 = CreateRectRgn( rctm.left, rctm.top, rctm.right, rctm.bottom ) ;
           SelectObject( hDC, hRgn1 ) ;
           SelectObject( hDC, hOldRg1 ) ;
           DeleteObject( hRgn1 ) ;
           DeleteObject( hOldRg1 ) ;
         }
      }
   }

   if( bFocused && iBorder && iShape != 2 && iShape != 6 && ! bMOver && ! bPressed )
   {
      GetClientRect( hWnd, &rct ) ;
      rct.top    += 2 ;
      rct.left   += 2 ;
      rct.bottom -= 2 ;
      rct.right  -= 2 ;
      DrawFocusRect( hDC, &rct ) ;
   }

   nHeight = ( nRows > 0 ? nRows * tm.tmHeight : tm.tmHeight ) ;

   if( ! bTPos )
   {
      switch( nPos )
      {
         case 0 :  // text only
            rctt.top = ( ( rctt.bottom - rctt.top ) / 2 ) - ( nHeight / 2 ) - 2 ;

            if( iShape == 7 ) // crystal shape
            {
               rctt.top = rctt.bottom - 4 - nHeight ;
            }
            rctt.bottom = rctt.top + nHeight ;
         case 1 :  // text on top
            rctt.top   += 1 ;
            rctt.left  += 4 ;
            rctt.bottom = rctt.top + nHeight ;
            rctt.right -= 4 ;
            break ;

         case 2 :  // text on left
            rctt.top    = ( ( rctt.bottom - rctt.top ) / 2 ) - ( nHeight / 2 ) ;
            rctt.left  += 4 ;
            rctt.bottom = rctt.top + nHeight ;
            rctt.right -= ( 4 + ibmWidth ) ;
            break ;

         case 3 :  // text on bottom
            rctt.top    = rct.bottom - nHeight - 2 ;
            rctt.left  += 4 ;
            rctt.right -= 4 ;
            break ;

         case 4 :   // text on right
            rctt.top = ( ( rctt.bottom - rctt.top ) / 2 ) - ( nHeight / 2 ) ;

            if( iShape == 7 ) // crystal shape
            {
               rctt.top = rctt.bottom - 4 - nHeight ;
            }

            rctt.left += ( 4 + ibmWidth ) ;
            rctt.bottom = rctt.top + nHeight ;
            rctt.right -= 4 ;

            break ;

         case 5 :  // text on center
            rctt.top = ( ( rctt.bottom - rctt.top ) / 2 ) - ( nHeight / 2 ) ;
            rctt.left += 4 ;
            rctt.bottom = rctt.top + nHeight ;
            rctt.right -= 4 ;
            break ;

         case 6 : // text on top out of button
            rctt.bottom = rctt.top + nHeight ;
            break ;

         case 7 : // on bottom out of button
            rctt.top = rctt.bottom - nHeight ;
            break ;
      }
   }
   else
   {
      rctt.top    = iTTop ;
      rctt.left   = iTLeft ;
      rctt.bottom = iTTop + nHeight ;
   }

   if( bPressed )
   {
      rctt.top++ ;
      rctt.left++ ;
   }

   nBkOld = SetBkMode( hDC, TRANSPARENT ) ;

   if( b3D )
   {
      rctt.top    -= 1 ;
      rctt.left   -= 1 ;
      rctt.bottom -= 1 ;
      rctt.right  -= 1 ;

      SetTextColor( hDC, b3DInv ? nClr3DS : nClr3DL ) ;
      DrawTextAW( hDC, cText, -1, &rctt, ( bTPos ? DT_LEFT : DT_CENTER ) | DT_TOP | ( nRows <= 1 ? DT_SINGLELINE : 0 ) ) ;
      rctt.top    += 2 ;
      rctt.left   += 2 ;
      rctt.bottom += 2 ;
      rctt.right  += 2 ;

      SetTextColor( hDC, b3DInv ? nClr3DL : nClr3DS ) ;
      DrawTextAW( hDC, cText, -1, &rctt,
                ( bTPos ? DT_LEFT : DT_CENTER ) | DT_TOP | ( nRows <= 1 ? DT_SINGLELINE : 0 ) ) ;

      rctt.top    -= 1 ;
      rctt.left   -= 1 ;
      rctt.bottom -= 1 ;
      rctt.right  -= 1 ;

      SetTextColor( hDC, nClrText ) ;

      DrawTextAW( hDC, cText, -1, &rctt,
                ( bTPos ? DT_LEFT : DT_CENTER ) | DT_TOP |
                ( nRows <= 1 ? DT_SINGLELINE : 0 ) ) ;
   }
   else
   {
      if( bClrRct )
      {
         DeleteObject( hBrush ) ;
         hBrush = CreateSolidBrush( nClrText ) ;
         SelectObject( hDC, hBrush ) ;
         FillRect( hDC, &rctt, hBrush ) ;
      }
      else
      {
         if( nPos == 6 )
         {
            rctt.top += nHeight ;
            rctt.bottom = rctt.top + nHeight ;
            rctt.top -= nHeight ;
            rctt.bottom -= nHeight ;
         }

         SetTextColor( hDC, ( bDisable ? RGB( 160, 160, 160 ) : nClrText ) ) ;
         DrawTextAW( hDC, cText, -1, &rctt,
                   ( bTPos ? DT_LEFT : DT_CENTER ) | DT_TOP | ( nRows <= 1 ? DT_SINGLELINE : 0 ) ) ;
      }
   }

   DeleteObject( hRgn ) ;

   SelectObject( hDC, hOldRgn ) ;

   DeleteObject( hRgn ) ;
   DeleteObject( hOldRgn ) ;

   SetBkMode( hDC, nBkOld ) ;

   SelectObject( hDC, hOldFont ) ;
   SelectObject( hDC, hBOld ) ;

   if( hBrush )
   {
      DeleteObject( hBrush ) ;
   }

   ReleaseDC( hWnd, hDC ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

void GoPoint( HDC hDC, int ix, int iy )
{
   POINT pt;

   MoveToEx( hDC, ix, iy, &pt ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

COLORREF MakeDarker( COLORREF nColor, signed long iFact )
{
   int iRed   = GetRValue( nColor ) ;
   int iGreen = GetGValue( nColor ) ;
   int iBlue  = GetBValue( nColor ) ;

   if( iRed > 0 )
   {
      iRed -= iFact ;
   }
   if( iGreen > 0 )
   {
      iGreen -= iFact ;
   }
   if( iBlue > 0 )
   {
      iBlue -= iFact ;
   }
   iRed   = ( iRed < 0 ? 0 : iRed > 255 ? 255 : iRed ) ;
   iGreen = ( iGreen < 0 ? 0 : iGreen > 255 ? 255 : iGreen ) ;
   iBlue  = ( iBlue < 0 ? 0 : iBlue > 255 ? 255 : iBlue ) ;

   return RGB( iRed, iGreen, iBlue ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

void VertSeparator( HDC hDC, HWND hWnd, int ix, COLORREF nColor, BOOL b3D )
{
   RECT rct ;
   int iTop, iBot, inx = ix ;
   COLORREF nClr1, nClr2 ;
   HPEN hOldPen, hPen1, hPen2, hPen3 ;

   nClr2  = MakeDarker( nColor, -32 ) ;
   nClr1  = MakeDarker( nColor, 32 ) ;

   hPen1  = CreatePen( PS_SOLID, 1, nClr1 ) ;
   hPen2  = CreatePen( PS_SOLID, 1, nColor ) ;
   hPen3  = CreatePen( PS_SOLID, 1, nClr2 ) ;

   GetClientRect( hWnd, &rct ) ;

   iTop = rct.top + ( b3D ? 2 : 0 ) ;
   iBot = rct.bottom - ( b3D ? 1 : 0 ) ;

   hOldPen = SelectObject( hDC, hPen2 ) ;
   GoPoint( hDC, inx, iTop ) ;
   LineTo( hDC, inx++, iBot ) ;

   SelectObject( hDC, hPen3 ) ;
   GoPoint( hDC, inx, iTop ) ;
   LineTo( hDC, inx++, iBot ) ;

   SelectObject( hDC, hPen3) ;
   GoPoint( hDC, inx, iTop ) ;
   LineTo( hDC, inx++, iBot ) ;

   SelectObject( hDC, hPen2) ;
   GoPoint( hDC, inx, iTop ) ;
   LineTo( hDC, inx++, iBot ) ;

   SelectObject( hDC, hPen1 ) ;
   GoPoint( hDC, inx, iTop ) ;
   LineTo( hDC, inx++, iBot ) ;

   SelectObject( hDC, hOldPen ) ;

   DeleteObject( hPen1 ) ;
   DeleteObject( hPen2 ) ;
   DeleteObject( hPen3 ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

void HorzSeparator( HDC hDC, HWND hWnd, int iy, COLORREF nColor, BOOL b3D )
{
   RECT rct ;
   int iTop, iBot, iny = iy ;
   COLORREF nClr1, nClr2 ;
   HPEN hOldPen, hPen1, hPen2, hPen3 ;

   nClr2  = MakeDarker( nColor, -64 ) ;
   nClr1  = MakeDarker( nColor, 96 ) ;

   hPen1  = CreatePen( PS_SOLID, 1, nClr1 ) ;
   hPen2  = CreatePen( PS_SOLID, 1, nColor ) ;
   hPen3  = CreatePen( PS_SOLID, 1, nClr2 ) ;

   GetClientRect( hWnd, &rct ) ;

   iTop = rct.left + ( b3D ? 0 : 0 ) ;
   iBot = rct.right - ( b3D ? 0 : 0 ) ;

   hOldPen = SelectObject( hDC, hPen1 ) ;
   GoPoint( hDC, iTop, iny ) ;
   LineTo( hDC, iBot, iny++ ) ;

   SelectObject( hDC, hPen2 ) ;
   GoPoint( hDC, iTop, iny ) ;
   LineTo( hDC, iBot, iny++ ) ;

   SelectObject( hDC, hPen3 ) ;
   GoPoint( hDC, iTop, iny ) ;
   LineTo( hDC, iBot, iny++ ) ;

   GoPoint( hDC, iTop, iny ) ;
   LineTo( hDC, iBot, iny++ ) ;

   SelectObject( hDC, hPen2) ;
   GoPoint( hDC, iTop, iny ) ;
   LineTo( hDC, iBot, iny++ ) ;

   SelectObject( hDC, hPen1) ;
   GoPoint( hDC, iTop, iny ) ;
   LineTo( hDC, iBot, iny++ ) ;

   SelectObject( hDC, hOldPen ) ;

   DeleteObject( hPen1 ) ;
   DeleteObject( hPen2 ) ;
   DeleteObject( hPen3 ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( MAKESEPARATOR ) //( hWnd, nxy, nColor, l3D, lVert )
{
   HWND hWnd  = ( HWND ) hb_parnl( 1 ) ;
   BOOL bVert = hb_parl( 5 ) ;

   HDC hDC = GetDC( hWnd ) ;

   if( bVert )
      VertSeparator( hDC, (HWND) hb_parnl( 1 ), (int) hb_parni( 2 ), (COLORREF) hb_parnl( 3 ), (BOOL) hb_parl( 4 ) ) ;
   else
      HorzSeparator( hDC, (HWND) hb_parnl( 1 ), (int) hb_parni( 2 ), (COLORREF) hb_parnl( 3 ), (BOOL) hb_parl( 4 ) ) ;

   ReleaseDC( hWnd, hDC ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( SBTNLINE ) // ( hWnd, nTop, nLeft, nBottom, nRight, nColor )
{
   HWND hWnd     = ( HWND ) hb_parnl( 1 ) ;
   int iTop      = hb_parni( 2 ) ;
   int iLeft     = hb_parni( 3 ) ;
   int iBottom   = hb_parni( 4 ) ;
   int iRight    = hb_parni( 5 ) ;
   COLORREF nClr = hb_parnl( 6 ) ;

   HDC hDC = GetDC( hWnd ) ;
   HPEN hPen1, hPen2, hOldPen ;
   COLORREF nLight, nShadow ;

   nLight  = MakeDarker( nClr, -64 ) ;
   nShadow = MakeDarker( nClr, 64 ) ;

   hPen1  = CreatePen( PS_SOLID, 1, nLight ) ;
   hPen2  = CreatePen( PS_SOLID, 1, nShadow ) ;

   hOldPen = (HPEN) SelectObject( hDC, hPen2 ) ;
   GoPoint( hDC, iLeft, iTop ) ;
   LineTo( hDC, iRight, iBottom ) ;

   if( iTop == iBottom )
   { iTop++ ;
     iBottom++ ;
   }
   else
   {
     iLeft++ ;
     iRight++ ;
   }

   SelectObject( hDC, hPen1 ) ;
   GoPoint( hDC, iLeft, iTop ) ;
   LineTo( hDC, iRight, iBottom ) ;

   SelectObject( hDC, hOldPen ) ;
   DeleteObject( hPen1 ) ;
   DeleteObject( hPen2 ) ;
   ReleaseDC( hWnd, hDC ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

void SBtnBox( HDC hDC, RECT * rct, COLORREF lColor, BOOL bBorder, int iBox )
{
   HPEN hGray  = CreatePen( PS_SOLID, 1, MakeDarker( lColor, 64 ) ) ;
   HPEN hWhite = CreatePen( PS_SOLID, 1, MakeDarker( lColor, -96 ) ) ;
   HPEN hBlack = CreatePen( PS_SOLID, 1, RGB( 0, 0, 0 ) ) ;
   HPEN hOldPen ;
   int iTop   = rct->top ;
   int iLeft  = rct->left ;
   int iBot   = rct->bottom - 1 ;
   int iRight = rct->right - 1 ;

   hOldPen = SelectObject( hDC, hBlack ) ;

   if( bBorder )
   {
      GoPoint( hDC, iLeft, iTop ) ;
      LineTo( hDC, iRight + 1, iTop ) ;
      GoPoint( hDC, iRight, iTop ) ;
      LineTo( hDC, iRight, iBot + 1 ) ;
      GoPoint( hDC, iRight, iBot ) ;
      LineTo( hDC, iLeft - 1, iBot ) ;
      GoPoint( hDC, iLeft, iBot ) ;
      LineTo( hDC, iLeft, iTop - 1) ;
      iLeft++ ;
      iTop++ ;
      iBot-- ;
      iRight-- ;
   }

   if( iBox > 0 )
   {
      SelectObject( hDC, iBox == 1 ? hWhite : hGray ) ;
      GoPoint( hDC, iLeft, iBot - 1 ) ;
      LineTo( hDC, iLeft, iTop - 1 ) ;
      GoPoint( hDC, iLeft, iTop ) ;
      LineTo( hDC, iRight + 1, iTop ) ;
      SelectObject( hDC, iBox == 1 ? hGray : hWhite ) ;
      GoPoint( hDC, iLeft, iBot ) ;
      LineTo( hDC, iRight + 1, iBot) ;
      GoPoint( hDC, iRight, iBot ) ;
      LineTo( hDC, iRight, iTop - 1 ) ;
   }

   SelectObject( hDC, hOldPen ) ;
   DeleteObject( hGray ) ;
   DeleteObject( hWhite ) ;
   DeleteObject( hBlack ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

void ColorDegrad( HDC hDC, RECT * rori, COLORREF cFrom, COLORREF cTo, int iType, int iShape, int iCorner )
{
   float clr1r, clr1g, clr1b, clr2r, clr2g, clr2b ;
   float iEle, iRed, iGreen, iBlue, iTot, iHalf ;
   BOOL bHorz = ( iType == 2 || iType == 4 || iType == 5 ) ;
   BOOL bDir ;
   RECT rct ;
   HPEN hOldPen, hPen ;
   LOGBRUSH lb ;
   HBRUSH hOldBrush, hBrush, hNull ;

   if( ! iCorner )
   {
      iCorner = 5 ;
   }

   rct.top = rori->top ;
   rct.left = rori->left ;
   rct.bottom = rori->bottom ;
   rct.right = rori->right ;

   iTot   = ( ! bHorz ? ( rct.bottom  - rct.top + 1 ) : ( rct.right - rct.left + 1 ) ) ;

   iHalf  = iTot / 2 ;
   lb.lbStyle = BS_NULL ;
   hNull  = CreateBrushIndirect( &lb ) ;

   clr1r = GetRValue( cFrom ) ;
   clr1g = GetGValue( cFrom ) ;
   clr1b = GetBValue( cFrom ) ;

   clr2r = GetRValue( cTo ) ;
   clr2g = GetGValue( cTo ) ;
   clr2b = GetBValue( cTo ) ;

   iRed   =  abs( clr2r - clr1r ) ;
   iGreen =  abs( clr2g - clr1g ) ;
   iBlue  =  abs( clr2b - clr1b ) ;

   iRed   = ( iRed <= 0 ? 0 : ( iRed / iTot ) );
   iGreen = ( iGreen <= 0 ? 0 : ( iGreen / iTot ) ) ;
   iBlue  = ( iBlue <= 0 ? 0 : ( iBlue / iTot ) ) ;

   if( iType == 3 || iType == 4 || iType == 5 )
   {
      iRed   *= 2 ;
      iGreen *= 2 ;
      iBlue  *= 2 ;
   }

   if( iType == 5 )
   {
      rct.top  += ( ( rct.bottom - rct.top ) / 2 ) ;
      rct.left += ( ( rct.right - rct.left ) / 2 ) ;
      rct.top  -= ( ( rct.bottom - rct.top ) / 3 ) ;
      rct.bottom = rct.top + 2 ;
      rct.right  = rct.left + 2 ;
   }
   else
   {
      if( ! bHorz )
      {
         rct.bottom = rct.top + 1 ;
      }
      else
      {
         rct.right = rct.left + 1 ;
      }
   }


   if( iType == 5 )
   {
      hPen      = CreatePen( PS_SOLID, 1, RGB( clr2r, clr2g, clr2b ) ) ;
      hOldPen   = SelectObject( hDC, hPen ) ;
      hBrush    = CreateSolidBrush( RGB( clr2r, clr2g, clr2b ) ) ;
      hOldBrush = SelectObject( hDC, hBrush ) ;

      if( iShape == 1 )
      {
         Ellipse( hDC, rori->left, rori->top, rori->right, rori->bottom ) ;
      }
      else
      {
         RoundRect( hDC, rori->left, rori->top, rori->right, rori->bottom, iCorner, iCorner ) ;
      }

      SelectObject( hDC, hOldBrush ) ;

      DeleteObject( hBrush ) ;
      SelectObject( hDC, hOldPen ) ;

      DeleteObject( hPen ) ;

      hPen    = CreatePen( PS_SOLID, 2, RGB( clr1r, clr1g, clr1b ) ) ;
      hOldPen = SelectObject( hDC, hPen ) ;

      SelectObject( hDC, hNull ) ;

      if( iShape == 1 )
      {
         Ellipse( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
      }
      else
      {
         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
      }
   }
   else
   {
      hPen      = CreatePen( PS_SOLID, 1, RGB( clr1r, clr1g, clr1b ) ) ;
      hOldPen   = SelectObject( hDC, hPen ) ;
      hBrush    = CreateSolidBrush( RGB( clr1r, clr1g, clr1b ) ) ;
      hOldBrush = SelectObject( hDC, hBrush ) ;
   }

   for( iEle = 1; iEle < iTot; iEle++ )
   {

      if( iType > 2 && iType < 5 && iEle > iHalf )
      {
         clr2r = GetRValue( cFrom ) ;
         clr2g = GetGValue( cFrom ) ;
         clr2b = GetBValue( cFrom ) ;
      }

      bDir = ( clr2r > clr1r ? TRUE : FALSE ) ;

      if( bDir )
      {
         clr1r += iRed ;
      }
      else
      {
         clr1r -= iRed ;
      }

      clr1r = ( clr1r < 0 ? 0 : clr1r > 255 ? 255 : clr1r ) ;

      bDir = ( clr2g > clr1g ? TRUE : FALSE  ) ;

      if( bDir )
      {
         clr1g += iGreen ;
      }
      else
      {
         clr1g -= iGreen ;
      }

      clr1g = ( clr1g < 0 ? 0 : clr1g > 255 ? 255 : clr1g ) ;

      bDir = ( clr2b > clr1b ? TRUE : FALSE  ) ;

      if( bDir )
      {
         clr1b += iBlue ;
      }
      else
      {
         clr1b -= iBlue ;
      }

      clr1b = ( clr1b < 0 ? 0 : clr1b > 255 ? 255 : clr1b ) ;

      if( iType == 5 )
      {
            SelectObject( hDC, hOldBrush ) ;
            DeleteObject( hNull ) ;
            hNull  = CreateBrushIndirect(&lb) ;
            SelectObject( hDC, hNull ) ;
            SelectObject( hDC, hOldPen ) ;
            DeleteObject( hPen ) ;
            hPen = CreatePen( PS_SOLID, 2, RGB( clr1r, clr1g, clr1b ) ) ;
            SelectObject( hDC, hPen ) ;
            if( iShape == 1 )
            {
               Ellipse( hDC, rct.left, rct.top, rct.right + 1, rct.bottom + 1 ) ;
            }
            else
            {
               RoundRect( hDC, rct.left, rct.top, rct.right + 1, rct.bottom + 1, iCorner, iCorner ) ;
            }
            rct.top    -= ( rct.top <= rori->top ? 0 : 1 ) ;
            rct.left   -= ( rct.left <= rori->left ? 0 : 1 );
            rct.bottom +=  ( rct.bottom >= rori->bottom ? 0 : 1 ) ;
            rct.right  +=  ( rct.right >= rori->right ? 0 : 1 ) ;
      }
      else
      {
         SelectObject( hDC, hOldBrush ) ;
         DeleteObject( hBrush ) ;
         hBrush = CreateSolidBrush( RGB( clr1r, clr1g, clr1b ) ) ;
         SelectObject( hDC, hBrush ) ;

         FillRect( hDC, &rct, hBrush ) ;

         if( ! bHorz )
         {
            rct.top++ ;
            rct.bottom++ ;
         }
         else
         {
            rct.left++ ;
            rct.right++ ;
         }
      }
   }

   SelectObject( hDC, hOldBrush ) ;
   SelectObject( hDC, hOldPen ) ;

   DeleteObject( hBrush ) ;
   DeleteObject( hPen ) ;
   DeleteObject( hNull ) ;
}

//---------------------------------------------------------------------------//

void SBtnRoundBox( HDC hDC, RECT * rct, COLORREF lColor, BOOL bPressed, BOOL bBlack )
{
   HPEN hGray  = CreatePen( PS_SOLID, 1, bBlack ? 0 : MakeDarker( lColor, 64 ) ) ;
   HPEN hWhite = CreatePen( PS_SOLID, 1, MakeDarker( lColor, -64 ) ) ;
   HPEN hOldPen ;
   RECT brct ;
   LOGBRUSH lb ;
   HBRUSH hNull, hbrOld ;
   POINT pO, pD ;

   lb.lbStyle = BS_NULL ;

   hNull  = CreateBrushIndirect(&lb) ;
   hbrOld = SelectObject(hDC, hNull) ;

   hOldPen = SelectObject( hDC, hGray ) ;

   brct.top = rct->top ;
   brct.left = rct->left ;
   brct.bottom = rct->bottom ;
   brct.right = rct->right ;

   pO.x = brct.left + ( ( brct.right - brct.left ) / 4 * 3 ) ;
   pO.y = brct.top ;
   pD.x = brct.left + ( ( brct.right - brct.left ) / 4 ) ;
   pD.y = brct.bottom ;

   if( ! bBlack )
      SelectObject( hDC, bPressed ? hWhite : hGray ) ;

   Ellipse( hDC, brct.left, brct.top, brct.right, brct.bottom ) ;

   if( ! bBlack )
   {
      SelectObject( hDC, bPressed ? hGray : hWhite ) ;
      Arc( hDC, brct.left, brct.top, brct.right, brct.bottom,  pO.x, pO.y, pD.x, pD.y ) ;
   }

   SelectObject( hDC, hOldPen ) ;
   SelectObject( hDC, hbrOld ) ;
   DeleteObject( hGray ) ;
   DeleteObject( hWhite ) ;
   DeleteObject( hNull ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

  // ( hDC, nTop, nLeft, cText, hFont, lChecked, nClrBtn,
  //   nClrText, nClrLight, nClrDark, lDisable, l3D,
  //   lFocused, nStyle, lDrawFocus, lTwice, hBitMap )
HB_FUNC( DRAWRADIO )
{
   HDC hDC            = ( HDC ) hb_parnl( 1 ) ;
   int iTop           = hb_parni( 2 ) ;
   int iLeft          = hb_parni( 3 ) ;
   LPSTR cText        = ( LPSTR ) hb_parc( 4 ) ;
   HFONT hFont        =  ( HFONT ) hb_parnl( 5 ) ;
   BOOL bSelect       = hb_parl( 6 ) ;
   COLORREF nClrBtn   = ( COLORREF ) hb_parnl( 7 ) ;
   COLORREF nClrText  = ( COLORREF ) hb_parnl( 8 ) ;
   COLORREF nClrLight = ( COLORREF ) hb_parnl( 9 ) ;
   COLORREF nClrDark  = ( COLORREF ) hb_parnl( 10 ) ;
   BOOL bDisable      = hb_parl( 11 ) ;
   BOOL b3DInv        = ( ISLOG( 12 ) ? ! hb_parl( 12 ) : FALSE ) ;
   BOOL b3D           = ( ISLOG( 12 ) ? TRUE : FALSE ) ;
   BOOL bFocus        = ( ISLOG( 13 ) ? hb_parl( 13 ) : FALSE ) ;
   int iStyle         = hb_parni( 14 ) ;
   BOOL bDraw         = hb_parl( 15 ) ;
   BOOL bTwice        = hb_parl( 16 ) ;
   HBITMAP hBitMap    = (HBITMAP) hb_parnl( 17 ) ;
   int iBmpW          = hb_parni( 18 ) + 2 ;
   int iBmpH          = hb_parni( 19 ) ;
   HFONT hOldFont = SelectObject( hDC, hFont ) ;

   COLORREF nClr2  = MakeDarker( nClrBtn, 48 ) ;
   COLORREF nClr3  = MakeDarker( nClrBtn, -48 ) ;

   HPEN hPDark  = CreatePen( PS_SOLID, 1, nClr2 ) ;
   HPEN hPNull  = CreatePen( PS_NULL, 0, 0 ) ;
   HPEN hPLight = CreatePen( PS_SOLID, 1, nClr3 ) ;
   HPEN hPWhite = CreatePen( PS_SOLID, 1, RGB( 221, 221, 221 ) );
   HPEN hPGray  = CreatePen( PS_SOLID, 1, RGB( 128, 128, 128 ) ) ;
   HPEN hPNegra = CreatePen( PS_SOLID, 1, 0 ) ;
   HPEN hPHGray = CreatePen( PS_SOLID, 1, RGB( 192, 192, 192 ) ) ;
   HPEN hPBlack = CreatePen( PS_SOLID, 1, bDisable ? GetSysColor( COLOR_BTNSHADOW ) : 0 ) ;
   HPEN hPOld   = SelectObject( hDC, iStyle == 3 || iStyle != 4 ? hPBlack : hPDark ) ;

   LOGBRUSH lb ;
   HBRUSH hBNull ;
   HBRUSH hBBlack = CreateSolidBrush( bDisable ? GetSysColor( COLOR_BTNSHADOW ) : 0 ) ;
   HBRUSH hBGray  = CreateSolidBrush( bDisable ? GetSysColor( COLOR_BTNFACE ) : nClrBtn ) ;
   HBRUSH hBDisab = CreateSolidBrush( GetSysColor( COLOR_BTNSHADOW ) ) ;
   HBRUSH hBWhite = CreateSolidBrush( RGB( 241, 241, 241 ) ) ;
   HBRUSH hBOld   = SelectObject( hDC, hBGray ) ;

   POINT aB[ 4 ] ;
   POINT aP[ 7 ] ;
   RECT rct ;
   int iBkOld, iExt, iLen = hb_parclen( 4 ) ;
   TEXTMETRIC tm ;
   GetTextMetrics( hDC, &tm ) ;

   lb.lbStyle = BS_NULL ;
   hBNull  = CreateBrushIndirect( &lb ) ;

   iExt       = LOWORD( GetTextExtent( hDC, cText, iLen ) ) ;
   rct.top    = iTop ;
   rct.left   = iLeft ;
   rct.bottom = rct.top + max( tm.tmHeight, iBmpH ) ;
   rct.right  = rct.left + iExt - tm.tmOverhang ;

   if( iStyle == 3 )
   {
      aP[ 0 ].x = 4 + iLeft ;
      aP[ 0 ].y = iTop + 2;
      aP[ 1 ].x = 9 + iLeft ;
      aP[ 1 ].y = 5 + iTop + 2 ;
      aP[ 2 ].x = 4 + iLeft ;
      aP[ 2 ].y = 10 + iTop + 2 ;
      aP[ 3 ].x = 4 + iLeft ;
      aP[ 3 ].y = 7 + iTop + 2 ;
      aP[ 4 ].x = 0 + iLeft ;
      aP[ 4 ].y = 7 + iTop + 2 ;
      aP[ 5 ].x = 0 + iLeft ;
      aP[ 5 ].y = 3 + iTop + 2 ;
      aP[ 6 ].x = 4 + iLeft ;
      aP[ 6 ].y = 3 + iTop + 2 ;
   }
   else
   {
      aB[ 0 ].x = 6 + iLeft ;
      aB[ 0 ].y = iTop ;
      aB[ 1 ].x = 12 + iLeft ;
      aB[ 1 ].y = 6 + iTop ;
      aB[ 2 ].x = 6 + iLeft ;
      aB[ 2 ].y = 12 + iTop ;
      aB[ 3 ].x = iLeft ;
      aB[ 3 ].y = 6 + iTop ;
   }

   switch( iStyle )
   {
   case 3 :  // Pointer arrow

      if( ! hBitMap && bSelect )
      {
         SelectObject( hDC, hPBlack ) ;
         SelectObject( hDC, hBGray ) ;

         Polygon( hDC, aP, sizeof( aP ) / sizeof( POINT ) ) ;
      }
      else
      if( bSelect )
      {
         DrawMasked( hDC, hBitMap, rct.top, rct.left ) ;
      }
      break ;
   case 4 :   // Check Box
      if( ! bDisable || ( bDisable && bSelect ) )
      {
         SelectObject( hDC, hPDark ) ;
         Rectangle( hDC, rct.left, rct.top, rct.left + 13, rct.top + 13 ) ;
         SelectObject( hDC, hPLight ) ;
         GoPoint( hDC, rct.left + 12, rct.top ) ;
         LineTo( hDC,  rct.left, rct.top ) ;
         LineTo( hDC, rct.left, rct.top + 12 ) ;

         if( bSelect )
         {
            SelectObject( hDC, hPBlack ) ;
            GoPoint( hDC, rct.left + 9, rct.top + 3 ) ;
            LineTo( hDC, rct.left + 2, rct.top + 10 ) ;
            LineTo( hDC, rct.left + 2, rct.top + 6 ) ;
            LineTo( hDC, rct.left + 3, rct.top + 5 ) ;
            LineTo( hDC, rct.left + 3, rct.top + 10 ) ;
            LineTo( hDC, rct.left + 10, rct.top + 3 ) ;
         }
      }
      break ;

   case 5 :   // bitmap
      if( hBitMap && ( ! bDisable || ( bDisable && bSelect ) ) )
      {
         DrawMasked( hDC, hBitMap, rct.top, rct.left ) ;
      }
      break ;

   case 6 :   // pressed rhombus

      if( ! bDisable || ( bDisable && bSelect ) )
      {
         SelectObject( hDC, hBNull ) ;
         Polygon( hDC, aB, sizeof( aB ) / sizeof( POINT ) ) ;
         SelectObject( hDC, hBGray ) ;
      }
      break ;

   case 8 :   // pressed arrow pointer
      if( ! hBitMap && ! bDisable && bSelect )
      {
         SelectObject( hDC, hPLight ) ;
         SelectObject( hDC, hBGray ) ;

         Polygon( hDC, aP, sizeof( aP ) / sizeof( POINT ) ) ;
      }
      else
      {
         if( ! bDisable && bSelect )
         {
            DrawMasked( hDC, hBitMap, rct.top, rct.left ) ;
         }
      }
      break ;
   case 9 :   // pressed check box

      if( ! bDisable || ( bDisable && bSelect ) )
      {
         SelectObject( hDC, hBNull ) ;
         SelectObject( hDC, hPBlack ) ;
         Rectangle( hDC, rct.left, rct.top, rct.left + 13, rct.top + 13 ) ;
         SelectObject( hDC, hBGray ) ;
      }
      break ;

   default :   // rhombus

      SelectObject( hDC, hPDark ) ;

      if( ! bDisable || ( bDisable && bSelect ) )
      {
         Polygon( hDC, aB, sizeof( aB ) / sizeof( POINT ) ) ;
      }

      if( ! bDisable || ( bDisable && bSelect ) )
      {
         if( iStyle != 1 )
         {
            aB[ 0 ].y += 1 ;
            aB[ 1 ].x -= 1 ;
            aB[ 2 ].y -= 1 ;
            aB[ 3 ].x += 1 ;
            SelectObject( hDC, hPDark ) ;
            Polygon( hDC, aB, sizeof( aB ) / sizeof( POINT ) ) ;
            aB[ 0 ].y -= 1 ;
            aB[ 1 ].x += 1 ;
            aB[ 2 ].y += 1 ;
            aB[ 3 ].x -= 1 ;
         }

         SelectObject( hDC, hPLight ) ;

         switch( bSelect )
         {
            case FALSE :
               GoPoint( hDC, aB[ 0 ].x, aB[ 0 ].y ) ;
               LineTo( hDC, aB[ 3 ].x, aB[ 3 ].y ) ;
               LineTo( hDC, aB[ 2 ].x, aB[ 2 ].y ) ;
               if( iStyle != 1 )
               {
                  GoPoint( hDC, aB[ 0 ].x, aB[ 0 ].y + 1 ) ;
                  LineTo( hDC, aB[ 3 ].x + 1, aB[ 3 ].y ) ;
                  LineTo( hDC, aB[ 2 ].x, aB[ 2 ].y - 1 ) ;
               }
               break ;

            case TRUE :
               GoPoint( hDC, aB[ 0 ].x + 1, aB[ 0 ].y +  1) ;
               LineTo( hDC, aB[ 1 ].x, aB[ 1 ].y ) ;
               LineTo( hDC, aB[ 2 ].x - 1, aB[ 2 ].y + 1 ) ;
               if( iStyle != 1 )
               {
                  GoPoint( hDC, aB[ 0 ].x + 1 , aB[ 0 ].y + 2 ) ;
                  LineTo( hDC, aB[ 1 ].x - 1, aB[ 1 ].y ) ;
                  LineTo( hDC, aB[ 2 ].x - 1, aB[ 2 ].y ) ;
               }

               aB[ 0 ].y += 4 ;
               aB[ 1 ].x -= 4 ;
               aB[ 2 ].y -= 4 ;
               aB[ 3 ].x += 4 ;

               SelectObject( hDC, hPBlack ) ;
               SelectObject( hDC, hBBlack ) ;

               Polygon( hDC, aB, sizeof( aB ) / sizeof( POINT ) ) ;

               break ;
         }

      }
      break ;
   }

   if( iStyle < 6 )
   {
      rct.top    += 1 ;
      rct.left   += max( 16, iBmpW ) ;
      rct.right  += max( 16, iBmpW ) ;
      rct.bottom += 1 ;

      iBkOld = SetBkMode( hDC, TRANSPARENT ) ;

      if( b3D )
      {
         rct.top    -= 1 ;
         rct.left   -= 1 ;
         rct.bottom -= 1 ;
         rct.right  -= 1 ;

         SetTextColor( hDC, b3DInv ? nClrDark : nClrLight ) ;
         DrawTextAW( hDC, cText, -1, &rct, DT_LEFT ) ;

         rct.top    += 2 ;
         rct.left   += 2 ;
         rct.bottom += 2 ;
         rct.right  += 2 ;

         SetTextColor( hDC, b3DInv ? nClrLight : nClrDark ) ;
         DrawTextAW( hDC, cText, -1, &rct, DT_LEFT ) ;

         rct.top    -= 1 ;
         rct.left   -= 1 ;
         rct.bottom -= 1 ;
         rct.right  -= 1 ;

         SetTextColor( hDC, nClrText ) ;
         DrawTextAW( hDC, cText, -1, &rct, DT_LEFT ) ;
      }
      else
      {
         SetTextColor( hDC, nClrText ) ;

         DrawTextAW( hDC, cText, -1, &rct, DT_LEFT ) ;
      }

      if( ( bFocus && ! bDisable && iStyle < 6 && bSelect ) || ( bFocus && bDraw ) )
      {
         rct.top    -= 1 ;
         rct.left   -= 1 ;
         rct.bottom += 1 ;
         rct.right  += 1 ;

         DrawFocusRect( hDC, &rct ) ;

         if( bFocus && bDraw && bTwice )
         {
            DrawFocusRect( hDC, &rct ) ;
         }
      }
   }

   SetBkMode( hDC, iBkOld ) ;

   SelectObject( hDC, hOldFont ) ;
   SelectObject( hDC, hPOld ) ;
   SelectObject( hDC, hBOld ) ;

   DeleteObject( hPDark ) ;
   DeleteObject( hPLight ) ;
   DeleteObject( hPBlack ) ;
   DeleteObject( hPNegra ) ;
   DeleteObject( hPWhite ) ;
   DeleteObject( hPHGray ) ;
   DeleteObject( hPNull ) ;
   DeleteObject( hPGray ) ;
   DeleteObject( hBWhite ) ;
   DeleteObject( hBBlack ) ;
   DeleteObject( hBGray ) ;
   DeleteObject( hBDisab ) ;
   DeleteObject( hBNull ) ;
}

//---------------------------------------------------------------------------//

HB_FUNC( DRAWBOXES ) // ( hDC, hWnd, nType, cText, hFont, nAlign, nClrLight,nClrDark, nClrLabel
{

   HDC hDC            = ( HDC  ) hb_parnl( 1 ) ;
   HWND hWnd          = ( HWND ) hb_parnl( 2 ) ;
   int iType          = hb_parni( 3 ) ;
   LPSTR cLabel       = ( LPSTR ) hb_parc( 4 ) ;
   HFONT hFont        = ( HFONT ) hb_parnl( 5 ) ;
   int iAlign         = ( ISNUM( 6 ) ? hb_parni( 6 ) : 0 ) ;
   COLORREF nClrLight = ( COLORREF ) ( ISNUM( 7 ) ? hb_parnl( 7 ) : MakeDarker( GetSysColor( COLOR_BTNFACE ), -48 ) ) ;
   COLORREF nClrDark  = ( COLORREF ) ( ISNUM( 8 ) ? hb_parnl( 8 ) : MakeDarker( GetSysColor( COLOR_BTNFACE ),  48 ) ) ;
   COLORREF nClrLabel = ( COLORREF ) ( ISNUM( 9 ) ? hb_parnl( 9 ) : GetSysColor( COLOR_BTNTEXT ) ) ;
   BOOL bLabel        = ( ISCHAR( 4 ) && hb_parclen( 4 ) > 0 ? TRUE : FALSE ) ;


   RECT rct ;
   GetClientRect( hWnd, &rct ) ;

   cDrawBoxes( hDC, &rct, iType, cLabel, hFont, iAlign, nClrLight, nClrDark, nClrLabel, bLabel, 0 ) ;

}

//--------------------------------------------------------------------------------------------------------------------//


HB_FUNC( DARKCOLOR ) // ( nColor, nIncrement ) --> New Color
{
   hb_retnl( MakeDarker( ( COLORREF ) hb_parnl( 1 ), hb_parni( 2 ) ) ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( GETFONTHEIGHT2 ) //( hDC, hFont ) --> Font Height
{
   HDC hDC     = ( HDC   ) hb_parnl( 1 ) ;
   HFONT hFont = ( HFONT ) hb_parnl( 2 ) ;

   TEXTMETRIC tm ;
   HFONT hOldFont = SelectObject( hDC, hFont ) ;

   GetTextMetrics( hDC, &tm ) ;
   SelectObject( hDC, hOldFont ) ;

   hb_retni( tm.tmHeight ) ;
}

//---------------------------------------------------------------------------//

HB_FUNC( DRAWRECTDOTTED  ) //( hDC, nTop, nLeft, nBottom, nRight )
{
   HDC hDC     = ( HDC ) hb_parnl( 1 ) ;
   int iTop    = hb_parni( 2 ) ;
   int iLeft   = hb_parni( 3 ) ;
   int iBottom = hb_parni( 4 ) ;
   int iRight  = hb_parni( 5 ) ;
   RECT rct ;

   rct.top    = iTop ;
   rct.left   = iLeft ;
   rct.bottom = iBottom ;
   rct.right  = iRight ;

   DrawFocusRect( hDC, &rct ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( SBARNEW ) // ( hWnd, hDC )
{
   HWND hWnd            = ( HWND ) hb_parnl( 1 ) ;
   HDC  hDC             = ( HDC  ) hb_parnl( 2 ) ;
   COLORREF ClrBack     = hb_parnl( 3 ) ;
   COLORREF nClrTo      = hb_parnl( 4 ) ;
   int iBottom, iShape  = hb_parni( 5 ) ;

   RECT rct ;
   HRGN hRgn, hOldRgn ;

   GetClientRect( hWnd, &rct ) ;
   hRgn = CreateRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
   hOldRgn = SelectObject( hDC, hRgn ) ;

   switch( iShape )
   {
      case 1 :
      {
         iBottom = rct.bottom ;
         rct.bottom = rct.bottom / 4 ;

         DegradColor( hDC, &rct, nClrTo, ClrBack ) ;

         rct.top    = rct.bottom ;
         rct.bottom = iBottom ;

         DegradColor( hDC, &rct, ClrBack, nClrTo ) ;
         break ;
      }
      case 2 :
      {
         iBottom = rct.bottom ;
         rct.bottom = rct.bottom / 4 ;

         DegradColor( hDC, &rct, nClrTo, MakeDarker( ClrBack, -40 ) ) ;

         rct.top = rct.bottom ;
         rct.bottom = iBottom;

         DegradColor( hDC, &rct, ClrBack, MakeDarker( ClrBack, -10 ) ) ;
         break ;
      }
   }

   DeleteObject( hRgn ) ;
   GetClientRect( hWnd, &rct ) ;

   hRgn = CreateRectRgn( rct.left, rct.top, rct.right, rct.bottom ) ;

   SelectObject( hDC, hRgn ) ;
   SelectObject( hDC, hOldRgn ) ;

   DeleteObject( hRgn ) ;
   DeleteObject( hOldRgn ) ;
}

//---------------------------------------------------------------------------//

void cDrawBoxes( HDC hDC, RECT * rrct, int iType, LPSTR cLabel, HFONT hFont, int iAlign, COLORREF nClrLight,
                 COLORREF nClrDark, COLORREF nClrLabel, BOOL bLabel, int iCorner )
{

   RECT rct, rctt ;
   TEXTMETRIC tm ;
   int iBkOld, iWidth, iLen = hb_parclen( 4 ) ;
   HFONT hFOld ;
   HRGN hRgn, hOldRgn ;
   POINT aP[ 3 ] ;

   HPEN hPDark  = CreatePen( PS_SOLID, 1, nClrDark ) ;
   HPEN hPLight = CreatePen( PS_SOLID, 1, nClrLight ) ;
   HPEN hPBlack = CreatePen( PS_SOLID, .5, 0 ) ;
   HPEN hPOld   = SelectObject( hDC, iType == 1 || iType == 4 ? hPDark : hPLight ) ;
   LOGBRUSH lb ;
   HBRUSH hBNull, hBOld ;

   if( ! iCorner )
   {
      iCorner = 5 ;
   }

   if( bLabel )
   {
      hFOld = SelectObject( hDC, hFont ) ;
   }

   lb.lbStyle = BS_NULL ;
   hBNull     = CreateBrushIndirect( &lb ) ;

   GetTextMetrics( hDC, &tm ) ;
   rct.top    = rrct->top ;
   rct.left   = rrct->left ;
   rct.bottom = rrct->bottom ;
   rct.right  = rrct->right ;

   rct.right  -= ( iType == 2 || iType == 5 || iType == 4 ? 1 : 0 ) ;
   rct.bottom -= ( iType == 2 || iType == 5 || iType == 4 ? 1 : 0 ) ;
   rctt.top    = rct.top ;
   rctt.bottom = rctt.top + tm.tmHeight ;
   iWidth      = LOWORD( GetTextExtent( hDC, cLabel, iLen ) ) ;

   if( bLabel )
   {
      switch( iAlign )
      {
         case 0 :  // left aligned label
            rctt.left = rct.left + 9 ;
            rctt.right = rctt.left + iWidth ;
            break ;

         case 1 :  // centered label
            rctt.left = rct.right - ( rct.right / 2 ) - ( iWidth / 2 ) ;
            rctt.right = rctt.left + iWidth ;
            break ;

         case 2 :  // right aligned label
            rctt.right = rct.right - 9 ;
            rctt.left = rctt.right - iWidth ;
            break ;
      }
   }

   rct.top += ( bLabel ? ( tm.tmHeight / 2 ) : 0 ) ;

   aP[ 0 ].x = rct.left ;
   aP[ 0 ].y = rct.top ;
   aP[ 1 ].x = rct.right ;
   aP[ 1 ].y = rct.top ;
   aP[ 2 ].x = rct.left ;
   aP[ 2 ].y = rct.bottom - 1 ;

   if( bLabel )
   {
      iBkOld = SetBkMode( hDC, TRANSPARENT ) ;
      SetTextColor( hDC, nClrLabel ) ;
      DrawTextAW( hDC, cLabel, -1, &rctt, DT_LEFT | DT_TOP | DT_SINGLELINE ) ;
      SetBkMode( hDC, iBkOld ) ;
      ExcludeClipRect( hDC, rctt.left, rct.top, rctt.right, rctt.bottom ) ;
   }

   if( iType == 1 || iType == 3 || iType == 4 || iType == 6 )
   {
      hRgn  = CreatePolygonRgn( aP, sizeof( aP ) / sizeof( POINT ), ALTERNATE ) ;
   }
   hBOld = SelectObject( hDC, hBNull ) ;

   switch( iType )
   {
      case 1 : // white box
         SelectObject( hDC, hPDark ) ;
         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
         hOldRgn = SelectObject( hDC, hRgn ) ;
         SelectObject( hDC, hPLight ) ;

         if( bLabel )
         {
            ExcludeClipRect( hDC, rctt.left, rct.top, rctt.right, rctt.bottom ) ;
         }

         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
         break ;

      case 2 : // gray box
         rct.top    += 1 ;
         rct.left   += 1 ;
         rct.bottom += 1 ;
         rct.right  += 1 ;

         SelectObject( hDC, hPLight ) ;
         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;

         rct.top    -= 1 ;
         rct.left   -= 1 ;
         rct.bottom -= 1 ;
         rct.right  -= 1 ;
         SelectObject( hDC, hPDark ) ;

         if( bLabel )
         {
            ExcludeClipRect( hDC, rctt.left, rct.top, rctt.right, rctt.bottom ) ;
         }

         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
         break ;

      case 3 : // black box
         SelectObject( hDC, hPLight ) ;
         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
         hOldRgn = SelectObject( hDC, hRgn ) ;
         SelectObject( hDC, hPDark ) ;

         if( bLabel )
         {
            ExcludeClipRect( hDC, rctt.left, rct.top, rctt.right, rctt.bottom ) ;
         }

         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
         break ;

      case 4 : // white round rect box
         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
         hOldRgn = SelectObject( hDC, hRgn ) ;
         SelectObject( hDC, hPLight ) ;

         if( bLabel )
         {
            ExcludeClipRect( hDC, rctt.left, rct.top, rctt.right, rctt.bottom ) ;
         }

         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, 5, 5 ) ;
         break ;

      case 5 : // gray round rect box
         rct.top    += 1 ;
         rct.left   += 1 ;
         rct.bottom += 1 ;
         rct.right  += 1 ;
         SelectObject( hDC, hPLight ) ;
         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
         rct.top    -= 1 ;
         rct.left   -= 1 ;
         rct.bottom -= 1 ;
         rct.right  -= 1 ;
         SelectObject( hDC, hPDark ) ;

         if( bLabel )
         {
            ExcludeClipRect( hDC, rctt.left, rct.top, rctt.right, rctt.bottom ) ;
         }

         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
         break ;

      case 6 : // black Round box
         SelectObject( hDC, hPLight ) ;
         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
         hOldRgn = SelectObject( hDC, hRgn ) ;
         SelectObject( hDC, hPDark ) ;

         if( bLabel )
         {
            ExcludeClipRect( hDC, rctt.left, rct.top, rctt.right, rctt.bottom ) ;
         }

         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
         break ;

      case 7 : // horizontal line

         SelectObject( hDC, hPDark ) ;
         GoPoint( hDC, rct.left, rct.top ) ;
         LineTo( hDC, rct.right + 1, rct.top ) ;
         SelectObject( hDC, hPLight ) ;
         GoPoint( hDC, rct.left, rct.top + 1 ) ;
         LineTo( hDC, rct.right + 1, rct.top + 1 ) ;
         break ;

      case 8 : // vertical line

         SelectObject( hDC, hPDark ) ;
         GoPoint( hDC, rct.left, rct.top ) ;
         LineTo( hDC, rct.left, rct.bottom + 1 ) ;
         SelectObject( hDC, hPLight ) ;
         GoPoint( hDC, rct.left + 1 , rct.top ) ;
         LineTo( hDC, rct.left + 1, rct.bottom + 1 ) ;
         break ;

      case 9 : // black rect
         SelectObject( hDC, hPBlack ) ;
         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
         break ;

      case 10 : // black Round rect
         SelectObject( hDC, hPBlack ) ;
         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
         break ;

      case 11 : // dark Round rect
         SelectObject( hDC, hPDark ) ;
         RoundRect( hDC, rct.left, rct.top, rct.right, rct.bottom, iCorner, iCorner ) ;
         break ;

      case 12 : // dark Round rect
         SelectObject( hDC, hPDark ) ;
         Rectangle( hDC, rct.left, rct.top, rct.right, rct.bottom ) ;
         break ;

   }


   if( iType == 1 || iType == 3 || iType == 4 || iType == 6 )
   {
      DeleteObject( hRgn ) ;
      hRgn = CreateRectRgn( rct.left, rct.top, rct.right, rct.bottom ) ;
      SelectObject( hDC, hRgn ) ;
      SelectObject( hDC, hOldRgn ) ;
      DeleteObject( hRgn ) ;
      DeleteObject( hOldRgn ) ;
   }

   SelectObject( hDC, hPOld ) ;
   SelectObject( hDC, hBOld ) ;

   if( bLabel )
   {
      SelectObject( hDC, hFOld ) ;
   }

   DeleteObject( hPLight ) ;
   DeleteObject( hPDark ) ;
   DeleteObject( hPBlack ) ;
   DeleteObject( hBNull ) ;
}
//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( DRAWLIMIT ) // ( hDC, aPoint, nPenWidth )
{

   HDC hDC  = ( HDC ) hb_parnl( 1 ) ;
   int iYo  = hb_parvni( 2, 1 ) ;
   int iXo  = hb_parvni( 2, 2 ) ;
   int iYd  = hb_parvni( 2, 3 ) ;
   int iXd  = hb_parvni( 2, 4 ) ;
   int iPenWidth = ( hb_parni( 3 ) ? hb_parni( 3 ) : 3 ) ;

   int iROP   = SetROP2( hDC, R2_NOT ) ;
   HPEN hPen  = CreatePen( PS_SOLID, iPenWidth, RGB( 128, 128, 128 ) ) ;
   HPEN hPOld = SelectObject( hDC, hPen ) ;

   GoPoint( hDC, iXo, iYo ) ;
   LineTo( hDC, iXd, iYd ) ;

   SetROP2( hDC, iROP ) ;

   SelectObject( hDC, hPOld ) ;

   DeleteObject( hPen ) ;
}

//---------------------------------------------------------------------------//

static void DegradColor( HDC hDC, RECT * rori, COLORREF cFrom, COLORREF cTo )
{
   float clr1r, clr1g, clr1b, clr2r, clr2g, clr2b ;
   float iEle, iRed, iGreen, iBlue ;
   float iTot = ( rori->bottom + 2 - rori->top ) ;
   BOOL bDir ;
   RECT rct ;
   HBRUSH hOldBrush, hBrush ;

   rct.top    = rori->top ;
   rct.left   = rori->left ;
   rct.bottom = rori->bottom ;
   rct.right  = rori->right ;

   clr1r = GetRValue( cFrom ) ;
   clr1g = GetGValue( cFrom ) ;
   clr1b = GetBValue( cFrom ) ;

   clr2r = GetRValue( cTo ) ;
   clr2g = GetGValue( cTo ) ;
   clr2b = GetBValue( cTo ) ;

   iRed   =  abs( clr2r - clr1r ) ;
   iGreen =  abs( clr2g - clr1g ) ;
   iBlue  =  abs( clr2b - clr1b ) ;

   iRed   = iRed / iTot ;
   iGreen = iGreen / iTot ;
   iBlue  = iBlue / iTot ;
   rct.bottom = rct.top + 1 ;

   hBrush = CreateSolidBrush( RGB( clr1r, clr1g, clr1b ) ) ;
   hOldBrush = SelectObject( hDC, hBrush ) ;
   FillRect( hDC, &rct, hBrush ) ;

   for( iEle = 1; iEle < iTot; iEle++ )
   {
         bDir = ( clr2r >= clr1r ? TRUE : FALSE ) ;

         if( bDir )
         {
            clr1r += iRed ;
         }
         else
         {
            clr1r -= iRed ;
         }
         clr1r = ( clr1r < 0 ? 0 : clr1r > 255 ? 255 : clr1r ) ;
         bDir  = ( clr2g >= clr1g ? TRUE : FALSE  ) ;

         if( bDir )
         {
            clr1g += iGreen ;
         }
         else
         {
            clr1g -= iGreen ;
         }
         clr1g = ( clr1g < 0 ? 0 : clr1g > 255 ? 255 : clr1g ) ;
         bDir = ( clr2b >= clr1b ? TRUE : FALSE  ) ;

         if( bDir )
         {
            clr1b += iBlue ;
         }
         else
         {
            clr1b -= iBlue ;
         }
         clr1b = ( clr1b < 0 ? 0 : clr1b > 255 ? 255 : clr1b ) ;

      SelectObject( hDC, hOldBrush ) ;
      DeleteObject( hBrush ) ;
      hBrush = CreateSolidBrush( RGB( clr1r, clr1g, clr1b ) ) ;
      SelectObject( hDC, hBrush ) ;
      FillRect( hDC, &rct, hBrush ) ;

      rct.top++ ;
      rct.bottom++ ;
   }

   SelectObject( hDC, hOldBrush ) ;

   DeleteObject( hBrush ) ;
}

//----------------------------------------------------------------------------//

static void DrawMasked( HDC hdc, HBITMAP hbm, signed int y, signed int x )
{
   HDC         hdcMask, hdcBmp;
   HBITMAP     hbOld, hbOld1, hbMask, hbmp;
   BITMAP      bm;
   COLORREF    bBack, bFore;

   hdcMask  = CreateCompatibleDC( hdc );
   hdcBmp   = CreateCompatibleDC( hdc );
   GetObject( hbm, sizeof( BITMAP ), ( LPSTR ) &bm );

   hbmp     = CreateCompatibleBitmap( hdc, bm.bmWidth, bm.bmHeight );
   hbMask   = CreateBitmap( bm.bmWidth, bm.bmHeight, 1, 1, NULL );

   hbOld  = ( HBITMAP ) SelectObject( hdcBmp, hbmp );
   hbOld1 = ( HBITMAP ) SelectObject( hdcMask, hbm );
   BitBlt( hdcBmp, 0, 0, bm.bmWidth, bm.bmHeight, hdcMask, 0, 0, SRCCOPY );
   SelectObject( hdcMask, hbMask );

   SetBkColor( hdcBmp, GetPixel( hdcBmp, 0, 0 ) );
   BitBlt( hdcMask, 0, 0, bm.bmWidth, bm.bmHeight, hdcBmp, 0, 0, SRCCOPY );
   BitBlt( hdcBmp, 0, 0, bm.bmWidth, bm.bmHeight, hdcMask, 0, 0, NOTSRCAND );
   bBack = SetBkColor( hdc, RGB( 255, 255, 255 ) );
   bFore = SetTextColor( hdc, 0 );
   BitBlt( hdc, x, y, bm.bmWidth, bm.bmHeight, hdcMask, 0, 0, SRCAND );
   BitBlt( hdc, x, y, bm.bmWidth, bm.bmHeight, hdcBmp, 0, 0, SRCPAINT );
   SetBkColor( hdc, bBack );
   SetTextColor( hdc, bFore );

   SelectObject( hdcBmp, hbOld );
   SelectObject( hdcMask, hbOld1 );
   DeleteObject( hbmp );
   DeleteObject( hbMask );
   DeleteDC( hdcMask );
   DeleteDC( hdcBmp );
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( GRADCOLOR ) // ( hDC, aRect, nClrFrom, nClrTo, nDegType )
{
   HDC hDC     = ( HDC ) hb_parnl( 1 ) ;
   int iTop    = hb_parvni( 2, 1 ) ;
   int iLeft   = hb_parvni( 2, 2 ) ;
   int iBottom = hb_parvni( 2, 3 ) ;
   int iRight  = hb_parvni( 2, 4 ) ;
   COLORREF ClrFrom = hb_parnl( 3 ) ;
   COLORREF ClrTo   = hb_parnl( 4 ) ;
   int iDegType = ISNUM( 5 ) ? hb_parni( 5 ) : 1 ; // default = vertical gradient
   RECT rct ;

   rct.top    = iTop ;
   rct.left   = iLeft ;
   rct.bottom = iBottom ;
   rct.right  = iRight ;

   ColorDegrad( hDC, &rct, ClrFrom, ClrTo, iDegType, 0, 0 ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( LIGHTCOLOR )
{
  LONG lScale        = hb_parnl( 1 ) ;
  COLORREF ColorFrom = hb_parnl( 2 ) ;

  long R = MulDiv( 255 - GetRValue( ColorFrom ), lScale, 255 ) + GetRValue( ColorFrom ) ;
  long G = MulDiv( 255 - GetGValue( ColorFrom ), lScale, 255 ) + GetGValue( ColorFrom ) ;
  long B = MulDiv( 255 - GetBValue( ColorFrom ), lScale, 255 ) + GetBValue( ColorFrom ) ;

  hb_retnl( RGB( R, G, B ) ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( SGRADIENT )
{
   HWND hWnd          = ( HWND ) hb_parnl( 1 ) ;
   HDC  hDC           = ( HDC  ) hb_parnl( 2 ) ;
   COLORREF ColorFrom = ( COLORREF ) hb_parnl( 3 ) ;
   COLORREF ColorTo   = ( COLORREF ) hb_parnl( 4 ) ;
   int iDegType       = hb_parni( 5 ) ;
   int iShape         = hb_parni( 6 ) ;
   int iCorner        = hb_parni( 7 ) ;
   RECT rct ;
   POINT pO[ 4 ] ;
   HRGN hRgn, hOldRgn ;

   GetClientRect( hWnd, &rct ) ;

   switch( iShape )
   {
      case 1 :  // rectangle
         hRgn = CreateRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
         break ;

      case 2 : // round rectangle
         hRgn = CreateRoundRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1, iCorner,
                                    iCorner ) ;
         break ;

      case 3 : // ellipse
         hRgn = CreateEllipticRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
         break ;

      case 4 : // right shade
         rct.left   = rct.right ;
         rct.bottom += iCorner ;
         rct.right  += iCorner ;
         pO[ 0 ].y  = rct.top + iCorner ;
         pO[ 0 ].x  = rct.right - iCorner ;
         pO[ 1 ].y  = rct.top + iCorner ;
         pO[ 1 ].x  = rct.right ;
         pO[ 2 ].y  = rct.bottom ;
         pO[ 2 ].x  = rct.right ;
         pO[ 3 ].y  = rct.bottom - iCorner ;
         pO[ 3 ].x  = rct.right - iCorner ;
         hRgn = CreatePolygonRgn( pO, 4, WINDING ) ;
         break ;

      case 5 : // bottom shade
         rct.top    = rct.bottom ;
         rct.bottom = rct.top + iCorner ;
         rct.right  += iCorner ;
         pO[ 0 ].y  = rct.bottom - iCorner ;
         pO[ 0 ].x  = rct.left + iCorner ;
         pO[ 1 ].y  = rct.bottom ;
         pO[ 1 ].x  = rct.left + iCorner ;
         pO[ 2 ].y  = rct.bottom ;
         pO[ 2 ].x  = rct.right ;
         pO[ 3 ].y  = rct.bottom - iCorner ;
         pO[ 3 ].x  = rct.right - iCorner ;
         hRgn = CreatePolygonRgn( pO, 4, WINDING ) ;
         break ;

      case 6 : // right frame
         rct.left  = rct.right ;
         rct.top    -= iCorner ;
         rct.bottom += iCorner ;
         rct.right  += iCorner ;
         pO[ 0 ].y = rct.top + iCorner ;
         pO[ 0 ].x = rct.left ;
         pO[ 1 ].y = rct.top ;
         pO[ 1 ].x = rct.right ;
         pO[ 2 ].y = rct.bottom ;
         pO[ 2 ].x = rct.right ;
         pO[ 3 ].y = rct.bottom - iCorner ;
         pO[ 3 ].x = rct.right - iCorner ;
         hRgn = CreatePolygonRgn( pO, 4, WINDING ) ;
         break ;

      case 7 : // bottom frame
         rct.top    = rct.bottom ;
         rct.bottom = rct.top + iCorner ;
         rct.right  += iCorner ;
         rct.left   -= iCorner ;
         pO[ 0 ].y  = rct.bottom - iCorner ;
         pO[ 0 ].x  = rct.left + iCorner ;
         pO[ 1 ].y  = rct.bottom ;
         pO[ 1 ].x  = rct.left ;
         pO[ 2 ].y  = rct.bottom ;
         pO[ 2 ].x  = rct.right ;
         pO[ 3 ].y  = rct.bottom - iCorner ;
         pO[ 3 ].x  = rct.right - iCorner ;
         hRgn = CreatePolygonRgn( pO, 4, WINDING ) ;
         break ;

      case 8 : // left frame
         rct.right  = rct.left ;
         rct.left   -= iCorner ;
         rct.top    -= iCorner ;
         rct.bottom += iCorner ;
         pO[ 0 ].y = rct.top + iCorner ;
         pO[ 0 ].x = rct.right ;
         pO[ 1 ].y = rct.top ;
         pO[ 1 ].x = rct.left ;
         pO[ 2 ].y = rct.bottom ;
         pO[ 2 ].x = rct.left ;
         pO[ 3 ].y = rct.bottom - iCorner ;
         pO[ 3 ].x = rct.right ;
         hRgn = CreatePolygonRgn( pO, 4, WINDING ) ;
         break ;

      case 9 : // top frame
         rct.top    -= iCorner ;
         rct.bottom = rct.top + iCorner ;
         rct.right  += iCorner ;
         rct.left   -= iCorner ;
         pO[ 0 ].y  = rct.top ;
         pO[ 0 ].x  = rct.left ;
         pO[ 1 ].y  = rct.top ;
         pO[ 1 ].x  = rct.right ;
         pO[ 2 ].y  = rct.bottom ;
         pO[ 2 ].x  = rct.right - iCorner ;
         pO[ 3 ].y  = rct.bottom ;
         pO[ 3 ].x  = rct.left + iCorner ;
         hRgn = CreatePolygonRgn( pO, 4, WINDING ) ;
         break ;

      default :  // rectangle
         hRgn = CreateRectRgn( rct.left, rct.top, rct.right - rct.left + 1, rct.bottom - rct.top + 1 ) ;
         break ;
   }

   hOldRgn = SelectObject( hDC, hRgn ) ;

   ColorDegrad( hDC, &rct, ColorFrom, ColorTo, iDegType, 0, iCorner ) ;

   SelectObject( hDC, hOldRgn ) ;

   DeleteObject( hRgn ) ;
   DeleteObject( hOldRgn ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

static void DrawGrayed( HDC hdc, HBITMAP hbm, signed int y, signed int x )
{
   HDC      hdcMask, hdcBmp;
   HBITMAP  hbOld, hbOld1, hbMask, hbmp, hbmpChecker;
   BITMAP   bm;
   HBRUSH   hbr, hbrOld;
   COLORREF bBack, bFore;

   USHORT aChecker[] = { 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55 };

   hdcMask  = CreateCompatibleDC( hdc );
   hdcBmp   = CreateCompatibleDC( hdc );
   GetObject( hbm, sizeof( BITMAP ), ( LPSTR ) &bm );

   hbmp     = CreateCompatibleBitmap( hdc, bm.bmWidth, bm.bmHeight );
   hbMask   = CreateBitmap( bm.bmWidth, bm.bmHeight, 1, 1, NULL );

   hbmpChecker = CreateBitmap( 8, 8, 1, 1, aChecker );
   hbr         = CreatePatternBrush( hbmpChecker );

   GetObject( hbmp, sizeof( BITMAP ), ( LPSTR ) &bm );

   hbOld  = ( HBITMAP ) SelectObject( hdcBmp, hbmp );
   hbOld1 = ( HBITMAP ) SelectObject( hdcMask, hbm );
   BitBlt( hdcBmp, 0, 0, bm.bmWidth, bm.bmHeight, hdcMask, 0, 0, SRCCOPY );
   SelectObject( hdcMask, hbMask );
   SetBkColor( hdcBmp, GetPixel( hdcBmp, 0, 0 ) );
   BitBlt( hdcMask, 0, 0, bm.bmWidth, bm.bmHeight, hdcBmp, 0, 0, SRCCOPY );
   BitBlt( hdcBmp, 0, 0, bm.bmWidth, bm.bmHeight, hdcMask, 0, 0, 0x220326 );

   bBack    = SetBkColor( hdc, GetSysColor( COLOR_BTNHIGHLIGHT ) );
   bFore    = SetTextColor( hdc, GetSysColor( COLOR_BTNFACE ) );
   hbrOld   = (HBRUSH) SelectObject( hdc, hbr );

   BitBlt( hdc, x, y, bm.bmWidth, bm.bmHeight, NULL, 0, 0, PATCOPY );

   SetBkColor( hdc, RGB( 255, 255, 255 ) );
   SetTextColor( hdc, 0 );

   BitBlt( hdc, x, y, bm.bmWidth, bm.bmHeight, hdcMask, 0, 0, SRCAND );
   BitBlt( hdc, x, y, bm.bmWidth, bm.bmHeight, hdcBmp, 0, 0, SRCPAINT );

   SetBkColor( hdc, bBack );
   SetTextColor( hdc, bFore );

   SelectObject( hdcBmp, hbOld );
   SelectObject( hdcMask, hbOld1 );
   SelectObject( hdc, hbrOld );

   DeleteObject( hbmpChecker );
   DeleteObject( hbMask );
   DeleteObject( hbmp );
   DeleteObject( hbr );

   DeleteDC( hdcMask );
   DeleteDC( hdcBmp );
}


//--------------------------------------------------------------------------------------------------------------------//

BOOL AlphaPaint( HDC dcDest, int x, int y, int cx, int cy, HDC dcSrc, int sx, int sy, int scx, int scy, int alpha )
{
    BITMAPINFOHEADER BMI ;
    BYTE * pSrcBits ;
    HBITMAP hbmSrc ;
    BYTE * pDestBits ;
    HBITMAP hbmDest ;
    HDC dc ;
    HBITMAP dcOld ;
    int j, i ;

    BMI.biSize = sizeof( BITMAPINFOHEADER ) ;
    BMI.biWidth = cx ;
    BMI.biHeight = cy ;
    BMI.biPlanes = 1 ;
    BMI.biBitCount = 32 ;
    BMI.biCompression = BI_RGB ;
    BMI.biSizeImage = 0 ;
    BMI.biXPelsPerMeter = 0 ;
    BMI.biYPelsPerMeter = 0 ;
    BMI.biClrUsed = 0 ;
    BMI.biClrImportant = 0 ;

    hbmSrc  = CreateDIBSection ( dcSrc,  ( BITMAPINFO * ) &BMI, DIB_RGB_COLORS, ( void ** ) &pSrcBits, 0, 0l ) ;
    hbmDest = CreateDIBSection ( dcDest, ( BITMAPINFO * ) &BMI, DIB_RGB_COLORS, ( void ** ) &pDestBits, 0, 0l ) ;
    dc      = CreateCompatibleDC(NULL);
    dcOld   = ( HBITMAP ) SelectObject( dc, hbmSrc ) ;

    if ( ! StretchBlt( dc, 0, 0, cx, cy, dcSrc, sx, sy, scx, scy, SRCCOPY ) )
    {
        return FALSE;
    }

    SelectObject( dc, hbmDest );

    if(  !StretchBlt( dc, 0, 0, cx, cy, dcDest, x, y, cx, cy, SRCCOPY ) )
    {
      return FALSE;
    }

    SelectObject( dc, dcOld ) ;
    DeleteDC( dc ) ;

    for( j = 0; j < cy; ++j )
    {
       LPBYTE pbDestRGB = ( LPBYTE )&( ( DWORD* )pDestBits )[ j * cx ] ;
       LPBYTE pbSrcRGB =  ( LPBYTE )&( ( DWORD* )pSrcBits )[ j * cx ] ;

       unsigned char a1, a2 ;

       for( i = 0; i < cx; ++i )
       {
          a1 = pbSrcRGB[ 3 ] ;

          if( a1 != 0 )
          {
             a1 = alpha * ( ( a1 * 100 ) / 255 ) / 100 ;
             a2 = 255 - a1 ;

             pbSrcRGB[ 0 ] = ( ( pbDestRGB[ 0 ] * a2 ) + ( pbSrcRGB[ 0 ] * a1 ) ) >> 8 ;
             pbSrcRGB[ 1 ] = ( ( pbDestRGB[ 1 ] * a2 ) + ( pbSrcRGB[ 1 ] * a1 ) ) >> 8 ;
             pbSrcRGB[ 2 ] = ( ( pbDestRGB[ 2 ] * a2 ) + ( pbSrcRGB[ 2 ] * a1 ) ) >> 8 ;
          }
          else
          {
             pbSrcRGB[ 0 ] = pbDestRGB[ 0 ] ;
             pbSrcRGB[ 1 ] = pbDestRGB[ 1 ] ;
             pbSrcRGB[ 2 ] = pbDestRGB[ 2 ] ;
          }
          pbSrcRGB  += 4 ;
          pbDestRGB += 4 ;
       }
    }

    dc    = CreateCompatibleDC( NULL ) ;
    dcOld = (HBITMAP) SelectObject( dc, hbmSrc ) ;

    if ( ! BitBlt( dcDest, x, y, cx, cy, dc, 0, 0, SRCCOPY ) )
    {
        return FALSE ;
    }

    SelectObject( dc, dcOld ) ;

    DeleteDC( dc ) ;
    DeleteObject( hbmSrc ) ;
    DeleteObject( hbmDest ) ;

    return TRUE ;
}

//--------------------------------------------------------------------------------------------------------------------//

HB_FUNC( ISALPHABITMAP )
{
   HDC hdcBmp, hDC ;
   BOOL bIsAlpha ;
   BITMAP bm ;
   HBITMAP hbmOld ;
   HWND hWnd = GetActiveWindow() ;

   hDC    = GetDC( hWnd ) ;
   hdcBmp = CreateCompatibleDC( hDC ) ;
   hbmOld = SelectObject( hdcBmp, ( HBITMAP ) hb_parnl( 1 ) ) ;

   GetObject( ( HBITMAP ) hb_parnl( 1 ), sizeof( BITMAP ), ( LPSTR ) &bm ) ;

   bIsAlpha =  DetectAlpha( hdcBmp, 0, 0, bm.bmWidth, bm.bmHeight ) ;

   ReleaseDC( hWnd, hDC ) ;

   SelectObject( hdcBmp, hbmOld ) ;

   DeleteObject( hdcBmp ) ;
   DeleteObject( hbmOld ) ;

   hb_retl( bIsAlpha ) ;
}

//--------------------------------------------------------------------------------------------------------------------//

BOOL DetectAlpha( HDC dcSrc, int sx, int sy, int scx, int scy )
{
   BITMAPINFOHEADER BMI ;
   BYTE * pSrcBits ;
   HBITMAP hbmSrc ;
   HDC dc ;
   HBITMAP dcOld ;
   int j, i ;
   BOOL bIsAlpha ;
   LPBYTE pbSrcRGB ;

   BMI.biSize = sizeof( BITMAPINFOHEADER ) ;
   BMI.biWidth = scx ;
   BMI.biHeight = scy ;
   BMI.biPlanes = 1 ;
   BMI.biBitCount = 32 ;
   BMI.biCompression = BI_RGB ;
   BMI.biSizeImage = 0;
   BMI.biXPelsPerMeter = 0 ;
   BMI.biYPelsPerMeter = 0 ;
   BMI.biClrUsed = 0 ;
   BMI.biClrImportant = 0 ;

   hbmSrc   = CreateDIBSection ( dcSrc,  ( BITMAPINFO * )  &BMI, DIB_RGB_COLORS, ( void ** ) &pSrcBits, 0, 0l ) ;
   dc       = CreateCompatibleDC( NULL ) ;
   dcOld    = ( HBITMAP ) SelectObject( dc, hbmSrc ) ;
   bIsAlpha = StretchBlt( dc, 0, 0, scx, scy, dcSrc, sx, sy, scx, scy, SRCCOPY ) ;

   if( bIsAlpha )
   {
      bIsAlpha = FALSE ;
      for( j = 0; j < scy && ! bIsAlpha; ++j )
      {
         pbSrcRGB  = ( LPBYTE ) &( ( DWORD* ) pSrcBits )[ j * scx ] ;
         for( i = 0; i < scx && ! bIsAlpha; ++i )
         {
            bIsAlpha = pbSrcRGB[ 3 ] != 0 ;
            pbSrcRGB += 4 ;
         }
      }
   }

   SelectObject( dc, dcOld ) ;

   DeleteDC( dc ) ;
   DeleteObject( hbmSrc ) ;
   DeleteObject( dcOld ) ;

   return bIsAlpha ;
}
