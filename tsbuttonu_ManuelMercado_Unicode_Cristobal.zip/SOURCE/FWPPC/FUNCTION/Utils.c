01.HDIB BitmapToDIB(HBITMAP hBitmap, HPALETTE hPal)
02.{
03.    BITMAP              bm;         // bitmap structure
04.    BITMAPINFOHEADER    bi;         // bitmap header
05.    LPBITMAPINFOHEADER  lpbi;       // pointer to BITMAPINFOHEADER
06.    DWORD               dwLen;      // size of memory block
07.    HANDLE              hDIB, h;    // handle to DIB, temp handle
08.    HDC                 hDC;        // handle to DC
09.    WORD                biBits;     // bits per pixel
10.
11.    // check if bitmap handle is valid
12.
13.    if (!hBitmap)
14.        return NULL;
15.
16.    // fill in BITMAP structure, return NULL if it didn't work
17.
18.    if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
19.        return NULL;
20.
21.    // if no palette is specified, use default palette
22.
23.    if (hPal == NULL)
24.        hPal = (HPALETTE)GetStockObject(DEFAULT_PALETTE);
25.
26.    // calculate bits per pixel
27.
28.    biBits = bm.bmPlanes * bm.bmBitsPixel;
29.
30.    // make sure bits per pixel is valid
31.
32.    if (biBits <= 1)
33.        biBits = 1;
34.    else if (biBits <= 4)
35.        biBits = 4;
36.    else if (biBits <= 8)
37.        biBits = 8;
38.    else // if greater than 8-bit, force to 24-bit
39.        biBits = 24;
40.
41.    // initialize BITMAPINFOHEADER
42.
43.    bi.biSize = sizeof(BITMAPINFOHEADER);
44.    bi.biWidth = bm.bmWidth;
45.    bi.biHeight = bm.bmHeight;
46.    bi.biPlanes = 1;
47.    bi.biBitCount = biBits;
48.    bi.biCompression = BI_RGB;
49.    bi.biSizeImage = 0;
50.    bi.biXPelsPerMeter = 0;
51.    bi.biYPelsPerMeter = 0;
52.    bi.biClrUsed = 0;
53.    bi.biClrImportant = 0;
54.
55.    // calculate size of memory block required to store BITMAPINFO
56.
57.    dwLen = bi.biSize + PaletteSize((LPSTR)&bi);
58.
59.    // get a DC
60.
61.    hDC = GetDC(NULL);
62.
63.    // select and realize our palette
64.
65.    hPal = SelectPalette(hDC, hPal, FALSE);
66.    RealizePalette(hDC);
67.
68.    // alloc memory block to store our bitmap
69.
70.    hDIB = GlobalAlloc(GHND, dwLen);
71.
72.    // if we couldn't get memory block
73.
74.    if (!hDIB)
75.    {
76.      // clean up and return NULL
77.
78.      SelectPalette(hDC, hPal, TRUE);
79.      RealizePalette(hDC);
80.      ReleaseDC(NULL, hDC);
81.      return NULL;
82.    }
83.
84.    // lock memory and get pointer to it
85.
86.    lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDIB);
87.
88.    /// use our bitmap info. to fill BITMAPINFOHEADER
89.
90.    *lpbi = bi;
91.
92.    // call GetDIBits with a NULL lpBits param, so it will calculate the
93.    // biSizeImage field for us
94.
95.    GetDIBits(hDC, hBitmap, 0, (UINT)bi.biHeight, NULL, (LPBITMAPINFO)lpbi,
96.        DIB_RGB_COLORS);
97.
98.    // get the info. returned by GetDIBits and unlock memory block
99.
100.    bi = *lpbi;
101.    GlobalUnlock(hDIB);
102.
103.    // if the driver did not fill in the biSizeImage field, make one up
104.    if (bi.biSizeImage == 0)
105.        bi.biSizeImage = WIDTHBYTES((DWORD)bm.bmWidth * biBits) * bm.bmHeight;
106.
107.    // realloc the buffer big enough to hold all the bits
108.
109.    dwLen = bi.biSize + PaletteSize((LPSTR)&bi) + bi.biSizeImage;
110.
111.    if (h = GlobalReAlloc(hDIB, dwLen, 0))
112.        hDIB = h;
113.    else
114.    {
115.        // clean up and return NULL
116.
117.        GlobalFree(hDIB);
118.        hDIB = NULL;
119.        SelectPalette(hDC, hPal, TRUE);
120.        RealizePalette(hDC);
121.        ReleaseDC(NULL, hDC);
122.        return NULL;
123.    }
124.
125.    // lock memory block and get pointer to it */
126.
127.    lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDIB);
128.
129.    // call GetDIBits with a NON-NULL lpBits param, and actualy get the
130.    // bits this time
131.
132.    if (GetDIBits(hDC, hBitmap, 0, (UINT)bi.biHeight, (LPSTR)lpbi +
133.            (WORD)lpbi->biSize + PaletteSize((LPSTR)lpbi), (LPBITMAPINFO)lpbi,
134.            DIB_RGB_COLORS) == 0)
135.    {
136.        // clean up and return NULL
137.
138.        GlobalUnlock(hDIB);
139.        hDIB = NULL;
140.        SelectPalette(hDC, hPal, TRUE);
141.        RealizePalette(hDC);
142.        ReleaseDC(NULL, hDC);
143.        return NULL;
144.    }
145.
146.    bi = *lpbi;
147.
148.    // clean up
149.    GlobalUnlock(hDIB);
150.    SelectPalette(hDC, hPal, TRUE);
151.    RealizePalette(hDC);
152.    ReleaseDC(NULL, hDC);
153.    // return handle to the DIB
154.    return hDIB;
155.}
