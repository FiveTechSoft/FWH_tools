//-----------------------------------------------------------------------------
// Archivo: hbpgpp.cpp
// Clase: THbPgpp
// Autor: Manu Exposito 2023
//-----------------------------------------------------------------------------


#include "hbpgpp.h"
#include "hbinit.h"

//-----------------------------------------------------------------------------
// Declaracion de funciones privadas de los metodos de Harbour

HB_FUNC_STATIC( THBPGPP_NEW );
HB_FUNC_STATIC( THBPGPP_OPEN );
HB_FUNC_STATIC( THBPGPP_EXEC );
HB_FUNC_STATIC( THBPGPP_QUERY );
HB_FUNC_STATIC( THBPGPP_GETLASTERROR );
HB_FUNC_STATIC( THBPGPP_GETERRCODE );
HB_FUNC_STATIC( THBPGPP_ISFAILURE );
HB_FUNC_STATIC( THBPGPP_END );
HB_FUNC_STATIC( THBPGPP_GETDBNAME );
HB_FUNC_STATIC( THBPGPP_GETUSER );
HB_FUNC_STATIC( THBPGPP_GETPASSWORD );
HB_FUNC_STATIC( THBPGPP_GETHOST );
HB_FUNC_STATIC( THBPGPP_GETPORT );
HB_FUNC_STATIC( THBPGPP_GETTTY );
HB_FUNC_STATIC( THBPGPP_GETOPTIONS );

// Lista de Metodos xBase
void THbPgpp::addMethods( HB_USHORT usClassH ) const
{
	hb_clsAdd( usClassH, "NEW", HB_FUNCNAME( THBPGPP_NEW ) );
	hb_clsAdd( usClassH, "OPEN", HB_FUNCNAME( THBPGPP_OPEN ) );
	hb_clsAdd( usClassH, "EXEC", HB_FUNCNAME( THBPGPP_EXEC ) );
	hb_clsAdd( usClassH, "QUERY", HB_FUNCNAME( THBPGPP_QUERY ) );
	hb_clsAdd( usClassH, "GETLASTERROR", HB_FUNCNAME( THBPGPP_GETLASTERROR ) );
	hb_clsAdd( usClassH, "GETERRCODE", HB_FUNCNAME( THBPGPP_GETERRCODE ) );
	hb_clsAdd( usClassH, "ISFAILURE", HB_FUNCNAME( THBPGPP_ISFAILURE ) );
	hb_clsAdd( usClassH, "END", HB_FUNCNAME( THBPGPP_END ) );
	hb_clsAdd( usClassH, "GETDBNAME", HB_FUNCNAME( THBPGPP_GETDBNAME ) );
	hb_clsAdd( usClassH, "GETUSER", HB_FUNCNAME( THBPGPP_GETUSER ) );
	hb_clsAdd( usClassH, "GETPASSWORD", HB_FUNCNAME( THBPGPP_GETPASSWORD ) );
	hb_clsAdd( usClassH, "GETHOST", HB_FUNCNAME( THBPGPP_GETHOST ) );
	hb_clsAdd( usClassH, "GETPORT", HB_FUNCNAME( THBPGPP_GETPORT ) );
	hb_clsAdd( usClassH, "GETTTY", HB_FUNCNAME( THBPGPP_GETTTY ) );
	hb_clsAdd( usClassH, "GETOPTIONS", HB_FUNCNAME( THBPGPP_GETOPTIONS ) );

}

//---------------------------------------------------------------------
// Constructores C++

THbPgpp::THbPgpp( void )
{
	conn = nullptr;
	szConnInfo = nullptr;
}

THbPgpp::~THbPgpp( void )
{
	close();
	conn = nullptr;

	if( szConnInfo )
	{
		hb_xfree( szConnInfo );
		szConnInfo = nullptr;
	}
}

// Constructor. Inicializa las variables de instancia
void THbPgpp::init( void ) {}

void THbPgpp::init( PHB_ITEM ccInfo )
{
	szConnInfo = hb_itemGetC( ccInfo );
}

// Abre la db y si no existe la crea por defecto
bool THbPgpp::open( void )
{
	bool bRet;

	conn = PQconnectdb( szConnInfo );
	bRet = ( PQstatus( conn ) == CONNECTION_OK );

	if( !bRet )
	{
		PQfinish( conn );
	}

	return bRet;
}

// Cierra la base de datos
void THbPgpp::close( void ) const
{
	PQfinish( conn );
}

// Ejecuta una sentencia que no devuelve un conjunto de resultados
bool THbPgpp::exec( const char *szStmt )
{
	bool bRet = false;

	if( szStmt )
	{
		PGresult *res = PQexec( conn, szStmt );

		bRet = ( PQresultStatus( res ) == PGRES_COMMAND_OK );
		PQclear( res );
	}

	return bRet;
}

// Ejecuta una sentencia que devuelve un conjunto de resultados
PHB_ITEM THbPgpp::query( const char *szQuery, PHB_ITEM aColName )
{
	PHB_ITEM aRet = nullptr;

	if( szQuery )
	{
		PGresult *res = PQexec( conn, szQuery );
		int uiRows = PQntuples( res );

		if( uiRows > 0 )
		{
			int n, i = 0, x = 0;
			int uiCol = PQnfields( res );
			PHB_ITEM aRec = hb_itemNew( nullptr );

			if( aColName )
			{
				hb_arraySize( aColName, uiCol );

				//---------------------------------------
				// Nombres de campo

				for( n = 0; n < uiCol; n++ )
				{
					hb_arraySetC( aColName, n + 1, PQfname( res, n ) );
				}
			}

			//---------------------------------------
			// Datos
			aRet = hb_itemArrayNew( uiRows );

			while( i < uiRows )
			{
				hb_arrayNew( aRec, uiCol );

				for( n = 0; n < uiCol; n++ )
				{
					hb_arraySetC( aRec, n + 1, PQgetvalue( res, i, n ) );
				}

				hb_arraySet( aRet, ++x, aRec );
				i++;
			}

			hb_itemRelease( aRec );
		}
		else
		{
			aRet = hb_itemArrayNew( 0 );
			hb_arrayNew( aColName, 0 );
		}

		PQclear( res );
	}

	return aRet;
}

const char *THbPgpp::getLastError( void )
{
	return PQerrorMessage( conn );
}

int THbPgpp::getErrCode( void )
{
	return PQstatus( conn );
}

//=============================================================================
// Funcion de clase para usar desde Harbour
//=============================================================================

HB_FUNC( THBPGPP )
{
	static HB_USHORT usClassH = 0;
	THbPgpp *pObjC = new THbPgpp;

	if( usClassH == 0 )
	{
		usClassH = pObjC->createClass( _NUN_VARS, "THBPGPP" );
	}

	hb_clsAssociate( usClassH );
	hb_arraySetPtr( hb_stackReturnItem(), _OBJC_POS, pObjC );
}

//=============================================================================
// Metodos de la clase THbPgpp (harbour)
//=============================================================================

HB_FUNC_STATIC( THBPGPP_NEW )
{
	PHB_ITEM pSelf = hb_stackSelfItem();
	THbPgpp *pObjC = _GETOBJC1( pSelf );
	PHB_ITEM cDbName = hb_param( 1, HB_IT_STRING );

	pObjC->init( cDbName );

	hb_itemReturn( pSelf );
}

HB_FUNC_STATIC( THBPGPP_OPEN )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retl( pObjC->open() );
}

HB_FUNC_STATIC( THBPGPP_EXEC )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retl( pObjC->exec( hb_parc( 1 ) ) );
}

HB_FUNC_STATIC( THBPGPP_QUERY )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_itemReturnRelease( pObjC->query( hb_parc( 1 ), hb_param( 2, HB_IT_ARRAY ) ) );
}

HB_FUNC_STATIC( THBPGPP_GETLASTERROR )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_itemReturnRelease( hb_itemPutC( nullptr, pObjC->getLastError() ) );
}

HB_FUNC_STATIC( THBPGPP_GETERRCODE )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_itemReturnRelease( hb_itemPutNI( nullptr, pObjC->getErrCode() ) );
}

HB_FUNC_STATIC( THBPGPP_ISFAILURE )
{
	THbPgpp *pObjC = _GETOBJC0();
	int iErr = pObjC->getErrCode();
	HB_BOOL bErr = ( iErr != 0 );

	if( bErr )
	{
		PHB_ITEM nCodErr = hb_param( 1, HB_IT_BYREF );
		PHB_ITEM cErrMsg = hb_param( 2, HB_IT_BYREF );

		if( nCodErr )
		{
			hb_storni( iErr, 1 );
		}

		if( cErrMsg )
		{
			hb_storc( pObjC->getLastError(), 2 );
		}
	}

	hb_itemReturnRelease( hb_itemPutL( nullptr, bErr ) );
}

HB_FUNC_STATIC( THBPGPP_END )
{
	PHB_ITEM pSelf = hb_stackSelfItem();
	THbPgpp *pObjC = _GETOBJC1( pSelf );

	delete pObjC;
	hb_arraySetPtr( pSelf, _OBJC_POS, nullptr );
}

HB_FUNC_STATIC( THBPGPP_GETDBNAME )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retc( pObjC->getDbName() );
}
HB_FUNC_STATIC( THBPGPP_GETUSER )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retc( pObjC->getUser() );
}

HB_FUNC_STATIC( THBPGPP_GETPASSWORD )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retc( pObjC->getPassword() );
}

HB_FUNC_STATIC( THBPGPP_GETHOST )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retc( pObjC->getHost() );
}

HB_FUNC_STATIC( THBPGPP_GETPORT )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retc( pObjC->getPort() );
}

HB_FUNC_STATIC( THBPGPP_GETTTY )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retc( pObjC->getTty() );
}

HB_FUNC_STATIC( THBPGPP_GETOPTIONS )
{
	THbPgpp *pObjC = _GETOBJC0();

	hb_retc( pObjC->getOptions() );
}


//=============================================================================
// Inicializa los simbolos de las clase en la tabla de simbolos de harbour.
//=============================================================================

HB_INIT_SYMBOLS_BEGIN( THBPGPP__InitSymbols )
{
	"THBPGPP", { HB_FS_PUBLIC | HB_FS_LOCAL }, { HB_FUNCNAME( THBPGPP ) }, nullptr
}
HB_INIT_SYMBOLS_END( THBPGPP__InitSymbols )

#if defined( HB_PRAGMA_STARTUP )
	#pragma startup THBPGPP__InitSymbols
#elif defined( HB_DATASEG_STARTUP )
	#define HB_DATASEG_BODY HB_DATASEG_FUNC( THBPGPP__InitSymbols )
	#include "hbiniseg.h"
#endif

//-----------------------------------------------------------------------------
