#-------------------------------------------------------------------------------
#  AUTOR.....: Manuel Expósito Suárez   Soft4U 2002-2020
#  CLASE.....: lib
#  FECHA MOD.: 20/02/2020
#  VERSION...: 1.00
#  PROPOSITO.: Script de borrado
#-------------------------------------------------------------------------------

echo Borrando ejecutables...
cd $HOME/desarrollo/proyectos/hbsqlitepp/test
if [ -x $demo ]
then

    rm demo
fi
if [ -f *.log ]
then

    rm *.log
fi
if [ -d .hbmk ]
then

    rm -r .hbmk
fi
echo Proceso terminado....
