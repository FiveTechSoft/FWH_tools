#------------------------------------------------------------------------------
# Proyecto: Generacion de ejecutables
# Fichero: ejforall.ch
# Descripción: Include para todos los ejemplos
# Autor: Manu Exposito 2014-21
# Fecha: 11/11/2020
#------------------------------------------------------------------------------
#!/bin/bash

cd test
hbmk2 -comp=clang $1 genexe.hbp
if [ $? -eq 0 ]
then
    ./demo
else
    echo -------------------------------------------------------------------------
    echo Se ha producido un error...
    echo -------------------------------------------------------------------------
fi
