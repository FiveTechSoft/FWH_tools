#-------------------------------------------------------------------------------
#  AUTOR.....: Manuel Expósito Suárez   Soft4U 2002-2020
#  CLASE.....: lib
#  FECHA MOD.: 20/02/2020
#  VERSION...: 1.00
#  PROPOSITO.: Script de construccion de las LIB para Linux
#  Notas.....: Compila con gcc y clang
#-------------------------------------------------------------------------------

echo Construyendo todas las libs y todos los compiladores
echo Para gcc
cd ./cmd/linux
hbmk2 -comp=gcc ../../hbp/buildall.hbp > gcc.log
echo ...............................................................................
echo Para clang
hbmk2 -comp=clang ../../hbp/buildall.hbp > clang.log
echo ...............................................................................
